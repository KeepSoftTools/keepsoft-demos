/*!
 * QuoteFlow front end. Vanilla JS, no dependencies.
 * The pricing maths below mirrors includes/class-quoteflow-calc.php.
 */
( function () {
	'use strict';

	var cfgGlobal = window.qfFront || { endpoint: '', i18n: {} };
	var t = cfgGlobal.i18n;

	function round2( n ) {
		return Math.round( ( n + Number.EPSILON ) * 100 ) / 100;
	}

	function isNum( v ) {
		return v !== '' && v !== null && v !== undefined && isFinite( Number( v ) );
	}

	function money( n, c ) {
		var dec = parseInt( c.decimals, 10 );
		if ( isNaN( dec ) ) {
			dec = 2;
		}
		var parts = Math.abs( n ).toFixed( dec ).split( '.' );
		parts[ 0 ] = parts[ 0 ].replace( /\B(?=(\d{3})+(?!\d))/g, ',' );
		var neg = n < 0 ? '-' : '';
		var num = parts.join( '.' );
		return c.currency_pos === 'after' ? neg + num + c.currency : neg + c.currency + num;
	}

	/* Pure calculation. answers: { fieldId: value | [values] } */
	function calculate( c, answers ) {
		var adds = 0;
		var mults = [];
		c.fields.forEach( function ( f ) {
			var raw = answers[ f.id ];
			var price = Number( f.price ) || 0;
			var v, i;
			if ( f.type === 'number' || f.type === 'slider' ) {
				if ( ! isNum( raw ) ) {
					raw = f.default;
				}
				v = Math.max( Number( f.min ), Math.min( Number( f.max ), Number( raw ) ) );
				if ( f.mode === 'multiply' ) {
					mults.push( v );
				} else {
					adds += v * price;
				}
			} else if ( f.type === 'select' || f.type === 'radio' ) {
				i = isNum( raw ) ? parseInt( raw, 10 ) : -1;
				if ( f.options[ i ] ) {
					applyOption( f, f.options[ i ] );
				}
			} else if ( f.type === 'checkbox' ) {
				( Array.isArray( raw ) ? raw : [] ).forEach( function ( r ) {
					if ( isNum( r ) && f.options[ parseInt( r, 10 ) ] ) {
						applyOption( f, f.options[ parseInt( r, 10 ) ] );
					}
				} );
			} else if ( f.type === 'text' ) {
				if ( typeof raw === 'string' && raw.trim() !== '' && price ) {
					if ( f.mode === 'multiply' && price > 0 ) {
						mults.push( price );
					} else {
						adds += price;
					}
				}
			}
		} );

		function applyOption( f, o ) {
			var p = Number( o.price ) || 0;
			if ( f.mode === 'multiply' ) {
				mults.push( p > 0 ? p : 1 );
			} else {
				adds += p;
			}
		}

		var sub = Number( c.base_price ) + adds;
		mults.forEach( function ( m ) {
			sub *= m;
		} );
		sub = Math.max( 0, sub );
		if ( sub < Number( c.min_charge ) ) {
			sub = Number( c.min_charge );
		}
		sub = round2( sub );
		var tax = round2( sub * ( Number( c.tax ) / 100 ) );
		return { subtotal: sub, tax: tax, total: round2( sub + tax ) };
	}

	function el( tag, cls, text ) {
		var n = document.createElement( tag );
		if ( cls ) {
			n.className = cls;
		}
		if ( text !== undefined ) {
			n.textContent = text;
		}
		return n;
	}

	function init( form ) {
		var wrap = form.closest( '.qf-wrap' );
		var resultBox = wrap.querySelector( '.qf-result' );
		var c;
		try {
			c = JSON.parse( form.getAttribute( 'data-qf-config' ) );
		} catch ( e ) {
			return;
		}
		var totalBox = form.querySelector( '.qf-total' );
		var totalEl = form.querySelector( '[data-qf-total]' );
		var metaEl = form.querySelector( '[data-qf-meta]' );
		var errBox = form.querySelector( '.qf-error' );
		var gated = totalBox.getAttribute( 'data-qf-gated' ) === '1';
		var fieldMap = {};
		c.fields.forEach( function ( f ) {
			fieldMap[ f.id ] = f;
		} );

		function readAnswers() {
			var answers = {};
			form.querySelectorAll( '[data-qf-field]' ).forEach( function ( box ) {
				var id = box.getAttribute( 'data-qf-field' );
				var f = fieldMap[ id ];
				if ( ! f ) {
					return;
				}
				if ( f.type === 'radio' ) {
					var r = box.querySelector( 'input:checked' );
					if ( r ) {
						answers[ id ] = r.value;
					}
				} else if ( f.type === 'checkbox' ) {
					var vals = [];
					box.querySelectorAll( 'input:checked' ).forEach( function ( i ) {
						vals.push( i.value );
					} );
					answers[ id ] = vals;
				} else {
					var inp = box.querySelector( '[data-qf-input]' );
					if ( inp && inp.value !== '' ) {
						answers[ id ] = inp.value;
					}
				}
			} );
			return answers;
		}

		function contactValue( key ) {
			var i = form.querySelector( '[name="' + key + '"]' );
			return i ? i.value.trim() : '';
		}

		function validEmail( v ) {
			return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test( v );
		}

		function contactOk() {
			var ok = true;
			form.querySelectorAll( '[data-qf-contact]' ).forEach( function ( box ) {
				var key = box.getAttribute( 'data-qf-contact' );
				var v = contactValue( key );
				if ( box.getAttribute( 'data-qf-required' ) === '1' && v === '' ) {
					ok = false;
				}
				if ( key === 'email' && v !== '' && ! validEmail( v ) ) {
					ok = false;
				}
			} );
			return ok;
		}

		function update() {
			form.querySelectorAll( '[data-qf-out]' ).forEach( function ( o ) {
				var inp = o.parentNode.querySelector( 'input' );
				o.textContent = inp ? inp.value : '';
			} );
			if ( gated && ! contactOk() ) {
				totalEl.textContent = t.gated;
				totalBox.classList.add( 'qf-total--gated' );
				metaEl.textContent = '';
				return;
			}
			totalBox.classList.remove( 'qf-total--gated' );
			var r = calculate( c, readAnswers() );
			totalEl.textContent = money( r.total, c );
			if ( Number( c.tax ) > 0 ) {
				metaEl.textContent = t.subtotal + ' ' + money( r.subtotal, c ) + ' + ' + c.tax_label + ' ' + money( r.tax, c );
			} else {
				metaEl.textContent = '';
			}
		}

		function setErr( box, msg ) {
			var e = box.querySelector( '.qf-field-error' );
			box.classList.toggle( 'qf-invalid', !! msg );
			if ( e ) {
				e.textContent = msg || '';
				e.hidden = ! msg;
			}
		}

		function validate() {
			var ok = true;
			var first = null;
			form.querySelectorAll( '[data-qf-field]' ).forEach( function ( box ) {
				var f = fieldMap[ box.getAttribute( 'data-qf-field' ) ];
				var msg = '';
				if ( f && Number( f.required ) === 1 ) {
					var a = readAnswers()[ f.id ];
					if ( a === undefined || a === '' || ( Array.isArray( a ) && ! a.length ) ) {
						msg = t.reqField;
					}
				}
				setErr( box, msg );
				if ( msg ) {
					ok = false;
					first = first || box;
				}
			} );
			form.querySelectorAll( '[data-qf-contact]' ).forEach( function ( box ) {
				var key = box.getAttribute( 'data-qf-contact' );
				var v = contactValue( key );
				var msg = '';
				if ( box.getAttribute( 'data-qf-required' ) === '1' && v === '' ) {
					msg = t.reqField;
				} else if ( key === 'email' && v !== '' && ! validEmail( v ) ) {
					msg = t.reqEmail;
				}
				setErr( box, msg );
				if ( msg ) {
					ok = false;
					first = first || box;
				}
			} );
			if ( first ) {
				var focusable = first.querySelector( 'input,select' );
				if ( focusable ) {
					focusable.focus();
				}
			}
			return ok;
		}

		function showError( msg ) {
			errBox.textContent = msg || '';
			errBox.hidden = ! msg;
		}

		function showResult( res ) {
			resultBox.textContent = '';
			resultBox.appendChild( el( 'h3', 'qf-result-title', t.yourQuote ) );
			String( res.message || '' ).split( /\n{2,}/ ).forEach( function ( p ) {
				if ( p.trim() ) {
					resultBox.appendChild( el( 'p', 'qf-result-msg', p.trim() ) );
				}
			} );
			var tbl = el( 'dl', 'qf-lines' );
			( res.lines || [] ).forEach( function ( l ) {
				tbl.appendChild( el( 'dt', '', l.label ) );
				tbl.appendChild( el( 'dd', '', l.amount ) );
			} );
			if ( res.tax ) {
				tbl.appendChild( el( 'dt', '', res.tax_label ) );
				tbl.appendChild( el( 'dd', '', res.tax ) );
			}
			resultBox.appendChild( tbl );
			var tot = el( 'div', 'qf-total qf-total--result' );
			tot.appendChild( el( 'span', 'qf-total-label', t.total ) );
			tot.appendChild( el( 'strong', 'qf-total-value', res.total ) );
			resultBox.appendChild( tot );
			if ( res.summary ) {
				var s = el( 'div', 'qf-ai-summary' );
				s.appendChild( el( 'strong', 'qf-ai-title', t.summary ) );
				s.appendChild( el( 'p', '', res.summary ) );
				resultBox.appendChild( s );
			}
			var again = el( 'button', 'qf-submit qf-submit--ghost', t.newQuote );
			again.type = 'button';
			again.addEventListener( 'click', function () {
				resultBox.hidden = true;
				form.hidden = false;
				form.reset();
				update();
				form.scrollIntoView( { behavior: 'smooth', block: 'start' } );
			} );
			resultBox.appendChild( again );
			form.hidden = true;
			resultBox.hidden = false;
			resultBox.focus();
		}

		form.addEventListener( 'input', update );
		form.addEventListener( 'change', update );

		form.addEventListener( 'submit', function ( ev ) {
			ev.preventDefault();
			showError( '' );
			if ( ! validate() ) {
				showError( t.fixErrors );
				return;
			}
			var btn = form.querySelector( '.qf-submit' );
			var label = btn.textContent;
			btn.disabled = true;
			btn.textContent = t.sending;

			var payload = {
				form_id: c.form_id,
				answers: readAnswers(),
				name: contactValue( 'name' ),
				email: contactValue( 'email' ),
				phone: contactValue( 'phone' ),
				website: ( form.querySelector( '[name="website"]' ) || {} ).value || '',
			};

			fetch( cfgGlobal.endpoint, {
				method: 'POST',
				headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
				body: JSON.stringify( payload ),
				credentials: 'same-origin',
			} )
				.then( function ( r ) {
					return r.json().then( function ( j ) {
						return { ok: r.ok, body: j };
					} );
				} )
				.then( function ( r ) {
					if ( r.ok && r.body && r.body.success ) {
						showResult( r.body );
					} else {
						showError( r.body && r.body.message ? r.body.message : t.error );
					}
				} )
				.catch( function () {
					showError( t.error );
				} )
				.then( function () {
					btn.disabled = false;
					btn.textContent = label;
				} );
		} );

		update();
	}

	function boot() {
		document.querySelectorAll( 'form.qf-form[data-qf-config]' ).forEach( init );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', boot );
	} else {
		boot();
	}

	window.QuoteFlowCalc = { calculate: calculate }; // Exposed for testing.
} )();
