/* QuoteFlow Gutenberg block (no build step required). */
( function ( wp ) {
	'use strict';
	var el = wp.element.createElement;
	var __ = wp.i18n.__;
	var data = window.qfBlock || { forms: [] };

	wp.blocks.registerBlockType( 'quoteflow/quote-form', {
		edit: function ( props ) {
			var blockProps = wp.blockEditor.useBlockProps( { className: 'qf-block-placeholder' } );
			var options = [ { value: 0, label: __( '— Select a quote form —', 'quoteflow' ) } ].concat( data.forms );
			var current = null;
			data.forms.forEach( function ( f ) {
				if ( f.value === props.attributes.formId ) {
					current = f;
				}
			} );

			return el(
				'div',
				blockProps,
				el(
					wp.components.Placeholder,
					{ icon: 'calculator', label: __( 'QuoteFlow quote calculator', 'quoteflow' ) },
					data.forms.length
						? el( wp.components.SelectControl, {
								label: __( 'Quote form', 'quoteflow' ),
								value: props.attributes.formId,
								options: options,
								onChange: function ( v ) {
									props.setAttributes( { formId: parseInt( v, 10 ) || 0 } );
								},
						  } )
						: el( 'p', null, __( 'No published quote forms yet. Create one under QuoteFlow in the admin menu.', 'quoteflow' ) ),
					current
						? el( 'p', null, __( 'The live calculator is shown on the front end:', 'quoteflow' ) + ' ' + current.label )
						: null
				)
			);
		},
		save: function () {
			return null; // Rendered on the server.
		},
	} );
} )( window.wp );
