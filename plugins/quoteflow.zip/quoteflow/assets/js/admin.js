/* QuoteFlow form builder (vanilla JS). Serialises to #qf-fields-json. */
( function () {
	'use strict';
	var data = window.qfAdmin;
	var root = document.getElementById( 'qf-builder' );
	var store = document.getElementById( 'qf-fields-json' );
	if ( ! data || ! root || ! store ) {
		return;
	}
	var i18n = data.i18n;
	var fields = [];
	try {
		fields = JSON.parse( store.value ) || [];
	} catch ( e ) {
		fields = [];
	}

	function uid() {
		return 'f' + Math.random().toString( 36 ).slice( 2, 8 );
	}

	function save() {
		store.value = JSON.stringify( fields );
	}

	function h( tag, attrs, children ) {
		var n = document.createElement( tag );
		Object.keys( attrs || {} ).forEach( function ( k ) {
			if ( attrs[ k ] === null ) {
				return;
			}
			if ( k === 'text' ) {
				n.textContent = attrs[ k ];
			} else if ( k.indexOf( 'on' ) === 0 ) {
				n.addEventListener( k.slice( 2 ), attrs[ k ] );
			} else if ( k === 'value' ) {
				n.value = attrs[ k ];
			} else if ( k === 'checked' ) {
				n.checked = !! attrs[ k ];
			} else {
				n.setAttribute( k, attrs[ k ] );
			}
		} );
		( children || [] ).forEach( function ( c ) {
			if ( c ) {
				n.appendChild( c );
			}
		} );
		return n;
	}

	function labelled( text, input, cls ) {
		return h( 'div', cls ? { class: cls } : {}, [ h( 'label', { text: text } ), input ] );
	}

	function textInput( f, key, type ) {
		return h( 'input', {
			type: type || 'text',
			step: type === 'number' ? 'any' : null,
			value: f[ key ] === undefined ? '' : f[ key ],
			oninput: function ( e ) {
				f[ key ] = e.target.value;
				save();
			},
		} );
	}

	function render() {
		root.textContent = '';
		if ( ! fields.length ) {
			root.appendChild( h( 'div', { class: 'qf-empty', text: i18n.noFields } ) );
		}
		fields.forEach( function ( f, idx ) {
			root.appendChild( card( f, idx ) );
		} );

		var typeSel = h( 'select', { id: 'qf-new-type' } );
		Object.keys( data.types ).forEach( function ( k ) {
			typeSel.appendChild( h( 'option', { value: k, text: data.types[ k ] } ) );
		} );
		root.appendChild(
			h( 'p', {}, [
				typeSel,
				document.createTextNode( ' ' ),
				h( 'button', {
					type: 'button',
					class: 'button button-primary',
					text: i18n.addField,
					onclick: function () {
						fields.push( {
							id: uid(),
							type: typeSel.value,
							label: i18n.newField,
							help: '',
							required: 0,
							mode: 'add',
							price: 0,
							unit: '',
							min: 0,
							max: 100,
							step: 1,
							default: 0,
							options: [],
						} );
						save();
						render();
					},
				} ),
			] )
		);
		save();
	}

	function card( f, idx ) {
		var isOpt = [ 'select', 'radio', 'checkbox' ].indexOf( f.type ) > -1;
		var isNum = f.type === 'number' || f.type === 'slider';

		var typeSel = h( 'select', {
			onchange: function ( e ) {
				f.type = e.target.value;
				if ( [ 'select', 'radio', 'checkbox' ].indexOf( f.type ) > -1 && ! ( f.options && f.options.length ) ) {
					f.options = [ { label: '', price: 0 } ];
				}
				save();
				render();
			},
		} );
		Object.keys( data.types ).forEach( function ( k ) {
			var o = h( 'option', { value: k, text: data.types[ k ] } );
			if ( k === f.type ) {
				o.selected = true;
			}
			typeSel.appendChild( o );
		} );

		var head = h( 'div', { class: 'qf-card-head' }, [
			h( 'strong', { text: '#' + ( idx + 1 ) } ),
			typeSel,
			h( 'input', {
				type: 'text',
				class: 'qf-grow',
				value: f.label,
				placeholder: i18n.label,
				'aria-label': i18n.label,
				oninput: function ( e ) {
					f.label = e.target.value;
					save();
				},
			} ),
			h( 'label', {}, [
				h( 'input', {
					type: 'checkbox',
					checked: !! Number( f.required ),
					onchange: function ( e ) {
						f.required = e.target.checked ? 1 : 0;
						save();
					},
				} ),
				document.createTextNode( ' ' + i18n.required ),
			] ),
			h( 'button', { type: 'button', class: 'button', text: '↑', title: i18n.up, 'aria-label': i18n.up, onclick: function () { move( idx, -1 ); } } ),
			h( 'button', { type: 'button', class: 'button', text: '↓', title: i18n.down, 'aria-label': i18n.down, onclick: function () { move( idx, 1 ); } } ),
			h( 'button', {
				type: 'button',
				class: 'button-link-delete button',
				text: i18n.remove,
				onclick: function () {
					if ( window.confirm( i18n.confirmDel ) ) {
						fields.splice( idx, 1 );
						render();
					}
				},
			} ),
		] );

		var body = h( 'div', { class: 'qf-card-body' } );

		if ( isNum || isOpt || f.type === 'text' ) {
			var modeSel = h( 'select', {
				onchange: function ( e ) {
					f.mode = e.target.value;
					save();
					render();
				},
			}, [
				h( 'option', { value: 'add', text: i18n.modeAdd } ),
				h( 'option', { value: 'multiply', text: i18n.modeMult } ),
			] );
			modeSel.value = f.mode === 'multiply' ? 'multiply' : 'add';
			body.appendChild( labelled( i18n.pricing, modeSel ) );
		}

		if ( ( isNum && f.mode !== 'multiply' ) || f.type === 'text' ) {
			body.appendChild( labelled( f.type === 'text' ? i18n.priceText : i18n.pricePer, textInput( f, 'price', 'number' ) ) );
		}
		if ( isNum && f.mode === 'multiply' ) {
			body.appendChild( h( 'p', { class: 'description qf-wide', text: i18n.multNote } ) );
		}
		if ( isNum ) {
			body.appendChild( labelled( i18n.min, textInput( f, 'min', 'number' ) ) );
			body.appendChild( labelled( i18n.max, textInput( f, 'max', 'number' ) ) );
			body.appendChild( labelled( i18n.step, textInput( f, 'step', 'number' ) ) );
			body.appendChild( labelled( i18n.def, textInput( f, 'default', 'number' ) ) );
			body.appendChild( labelled( i18n.unit, textInput( f, 'unit' ) ) );
		}
		body.appendChild( labelled( i18n.help, textInput( f, 'help' ), 'qf-wide' ) );

		if ( isOpt ) {
			f.options = f.options || [];
			var box = h( 'div', { class: 'qf-options' }, [ h( 'label', { text: i18n.options } ) ] );
			if ( f.mode === 'multiply' ) {
				box.appendChild( h( 'p', { class: 'description', text: i18n.multOptNote } ) );
			}
			f.options.forEach( function ( o, oi ) {
				box.appendChild(
					h( 'div', { class: 'qf-opt-row' }, [
						h( 'input', {
							type: 'text',
							class: 'qf-opt-label',
							value: o.label,
							placeholder: i18n.optLabel,
							'aria-label': i18n.optLabel,
							oninput: function ( e ) {
								o.label = e.target.value;
								save();
							},
						} ),
						h( 'input', {
							type: 'number',
							step: 'any',
							class: 'qf-opt-price',
							value: o.price,
							placeholder: i18n.optPrice,
							'aria-label': i18n.optPrice,
							oninput: function ( e ) {
								o.price = e.target.value;
								save();
							},
						} ),
						h( 'button', {
							type: 'button',
							class: 'button',
							text: '×',
							title: i18n.remove,
							'aria-label': i18n.remove,
							onclick: function () {
								f.options.splice( oi, 1 );
								render();
							},
						} ),
					] )
				);
			} );
			box.appendChild(
				h( 'button', {
					type: 'button',
					class: 'button',
					text: i18n.addOption,
					onclick: function () {
						f.options.push( { label: '', price: 0 } );
						render();
					},
				} )
			);
			body.appendChild( box );
		}

		return h( 'div', { class: 'qf-card' }, [ head, body ] );
	}

	function move( idx, dir ) {
		var to = idx + dir;
		if ( to < 0 || to >= fields.length ) {
			return;
		}
		var tmp = fields[ idx ];
		fields[ idx ] = fields[ to ];
		fields[ to ] = tmp;
		render();
	}

	render();
} )();
