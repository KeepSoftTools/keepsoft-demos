<?php
/**
 * Plugin Name:       QuoteFlow – Instant Quote Calculator & Lead Capture
 * Plugin URI:        https://keepsofttools.github.io/keepsoft-demos/
 * Description:       Build instant online quote calculators, show live prices, capture leads, export to CSV and optionally write AI quote summaries.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Keepsoft
 * Author URI:        https://keepsofttools.github.io/keepsoft-demos/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       quoteflow
 * Domain Path:       /languages
 *
 * @package QuoteFlow
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'QF_VERSION', '1.0.0' );
define( 'QF_FILE', __FILE__ );
define( 'QF_PATH', plugin_dir_path( __FILE__ ) );
define( 'QF_URL', plugin_dir_url( __FILE__ ) );
define( 'QF_DB_VERSION', '1.0' );

require_once QF_PATH . 'includes/class-quoteflow-form.php';
require_once QF_PATH . 'includes/class-quoteflow-calc.php';
require_once QF_PATH . 'includes/class-quoteflow-install.php';
require_once QF_PATH . 'includes/class-quoteflow-cpt.php';
require_once QF_PATH . 'includes/class-quoteflow-settings.php';
require_once QF_PATH . 'includes/class-quoteflow-examples.php';
require_once QF_PATH . 'includes/class-quoteflow-leads.php';
require_once QF_PATH . 'includes/class-quoteflow-ai.php';
require_once QF_PATH . 'includes/class-quoteflow-rest.php';
require_once QF_PATH . 'includes/class-quoteflow-frontend.php';

register_activation_hook( __FILE__, array( 'QuoteFlow_Install', 'activate' ) );

/**
 * Boot the plugin.
 *
 * @return void
 */
function qf_init() {
	QuoteFlow_Install::maybe_upgrade();
	QuoteFlow_CPT::init();
	QuoteFlow_Settings::init();
	QuoteFlow_Examples::init();
	QuoteFlow_Leads::init();
	QuoteFlow_REST::init();
	QuoteFlow_Frontend::init();
}
add_action( 'plugins_loaded', 'qf_init' );

/**
 * Add a Settings link on the plugins screen.
 *
 * @param array $links Existing links.
 * @return array
 */
function qf_action_links( $links ) {
	$url = admin_url( 'edit.php?post_type=' . QuoteFlow_CPT::POST_TYPE . '&page=qf-settings' );
	array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'quoteflow' ) . '</a>' );
	return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'qf_action_links' );
