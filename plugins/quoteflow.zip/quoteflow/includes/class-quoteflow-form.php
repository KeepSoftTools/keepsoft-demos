<?php
/**
 * Form configuration: defaults, loading and sanitising.
 *
 * @package QuoteFlow
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Form config helper.
 */
class QuoteFlow_Form {

	const META_KEY = '_qf_config';

	/**
	 * Allowed field types.
	 *
	 * @return array
	 */
	public static function field_types() {
		return array(
			'number'   => __( 'Number', 'quoteflow' ),
			'select'   => __( 'Dropdown', 'quoteflow' ),
			'radio'    => __( 'Radio buttons', 'quoteflow' ),
			'checkbox' => __( 'Checkboxes', 'quoteflow' ),
			'slider'   => __( 'Slider', 'quoteflow' ),
			'text'     => __( 'Text', 'quoteflow' ),
		);
	}

	/**
	 * Default configuration.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'base_price'      => 0,
			'currency'        => '$',
			'currency_pos'    => 'before',
			'decimals'        => 2,
			'tax'             => 0,
			'tax_label'       => __( 'GST/VAT', 'quoteflow' ),
			'min_charge'      => 0,
			'intro'           => '',
			'submit_label'    => __( 'Get my quote', 'quoteflow' ),
			'thank_you'       => __( 'Thank you! We have received your request and will be in touch shortly.', 'quoteflow' ),
			'require_name'    => 0,
			'require_email'   => 1,
			'require_phone'   => 0,
			'gate_total'      => 0,
			'webhook_url'     => '',
			'notify_email'    => '',
			'customer_email'  => 1,
			'fields'          => array(),
		);
	}

	/**
	 * Load a form config (merged with defaults).
	 *
	 * @param int $form_id Post ID.
	 * @return array
	 */
	public static function get( $form_id ) {
		$stored = get_post_meta( $form_id, self::META_KEY, true );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		$config           = array_merge( self::defaults(), $stored );
		$config['fields'] = isset( $stored['fields'] ) && is_array( $stored['fields'] ) ? $stored['fields'] : array();
		return $config;
	}

	/**
	 * Sanitise a raw config array coming from the admin screen.
	 *
	 * @param array  $raw         Raw general settings (already unslashed).
	 * @param string $fields_json JSON string describing the fields.
	 * @return array
	 */
	public static function sanitize( $raw, $fields_json ) {
		$d = self::defaults();

		$out                   = array();
		$out['base_price']     = self::num( isset( $raw['base_price'] ) ? $raw['base_price'] : 0 );
		$out['currency']       = isset( $raw['currency'] ) ? sanitize_text_field( $raw['currency'] ) : $d['currency'];
		$out['currency']       = mb_substr( $out['currency'], 0, 8 );
		$out['currency_pos']   = isset( $raw['currency_pos'] ) && 'after' === $raw['currency_pos'] ? 'after' : 'before';
		$out['decimals']       = isset( $raw['decimals'] ) ? max( 0, min( 2, (int) $raw['decimals'] ) ) : 2;
		$out['tax']            = max( 0, min( 100, self::num( isset( $raw['tax'] ) ? $raw['tax'] : 0 ) ) );
		$out['tax_label']      = isset( $raw['tax_label'] ) ? sanitize_text_field( $raw['tax_label'] ) : $d['tax_label'];
		$out['min_charge']     = max( 0, self::num( isset( $raw['min_charge'] ) ? $raw['min_charge'] : 0 ) );
		$out['intro']          = isset( $raw['intro'] ) ? sanitize_textarea_field( $raw['intro'] ) : '';
		$out['submit_label']   = isset( $raw['submit_label'] ) && '' !== trim( $raw['submit_label'] ) ? sanitize_text_field( $raw['submit_label'] ) : $d['submit_label'];
		$out['thank_you']      = isset( $raw['thank_you'] ) ? sanitize_textarea_field( $raw['thank_you'] ) : $d['thank_you'];
		$out['require_name']   = empty( $raw['require_name'] ) ? 0 : 1;
		$out['require_email']  = empty( $raw['require_email'] ) ? 0 : 1;
		$out['require_phone']  = empty( $raw['require_phone'] ) ? 0 : 1;
		$out['gate_total']     = empty( $raw['gate_total'] ) ? 0 : 1;
		$out['customer_email'] = empty( $raw['customer_email'] ) ? 0 : 1;
		$out['webhook_url']    = isset( $raw['webhook_url'] ) ? esc_url_raw( trim( $raw['webhook_url'] ), array( 'http', 'https' ) ) : '';
		$out['notify_email']   = isset( $raw['notify_email'] ) ? self::sanitize_email_list( $raw['notify_email'] ) : '';
		$out['fields']         = self::sanitize_fields( $fields_json );

		return $out;
	}

	/**
	 * Sanitise a comma separated list of emails.
	 *
	 * @param string $list Raw list.
	 * @return string
	 */
	public static function sanitize_email_list( $list ) {
		$emails = array();
		foreach ( explode( ',', (string) $list ) as $email ) {
			$email = sanitize_email( trim( $email ) );
			if ( $email && is_email( $email ) ) {
				$emails[] = $email;
			}
		}
		return implode( ',', array_slice( $emails, 0, 5 ) );
	}

	/**
	 * Sanitise the JSON fields definition.
	 *
	 * @param string $json JSON.
	 * @return array
	 */
	public static function sanitize_fields( $json ) {
		$data = json_decode( (string) $json, true );
		if ( ! is_array( $data ) ) {
			return array();
		}

		$types  = array_keys( self::field_types() );
		$fields = array();
		$ids    = array();

		foreach ( array_slice( $data, 0, 50 ) as $f ) {
			if ( ! is_array( $f ) ) {
				continue;
			}
			$type = isset( $f['type'] ) ? sanitize_key( $f['type'] ) : '';
			if ( ! in_array( $type, $types, true ) ) {
				continue;
			}

			$id = isset( $f['id'] ) ? sanitize_key( $f['id'] ) : '';
			if ( '' === $id || in_array( $id, $ids, true ) ) {
				$id = 'f' . strtolower( wp_generate_password( 6, false, false ) );
			}
			$ids[] = $id;

			$field = array(
				'id'       => $id,
				'type'     => $type,
				'label'    => isset( $f['label'] ) ? sanitize_text_field( $f['label'] ) : '',
				'help'     => isset( $f['help'] ) ? sanitize_text_field( $f['help'] ) : '',
				'required' => empty( $f['required'] ) ? 0 : 1,
				'mode'     => isset( $f['mode'] ) && 'multiply' === $f['mode'] ? 'multiply' : 'add',
				'price'    => self::num( isset( $f['price'] ) ? $f['price'] : 0 ),
				'unit'     => isset( $f['unit'] ) ? sanitize_text_field( $f['unit'] ) : '',
				'min'      => self::num( isset( $f['min'] ) ? $f['min'] : 0 ),
				'max'      => self::num( isset( $f['max'] ) ? $f['max'] : 100 ),
				'step'     => max( 0.001, self::num( isset( $f['step'] ) ? $f['step'] : 1 ) ),
				'default'  => self::num( isset( $f['default'] ) ? $f['default'] : 0 ),
				'options'  => array(),
			);
			if ( $field['max'] < $field['min'] ) {
				$field['max'] = $field['min'];
			}

			if ( in_array( $type, array( 'select', 'radio', 'checkbox' ), true ) && ! empty( $f['options'] ) && is_array( $f['options'] ) ) {
				foreach ( array_slice( $f['options'], 0, 50 ) as $o ) {
					if ( ! is_array( $o ) ) {
						continue;
					}
					$label = isset( $o['label'] ) ? sanitize_text_field( $o['label'] ) : '';
					if ( '' === $label ) {
						continue;
					}
					$field['options'][] = array(
						'label' => $label,
						'price' => self::num( isset( $o['price'] ) ? $o['price'] : 0 ),
					);
				}
			}
			$fields[] = $field;
		}
		return $fields;
	}

	/**
	 * Settings visible to the browser (never includes webhook/email).
	 *
	 * @param int $form_id Post ID.
	 * @return array
	 */
	public static function public_config( $form_id ) {
		$c = self::get( $form_id );
		unset( $c['webhook_url'], $c['notify_email'] );
		$c['form_id'] = (int) $form_id;
		return $c;
	}

	/**
	 * Parse a numeric string into float.
	 *
	 * @param mixed $v Value.
	 * @return float
	 */
	public static function num( $v ) {
		if ( is_string( $v ) ) {
			$v = str_replace( ',', '.', trim( $v ) );
		}
		return is_numeric( $v ) ? (float) $v : 0.0;
	}

	/**
	 * Format money using a form's currency settings.
	 *
	 * @param float $amount Amount.
	 * @param array $config Form config.
	 * @return string
	 */
	public static function money( $amount, $config ) {
		$dec = isset( $config['decimals'] ) ? (int) $config['decimals'] : 2;
		$neg = (float) $amount < 0 ? '-' : '';
		$num = number_format( abs( (float) $amount ), $dec, '.', ',' );
		$sym = isset( $config['currency'] ) ? $config['currency'] : '';
		return ( isset( $config['currency_pos'] ) && 'after' === $config['currency_pos'] ) ? $neg . $num . $sym : $neg . $sym . $num;
	}
}
