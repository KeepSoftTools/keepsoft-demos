<?php
/**
 * Global settings page (Quote Forms > Settings).
 *
 * @package QuoteFlow
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings.
 */
class QuoteFlow_Settings {

	const OPTION = 'qf_settings';

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
	}

	/**
	 * Defaults.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'ai_api_key'          => '',
			'ai_model'            => 'gpt-4o-mini',
			'ai_base_url'         => 'https://api.openai.com/v1',
			'rate_limit'          => 20,
			'delete_on_uninstall' => 0,
		);
	}

	/**
	 * Get all settings.
	 *
	 * @return array
	 */
	public static function all() {
		$saved = get_option( self::OPTION, array() );
		return array_merge( self::defaults(), is_array( $saved ) ? $saved : array() );
	}

	/**
	 * Get one setting.
	 *
	 * @param string $key Key.
	 * @return mixed
	 */
	public static function get( $key ) {
		$all = self::all();
		return isset( $all[ $key ] ) ? $all[ $key ] : null;
	}

	/**
	 * Admin menu entry.
	 *
	 * @return void
	 */
	public static function menu() {
		add_submenu_page(
			'edit.php?post_type=' . QuoteFlow_CPT::POST_TYPE,
			__( 'QuoteFlow Settings', 'quoteflow' ),
			__( 'Settings', 'quoteflow' ),
			'manage_options',
			'qf-settings',
			array( __CLASS__, 'render' )
		);
	}

	/**
	 * Register setting.
	 *
	 * @return void
	 */
	public static function register() {
		register_setting(
			'qf_settings_group',
			self::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
				'default'           => self::defaults(),
			)
		);
	}

	/**
	 * Sanitise settings input.
	 *
	 * @param mixed $in Raw input.
	 * @return array
	 */
	public static function sanitize( $in ) {
		$old = self::all();
		$in  = is_array( $in ) ? $in : array();
		$out = self::defaults();

		if ( ! empty( $in['ai_remove_key'] ) ) {
			$out['ai_api_key'] = '';
		} elseif ( isset( $in['ai_api_key'] ) && '' !== trim( $in['ai_api_key'] ) ) {
			$out['ai_api_key'] = trim( preg_replace( '/[^\x21-\x7E]/', '', $in['ai_api_key'] ) );
		} else {
			$out['ai_api_key'] = $old['ai_api_key'];
		}

		$model              = isset( $in['ai_model'] ) ? preg_replace( '/[^A-Za-z0-9._:\/-]/', '', $in['ai_model'] ) : '';
		$out['ai_model']    = '' !== $model ? $model : $out['ai_model'];
		$base               = isset( $in['ai_base_url'] ) ? esc_url_raw( trim( $in['ai_base_url'] ), array( 'https', 'http' ) ) : '';
		$out['ai_base_url'] = '' !== $base ? untrailingslashit( $base ) : $out['ai_base_url'];
		$out['rate_limit']  = isset( $in['rate_limit'] ) ? max( 1, min( 1000, (int) $in['rate_limit'] ) ) : 20;
		$out['delete_on_uninstall'] = empty( $in['delete_on_uninstall'] ) ? 0 : 1;
		return $out;
	}

	/**
	 * Render page.
	 *
	 * @return void
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'quoteflow' ) );
		}
		$s = self::all();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'QuoteFlow Settings', 'quoteflow' ); ?></h1>
			<form method="post" action="options.php">
				<?php settings_fields( 'qf_settings_group' ); ?>

				<h2 class="title"><?php esc_html_e( 'AI quote summary (optional)', 'quoteflow' ); ?></h2>
				<p><?php esc_html_e( 'Works with OpenAI and any OpenAI-compatible chat completions API. Leave the key empty to turn the feature off – quotes work exactly the same without it.', 'quoteflow' ); ?></p>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="qf_ai_key"><?php esc_html_e( 'API key', 'quoteflow' ); ?></label></th>
						<td>
							<input type="password" class="regular-text" id="qf_ai_key" name="<?php echo esc_attr( self::OPTION ); ?>[ai_api_key]" value="" autocomplete="new-password" placeholder="<?php echo '' !== $s['ai_api_key'] ? esc_attr__( 'A key is saved – enter a new one to replace it', 'quoteflow' ) : 'sk-…'; ?>" />
							<?php if ( '' !== $s['ai_api_key'] ) : ?>
								<br /><label><input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[ai_remove_key]" value="1" /> <?php esc_html_e( 'Remove saved key', 'quoteflow' ); ?></label>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="qf_ai_model"><?php esc_html_e( 'Model', 'quoteflow' ); ?></label></th>
						<td><input type="text" class="regular-text" id="qf_ai_model" name="<?php echo esc_attr( self::OPTION ); ?>[ai_model]" value="<?php echo esc_attr( $s['ai_model'] ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="qf_ai_base"><?php esc_html_e( 'API base URL', 'quoteflow' ); ?></label></th>
						<td><input type="url" class="regular-text" id="qf_ai_base" name="<?php echo esc_attr( self::OPTION ); ?>[ai_base_url]" value="<?php echo esc_attr( $s['ai_base_url'] ); ?>" />
						<p class="description"><?php esc_html_e( 'The plugin calls {base URL}/chat/completions.', 'quoteflow' ); ?></p></td>
					</tr>
				</table>

				<h2 class="title"><?php esc_html_e( 'General', 'quoteflow' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="qf_rate"><?php esc_html_e( 'Spam limit', 'quoteflow' ); ?></label></th>
						<td><input type="number" min="1" max="1000" class="small-text" id="qf_rate" name="<?php echo esc_attr( self::OPTION ); ?>[rate_limit]" value="<?php echo esc_attr( $s['rate_limit'] ); ?>" />
						<p class="description"><?php esc_html_e( 'Maximum submissions per visitor per hour.', 'quoteflow' ); ?></p></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Uninstall', 'quoteflow' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[delete_on_uninstall]" value="1" <?php checked( $s['delete_on_uninstall'], 1 ); ?> /> <?php esc_html_e( 'Delete all forms, leads and settings when the plugin is deleted', 'quoteflow' ); ?></label></td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}
