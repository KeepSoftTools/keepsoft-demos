<?php
/**
 * "Quote Forms" custom post type and the form builder meta boxes.
 *
 * @package QuoteFlow
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CPT + builder.
 */
class QuoteFlow_CPT {

	const POST_TYPE = 'qf_form';
	const NONCE     = 'qf_save_form';

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_post_type' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_boxes' ) );
		add_action( 'save_post_' . self::POST_TYPE, array( __CLASS__, 'save' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin_assets' ) );
		add_filter( 'manage_' . self::POST_TYPE . '_posts_columns', array( __CLASS__, 'columns' ) );
		add_action( 'manage_' . self::POST_TYPE . '_posts_custom_column', array( __CLASS__, 'column_content' ), 10, 2 );
	}

	/**
	 * Register the post type.
	 *
	 * @return void
	 */
	public static function register_post_type() {
		register_post_type(
			self::POST_TYPE,
			array(
				'labels'              => array(
					'name'               => __( 'Quote Forms', 'quoteflow' ),
					'singular_name'      => __( 'Quote Form', 'quoteflow' ),
					'add_new'            => __( 'Add New', 'quoteflow' ),
					'add_new_item'       => __( 'Add New Quote Form', 'quoteflow' ),
					'edit_item'          => __( 'Edit Quote Form', 'quoteflow' ),
					'new_item'           => __( 'New Quote Form', 'quoteflow' ),
					'view_item'          => __( 'View Quote Form', 'quoteflow' ),
					'search_items'       => __( 'Search Quote Forms', 'quoteflow' ),
					'not_found'          => __( 'No quote forms found.', 'quoteflow' ),
					'not_found_in_trash' => __( 'No quote forms found in Trash.', 'quoteflow' ),
					'all_items'          => __( 'All Quote Forms', 'quoteflow' ),
					'menu_name'          => __( 'QuoteFlow', 'quoteflow' ),
				),
				'public'              => false,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'show_in_rest'        => false,
				'exclude_from_search' => true,
				'publicly_queryable'  => false,
				'has_archive'         => false,
				'rewrite'             => false,
				'menu_icon'           => 'dashicons-calculator',
				'menu_position'       => 58,
				'supports'            => array( 'title' ),
				'capability_type'     => 'post',
			)
		);
	}

	/**
	 * Meta boxes.
	 *
	 * @return void
	 */
	public static function add_meta_boxes() {
		add_meta_box( 'qf_general', __( 'Pricing & Settings', 'quoteflow' ), array( __CLASS__, 'box_general' ), self::POST_TYPE, 'normal', 'high' );
		add_meta_box( 'qf_builder', __( 'Form Fields', 'quoteflow' ), array( __CLASS__, 'box_builder' ), self::POST_TYPE, 'normal', 'default' );
		add_meta_box( 'qf_notify', __( 'Notifications & Contact', 'quoteflow' ), array( __CLASS__, 'box_notify' ), self::POST_TYPE, 'normal', 'default' );
		add_meta_box( 'qf_shortcode', __( 'Use this form', 'quoteflow' ), array( __CLASS__, 'box_shortcode' ), self::POST_TYPE, 'side', 'high' );
	}

	/**
	 * Enqueue admin builder assets.
	 *
	 * @param string $hook Current admin page.
	 * @return void
	 */
	public static function admin_assets( $hook ) {
		$screen = get_current_screen();
		if ( ! $screen || self::POST_TYPE !== $screen->post_type ) {
			return;
		}
		wp_enqueue_style( 'qf-admin', QF_URL . 'assets/css/admin.css', array(), QF_VERSION );

		if ( in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			wp_enqueue_script( 'qf-admin', QF_URL . 'assets/js/admin.js', array(), QF_VERSION, true );
			wp_localize_script(
				'qf-admin',
				'qfAdmin',
				array(
					'types' => QuoteFlow_Form::field_types(),
					'i18n'  => array(
						'addField'    => __( 'Add field', 'quoteflow' ),
						'noFields'    => __( 'No fields yet. Add your first field below.', 'quoteflow' ),
						'fieldType'   => __( 'Type', 'quoteflow' ),
						'label'       => __( 'Label', 'quoteflow' ),
						'help'        => __( 'Help text', 'quoteflow' ),
						'required'    => __( 'Required', 'quoteflow' ),
						'pricing'     => __( 'Pricing mode', 'quoteflow' ),
						'modeAdd'     => __( 'Add to price', 'quoteflow' ),
						'modeMult'    => __( 'Multiply price', 'quoteflow' ),
						'price'       => __( 'Price', 'quoteflow' ),
						'pricePer'    => __( 'Price per unit', 'quoteflow' ),
						'priceText'   => __( 'Price if filled in', 'quoteflow' ),
						'min'         => __( 'Min', 'quoteflow' ),
						'max'         => __( 'Max', 'quoteflow' ),
						'step'        => __( 'Step', 'quoteflow' ),
						'def'         => __( 'Default', 'quoteflow' ),
						'unit'        => __( 'Unit label', 'quoteflow' ),
						'options'     => __( 'Options', 'quoteflow' ),
						'optLabel'    => __( 'Option label', 'quoteflow' ),
						'optPrice'    => __( 'Price / factor', 'quoteflow' ),
						'addOption'   => __( 'Add option', 'quoteflow' ),
						'remove'      => __( 'Remove', 'quoteflow' ),
						'up'          => __( 'Move up', 'quoteflow' ),
						'down'        => __( 'Move down', 'quoteflow' ),
						'confirmDel'  => __( 'Remove this field?', 'quoteflow' ),
						'multNote'    => __( 'Multiply: the running total is multiplied by the number entered.', 'quoteflow' ),
						'multOptNote' => __( 'Multiply: enter a factor such as 1.25 (= +25%). Empty or 0 = no change.', 'quoteflow' ),
						'newField'    => __( 'New field', 'quoteflow' ),
					),
				)
			);
		}
	}

	/**
	 * General settings box.
	 *
	 * @param WP_Post $post Post.
	 * @return void
	 */
	public static function box_general( $post ) {
		wp_nonce_field( self::NONCE, 'qf_nonce' );
		$c = QuoteFlow_Form::get( $post->ID );
		?>
		<table class="form-table qf-form-table" role="presentation">
			<tr>
				<th scope="row"><label for="qf_base_price"><?php esc_html_e( 'Base price', 'quoteflow' ); ?></label></th>
				<td><input type="number" step="any" min="0" class="small-text" id="qf_base_price" name="qf_cfg[base_price]" value="<?php echo esc_attr( $c['base_price'] ); ?>" />
				<p class="description"><?php esc_html_e( 'Starting price before any field is added.', 'quoteflow' ); ?></p></td>
			</tr>
			<tr>
				<th scope="row"><label for="qf_currency"><?php esc_html_e( 'Currency symbol', 'quoteflow' ); ?></label></th>
				<td>
					<input type="text" class="small-text" maxlength="8" id="qf_currency" name="qf_cfg[currency]" value="<?php echo esc_attr( $c['currency'] ); ?>" />
					<select name="qf_cfg[currency_pos]" aria-label="<?php esc_attr_e( 'Currency position', 'quoteflow' ); ?>">
						<option value="before" <?php selected( $c['currency_pos'], 'before' ); ?>><?php esc_html_e( 'Before amount ($10)', 'quoteflow' ); ?></option>
						<option value="after" <?php selected( $c['currency_pos'], 'after' ); ?>><?php esc_html_e( 'After amount (10$)', 'quoteflow' ); ?></option>
					</select>
					<select name="qf_cfg[decimals]" aria-label="<?php esc_attr_e( 'Decimals', 'quoteflow' ); ?>">
						<?php foreach ( array( 0, 1, 2 ) as $d ) : ?>
							<option value="<?php echo esc_attr( $d ); ?>" <?php selected( (int) $c['decimals'], $d ); ?>>
								<?php
								/* translators: %d: number of decimal places */
								echo esc_html( sprintf( _n( '%d decimal', '%d decimals', $d, 'quoteflow' ), $d ) );
								?>
							</option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="qf_tax"><?php esc_html_e( 'Tax %', 'quoteflow' ); ?></label></th>
				<td>
					<input type="number" step="any" min="0" max="100" class="small-text" id="qf_tax" name="qf_cfg[tax]" value="<?php echo esc_attr( $c['tax'] ); ?>" />
					<input type="text" class="regular-text" name="qf_cfg[tax_label]" value="<?php echo esc_attr( $c['tax_label'] ); ?>" aria-label="<?php esc_attr_e( 'Tax label', 'quoteflow' ); ?>" />
					<p class="description"><?php esc_html_e( 'Added on top of the subtotal. Leave 0 for no tax line.', 'quoteflow' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="qf_min_charge"><?php esc_html_e( 'Minimum charge', 'quoteflow' ); ?></label></th>
				<td><input type="number" step="any" min="0" class="small-text" id="qf_min_charge" name="qf_cfg[min_charge]" value="<?php echo esc_attr( $c['min_charge'] ); ?>" />
				<p class="description"><?php esc_html_e( 'The subtotal (before tax) will never be lower than this.', 'quoteflow' ); ?></p></td>
			</tr>
			<tr>
				<th scope="row"><label for="qf_intro"><?php esc_html_e( 'Intro text', 'quoteflow' ); ?></label></th>
				<td><textarea class="large-text" rows="2" id="qf_intro" name="qf_cfg[intro]"><?php echo esc_textarea( $c['intro'] ); ?></textarea></td>
			</tr>
			<tr>
				<th scope="row"><label for="qf_submit_label"><?php esc_html_e( 'Button text', 'quoteflow' ); ?></label></th>
				<td><input type="text" class="regular-text" id="qf_submit_label" name="qf_cfg[submit_label]" value="<?php echo esc_attr( $c['submit_label'] ); ?>" /></td>
			</tr>
			<tr>
				<th scope="row"><label for="qf_thank_you"><?php esc_html_e( 'Thank-you message', 'quoteflow' ); ?></label></th>
				<td><textarea class="large-text" rows="3" id="qf_thank_you" name="qf_cfg[thank_you]"><?php echo esc_textarea( $c['thank_you'] ); ?></textarea></td>
			</tr>
		</table>
		<?php
	}

	/**
	 * Builder box.
	 *
	 * @param WP_Post $post Post.
	 * @return void
	 */
	public static function box_builder( $post ) {
		$c = QuoteFlow_Form::get( $post->ID );
		?>
		<p class="description"><?php esc_html_e( 'Add the questions your visitors will answer. Each field changes the price. Use the arrows to re-order.', 'quoteflow' ); ?></p>
		<div id="qf-builder" class="qf-builder"></div>
		<textarea id="qf-fields-json" name="qf_fields_json" class="qf-hidden" aria-hidden="true" tabindex="-1"><?php echo esc_textarea( wp_json_encode( $c['fields'] ) ); ?></textarea>
		<?php
	}

	/**
	 * Notifications box.
	 *
	 * @param WP_Post $post Post.
	 * @return void
	 */
	public static function box_notify( $post ) {
		$c = QuoteFlow_Form::get( $post->ID );
		?>
		<table class="form-table qf-form-table" role="presentation">
			<tr>
				<th scope="row"><?php esc_html_e( 'Contact details', 'quoteflow' ); ?></th>
				<td>
					<fieldset>
						<label><input type="checkbox" name="qf_cfg[require_name]" value="1" <?php checked( $c['require_name'], 1 ); ?> /> <?php esc_html_e( 'Require name', 'quoteflow' ); ?></label><br />
						<label><input type="checkbox" name="qf_cfg[require_email]" value="1" <?php checked( $c['require_email'], 1 ); ?> /> <?php esc_html_e( 'Require email', 'quoteflow' ); ?></label><br />
						<label><input type="checkbox" name="qf_cfg[require_phone]" value="1" <?php checked( $c['require_phone'], 1 ); ?> /> <?php esc_html_e( 'Require phone', 'quoteflow' ); ?></label><br />
						<label><input type="checkbox" name="qf_cfg[gate_total]" value="1" <?php checked( $c['gate_total'], 1 ); ?> /> <?php esc_html_e( 'Only show the total after the required details above are filled in', 'quoteflow' ); ?></label>
					</fieldset>
					<p class="description"><?php esc_html_e( 'Name, email and phone inputs are always shown; the ticked ones are mandatory.', 'quoteflow' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="qf_notify_email"><?php esc_html_e( 'Notification email(s)', 'quoteflow' ); ?></label></th>
				<td><input type="text" class="large-text" id="qf_notify_email" name="qf_cfg[notify_email]" value="<?php echo esc_attr( $c['notify_email'] ); ?>" placeholder="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>" />
				<p class="description"><?php esc_html_e( 'Comma separated. Leave empty to use the site admin email.', 'quoteflow' ); ?></p></td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Customer copy', 'quoteflow' ); ?></th>
				<td><label><input type="checkbox" name="qf_cfg[customer_email]" value="1" <?php checked( $c['customer_email'], 1 ); ?> /> <?php esc_html_e( 'Email the quote (and AI summary, if enabled) to the customer', 'quoteflow' ); ?></label></td>
			</tr>
			<tr>
				<th scope="row"><label for="qf_webhook"><?php esc_html_e( 'Webhook URL', 'quoteflow' ); ?></label></th>
				<td><input type="url" class="large-text" id="qf_webhook" name="qf_cfg[webhook_url]" value="<?php echo esc_attr( $c['webhook_url'] ); ?>" placeholder="https://" />
				<p class="description"><?php esc_html_e( 'Each submission is POSTed as JSON to this URL (Zapier, Make, n8n, your CRM…).', 'quoteflow' ); ?></p></td>
			</tr>
		</table>
		<?php
	}

	/**
	 * Shortcode box.
	 *
	 * @param WP_Post $post Post.
	 * @return void
	 */
	public static function box_shortcode( $post ) {
		if ( 'auto-draft' === $post->post_status ) {
			echo '<p>' . esc_html__( 'Save the form to get its shortcode.', 'quoteflow' ) . '</p>';
			return;
		}
		$sc = '[quoteflow id="' . (int) $post->ID . '"]';
		echo '<p><input type="text" class="widefat" readonly="readonly" onfocus="this.select();" value="' . esc_attr( $sc ) . '" /></p>';
		echo '<p class="description">' . esc_html__( 'Paste the shortcode into any page, or use the "QuoteFlow" block in the editor.', 'quoteflow' ) . '</p>';
	}

	/**
	 * Save handler.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post.
	 * @return void
	 */
	public static function save( $post_id, $post ) {
		if ( ! isset( $_POST['qf_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['qf_nonce'] ) ), self::NONCE ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised in QuoteFlow_Form::sanitize().
		$raw = isset( $_POST['qf_cfg'] ) && is_array( $_POST['qf_cfg'] ) ? wp_unslash( $_POST['qf_cfg'] ) : array();
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON, validated field by field in sanitize_fields().
		$json = isset( $_POST['qf_fields_json'] ) ? wp_unslash( $_POST['qf_fields_json'] ) : '[]';

		$config = QuoteFlow_Form::sanitize( $raw, $json );
		update_post_meta( $post_id, QuoteFlow_Form::META_KEY, wp_slash( $config ) );
	}

	/**
	 * List table columns.
	 *
	 * @param array $cols Columns.
	 * @return array
	 */
	public static function columns( $cols ) {
		$new = array();
		foreach ( $cols as $k => $v ) {
			$new[ $k ] = $v;
			if ( 'title' === $k ) {
				$new['qf_shortcode'] = __( 'Shortcode', 'quoteflow' );
				$new['qf_fields']    = __( 'Fields', 'quoteflow' );
				$new['qf_leads']     = __( 'Leads', 'quoteflow' );
			}
		}
		return $new;
	}

	/**
	 * Column output.
	 *
	 * @param string $col     Column key.
	 * @param int    $post_id Post ID.
	 * @return void
	 */
	public static function column_content( $col, $post_id ) {
		if ( 'qf_shortcode' === $col ) {
			echo '<code>' . esc_html( '[quoteflow id="' . (int) $post_id . '"]' ) . '</code>';
		} elseif ( 'qf_fields' === $col ) {
			$c = QuoteFlow_Form::get( $post_id );
			echo esc_html( number_format_i18n( count( $c['fields'] ) ) );
		} elseif ( 'qf_leads' === $col ) {
			$n   = QuoteFlow_Leads::count( (int) $post_id );
			$url = add_query_arg(
				array(
					'post_type' => self::POST_TYPE,
					'page'      => 'qf-leads',
					'form_id'   => (int) $post_id,
				),
				admin_url( 'edit.php' )
			);
			echo '<a href="' . esc_url( $url ) . '">' . esc_html( number_format_i18n( $n ) ) . '</a>';
		}
	}
}
