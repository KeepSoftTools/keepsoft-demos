<?php
/**
 * Optional AI quote summary via an OpenAI-compatible chat completions API.
 *
 * @package QuoteFlow
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * AI summary.
 */
class QuoteFlow_AI {

	/**
	 * Is the feature configured?
	 *
	 * @return bool
	 */
	public static function is_enabled() {
		return '' !== (string) QuoteFlow_Settings::get( 'ai_api_key' );
	}

	/**
	 * Request a short plain-English summary.
	 *
	 * Returns an empty string on any failure so callers can degrade gracefully.
	 *
	 * @param string $form_title Form title.
	 * @param array  $config     Form config.
	 * @param array  $calc       Result of QuoteFlow_Calc::calculate().
	 * @param string $name       Customer name (may be empty).
	 * @return string
	 */
	public static function summarize( $form_title, $config, $calc, $name = '' ) {
		if ( ! self::is_enabled() ) {
			return '';
		}

		$settings = QuoteFlow_Settings::all();
		$url      = trailingslashit( $settings['ai_base_url'] ) . 'chat/completions';

		$facts = array(
			'service'  => $form_title,
			'customer' => $name,
			'choices'  => $calc['answers'],
			'lines'    => $calc['lines'],
			'subtotal' => QuoteFlow_Form::money( $calc['subtotal'], $config ),
			'tax'      => $config['tax'] > 0 ? QuoteFlow_Form::money( $calc['tax'], $config ) . ' (' . $config['tax_label'] . ' ' . $config['tax'] . '%)' : 'none',
			'total'    => QuoteFlow_Form::money( $calc['total'], $config ),
		);

		$body = array(
			'model'       => $settings['ai_model'],
			'temperature' => 0.4,
			'max_tokens'  => 300,
			'messages'    => array(
				array(
					'role'    => 'system',
					'content' => 'You write short, friendly quote summaries for a service business. Use plain English, no markdown, no bullet symbols, at most 90 words. Only use the facts given; never invent prices, dates or promises. Mention the total exactly as given and say the price is an estimate.',
				),
				array(
					'role'    => 'user',
					'content' => 'Write the summary for this quote: ' . wp_json_encode( $facts ),
				),
			),
		);

		$args = apply_filters(
			'qf_ai_request_args',
			array(
				'timeout' => 20,
				'headers' => array(
					'Authorization' => 'Bearer ' . $settings['ai_api_key'],
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( $body ),
			),
			$body
		);

		$response = wp_remote_post( esc_url_raw( $url ), $args );
		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return '';
		}
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( empty( $data['choices'][0]['message']['content'] ) || ! is_string( $data['choices'][0]['message']['content'] ) ) {
			return '';
		}
		return mb_substr( sanitize_textarea_field( $data['choices'][0]['message']['content'] ), 0, 1200 );
	}
}
