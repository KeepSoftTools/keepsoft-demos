<?php
/**
 * REST API: public quote submission endpoint.
 *
 * @package QuoteFlow
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * REST controller.
 */
class QuoteFlow_REST {

	const NS = 'quoteflow/v1';

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	/**
	 * Register routes.
	 *
	 * @return void
	 */
	public static function routes() {
		register_rest_route(
			self::NS,
			'/submit',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				// Public endpoint by design (visitors are not logged in and pages may be cached,
				// so a nonce would expire). Protected by honeypot, rate limit and server-side validation.
				'permission_callback' => '__return_true',
				'callback'            => array( __CLASS__, 'submit' ),
				'args'                => array(
					'form_id' => array(
						'required'          => true,
						'sanitize_callback' => 'absint',
					),
					'answers' => array(
						'required' => false,
						'type'     => 'object',
					),
					'name'    => array( 'sanitize_callback' => 'sanitize_text_field' ),
					'email'   => array( 'sanitize_callback' => 'sanitize_email' ),
					'phone'   => array( 'sanitize_callback' => 'sanitize_text_field' ),
					'website' => array( 'sanitize_callback' => 'sanitize_text_field' ),
				),
			)
		);
	}

	/**
	 * Rate limit by hashed IP (nothing identifiable is stored).
	 *
	 * @return bool True when allowed.
	 */
	private static function rate_ok() {
		$ip    = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$key   = 'qf_rl_' . md5( $ip . wp_salt() );
		$count = (int) get_transient( $key );
		$max   = (int) QuoteFlow_Settings::get( 'rate_limit' );
		if ( $count >= $max ) {
			return false;
		}
		set_transient( $key, $count + 1, HOUR_IN_SECONDS );
		return true;
	}

	/**
	 * Handle a submission.
	 *
	 * @param WP_REST_Request $req Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function submit( $req ) {
		// Honeypot: bots fill the hidden field. Pretend success.
		if ( '' !== (string) $req->get_param( 'website' ) ) {
			return rest_ensure_response( array( 'success' => true, 'message' => '', 'total' => '', 'lines' => array(), 'summary' => '' ) );
		}
		if ( ! self::rate_ok() ) {
			return new WP_Error( 'qf_rate', __( 'Too many requests. Please try again later.', 'quoteflow' ), array( 'status' => 429 ) );
		}

		$form_id = absint( $req->get_param( 'form_id' ) );
		$form    = $form_id ? get_post( $form_id ) : null;
		if ( ! $form || QuoteFlow_CPT::POST_TYPE !== $form->post_type || 'publish' !== $form->post_status ) {
			return new WP_Error( 'qf_form', __( 'This quote form is not available.', 'quoteflow' ), array( 'status' => 404 ) );
		}
		$config = QuoteFlow_Form::get( $form_id );

		$name  = mb_substr( sanitize_text_field( (string) $req->get_param( 'name' ) ), 0, 190 );
		$email = sanitize_email( (string) $req->get_param( 'email' ) );
		$phone = mb_substr( sanitize_text_field( (string) $req->get_param( 'phone' ) ), 0, 60 );

		if ( ! empty( $config['require_name'] ) && '' === $name ) {
			return new WP_Error( 'qf_name', __( 'Please enter your name.', 'quoteflow' ), array( 'status' => 400 ) );
		}
		if ( ( ! empty( $config['require_email'] ) && '' === $email ) || ( '' !== $email && ! is_email( $email ) ) ) {
			return new WP_Error( 'qf_email', __( 'Please enter a valid email address.', 'quoteflow' ), array( 'status' => 400 ) );
		}
		if ( ! empty( $config['require_phone'] ) && '' === $phone ) {
			return new WP_Error( 'qf_phone', __( 'Please enter your phone number.', 'quoteflow' ), array( 'status' => 400 ) );
		}

		$answers = $req->get_param( 'answers' );
		$calc    = QuoteFlow_Calc::calculate( $config, is_array( $answers ) ? $answers : array() );
		if ( is_wp_error( $calc ) ) {
			$calc->add_data( array( 'status' => 400 ) );
			return $calc;
		}

		$summary = QuoteFlow_AI::summarize( $form->post_title, $config, $calc, $name );

		$lead_id = QuoteFlow_Leads::insert(
			array(
				'form_id'    => $form_id,
				'form_title' => $form->post_title,
				'name'       => $name,
				'email'      => $email,
				'phone'      => $phone,
				'answers'    => $calc['answers'],
				'subtotal'   => $calc['subtotal'],
				'tax'        => $calc['tax'],
				'total'      => $calc['total'],
				'currency'   => $config['currency'],
				'summary'    => $summary,
			)
		);
		if ( ! $lead_id ) {
			return new WP_Error( 'qf_db', __( 'Sorry, we could not save your request. Please try again.', 'quoteflow' ), array( 'status' => 500 ) );
		}

		$lead = array(
			'id'    => $lead_id,
			'name'  => $name,
			'email' => $email,
			'phone' => $phone,
		);
		self::send_emails( $form, $config, $calc, $lead, $summary );
		self::send_webhook( $form, $config, $calc, $lead, $summary );

		/**
		 * Fires after a quote lead has been saved.
		 *
		 * @param int   $lead_id Lead ID.
		 * @param int   $form_id Form ID.
		 * @param array $calc    Calculation result.
		 */
		do_action( 'qf_lead_created', $lead_id, $form_id, $calc );

		$lines = array();
		foreach ( $calc['lines'] as $l ) {
			$lines[] = array(
				'label'  => $l['label'],
				'amount' => QuoteFlow_Form::money( $l['amount'], $config ),
			);
		}

		return rest_ensure_response(
			array(
				'success'  => true,
				'message'  => $config['thank_you'],
				'summary'  => $summary,
				'total'    => QuoteFlow_Form::money( $calc['total'], $config ),
				'subtotal' => QuoteFlow_Form::money( $calc['subtotal'], $config ),
				'tax'      => $config['tax'] > 0 ? QuoteFlow_Form::money( $calc['tax'], $config ) : '',
				'tax_label'=> $config['tax_label'],
				'lines'    => $lines,
			)
		);
	}

	/**
	 * Plain-text quote body.
	 *
	 * @param array  $config  Config.
	 * @param array  $calc    Calc.
	 * @param string $summary AI summary.
	 * @return string
	 */
	private static function quote_text( $config, $calc, $summary ) {
		$t = '';
		foreach ( $calc['answers'] as $a ) {
			$t .= $a['label'] . ': ' . $a['value'] . "\n";
		}
		$t .= "\n";
		$t .= __( 'Subtotal', 'quoteflow' ) . ': ' . QuoteFlow_Form::money( $calc['subtotal'], $config ) . "\n";
		if ( $config['tax'] > 0 ) {
			$t .= $config['tax_label'] . ' (' . $config['tax'] . '%): ' . QuoteFlow_Form::money( $calc['tax'], $config ) . "\n";
		}
		$t .= __( 'Total', 'quoteflow' ) . ': ' . QuoteFlow_Form::money( $calc['total'], $config ) . "\n";
		if ( '' !== $summary ) {
			$t .= "\n" . $summary . "\n";
		}
		return $t;
	}

	/**
	 * Send admin + customer emails.
	 *
	 * @param WP_Post $form    Form.
	 * @param array   $config  Config.
	 * @param array   $calc    Calc.
	 * @param array   $lead    Lead contact info.
	 * @param string  $summary AI summary.
	 * @return void
	 */
	private static function send_emails( $form, $config, $calc, $lead, $summary ) {
		$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$to   = '' !== $config['notify_email'] ? $config['notify_email'] : get_option( 'admin_email' );

		$headers = array();
		if ( '' !== $lead['email'] ) {
			$reply_name = trim( str_replace( array( '<', '>', '"', ',', "\r", "\n" ), '', $lead['name'] ) );
			$headers[]  = 'Reply-To: ' . ( '' !== $reply_name ? $reply_name . ' ' : '' ) . '<' . $lead['email'] . '>';
		}

		/* translators: 1: form title, 2: total amount */
		$subject = sprintf( __( 'New quote lead: %1$s (%2$s)', 'quoteflow' ), $form->post_title, QuoteFlow_Form::money( $calc['total'], $config ) );
		$body    = __( 'Contact', 'quoteflow' ) . ":\n" . $lead['name'] . "\n" . $lead['email'] . "\n" . $lead['phone'] . "\n\n" . self::quote_text( $config, $calc, $summary );
		$body   .= "\n" . admin_url( 'edit.php?post_type=' . QuoteFlow_CPT::POST_TYPE . '&page=qf-leads' ) . "\n";
		wp_mail( $to, wp_strip_all_tags( $subject ), $body, $headers );

		if ( ! empty( $config['customer_email'] ) && '' !== $lead['email'] ) {
			/* translators: 1: site name, 2: form title */
			$subject = sprintf( __( 'Your quote from %1$s: %2$s', 'quoteflow' ), $site, $form->post_title );
			$body    = ( '' !== $lead['name'] ? sprintf( /* translators: %s: customer name */ __( 'Hi %s,', 'quoteflow' ), $lead['name'] ) : __( 'Hello,', 'quoteflow' ) ) . "\n\n";
			$body   .= $config['thank_you'] . "\n\n" . self::quote_text( $config, $calc, $summary );
			wp_mail( $lead['email'], wp_strip_all_tags( $subject ), $body );
		}
	}

	/**
	 * POST the lead to the configured webhook.
	 *
	 * @param WP_Post $form    Form.
	 * @param array   $config  Config.
	 * @param array   $calc    Calc.
	 * @param array   $lead    Lead.
	 * @param string  $summary AI summary.
	 * @return void
	 */
	private static function send_webhook( $form, $config, $calc, $lead, $summary ) {
		if ( empty( $config['webhook_url'] ) ) {
			return;
		}
		$payload = array(
			'lead_id'      => $lead['id'],
			'form_id'      => $form->ID,
			'form_title'   => $form->post_title,
			'name'         => $lead['name'],
			'email'        => $lead['email'],
			'phone'        => $lead['phone'],
			'answers'      => $calc['answers'],
			'subtotal'     => $calc['subtotal'],
			'tax'          => $calc['tax'],
			'total'        => $calc['total'],
			'currency'     => $config['currency'],
			'summary'      => $summary,
			'submitted_at' => gmdate( 'c' ),
			'site'         => home_url(),
		);
		wp_safe_remote_post(
			$config['webhook_url'],
			array(
				'timeout'  => 8,
				'blocking' => (bool) apply_filters( 'qf_webhook_blocking', false ),
				'headers'  => array( 'Content-Type' => 'application/json' ),
				'body'     => wp_json_encode( apply_filters( 'qf_webhook_payload', $payload, $lead['id'] ) ),
			)
		);
	}
}
