<?php
/**
 * Ready-made example forms and the importer (Quote Forms > Examples).
 *
 * @package QuoteFlow
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Examples.
 */
class QuoteFlow_Examples {

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_post_qf_import_example', array( __CLASS__, 'handle_import' ) );
	}

	/**
	 * Submenu.
	 *
	 * @return void
	 */
	public static function menu() {
		add_submenu_page(
			'edit.php?post_type=' . QuoteFlow_CPT::POST_TYPE,
			__( 'Example Forms', 'quoteflow' ),
			__( 'Example Forms', 'quoteflow' ),
			'manage_options',
			'qf-examples',
			array( __CLASS__, 'render' )
		);
	}

	/**
	 * Build an option list from label => price pairs.
	 *
	 * @param array $pairs Pairs.
	 * @return array
	 */
	private static function opts( $pairs ) {
		$out = array();
		foreach ( $pairs as $label => $price ) {
			$out[] = array(
				'label' => $label,
				'price' => $price,
			);
		}
		return $out;
	}

	/**
	 * Build a field.
	 *
	 * @param string $id   ID.
	 * @param string $type Type.
	 * @param string $label Label.
	 * @param array  $args Extra.
	 * @return array
	 */
	private static function field( $id, $type, $label, $args = array() ) {
		return array_merge(
			array(
				'id'       => $id,
				'type'     => $type,
				'label'    => $label,
				'help'     => '',
				'required' => 0,
				'mode'     => 'add',
				'price'    => 0,
				'unit'     => '',
				'min'      => 0,
				'max'      => 100,
				'step'     => 1,
				'default'  => 0,
				'options'  => array(),
			),
			$args
		);
	}

	/**
	 * Example definitions.
	 *
	 * @return array slug => array( title, description, config )
	 */
	public static function definitions() {
		$base = QuoteFlow_Form::defaults();

		$plumbing = array_merge(
			$base,
			array(
				'base_price'   => 90,
				'tax'          => 10,
				'tax_label'    => __( 'GST', 'quoteflow' ),
				'min_charge'   => 150,
				'intro'        => __( 'Tell us about the job and get an instant estimate. Final price is confirmed on site.', 'quoteflow' ),
				'submit_label' => __( 'Email me this quote', 'quoteflow' ),
				'thank_you'    => __( 'Thanks! Your plumbing quote request is in. One of our plumbers will call you shortly to confirm a time.', 'quoteflow' ),
				'require_phone' => 1,
				'fields'       => array(
					self::field( 'job', 'select', __( 'What do you need done?', 'quoteflow' ), array( 'required' => 1, 'options' => self::opts( array( __( 'Leaking tap or fitting', 'quoteflow' ) => 80, __( 'Blocked drain', 'quoteflow' ) => 150, __( 'Toilet repair', 'quoteflow' ) => 120, __( 'Hot water system replacement', 'quoteflow' ) => 1450, __( 'New fixture installation', 'quoteflow' ) => 220 ) ) ) ),
					self::field( 'fixtures', 'number', __( 'Number of fixtures affected', 'quoteflow' ), array( 'price' => 65, 'min' => 1, 'max' => 20, 'default' => 1, 'help' => __( 'Taps, toilets, basins, etc.', 'quoteflow' ) ) ),
					self::field( 'urgency', 'radio', __( 'How urgent is it?', 'quoteflow' ), array( 'mode' => 'multiply', 'required' => 1, 'options' => self::opts( array( __( 'Next available (standard)', 'quoteflow' ) => 1, __( 'Same day', 'quoteflow' ) => 1.25, __( 'After hours / emergency', 'quoteflow' ) => 1.6 ) ) ) ),
					self::field( 'extras', 'checkbox', __( 'Extras', 'quoteflow' ), array( 'options' => self::opts( array( __( 'CCTV drain inspection', 'quoteflow' ) => 180, __( 'Replace washers & seals', 'quoteflow' ) => 25, __( 'Supply new tapware', 'quoteflow' ) => 95, __( 'Old fixture removal', 'quoteflow' ) => 40 ) ) ) ),
					self::field( 'notes', 'text', __( 'Anything we should know?', 'quoteflow' ) ),
				),
			)
		);

		$cleaning = array_merge(
			$base,
			array(
				'base_price'   => 0,
				'tax'          => 10,
				'tax_label'    => __( 'GST', 'quoteflow' ),
				'min_charge'   => 120,
				'intro'        => __( 'Get an instant price for your home clean – no phone call needed.', 'quoteflow' ),
				'submit_label' => __( 'Get my cleaning quote', 'quoteflow' ),
				'thank_you'    => __( 'Thank you! We will confirm availability and send a booking link within one business day.', 'quoteflow' ),
				'fields'       => array(
					self::field( 'beds', 'number', __( 'Bedrooms', 'quoteflow' ), array( 'price' => 35, 'min' => 1, 'max' => 10, 'default' => 2, 'required' => 1 ) ),
					self::field( 'baths', 'number', __( 'Bathrooms', 'quoteflow' ), array( 'price' => 30, 'min' => 1, 'max' => 6, 'default' => 1, 'required' => 1 ) ),
					self::field( 'type', 'radio', __( 'Type of clean', 'quoteflow' ), array( 'mode' => 'multiply', 'required' => 1, 'options' => self::opts( array( __( 'Standard clean', 'quoteflow' ) => 1, __( 'Deep clean', 'quoteflow' ) => 1.6, __( 'End of lease clean', 'quoteflow' ) => 1.9 ) ) ) ),
					self::field( 'extras', 'checkbox', __( 'Add-ons', 'quoteflow' ), array( 'options' => self::opts( array( __( 'Inside oven', 'quoteflow' ) => 45, __( 'Inside fridge', 'quoteflow' ) => 30, __( 'Interior windows', 'quoteflow' ) => 60, __( 'Carpet steam clean', 'quoteflow' ) => 80, __( 'Laundry & ironing (1 hr)', 'quoteflow' ) => 40 ) ) ) ),
					self::field( 'freq', 'select', __( 'How often?', 'quoteflow' ), array( 'mode' => 'multiply', 'required' => 1, 'options' => self::opts( array( __( 'One-off', 'quoteflow' ) => 1, __( 'Weekly (20% off)', 'quoteflow' ) => 0.8, __( 'Fortnightly (12% off)', 'quoteflow' ) => 0.88, __( 'Monthly (5% off)', 'quoteflow' ) => 0.95 ) ) ) ),
				),
			)
		);

		$lawn = array_merge(
			$base,
			array(
				'base_price'    => 30,
				'tax'           => 10,
				'tax_label'     => __( 'GST', 'quoteflow' ),
				'min_charge'    => 60,
				'intro'         => __( 'Slide to your lawn size and see your mowing price straight away.', 'quoteflow' ),
				'submit_label'  => __( 'Book my mow', 'quoteflow' ),
				'thank_you'     => __( 'Thanks! We will text you the next available mowing day.', 'quoteflow' ),
				'require_phone' => 1,
				'fields'        => array(
					self::field( 'size', 'slider', __( 'Lawn size', 'quoteflow' ), array( 'price' => 0.12, 'unit' => 'm²', 'min' => 20, 'max' => 1500, 'step' => 10, 'default' => 200, 'help' => __( 'Approximate mowable area.', 'quoteflow' ) ) ),
					self::field( 'height', 'select', __( 'Current grass height', 'quoteflow' ), array( 'mode' => 'multiply', 'required' => 1, 'options' => self::opts( array( __( 'Normal (regularly mowed)', 'quoteflow' ) => 1, __( 'Long (4+ weeks)', 'quoteflow' ) => 1.3, __( 'Overgrown', 'quoteflow' ) => 1.7 ) ) ) ),
					self::field( 'addons', 'checkbox', __( 'Add-ons', 'quoteflow' ), array( 'options' => self::opts( array( __( 'Edging & whipper snipping', 'quoteflow' ) => 25, __( 'Green waste removal', 'quoteflow' ) => 35, __( 'Hedge trimming', 'quoteflow' ) => 60, __( 'Fertiliser application', 'quoteflow' ) => 45 ) ) ) ),
					self::field( 'freq', 'radio', __( 'How often?', 'quoteflow' ), array( 'mode' => 'multiply', 'required' => 1, 'options' => self::opts( array( __( 'One-off', 'quoteflow' ) => 1, __( 'Fortnightly (15% off)', 'quoteflow' ) => 0.85, __( 'Monthly (8% off)', 'quoteflow' ) => 0.92 ) ) ) ),
					self::field( 'address', 'text', __( 'Suburb', 'quoteflow' ) ),
				),
			)
		);

		return array(
			'plumbing' => array(
				'title'       => __( 'Plumbing Job Quote', 'quoteflow' ),
				'description' => __( 'Job type, number of fixtures, urgency multiplier and extras. Includes minimum call-out and 10% tax.', 'quoteflow' ),
				'config'      => $plumbing,
			),
			'cleaning' => array(
				'title'       => __( 'House Cleaning Quote', 'quoteflow' ),
				'description' => __( 'Bedrooms and bathrooms, clean type multiplier, add-ons and recurring-visit discounts.', 'quoteflow' ),
				'config'      => $cleaning,
			),
			'lawn'     => array(
				'title'       => __( 'Lawn Mowing Quote', 'quoteflow' ),
				'description' => __( 'Lawn-size slider, grass height multiplier, add-ons and frequency discounts.', 'quoteflow' ),
				'config'      => $lawn,
			),
		);
	}

	/**
	 * Create a form post from an example.
	 *
	 * @param string $slug Example slug.
	 * @return int|WP_Error Post ID.
	 */
	public static function import( $slug ) {
		$defs = self::definitions();
		if ( ! isset( $defs[ $slug ] ) ) {
			return new WP_Error( 'qf_unknown', __( 'Unknown example.', 'quoteflow' ) );
		}
		$post_id = wp_insert_post(
			array(
				'post_type'   => QuoteFlow_CPT::POST_TYPE,
				'post_status' => 'publish',
				'post_title'  => $defs[ $slug ]['title'],
			),
			true
		);
		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}
		// Run through the sanitiser so imported data is identical to saved data.
		$cfg = $defs[ $slug ]['config'];
		$cfg = QuoteFlow_Form::sanitize( $cfg, wp_json_encode( $cfg['fields'] ) );
		update_post_meta( $post_id, QuoteFlow_Form::META_KEY, wp_slash( $cfg ) );
		update_post_meta( $post_id, '_qf_example', $slug );
		return (int) $post_id;
	}

	/**
	 * Handle import request.
	 *
	 * @return void
	 */
	public static function handle_import() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'quoteflow' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'qf_import_example' );

		$which = isset( $_POST['example'] ) ? sanitize_key( wp_unslash( $_POST['example'] ) ) : '';
		$slugs = 'all' === $which ? array_keys( self::definitions() ) : array( $which );
		$count = 0;
		foreach ( $slugs as $slug ) {
			if ( ! is_wp_error( self::import( $slug ) ) ) {
				++$count;
			}
		}
		wp_safe_redirect(
			add_query_arg(
				array(
					'post_type' => QuoteFlow_CPT::POST_TYPE,
					'page'      => 'qf-examples',
					'imported'  => $count,
				),
				admin_url( 'edit.php' )
			)
		);
		exit;
	}

	/**
	 * Render the examples page.
	 *
	 * @return void
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'quoteflow' ) );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display only.
		$imported = isset( $_GET['imported'] ) ? absint( $_GET['imported'] ) : null;
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Example Forms', 'quoteflow' ); ?></h1>
			<?php if ( null !== $imported ) : ?>
				<div class="notice notice-success is-dismissible"><p>
					<?php
					/* translators: %d: number of forms imported */
					echo esc_html( sprintf( _n( '%d form imported.', '%d forms imported.', $imported, 'quoteflow' ), $imported ) );
					?>
					<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=' . QuoteFlow_CPT::POST_TYPE ) ); ?>"><?php esc_html_e( 'View Quote Forms', 'quoteflow' ); ?></a>
				</p></div>
			<?php endif; ?>
			<p><?php esc_html_e( 'Import a ready-made form, then edit prices to suit your business. Importing creates a new form each time.', 'quoteflow' ); ?></p>
			<table class="widefat striped" style="max-width:900px">
				<thead><tr><th><?php esc_html_e( 'Form', 'quoteflow' ); ?></th><th><?php esc_html_e( 'What it includes', 'quoteflow' ); ?></th><th></th></tr></thead>
				<tbody>
				<?php foreach ( self::definitions() as $slug => $def ) : ?>
					<tr>
						<td><strong><?php echo esc_html( $def['title'] ); ?></strong></td>
						<td><?php echo esc_html( $def['description'] ); ?></td>
						<td>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<input type="hidden" name="action" value="qf_import_example" />
								<input type="hidden" name="example" value="<?php echo esc_attr( $slug ); ?>" />
								<?php wp_nonce_field( 'qf_import_example' ); ?>
								<?php submit_button( __( 'Import', 'quoteflow' ), 'secondary small', 'submit', false ); ?>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="qf_import_example" />
				<input type="hidden" name="example" value="all" />
				<?php wp_nonce_field( 'qf_import_example' ); ?>
				<?php submit_button( __( 'Import all 3 examples', 'quoteflow' ), 'primary' ); ?>
			</form>
		</div>
		<?php
	}
}
