<?php
/**
 * Activation and database setup.
 *
 * @package QuoteFlow
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Installer.
 */
class QuoteFlow_Install {

	/**
	 * Table name (with prefix).
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'qf_leads';
	}

	/**
	 * Activation callback.
	 *
	 * @return void
	 */
	public static function activate() {
		self::create_table();
		QuoteFlow_CPT::register_post_type();
		flush_rewrite_rules();
	}

	/**
	 * Re-run table creation when the stored DB version is old.
	 *
	 * @return void
	 */
	public static function maybe_upgrade() {
		if ( get_option( 'qf_db_version' ) !== QF_DB_VERSION ) {
			self::create_table();
		}
	}

	/**
	 * Create the leads table with dbDelta.
	 *
	 * @return void
	 */
	public static function create_table() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table   = self::table();
		$charset = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  form_id bigint(20) unsigned NOT NULL DEFAULT 0,
  form_title varchar(255) NOT NULL DEFAULT '',
  name varchar(190) NOT NULL DEFAULT '',
  email varchar(190) NOT NULL DEFAULT '',
  phone varchar(60) NOT NULL DEFAULT '',
  answers longtext NULL,
  subtotal decimal(14,2) NOT NULL DEFAULT 0,
  tax decimal(14,2) NOT NULL DEFAULT 0,
  total decimal(14,2) NOT NULL DEFAULT 0,
  currency varchar(16) NOT NULL DEFAULT '',
  summary text NULL,
  created_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY  (id),
  KEY form_id (form_id),
  KEY created_at (created_at)
) {$charset};";

		dbDelta( $sql );
		update_option( 'qf_db_version', QF_DB_VERSION );
	}
}
