<?php
/**
 * Front end: shortcode, Gutenberg block, assets and form markup.
 *
 * @package QuoteFlow
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Frontend.
 */
class QuoteFlow_Frontend {

	/**
	 * Instance counter for unique element IDs.
	 *
	 * @var int
	 */
	private static $instance = 0;

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_assets' ) );
		add_action( 'init', array( __CLASS__, 'register_block' ) );
		add_shortcode( 'quoteflow', array( __CLASS__, 'shortcode' ) );
		add_action( 'enqueue_block_editor_assets', array( __CLASS__, 'editor_data' ) );
	}

	/**
	 * Register (not enqueue) assets.
	 *
	 * @return void
	 */
	public static function register_assets() {
		wp_register_style( 'qf-frontend', QF_URL . 'assets/css/frontend.css', array(), QF_VERSION );
		wp_register_script( 'qf-frontend', QF_URL . 'assets/js/frontend.js', array(), QF_VERSION, true );
		wp_localize_script(
			'qf-frontend',
			'qfFront',
			array(
				'endpoint' => esc_url_raw( rest_url( QuoteFlow_REST::NS . '/submit' ) ),
				'i18n'     => array(
					'total'        => __( 'Estimated total', 'quoteflow' ),
					'gated'        => __( 'Enter your details above to see your price.', 'quoteflow' ),
					'incTax'       => __( 'Includes tax', 'quoteflow' ),
					'sending'      => __( 'Sending…', 'quoteflow' ),
					'error'        => __( 'Something went wrong. Please try again.', 'quoteflow' ),
					'reqField'     => __( 'This field is required.', 'quoteflow' ),
					'reqEmail'     => __( 'Please enter a valid email address.', 'quoteflow' ),
					'fixErrors'    => __( 'Please fix the highlighted fields.', 'quoteflow' ),
					'yourQuote'    => __( 'Your quote', 'quoteflow' ),
					'summary'      => __( 'Summary', 'quoteflow' ),
					'newQuote'     => __( 'Start a new quote', 'quoteflow' ),
					'subtotal'     => __( 'Subtotal', 'quoteflow' ),
				),
			)
		);
	}

	/**
	 * Register the Gutenberg block.
	 *
	 * @return void
	 */
	public static function register_block() {
		wp_register_script(
			'qf-block-editor',
			QF_URL . 'assets/js/block.js',
			array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n' ),
			QF_VERSION,
			true
		);
		if ( function_exists( 'wp_set_script_translations' ) ) {
			wp_set_script_translations( 'qf-block-editor', 'quoteflow', QF_PATH . 'languages' );
		}
		register_block_type(
			QF_PATH . 'blocks/quote-form',
			array( 'render_callback' => array( __CLASS__, 'render_block' ) )
		);
	}

	/**
	 * Pass the form list to the block editor script.
	 *
	 * @return void
	 */
	public static function editor_data() {
		$forms = array();
		foreach ( get_posts(
			array(
				'post_type'      => QuoteFlow_CPT::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => 200,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		) as $p ) {
			$forms[] = array(
				'value' => (int) $p->ID,
				'label' => '' !== $p->post_title ? $p->post_title : '#' . $p->ID,
			);
		}
		wp_localize_script( 'qf-block-editor', 'qfBlock', array( 'forms' => $forms ) );
	}

	/**
	 * Shortcode callback.
	 *
	 * @param array $atts Attributes.
	 * @return string
	 */
	public static function shortcode( $atts ) {
		$atts = shortcode_atts( array( 'id' => 0 ), $atts, 'quoteflow' );
		return self::render( absint( $atts['id'] ) );
	}

	/**
	 * Block render callback.
	 *
	 * @param array $attrs Block attributes.
	 * @return string
	 */
	public static function render_block( $attrs ) {
		$id = isset( $attrs['formId'] ) ? absint( $attrs['formId'] ) : 0;
		return self::render( $id );
	}

	/**
	 * Build the form HTML.
	 *
	 * @param int $form_id Form ID.
	 * @return string
	 */
	public static function render( $form_id ) {
		$form = $form_id ? get_post( $form_id ) : null;
		if ( ! $form || QuoteFlow_CPT::POST_TYPE !== $form->post_type || 'publish' !== $form->post_status ) {
			if ( current_user_can( 'edit_posts' ) ) {
				return '<p class="qf-notice">' . esc_html__( 'QuoteFlow: this quote form was not found or is not published.', 'quoteflow' ) . '</p>';
			}
			return '';
		}

		wp_enqueue_style( 'qf-frontend' );
		wp_enqueue_script( 'qf-frontend' );

		++self::$instance;
		$uid    = 'qf' . self::$instance . '-' . $form_id;
		$config = QuoteFlow_Form::public_config( $form_id );
		$gated  = $config['gate_total'] && ( $config['require_name'] || $config['require_email'] || $config['require_phone'] );

		ob_start();
		?>
		<div class="qf-wrap" id="<?php echo esc_attr( $uid ); ?>">
			<form class="qf-form" method="post" novalidate data-qf-config="<?php echo esc_attr( wp_json_encode( $config ) ); ?>">
				<?php if ( '' !== $form->post_title ) : ?>
					<h3 class="qf-title"><?php echo esc_html( $form->post_title ); ?></h3>
				<?php endif; ?>
				<?php if ( '' !== $config['intro'] ) : ?>
					<p class="qf-intro"><?php echo esc_html( $config['intro'] ); ?></p>
				<?php endif; ?>

				<div class="qf-fields">
					<?php
					foreach ( $config['fields'] as $f ) {
						self::render_field( $f, $uid ); // Escaped inside.
					}
					?>
				</div>

				<fieldset class="qf-contact">
					<legend class="qf-contact-title"><?php esc_html_e( 'Your details', 'quoteflow' ); ?></legend>
					<?php
					self::contact_input( $uid, 'name', __( 'Name', 'quoteflow' ), 'text', $config['require_name'], 'name' );
					self::contact_input( $uid, 'email', __( 'Email', 'quoteflow' ), 'email', $config['require_email'], 'email' );
					self::contact_input( $uid, 'phone', __( 'Phone', 'quoteflow' ), 'tel', $config['require_phone'], 'tel' );
					?>
				</fieldset>

				<div class="qf-hp" aria-hidden="true">
					<label><?php esc_html_e( 'Leave this field empty', 'quoteflow' ); ?>
						<input type="text" name="website" value="" tabindex="-1" autocomplete="off" />
					</label>
				</div>

				<div class="qf-total" aria-live="polite" data-qf-gated="<?php echo $gated ? '1' : '0'; ?>">
					<span class="qf-total-label"><?php esc_html_e( 'Estimated total', 'quoteflow' ); ?></span>
					<strong class="qf-total-value" data-qf-total></strong>
					<small class="qf-total-meta" data-qf-meta></small>
				</div>
				<noscript><p class="qf-notice"><?php esc_html_e( 'Please enable JavaScript to use the quote calculator.', 'quoteflow' ); ?></p></noscript>

				<div class="qf-error" role="alert" hidden></div>
				<button type="submit" class="qf-submit"><?php echo esc_html( $config['submit_label'] ); ?></button>
			</form>
			<div class="qf-result" tabindex="-1" hidden></div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * One contact input.
	 *
	 * @param string $uid      Instance ID.
	 * @param string $key      Field key.
	 * @param string $label    Label.
	 * @param string $type     Input type.
	 * @param int    $required Required flag.
	 * @param string $auto     Autocomplete token.
	 * @return void
	 */
	private static function contact_input( $uid, $key, $label, $type, $required, $auto ) {
		$id = $uid . '-' . $key;
		?>
		<div class="qf-field qf-field--contact" data-qf-contact="<?php echo esc_attr( $key ); ?>" data-qf-required="<?php echo $required ? '1' : '0'; ?>">
			<label class="qf-label" for="<?php echo esc_attr( $id ); ?>">
				<?php echo esc_html( $label ); ?><?php echo $required ? ' <span class="qf-req" aria-hidden="true">*</span>' : ''; ?>
			</label>
			<input class="qf-input" type="<?php echo esc_attr( $type ); ?>" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $key ); ?>" autocomplete="<?php echo esc_attr( $auto ); ?>" <?php echo $required ? 'required aria-required="true"' : ''; ?> />
			<span class="qf-field-error" hidden></span>
		</div>
		<?php
	}

	/**
	 * Render one calculator field.
	 *
	 * @param array  $f   Field.
	 * @param string $uid Instance ID.
	 * @return void
	 */
	private static function render_field( $f, $uid ) {
		$fid  = $uid . '-' . $f['id'];
		$type = $f['type'];
		?>
		<div class="qf-field qf-field--<?php echo esc_attr( $type ); ?>" data-qf-field="<?php echo esc_attr( $f['id'] ); ?>" data-qf-required="<?php echo ! empty( $f['required'] ) ? '1' : '0'; ?>">
			<?php if ( in_array( $type, array( 'radio', 'checkbox' ), true ) ) : ?>
				<fieldset class="qf-group">
					<legend class="qf-label"><?php echo esc_html( $f['label'] ); ?><?php echo ! empty( $f['required'] ) ? ' <span class="qf-req" aria-hidden="true">*</span>' : ''; ?></legend>
					<?php foreach ( $f['options'] as $i => $o ) : ?>
						<label class="qf-choice">
							<input type="<?php echo esc_attr( $type ); ?>" name="<?php echo esc_attr( $fid ); ?><?php echo 'checkbox' === $type ? '[]' : ''; ?>" value="<?php echo esc_attr( $i ); ?>" data-qf-input />
							<span><?php echo esc_html( $o['label'] ); ?></span>
						</label>
					<?php endforeach; ?>
				</fieldset>
			<?php else : ?>
				<label class="qf-label" for="<?php echo esc_attr( $fid ); ?>"><?php echo esc_html( $f['label'] ); ?><?php echo ! empty( $f['required'] ) ? ' <span class="qf-req" aria-hidden="true">*</span>' : ''; ?></label>
				<?php if ( 'select' === $type ) : ?>
					<select class="qf-input" id="<?php echo esc_attr( $fid ); ?>" data-qf-input>
						<option value=""><?php esc_html_e( '— Select —', 'quoteflow' ); ?></option>
						<?php foreach ( $f['options'] as $i => $o ) : ?>
							<option value="<?php echo esc_attr( $i ); ?>"><?php echo esc_html( $o['label'] ); ?></option>
						<?php endforeach; ?>
					</select>
				<?php elseif ( 'number' === $type ) : ?>
					<div class="qf-numwrap">
						<input class="qf-input" type="number" inputmode="decimal" id="<?php echo esc_attr( $fid ); ?>" min="<?php echo esc_attr( $f['min'] ); ?>" max="<?php echo esc_attr( $f['max'] ); ?>" step="<?php echo esc_attr( $f['step'] ); ?>" value="<?php echo esc_attr( $f['default'] ); ?>" data-qf-input />
						<?php if ( '' !== $f['unit'] ) : ?><span class="qf-unit"><?php echo esc_html( $f['unit'] ); ?></span><?php endif; ?>
					</div>
				<?php elseif ( 'slider' === $type ) : ?>
					<div class="qf-sliderwrap">
						<input class="qf-range" type="range" id="<?php echo esc_attr( $fid ); ?>" min="<?php echo esc_attr( $f['min'] ); ?>" max="<?php echo esc_attr( $f['max'] ); ?>" step="<?php echo esc_attr( $f['step'] ); ?>" value="<?php echo esc_attr( min( $f['max'], max( $f['min'], $f['default'] ) ) ); ?>" data-qf-input />
						<output class="qf-range-out" for="<?php echo esc_attr( $fid ); ?>" data-qf-out></output>
						<?php if ( '' !== $f['unit'] ) : ?><span class="qf-unit"><?php echo esc_html( $f['unit'] ); ?></span><?php endif; ?>
					</div>
				<?php else : ?>
					<input class="qf-input" type="text" id="<?php echo esc_attr( $fid ); ?>" maxlength="500" data-qf-input />
				<?php endif; ?>
			<?php endif; ?>
			<?php if ( '' !== $f['help'] ) : ?><span class="qf-help"><?php echo esc_html( $f['help'] ); ?></span><?php endif; ?>
			<span class="qf-field-error" hidden></span>
		</div>
		<?php
	}
}
