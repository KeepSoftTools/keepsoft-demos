<?php
/**
 * Leads storage, admin list and CSV export.
 *
 * @package QuoteFlow
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Leads.
 */
class QuoteFlow_Leads {

	const PER_PAGE = 20;

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_post_qf_export_leads', array( __CLASS__, 'export_csv' ) );
		add_action( 'admin_post_qf_delete_lead', array( __CLASS__, 'delete_lead' ) );
	}

	/**
	 * Insert a lead.
	 *
	 * @param array $data Lead data.
	 * @return int Insert ID (0 on failure).
	 */
	public static function insert( $data ) {
		global $wpdb;
		$ok = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			QuoteFlow_Install::table(),
			array(
				'form_id'    => (int) $data['form_id'],
				'form_title' => mb_substr( $data['form_title'], 0, 255 ),
				'name'       => mb_substr( $data['name'], 0, 190 ),
				'email'      => mb_substr( $data['email'], 0, 190 ),
				'phone'      => mb_substr( $data['phone'], 0, 60 ),
				'answers'    => wp_json_encode( $data['answers'] ),
				'subtotal'   => $data['subtotal'],
				'tax'        => $data['tax'],
				'total'      => $data['total'],
				'currency'   => mb_substr( $data['currency'], 0, 16 ),
				'summary'    => $data['summary'],
				'created_at' => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s', '%s', '%s', '%s', '%f', '%f', '%f', '%s', '%s', '%s' )
		);
		return $ok ? (int) $wpdb->insert_id : 0;
	}

	/**
	 * Count leads (optionally per form).
	 *
	 * @param int $form_id Form ID or 0 for all.
	 * @return int
	 */
	public static function count( $form_id = 0 ) {
		global $wpdb;
		$table = QuoteFlow_Install::table();
		if ( $form_id ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE form_id = %d", $form_id ) );
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
	}

	/**
	 * Fetch leads.
	 *
	 * @param int $form_id Form ID or 0.
	 * @param int $limit   Limit (0 = no limit).
	 * @param int $offset  Offset.
	 * @return array
	 */
	public static function get_rows( $form_id = 0, $limit = 0, $offset = 0 ) {
		global $wpdb;
		$table = QuoteFlow_Install::table();
		$where = $form_id ? $wpdb->prepare( 'WHERE form_id = %d', $form_id ) : '';
		$lim   = $limit ? $wpdb->prepare( 'LIMIT %d OFFSET %d', $limit, $offset ) : '';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (array) $wpdb->get_results( "SELECT * FROM {$table} {$where} ORDER BY id DESC {$lim}", ARRAY_A );
	}

	/**
	 * Menu.
	 *
	 * @return void
	 */
	public static function menu() {
		add_submenu_page(
			'edit.php?post_type=' . QuoteFlow_CPT::POST_TYPE,
			__( 'QuoteFlow Leads', 'quoteflow' ),
			__( 'Leads', 'quoteflow' ),
			'manage_options',
			'qf-leads',
			array( __CLASS__, 'render' )
		);
	}

	/**
	 * Current form filter.
	 *
	 * @return int
	 */
	private static function filter_form_id() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only filter.
		return isset( $_REQUEST['form_id'] ) ? absint( $_REQUEST['form_id'] ) : 0;
	}

	/**
	 * Render the Leads page.
	 *
	 * @return void
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'quoteflow' ) );
		}
		$form_id = self::filter_form_id();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only pagination.
		$paged = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		$total = self::count( $form_id );
		$pages = max( 1, (int) ceil( $total / self::PER_PAGE ) );
		$paged = min( $paged, $pages );
		$rows  = self::get_rows( $form_id, self::PER_PAGE, ( $paged - 1 ) * self::PER_PAGE );
		$forms = get_posts(
			array(
				'post_type'      => QuoteFlow_CPT::POST_TYPE,
				'post_status'    => 'any',
				'posts_per_page' => 200,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);
		$base  = array(
			'post_type' => QuoteFlow_CPT::POST_TYPE,
			'page'      => 'qf-leads',
		);
		if ( $form_id ) {
			$base['form_id'] = $form_id;
		}
		$export = wp_nonce_url(
			add_query_arg(
				array(
					'action'  => 'qf_export_leads',
					'form_id' => $form_id,
				),
				admin_url( 'admin-post.php' )
			),
			'qf_export_leads'
		);
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display only.
		$deleted = isset( $_GET['deleted'] );
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Leads', 'quoteflow' ); ?></h1>
			<a href="<?php echo esc_url( $export ); ?>" class="page-title-action"><?php esc_html_e( 'Export CSV', 'quoteflow' ); ?></a>
			<hr class="wp-header-end" />
			<?php if ( $deleted ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Lead deleted.', 'quoteflow' ); ?></p></div>
			<?php endif; ?>

			<form method="get" class="tablenav top">
				<input type="hidden" name="post_type" value="<?php echo esc_attr( QuoteFlow_CPT::POST_TYPE ); ?>" />
				<input type="hidden" name="page" value="qf-leads" />
				<label for="qf-filter-form" class="screen-reader-text"><?php esc_html_e( 'Filter by form', 'quoteflow' ); ?></label>
				<select name="form_id" id="qf-filter-form">
					<option value="0"><?php esc_html_e( 'All forms', 'quoteflow' ); ?></option>
					<?php foreach ( $forms as $f ) : ?>
						<option value="<?php echo esc_attr( $f->ID ); ?>" <?php selected( $form_id, $f->ID ); ?>><?php echo esc_html( $f->post_title ); ?></option>
					<?php endforeach; ?>
				</select>
				<?php submit_button( __( 'Filter', 'quoteflow' ), 'secondary', '', false ); ?>
				<span class="displaying-num">
					<?php
					/* translators: %s: number of leads */
					echo esc_html( sprintf( _n( '%s lead', '%s leads', $total, 'quoteflow' ), number_format_i18n( $total ) ) );
					?>
				</span>
			</form>

			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th style="width:60px"><?php esc_html_e( 'ID', 'quoteflow' ); ?></th>
						<th><?php esc_html_e( 'Date', 'quoteflow' ); ?></th>
						<th><?php esc_html_e( 'Form', 'quoteflow' ); ?></th>
						<th><?php esc_html_e( 'Contact', 'quoteflow' ); ?></th>
						<th><?php esc_html_e( 'Answers', 'quoteflow' ); ?></th>
						<th><?php esc_html_e( 'Total', 'quoteflow' ); ?></th>
						<th style="width:70px"></th>
					</tr>
				</thead>
				<tbody>
				<?php if ( empty( $rows ) ) : ?>
					<tr><td colspan="7"><?php esc_html_e( 'No leads yet.', 'quoteflow' ); ?></td></tr>
				<?php endif; ?>
				<?php foreach ( $rows as $r ) : ?>
					<?php
					$answers = json_decode( (string) $r['answers'], true );
					$del     = wp_nonce_url(
						add_query_arg(
							array(
								'action'  => 'qf_delete_lead',
								'lead_id' => (int) $r['id'],
								'form_id' => $form_id,
							),
							admin_url( 'admin-post.php' )
						),
						'qf_delete_lead_' . (int) $r['id']
					);
					?>
					<tr>
						<td><?php echo esc_html( $r['id'] ); ?></td>
						<td><?php echo esc_html( mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $r['created_at'] ) ); ?></td>
						<td><?php echo esc_html( $r['form_title'] ); ?></td>
						<td>
							<strong><?php echo esc_html( $r['name'] ); ?></strong><br />
							<?php if ( $r['email'] ) : ?><a href="mailto:<?php echo esc_attr( $r['email'] ); ?>"><?php echo esc_html( $r['email'] ); ?></a><br /><?php endif; ?>
							<?php echo esc_html( $r['phone'] ); ?>
						</td>
						<td>
							<?php
							if ( is_array( $answers ) ) {
								foreach ( $answers as $a ) {
									if ( isset( $a['label'], $a['value'] ) ) {
										echo '<div><strong>' . esc_html( $a['label'] ) . ':</strong> ' . esc_html( $a['value'] ) . '</div>';
									}
								}
							}
							if ( ! empty( $r['summary'] ) ) {
								echo '<details><summary>' . esc_html__( 'AI summary', 'quoteflow' ) . '</summary><p>' . esc_html( $r['summary'] ) . '</p></details>';
							}
							?>
						</td>
						<td><strong><?php echo esc_html( $r['currency'] . number_format_i18n( (float) $r['total'], 2 ) ); ?></strong></td>
						<td><a href="<?php echo esc_url( $del ); ?>" class="submitdelete" onclick="return confirm('<?php echo esc_js( __( 'Delete this lead permanently?', 'quoteflow' ) ); ?>');"><?php esc_html_e( 'Delete', 'quoteflow' ); ?></a></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<?php if ( $pages > 1 ) : ?>
				<div class="tablenav bottom"><div class="tablenav-pages">
					<?php
					echo wp_kses_post(
						paginate_links(
							array(
								'base'      => add_query_arg( array_merge( $base, array( 'paged' => '%#%' ) ), admin_url( 'edit.php' ) ),
								'format'    => '',
								'current'   => $paged,
								'total'     => $pages,
								'prev_text' => '&laquo;',
								'next_text' => '&raquo;',
							)
						)
					);
					?>
				</div></div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Delete one lead.
	 *
	 * @return void
	 */
	public static function delete_lead() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'quoteflow' ), '', array( 'response' => 403 ) );
		}
		$id = isset( $_GET['lead_id'] ) ? absint( $_GET['lead_id'] ) : 0;
		check_admin_referer( 'qf_delete_lead_' . $id );
		global $wpdb;
		$wpdb->delete( QuoteFlow_Install::table(), array( 'id' => $id ), array( '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		wp_safe_redirect(
			add_query_arg(
				array(
					'post_type' => QuoteFlow_CPT::POST_TYPE,
					'page'      => 'qf-leads',
					'form_id'   => self::filter_form_id(),
					'deleted'   => 1,
				),
				admin_url( 'edit.php' )
			)
		);
		exit;
	}

	/**
	 * Stream a CSV export.
	 *
	 * @return void
	 */
	public static function export_csv() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'quoteflow' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'qf_export_leads' );

		$rows = self::get_rows( self::filter_form_id() );

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="quoteflow-leads-' . gmdate( 'Y-m-d' ) . '.csv"' );

		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
		fputcsv( $out, array( 'ID', 'Date', 'Form', 'Name', 'Email', 'Phone', 'Answers', 'Subtotal', 'Tax', 'Total', 'Currency', 'Summary' ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		foreach ( $rows as $r ) {
			$answers = json_decode( (string) $r['answers'], true );
			$flat    = array();
			if ( is_array( $answers ) ) {
				foreach ( $answers as $a ) {
					if ( isset( $a['label'], $a['value'] ) ) {
						$flat[] = $a['label'] . ': ' . $a['value'];
					}
				}
			}
			fputcsv( // phpcs:ignore WordPress.WP.AlternativeFunctions
				$out,
				array(
					$r['id'],
					$r['created_at'],
					self::csv_safe( $r['form_title'] ),
					self::csv_safe( $r['name'] ),
					self::csv_safe( $r['email'] ),
					self::csv_safe( $r['phone'] ),
					self::csv_safe( implode( ' | ', $flat ) ),
					$r['subtotal'],
					$r['tax'],
					$r['total'],
					self::csv_safe( $r['currency'] ),
					self::csv_safe( $r['summary'] ),
				)
			);
		}
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		exit;
	}

	/**
	 * Neutralise spreadsheet formula injection.
	 *
	 * @param string $v Value.
	 * @return string
	 */
	private static function csv_safe( $v ) {
		$v = (string) $v;
		if ( '' !== $v && in_array( $v[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) ) {
			return "'" . $v;
		}
		return $v;
	}
}
