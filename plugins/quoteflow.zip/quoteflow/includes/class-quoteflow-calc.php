<?php
/**
 * Server-side price calculation. Mirrors assets/js/frontend.js exactly.
 *
 * Order of operations:
 *   1. base price + every "add" amount
 *   2. every "multiply" factor applied to that running subtotal
 *   3. minimum charge (before tax)
 *   4. tax %
 *
 * @package QuoteFlow
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Calculator.
 */
class QuoteFlow_Calc {

	/**
	 * Calculate a quote.
	 *
	 * @param array $config  Form config.
	 * @param array $answers Map of field id => raw answer.
	 * @return array|WP_Error
	 */
	public static function calculate( $config, $answers ) {
		$adds    = array();
		$mults   = array();
		$summary = array();
		$sub     = (float) $config['base_price'];

		if ( ! is_array( $answers ) ) {
			$answers = array();
		}

		foreach ( $config['fields'] as $f ) {
			$id    = $f['id'];
			$raw   = isset( $answers[ $id ] ) ? $answers[ $id ] : null;
			$label = '' !== $f['label'] ? $f['label'] : $id;
			$mode  = $f['mode'];

			switch ( $f['type'] ) {
				case 'number':
				case 'slider':
					if ( ! is_scalar( $raw ) || ! is_numeric( $raw ) ) {
						if ( ! empty( $f['required'] ) && 'number' === $f['type'] ) {
							/* translators: %s: field label */
							return new WP_Error( 'qf_required', sprintf( __( 'Please complete: %s', 'quoteflow' ), $label ) );
						}
						$raw = $f['default'];
					}
					$v = max( $f['min'], min( $f['max'], (float) $raw ) );
					if ( 'multiply' === $mode ) {
						$mults[]   = array( $label . ' × ' . self::trim_num( $v ), $v );
					} else {
						$adds[]    = array( $label . ' × ' . self::trim_num( $v ), $v * $f['price'] );
					}
					$summary[] = array(
						'label' => $label,
						'value' => self::trim_num( $v ) . ( '' !== $f['unit'] ? ' ' . $f['unit'] : '' ),
					);
					break;

				case 'select':
				case 'radio':
					$idx = ( is_scalar( $raw ) && is_numeric( $raw ) ) ? (int) $raw : -1;
					if ( ! isset( $f['options'][ $idx ] ) ) {
						if ( ! empty( $f['required'] ) ) {
							/* translators: %s: field label */
							return new WP_Error( 'qf_required', sprintf( __( 'Please choose: %s', 'quoteflow' ), $label ) );
						}
						break;
					}
					$o = $f['options'][ $idx ];
					self::push_option( $adds, $mults, $mode, $label, $o );
					$summary[] = array(
						'label' => $label,
						'value' => $o['label'],
					);
					break;

				case 'checkbox':
					$picked = array();
					$list   = is_array( $raw ) ? $raw : array();
					foreach ( $list as $r ) {
						if ( is_scalar( $r ) && is_numeric( $r ) && isset( $f['options'][ (int) $r ] ) ) {
							$picked[ (int) $r ] = true;
						}
					}
					if ( empty( $picked ) ) {
						if ( ! empty( $f['required'] ) ) {
							/* translators: %s: field label */
							return new WP_Error( 'qf_required', sprintf( __( 'Please choose at least one: %s', 'quoteflow' ), $label ) );
						}
						break;
					}
					$names = array();
					foreach ( array_keys( $picked ) as $i ) {
						self::push_option( $adds, $mults, $mode, $label, $f['options'][ $i ] );
						$names[] = $f['options'][ $i ]['label'];
					}
					$summary[] = array(
						'label' => $label,
						'value' => implode( ', ', $names ),
					);
					break;

				case 'text':
					$text = is_scalar( $raw ) ? trim( sanitize_text_field( (string) $raw ) ) : '';
					$text = mb_substr( $text, 0, 500 );
					if ( '' === $text ) {
						if ( ! empty( $f['required'] ) ) {
							/* translators: %s: field label */
							return new WP_Error( 'qf_required', sprintf( __( 'Please complete: %s', 'quoteflow' ), $label ) );
						}
						break;
					}
					if ( $f['price'] ) {
						if ( 'multiply' === $mode && $f['price'] > 0 ) {
							$mults[] = array( $label, $f['price'] );
						} else {
							$adds[] = array( $label, $f['price'] );
						}
					}
					$summary[] = array(
						'label' => $label,
						'value' => $text,
					);
					break;
			}
		}

		$lines = array();
		if ( 0.0 !== (float) $config['base_price'] ) {
			$lines[] = array(
				'label'  => __( 'Base price', 'quoteflow' ),
				'amount' => round( (float) $config['base_price'], 2 ),
			);
		}
		foreach ( $adds as $a ) {
			$sub    += $a[1];
			$lines[] = array(
				'label'  => $a[0],
				'amount' => round( $a[1], 2 ),
			);
		}
		foreach ( $mults as $m ) {
			$before  = $sub;
			$sub    *= $m[1];
			$lines[] = array(
				'label'  => $m[0] . ' (×' . self::trim_num( $m[1] ) . ')',
				'amount' => round( $sub - $before, 2 ),
			);
		}

		$sub = max( 0, $sub );
		if ( $sub < (float) $config['min_charge'] ) {
			$lines[] = array(
				'label'  => __( 'Minimum charge adjustment', 'quoteflow' ),
				'amount' => round( (float) $config['min_charge'] - $sub, 2 ),
			);
			$sub     = (float) $config['min_charge'];
		}
		$sub   = round( $sub, 2 );
		$tax   = round( $sub * ( (float) $config['tax'] / 100 ), 2 );
		$total = round( $sub + $tax, 2 );

		return array(
			'subtotal' => $sub,
			'tax'      => $tax,
			'total'    => $total,
			'lines'    => $lines,
			'answers'  => $summary,
		);
	}

	/**
	 * Register an option's effect.
	 *
	 * @param array  $adds  Adds (by ref).
	 * @param array  $mults Multipliers (by ref).
	 * @param string $mode  add|multiply.
	 * @param string $label Field label.
	 * @param array  $o     Option.
	 * @return void
	 */
	private static function push_option( &$adds, &$mults, $mode, $label, $o ) {
		$name = $label . ': ' . $o['label'];
		if ( 'multiply' === $mode ) {
			$factor = $o['price'] > 0 ? $o['price'] : 1;
			$mults[] = array( $name, $factor );
		} else {
			$adds[] = array( $name, $o['price'] );
		}
	}

	/**
	 * Trim trailing zeros from a number for display.
	 *
	 * @param float $n Number.
	 * @return string
	 */
	public static function trim_num( $n ) {
		return rtrim( rtrim( number_format( (float) $n, 3, '.', '' ), '0' ), '.' );
	}
}
