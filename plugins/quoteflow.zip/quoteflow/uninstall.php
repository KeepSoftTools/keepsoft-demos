<?php
/**
 * Uninstall QuoteFlow: removes options, forms and the leads table
 * (only if "Delete data on uninstall" is enabled in the settings).
 *
 * @package QuoteFlow
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$qf_settings = get_option( 'qf_settings', array() );

if ( ! empty( $qf_settings['delete_on_uninstall'] ) ) {
	global $wpdb;

	$qf_ids = get_posts(
		array(
			'post_type'      => 'qf_form',
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'fields'         => 'ids',
		)
	);
	foreach ( $qf_ids as $qf_id ) {
		wp_delete_post( $qf_id, true );
	}

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'qf_leads' );
	delete_option( 'qf_settings' );
	delete_option( 'qf_db_version' );
}
