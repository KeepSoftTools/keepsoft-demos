=== QuoteFlow – Instant Quote Calculator & Lead Capture ===
Contributors: keepsoft
Tags: quote calculator, price calculator, lead capture, estimate form, quote form
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Build instant quote calculators with live pricing, capture leads, export to CSV and optionally add AI-written quote summaries.

== Description ==

QuoteFlow lets service businesses (plumbers, cleaners, landscapers, installers, agencies...) show visitors an instant price and turn them into leads.

Create a "Quote Form" in the WordPress admin, add fields that change the price, and place it on any page with a shortcode or the Gutenberg block. The total updates live as the visitor makes choices. When they submit, the lead is stored in your database, you receive an email, an optional webhook fires, and the visitor sees a thank-you message with their quote.

**Highlights**

* Field types: number, dropdown, radio buttons, checkboxes, slider and text.
* Every field can add to the price or multiply it.
* Base price, currency symbol, tax %, minimum charge.
* Optionally require name / email / phone, and hide the total until they are entered.
* Live total, vanilla JavaScript (no jQuery), mobile friendly.
* Submissions via the WordPress REST API, stored in a custom table.
* Leads screen with CSV export.
* Email notification, customer copy and webhook (Zapier, Make, n8n).
* Optional AI quote summary using any OpenAI-compatible chat completions API.
* Three example forms: plumbing, house cleaning and lawn mowing.
* Themeable with CSS variables, translation ready.

== Installation ==

1. Upload the `quoteflow` folder to `/wp-content/plugins/`, or install the ZIP via Plugins > Add New > Upload.
2. Activate the plugin.
3. Go to QuoteFlow > Example Forms and import an example, or choose QuoteFlow > Add New.
4. Copy the shortcode (for example `[quoteflow id="123"]`) into a page, or add the "QuoteFlow" block.

== Frequently Asked Questions ==

= Do I need an OpenAI key? =
No. The AI summary is optional. Without a key everything else works the same.

= Which AI providers work? =
Any service that offers an OpenAI-compatible `/chat/completions` endpoint. Set the API base URL and model under QuoteFlow > Settings.

= Is the price calculated on the server? =
Yes. The browser shows a live total, but the price saved with each lead is always recalculated on the server from the submitted choices.

= Does it need jQuery? =
No. The front end script is plain JavaScript.

= How do I change the colours? =
Override the `--qf-*` CSS variables on `.qf-wrap` in your theme. See the documentation folder.

= What happens to data when I delete the plugin? =
Nothing, unless you tick "Delete all forms, leads and settings" in QuoteFlow > Settings first.

== Third-party services ==

If you enter an API key under QuoteFlow > Settings, the plugin sends the visitor's quote selections, the computed prices and the visitor's name (if provided), including any text-field answers to the API base URL you configure (by default https://api.openai.com/v1) to generate a summary. Nothing is sent unless a key is saved. See your provider's terms of service and privacy policy (OpenAI: https://openai.com/policies/).

If you enter a webhook URL on a form, each submission (contact details, answers and totals) is sent to that URL.

== Screenshots ==

1. Front-end calculator with live total.
2. Form builder in the admin.
3. Leads screen with CSV export.
4. Settings screen with optional AI summary.

== Changelog ==

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.0 =
First release.
