=== ProfitLens – Net Profit & Margin Reports for WooCommerce ===
Contributors: keepsoft
Tags: woocommerce, profit, margin, cost of goods, reports
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Requires Plugins: woocommerce
WC requires at least: 7.0
WC tested up to: 11.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

See your real net profit and margin per order, product, category, payment gateway, country, coupon and customer, after costs, fees, shipping and ad spend.

== Description ==

WooCommerce shows you revenue. ProfitLens shows you what you actually keep.

For every order ProfitLens works out revenue (net of refunds and tax), cost of goods, payment gateway fee, shipping you really paid, packaging, ad spend and fixed costs, and stores the net profit and margin. Reports then slice that by product, category, gateway, country, coupon and customer lifetime value, and flag products that lose money.

**Features**

* Cost of goods per product and per variation, with a default margin % fallback. Also reads WooCommerce core cost of goods, WooCommerce Cost of Goods, Alg/WPFactory and YITH cost fields (editable list of meta keys).
* Bulk CSV import and export of costs.
* Per-gateway fee rules (percentage plus fixed fee). Uses the real fee when Stripe or PayPal stored it on the order.
* Shipping cost actually paid: per-order field, per-method default, or "same as charged".
* Packaging cost default and per-order extra expenses.
* Ad spend and expense ledger (daily or monthly), CSV import for Meta Ads and Google Ads exports, allocated to orders by day in proportion to revenue.
* Recurring fixed costs (subscriptions, rent, salaries) converted to a daily amount.
* Backfill tool: calculates existing orders in batches of 200 with a progress bar.
* Reports under WooCommerce > Profit: date presets, KPIs with comparison to the previous period, trend chart, sortable breakdown tables with CSV export.
* Profit metabox on the order screen and a Profit column in the orders list.
* Optional weekly email summary.
* Compatible with High-Performance Order Storage (HPOS) and the legacy posts storage.
* No external requests, no CDN assets, no jQuery dependency on the front end. Charts are drawn with a small built-in canvas script.
* Translation ready. Clean uninstall option.

== Installation ==

1. Upload the `profitlens` folder to `/wp-content/plugins/`, or use Plugins > Add New > Upload.
2. Activate the plugin. WooCommerce must be active.
3. Go to WooCommerce > Settings > ProfitLens to set payment fees, shipping and packaging costs.
4. Enter product costs (product edit screen, or WooCommerce > Profit > Product costs for CSV).
5. Open WooCommerce > Profit > Tools and run "Start calculation" once for existing orders.

== Frequently Asked Questions ==

= Does it work with HPOS? =
Yes. The plugin declares compatibility and only uses WooCommerce order APIs.

= Which orders count? =
Statuses chosen in the settings. Default: completed, processing, on-hold and refunded.

= How is ad spend allocated? =
Each day's ad spend and fixed costs are split across that day's orders in proportion to revenue. Spend on days without orders still reduces net profit in the report totals.

= Does changing a product cost change old orders? =
No. The cost is saved on each order item the first time the order is calculated. Use "Re-read product costs" in Tools to refresh.

= Does it support multiple currencies? =
Reports assume one store currency. Orders placed in other currencies are not converted.

== Changelog ==

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.0 =
First release.
