/*! ProfitLens chart - small dependency-free canvas chart (revenue line + profit bars). GPL-2.0-or-later */
(function (global) {
	'use strict';

	var COLORS = { rev: '#2271b1', pos: '#1a8a3d', neg: '#c62828', grid: '#dcdcde', axis: '#50575e', zero: '#8c8f94' };

	function niceStep(range, ticks) {
		var raw = range / Math.max(1, ticks);
		var mag = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10));
		var norm = raw / mag;
		var step = norm <= 1 ? 1 : norm <= 2 ? 2 : norm <= 5 ? 5 : 10;
		return step * mag;
	}

	function formatMoney(v, m, compact) {
		m = m || { symbol: '', position: 'left', decimals: 2, thousand: ',', decimal: '.' };
		var abs = Math.abs(v), suffix = '', dec = m.decimals;
		if (compact) {
			if (abs >= 1e6) { abs /= 1e6; suffix = 'M'; dec = 1; }
			else if (abs >= 1e4) { abs /= 1e3; suffix = 'k'; dec = 1; }
			else { dec = abs >= 100 ? 0 : Math.min(dec, 2); }
		}
		var parts = abs.toFixed(dec).split('.');
		parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, m.thousand);
		var num = parts.join(m.decimal) + suffix;
		var s = m.symbol;
		var out;
		switch (m.position) {
			case 'right': out = num + s; break;
			case 'left_space': out = s + ' ' + num; break;
			case 'right_space': out = num + ' ' + s; break;
			default: out = s + num;
		}
		return (v < 0 ? '-' : '') + out;
	}

	function shortLabel(label, unit) {
		if (unit === 'month') { return label; }
		return label.slice(5); // MM-DD
	}

	function Chart(canvas, data, money, i18n) {
		this.canvas = canvas;
		this.data = data;
		this.money = money;
		this.i18n = i18n || {};
		this.tip = canvas.parentNode.querySelector('.pl-tooltip');
		this.hover = -1;
		var self = this;
		canvas.addEventListener('mousemove', function (e) { self.onMove(e); });
		canvas.addEventListener('mouseleave', function () { self.hover = -1; self.draw(); self.hideTip(); });
		canvas.addEventListener('touchstart', function (e) { if (e.touches[0]) { self.onMove(e.touches[0]); } }, { passive: true });
		if (global.ResizeObserver) {
			new global.ResizeObserver(function () { self.draw(); }).observe(canvas.parentNode);
		} else {
			global.addEventListener('resize', function () { self.draw(); });
		}
		this.draw();
	}

	Chart.prototype.layout = function () {
		var w = this.canvas.parentNode.clientWidth || 600;
		var h = Math.max(220, Math.min(340, Math.round(w * 0.38)));
		var dpr = global.devicePixelRatio || 1;
		this.canvas.style.width = w + 'px';
		this.canvas.style.height = h + 'px';
		this.canvas.width = Math.round(w * dpr);
		this.canvas.height = Math.round(h * dpr);
		this.w = w; this.h = h; this.dpr = dpr;
		this.pad = { l: 64, r: 12, t: 12, b: 28 };
	};

	Chart.prototype.draw = function () {
		var pts = this.data.points || [];
		this.layout();
		var ctx = this.canvas.getContext('2d');
		ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
		ctx.clearRect(0, 0, this.w, this.h);
		ctx.font = '11px -apple-system, "Segoe UI", Roboto, sans-serif';

		var hasData = pts.some(function (p) { return p[1] !== 0 || p[2] !== 0; });
		if (!pts.length || !hasData) {
			ctx.fillStyle = COLORS.axis;
			ctx.textAlign = 'center';
			ctx.fillText(this.i18n.noData || 'No data', this.w / 2, this.h / 2);
			return;
		}
		var min = 0, max = 0, i;
		for (i = 0; i < pts.length; i++) {
			max = Math.max(max, pts[i][1], pts[i][2]);
			min = Math.min(min, pts[i][2]);
		}
		if (max === min) { max = min + 1; }
		var step = niceStep(max - min, 5);
		max = Math.ceil(max / step) * step;
		min = Math.floor(min / step) * step;

		var p = this.pad, cw = this.w - p.l - p.r, ch = this.h - p.t - p.b;
		var y = function (v) { return p.t + ch - ((v - min) / (max - min)) * ch; };
		this.y = y;

		ctx.strokeStyle = COLORS.grid; ctx.fillStyle = COLORS.axis; ctx.lineWidth = 1;
		ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
		for (var v = min; v <= max + step / 2; v += step) {
			var yy = Math.round(y(v)) + 0.5;
			ctx.beginPath(); ctx.moveTo(p.l, yy); ctx.lineTo(this.w - p.r, yy); ctx.stroke();
			ctx.fillText(formatMoney(v, this.money, true), p.l - 8, yy);
		}
		// Zero line.
		ctx.strokeStyle = COLORS.zero;
		ctx.beginPath(); ctx.moveTo(p.l, Math.round(y(0)) + 0.5); ctx.lineTo(this.w - p.r, Math.round(y(0)) + 0.5); ctx.stroke();

		var n = pts.length, slot = cw / n, bw = Math.max(1, Math.min(40, slot * 0.6));
		this.slot = slot;
		// Bars (profit).
		for (i = 0; i < n; i++) {
			var x = p.l + slot * i + (slot - bw) / 2;
			var v0 = y(0), v1 = y(pts[i][2]);
			ctx.fillStyle = pts[i][2] < 0 ? COLORS.neg : COLORS.pos;
			ctx.globalAlpha = (this.hover === i || this.hover < 0) ? 1 : 0.55;
			ctx.fillRect(x, Math.min(v0, v1), bw, Math.max(1, Math.abs(v1 - v0)));
		}
		ctx.globalAlpha = 1;
		// Line (revenue).
		ctx.strokeStyle = COLORS.rev; ctx.lineWidth = 2; ctx.lineJoin = 'round';
		ctx.beginPath();
		for (i = 0; i < n; i++) {
			var cx = p.l + slot * i + slot / 2;
			if (i === 0) { ctx.moveTo(cx, y(pts[i][1])); } else { ctx.lineTo(cx, y(pts[i][1])); }
		}
		ctx.stroke();
		if (n <= 45) {
			ctx.fillStyle = COLORS.rev;
			for (i = 0; i < n; i++) {
				ctx.beginPath(); ctx.arc(p.l + slot * i + slot / 2, y(pts[i][1]), 2.5, 0, Math.PI * 2); ctx.fill();
			}
		}
		// X labels.
		ctx.fillStyle = COLORS.axis; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
		var every = Math.max(1, Math.ceil(n / Math.max(2, Math.floor(cw / 56))));
		for (i = 0; i < n; i += every) {
			ctx.fillText(shortLabel(pts[i][0], this.data.unit), p.l + slot * i + slot / 2, this.h - p.b + 8);
		}
		if (this.hover >= 0) {
			ctx.strokeStyle = 'rgba(0,0,0,.25)'; ctx.lineWidth = 1;
			var hx = Math.round(p.l + slot * this.hover + slot / 2) + 0.5;
			ctx.beginPath(); ctx.moveTo(hx, p.t); ctx.lineTo(hx, p.t + ch); ctx.stroke();
		}
	};

	Chart.prototype.onMove = function (e) {
		var rect = this.canvas.getBoundingClientRect();
		var x = e.clientX - rect.left - this.pad.l;
		var i = Math.floor(x / this.slot);
		var pts = this.data.points || [];
		if (i < 0 || i >= pts.length) { this.hover = -1; this.draw(); this.hideTip(); return; }
		if (i !== this.hover) { this.hover = i; this.draw(); }
		var pt = pts[i], tip = this.tip;
		if (!tip) { return; }
		tip.textContent = '';
		var title = document.createElement('strong');
		title.textContent = pt[0];
		tip.appendChild(title);
		var rows = [
			[this.i18n.revenue || 'Revenue', formatMoney(pt[1], this.money, false)],
			[this.i18n.profit || 'Net profit', formatMoney(pt[2], this.money, false)],
			[this.i18n.orders || 'Orders', String(pt[3])]
		];
		rows.forEach(function (r) {
			var d = document.createElement('div');
			d.textContent = r[0] + ': ' + r[1];
			tip.appendChild(d);
		});
		tip.hidden = false;
		var left = this.pad.l + this.slot * i + this.slot / 2 + 12;
		if (left + tip.offsetWidth > this.w) { left -= tip.offsetWidth + 24; }
		tip.style.left = Math.max(0, left) + 'px';
		tip.style.top = (this.pad.t + 8) + 'px';
	};

	Chart.prototype.hideTip = function () { if (this.tip) { this.tip.hidden = true; } };

	global.PLChart = {
		init: function (canvas, money, i18n) {
			var data;
			try { data = JSON.parse(canvas.getAttribute('data-pl-chart')); } catch (err) { return null; }
			return new Chart(canvas, data, money, i18n);
		},
		formatMoney: formatMoney
	};
})(window);
