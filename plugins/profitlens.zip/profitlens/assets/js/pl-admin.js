/*! ProfitLens admin scripts. GPL-2.0-or-later */
(function () {
	'use strict';
	var cfg = window.plAdmin || {};
	var i18n = cfg.i18n || {};

	function ready(fn) {
		if (document.readyState !== 'loading') { fn(); } else { document.addEventListener('DOMContentLoaded', fn); }
	}

	function fmt(str) {
		var args = Array.prototype.slice.call(arguments, 1), i = 0;
		return str.replace(/%(\d\$)?s/g, function () { return args[i++]; });
	}

	ready(function () {
		// Charts.
		var canvases = document.querySelectorAll('canvas[data-pl-chart]');
		Array.prototype.forEach.call(canvases, function (c) {
			if (window.PLChart) { window.PLChart.init(c, cfg.money, i18n); }
		});

		// Show custom dates only for the custom preset.
		var preset = document.getElementById('pl-preset');
		var custom = document.querySelector('.pl-custom-dates');
		if (preset && custom) {
			var toggle = function () { custom.style.display = preset.value === 'custom' ? '' : 'none'; };
			preset.addEventListener('change', toggle);
			toggle();
		}

		// Daily / monthly entry toggle.
		var mode = document.querySelector('.pl-mode');
		if (mode) {
			var d = document.querySelector('.pl-mode-daily'), m = document.querySelector('.pl-mode-monthly');
			var sw = function () { d.hidden = mode.value === 'monthly'; m.hidden = mode.value !== 'monthly'; };
			mode.addEventListener('change', sw);
			sw();
		}

		// Confirm delete links.
		Array.prototype.forEach.call(document.querySelectorAll('a.pl-confirm'), function (a) {
			a.addEventListener('click', function (e) { if (!window.confirm(i18n.confirm || 'Are you sure?')) { e.preventDefault(); } });
		});

		// Backfill.
		var btn = document.getElementById('pl-backfill');
		if (!btn) { return; }
		var status = document.getElementById('pl-backfill-status');
		var wrap = document.querySelector('.pl-progress');
		var bar = wrap.querySelector('.pl-progress-bar');
		var inner = bar.querySelector('span');

		function setProgress(done, total) {
			var pct = total ? Math.round(done / total * 100) : 100;
			inner.style.width = pct + '%';
			bar.setAttribute('aria-valuenow', String(pct));
			status.textContent = fmt(i18n.processed || '%s of %s', done, total);
		}

		function step(page, refresh) {
			var body = new FormData();
			body.append('action', 'pl_backfill');
			body.append('nonce', cfg.nonce);
			body.append('page', String(page));
			body.append('refresh', refresh ? '1' : '0');
			fetch(cfg.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body })
				.then(function (r) { return r.json(); })
				.then(function (res) {
					if (!res || !res.success) { throw new Error('failed'); }
					setProgress(res.data.processed, res.data.total);
					if (res.data.done) {
						status.textContent = fmt(i18n.finished || 'Finished (%s)', res.data.total);
						btn.disabled = false;
					} else {
						step(res.data.next_page, refresh);
					}
				})
				.catch(function () {
					status.textContent = i18n.error || 'Error';
					btn.disabled = false;
				});
		}

		btn.addEventListener('click', function () {
			btn.disabled = true;
			wrap.hidden = false;
			setProgress(0, 0);
			status.textContent = i18n.running || 'Working...';
			var refresh = document.getElementById('pl-refresh');
			step(1, refresh && refresh.checked);
		});
	});
})();
