<?php
/**
 * WooCommerce > Settings > ProfitLens tab.
 *
 * @package ProfitLens
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings page.
 */
class ProfitLens_Settings_Page extends WC_Settings_Page {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->id    = 'profitlens';
		$this->label = __( 'ProfitLens', 'profitlens' );
		parent::__construct();
	}

	/**
	 * Sections.
	 *
	 * @return array
	 */
	protected function get_own_sections() {
		return array(
			''         => __( 'General & costs', 'profitlens' ),
			'fees'     => __( 'Payment fees', 'profitlens' ),
			'shipping' => __( 'Shipping & packaging', 'profitlens' ),
			'email'    => __( 'Weekly email', 'profitlens' ),
			'data'     => __( 'Data', 'profitlens' ),
		);
	}

	/**
	 * Settings for a section.
	 *
	 * @param string $section Section id.
	 * @return array
	 */
	protected function get_settings_for_section_core( $section ) {
		$d = ProfitLens_Settings::defaults();

		if ( 'fees' === $section ) {
			return array(
				array(
					'title' => __( 'Payment gateway fees', 'profitlens' ),
					'type'  => 'title',
					'desc'  => __( 'Fee = order total x percentage + fixed fee. Example: Stripe in Australia is 1.75% + 0.30. If the gateway stores the real fee on the order, the real fee is used instead (when enabled below).', 'profitlens' ),
					'id'    => 'pl_fees_title',
				),
				array(
					'title'   => __( 'Use actual fees', 'profitlens' ),
					'desc'    => __( 'Use the fee stored by the gateway (Stripe, PayPal) when it exists', 'profitlens' ),
					'id'      => 'pl_use_actual_fees',
					'type'    => 'checkbox',
					'default' => $d['use_actual_fees'],
				),
				array(
					'title'    => __( 'Extra fee meta keys', 'profitlens' ),
					'desc'     => __( 'Optional. Order meta keys (comma separated) that hold the real gateway fee as a number.', 'profitlens' ),
					'desc_tip' => true,
					'id'       => 'pl_fee_meta_keys',
					'type'     => 'text',
					'css'      => 'min-width:350px;',
					'default'  => '',
				),
				array(
					'title' => __( 'Fee rules', 'profitlens' ),
					'desc'  => __( 'Leave empty for gateways that do not charge you (bank transfer, cash on delivery).', 'profitlens' ),
					'id'    => 'pl_gateway_fees',
					'type'  => 'pl_gateway_fees',
				),
				array(
					'type' => 'sectionend',
					'id'   => 'pl_fees_title',
				),
			);
		}

		if ( 'shipping' === $section ) {
			return array(
				array(
					'title' => __( 'Shipping & packaging', 'profitlens' ),
					'type'  => 'title',
					'desc'  => __( 'What you actually pay carriers and spend on packaging. You can override the shipping cost on each order.', 'profitlens' ),
					'id'    => 'pl_ship_title',
				),
				array(
					'title'   => __( 'When no shipping cost is known', 'profitlens' ),
					'id'      => 'pl_shipping_fallback',
					'type'    => 'select',
					'class'   => 'wc-enhanced-select',
					'default' => $d['shipping_fallback'],
					'options' => array(
						'income' => __( 'Assume cost equals what the customer paid for shipping', 'profitlens' ),
						'zero'   => __( 'Assume zero cost', 'profitlens' ),
					),
				),
				array(
					'title' => __( 'Default cost per shipping method', 'profitlens' ),
					'desc'  => __( 'Applies to orders that use the method and have no per-order cost. Leave blank to use the setting above.', 'profitlens' ),
					'id'    => 'pl_shipping_costs',
					'type'  => 'pl_shipping_costs',
				),
				array(
					'title'             => __( 'Packaging cost per order', 'profitlens' ),
					'id'                => 'pl_packaging_cost',
					'type'              => 'text',
					'css'               => 'width:100px;',
					'class'             => 'wc_input_price',
					'default'           => '0',
					'desc_tip'          => __( 'Box, tape, label, filler: the average per order.', 'profitlens' ),
				),
				array(
					'title'   => __( 'Packaging applies to', 'profitlens' ),
					'desc'    => __( 'Only orders that contain a physical product', 'profitlens' ),
					'id'      => 'pl_packaging_physical',
					'type'    => 'checkbox',
					'default' => $d['packaging_physical'],
				),
				array(
					'type' => 'sectionend',
					'id'   => 'pl_ship_title',
				),
			);
		}

		if ( 'email' === $section ) {
			return array(
				array(
					'title' => __( 'Weekly email summary', 'profitlens' ),
					'type'  => 'title',
					'desc'  => __( 'A short profit summary for the last 7 days, sent every Monday morning (site time) using WP-Cron.', 'profitlens' ),
					'id'    => 'pl_email_title',
				),
				array(
					'title'   => __( 'Enable', 'profitlens' ),
					'desc'    => __( 'Send the weekly summary', 'profitlens' ),
					'id'      => 'pl_weekly_email',
					'type'    => 'checkbox',
					'default' => 'no',
				),
				array(
					'title'    => __( 'Recipients', 'profitlens' ),
					'desc'     => __( 'Comma separated email addresses. Defaults to the site admin email.', 'profitlens' ),
					'desc_tip' => true,
					'id'       => 'pl_email_to',
					'type'     => 'text',
					'css'      => 'min-width:350px;',
					'default'  => '',
				),
				array(
					'type' => 'sectionend',
					'id'   => 'pl_email_title',
				),
			);
		}

		if ( 'data' === $section ) {
			return array(
				array(
					'title' => __( 'Data', 'profitlens' ),
					'type'  => 'title',
					'id'    => 'pl_data_title',
				),
				array(
					'title'   => __( 'Delete data on uninstall', 'profitlens' ),
					'desc'    => __( 'When the plugin is deleted, remove all ProfitLens tables, costs, expenses and settings. Leave unticked to keep your data.', 'profitlens' ),
					'id'      => 'pl_delete_data',
					'type'    => 'checkbox',
					'default' => 'no',
				),
				array(
					'type' => 'sectionend',
					'id'   => 'pl_data_title',
				),
			);
		}

		// General.
		return array(
			array(
				'title' => __( 'ProfitLens', 'profitlens' ),
				'type'  => 'title',
				'desc'  => __( 'Define which orders count and where product costs come from.', 'profitlens' ),
				'id'    => 'pl_general_title',
			),
			array(
				'title'    => __( 'Order statuses to include', 'profitlens' ),
				'id'       => 'pl_counted_statuses',
				'type'     => 'multiselect',
				'class'    => 'wc-enhanced-select',
				'css'      => 'min-width:350px;',
				'default'  => $d['counted_statuses'],
				'options'  => wc_get_order_statuses(),
				'desc_tip' => __( 'Orders in other statuses (pending, cancelled, failed) are ignored.', 'profitlens' ),
			),
			array(
				'title'    => __( 'Default margin %', 'profitlens' ),
				'desc'     => __( 'Fallback for products without a cost: cost is estimated as sale price x (100 - margin)%. Leave blank to treat missing costs as zero.', 'profitlens' ),
				'desc_tip' => true,
				'id'       => 'pl_default_margin',
				'type'     => 'text',
				'css'      => 'width:100px;',
				'default'  => '',
			),
			array(
				'title'    => __( 'Other cost meta keys', 'profitlens' ),
				'desc'     => __( 'Product meta keys read when ProfitLens has no cost for a product, in priority order. Defaults cover WooCommerce core cost of goods, WooCommerce Cost of Goods, the Alg/WPFactory plugin and YITH.', 'profitlens' ),
				'desc_tip' => true,
				'id'       => 'pl_cost_meta_keys',
				'type'     => 'textarea',
				'css'      => 'min-width:350px;height:60px;',
				'default'  => $d['cost_meta_keys'],
			),
			array(
				'title'   => __( 'Refunded items', 'profitlens' ),
				'desc'    => __( 'Treat refunded items as returned to stock (their cost of goods is not counted)', 'profitlens' ),
				'id'      => 'pl_recover_cogs_refund',
				'type'    => 'checkbox',
				'default' => 'yes',
			),
			array(
				'title'   => __( 'Country reports use', 'profitlens' ),
				'id'      => 'pl_country_source',
				'type'    => 'select',
				'class'   => 'wc-enhanced-select',
				'default' => 'billing',
				'options' => array(
					'billing'  => __( 'Billing country', 'profitlens' ),
					'shipping' => __( 'Shipping country (falls back to billing)', 'profitlens' ),
				),
			),
			array(
				'type' => 'sectionend',
				'id'   => 'pl_general_title',
			),
		);
	}
}
