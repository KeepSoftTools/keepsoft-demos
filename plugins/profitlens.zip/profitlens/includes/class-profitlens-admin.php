<?php
/**
 * Admin screens: reports, expenses, costs and tools.
 *
 * @package ProfitLens
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin UI.
 */
class ProfitLens_Admin {

	const PAGE = 'profitlens';

	/**
	 * Screen hook suffix.
	 *
	 * @var string
	 */
	private static $hook = '';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_pl_export_report', array( __CLASS__, 'handle_export' ) );
	}

	/**
	 * Store a notice for the next page load.
	 *
	 * @param string $type    success|error|warning.
	 * @param string $message Message.
	 */
	public static function flash( $type, $message ) {
		set_transient(
			'pl_flash_' . get_current_user_id(),
			array(
				'type'    => $type,
				'message' => $message,
			),
			120
		);
	}

	/**
	 * Register the menu item under WooCommerce.
	 */
	public static function menu() {
		self::$hook = add_submenu_page(
			'woocommerce',
			__( 'Profit', 'profitlens' ),
			__( 'Profit', 'profitlens' ),
			'manage_woocommerce',
			self::PAGE,
			array( __CLASS__, 'render' )
		);
	}

	/**
	 * Enqueue CSS/JS where needed.
	 *
	 * @param string $hook Current admin hook.
	 */
	public static function assets( $hook ) {
		$screen    = get_current_screen();
		$screen_id = $screen ? $screen->id : '';
		$is_ours   = ( $hook === self::$hook );
		$is_order  = in_array( $screen_id, array( 'shop_order', 'edit-shop_order', 'woocommerce_page_wc-orders' ), true );
		if ( ! $is_ours && ! $is_order ) {
			return;
		}
		wp_enqueue_style( 'profitlens-admin', PL_URL . 'assets/css/pl-admin.css', array(), PL_VERSION );
		if ( ! $is_ours ) {
			return;
		}
		wp_enqueue_script( 'profitlens-chart', PL_URL . 'assets/js/pl-chart.js', array(), PL_VERSION, true );
		wp_enqueue_script( 'profitlens-admin', PL_URL . 'assets/js/pl-admin.js', array( 'profitlens-chart' ), PL_VERSION, true );
		wp_localize_script(
			'profitlens-admin',
			'plAdmin',
			array(
				'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'pl_backfill' ),
				'money'    => array(
					'symbol'   => html_entity_decode( get_woocommerce_currency_symbol() ),
					'position' => get_option( 'woocommerce_currency_pos', 'left' ),
					'decimals' => wc_get_price_decimals(),
					'thousand' => wc_get_price_thousand_separator(),
					'decimal'  => wc_get_price_decimal_separator(),
				),
				'i18n'     => array(
					'revenue'   => __( 'Revenue', 'profitlens' ),
					'profit'    => __( 'Net profit', 'profitlens' ),
					'orders'    => __( 'Orders', 'profitlens' ),
					'noData'    => __( 'No orders in this period.', 'profitlens' ),
					'running'   => __( 'Working...', 'profitlens' ),
					'processed' => __( '%1$s of %2$s orders processed', 'profitlens' ),
					'finished'  => __( 'Finished. Profit has been calculated for %s orders.', 'profitlens' ),
					'error'     => __( 'Something went wrong. Please try again.', 'profitlens' ),
					'confirm'   => __( 'Are you sure?', 'profitlens' ),
				),
			)
		);
	}

	/**
	 * Tabs.
	 *
	 * @return array
	 */
	private static function tabs() {
		return array(
			'reports'  => __( 'Reports', 'profitlens' ),
			'expenses' => __( 'Ad spend & expenses', 'profitlens' ),
			'costs'    => __( 'Product costs', 'profitlens' ),
			'tools'    => __( 'Tools', 'profitlens' ),
		);
	}

	/**
	 * Render the page shell.
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'profitlens' ) );
		}
		$tabs = self::tabs();
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'reports'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $tabs[ $tab ] ) ) {
			$tab = 'reports';
		}
		echo '<div class="wrap pl-wrap"><h1 class="wp-heading-inline">' . esc_html__( 'Profit', 'profitlens' ) . '</h1>';
		echo ' <a class="page-title-action" href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=profitlens' ) ) . '">' . esc_html__( 'Settings', 'profitlens' ) . '</a><hr class="wp-header-end">';

		$flash = get_transient( 'pl_flash_' . get_current_user_id() );
		if ( $flash ) {
			delete_transient( 'pl_flash_' . get_current_user_id() );
			$type = in_array( $flash['type'], array( 'success', 'error', 'warning' ), true ) ? $flash['type'] : 'info';
			echo '<div class="notice notice-' . esc_attr( $type ) . ' is-dismissible"><p>' . esc_html( $flash['message'] ) . '</p></div>';
		}

		echo '<nav class="nav-tab-wrapper pl-tabs">';
		foreach ( $tabs as $key => $label ) {
			printf(
				'<a href="%s" class="nav-tab%s">%s</a>',
				esc_url( admin_url( 'admin.php?page=' . self::PAGE . '&tab=' . $key ) ),
				$key === $tab ? ' nav-tab-active' : '',
				esc_html( $label )
			);
		}
		echo '</nav>';

		call_user_func( array( __CLASS__, 'tab_' . $tab ) );
		echo '</div>';
	}

	/**
	 * Read the report filter from the request.
	 *
	 * @return array { from, to, preset, dim, orderby, order }
	 */
	private static function request_filter() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only filters.
		$preset = isset( $_GET['preset'] ) ? sanitize_key( wp_unslash( $_GET['preset'] ) ) : 'last30';
		$from   = isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '';
		$to     = isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '';
		$dim    = isset( $_GET['dim'] ) ? sanitize_key( wp_unslash( $_GET['dim'] ) ) : 'product';
		$orderby = isset( $_GET['orderby'] ) ? sanitize_key( wp_unslash( $_GET['orderby'] ) ) : 'profit';
		$order   = ( isset( $_GET['order'] ) && 'asc' === sanitize_key( wp_unslash( $_GET['order'] ) ) ) ? 'asc' : 'desc';
		// phpcs:enable
		if ( ! isset( ProfitLens_Reports::presets()[ $preset ] ) ) {
			$preset = 'last30';
		}
		if ( ! isset( ProfitLens_Reports::dimensions()[ $dim ] ) ) {
			$dim = 'product';
		}
		list( $f, $t, $p ) = ProfitLens_Reports::resolve_range( $preset, $from, $to );
		return array(
			'from'    => $f,
			'to'      => $t,
			'preset'  => $p,
			'dim'     => $dim,
			'orderby' => $orderby,
			'order'   => $order,
		);
	}

	/**
	 * Format a value for a column type.
	 *
	 * @param mixed  $value Value.
	 * @param string $type  money|int|percent|text.
	 * @return string HTML.
	 */
	private static function fmt( $value, $type ) {
		switch ( $type ) {
			case 'money':
				return wp_kses_post( wc_price( $value ) );
			case 'int':
				return esc_html( number_format_i18n( (float) $value, floor( $value ) == $value ? 0 : 2 ) ); // phpcs:ignore Universal.Operators.StrictComparisons
			case 'percent':
				return esc_html( number_format_i18n( (float) $value, 1 ) ) . '%';
		}
		return esc_html( (string) $value );
	}

	/**
	 * Reports tab.
	 */
	private static function tab_reports() {
		$f = self::request_filter();
		list( $pf, $pt ) = ProfitLens_Reports::previous_range( $f['from'], $f['to'] );
		$k    = ProfitLens_Reports::kpis( $f['from'], $f['to'] );
		$prev = ProfitLens_Reports::kpis( $pf, $pt );

		self::filter_form( $f );

		// KPI cards.
		$cards = array(
			array( 'revenue', __( 'Revenue', 'profitlens' ), 'money', true ),
			array( 'cogs', __( 'Cost of goods', 'profitlens' ), 'money', false ),
			array( 'fees', __( 'Payment fees', 'profitlens' ), 'money', false ),
			array( 'shipping_cost', __( 'Shipping paid', 'profitlens' ), 'money', false ),
			array( 'ad', __( 'Ad spend', 'profitlens' ), 'money', false ),
			array( 'fixed', __( 'Fixed costs', 'profitlens' ), 'money', false ),
			array( 'profit', __( 'Net profit', 'profitlens' ), 'money', true ),
			array( 'margin', __( 'Net margin', 'profitlens' ), 'percent', true ),
			array( 'aov', __( 'Avg. order value', 'profitlens' ), 'money', true ),
			array( 'ppo', __( 'Profit per order', 'profitlens' ), 'money', true ),
		);
		echo '<div class="pl-cards">';
		foreach ( $cards as $card ) {
			list( $key, $label, $type, $good_up ) = $card;
			$value = $k[ $key ];
			$class = '';
			if ( 'profit' === $key || 'margin' === $key || 'ppo' === $key ) {
				$class = $value < 0 ? ' pl-card-neg' : ' pl-card-pos';
			}
			echo '<div class="pl-card' . esc_attr( $class ) . '"><span class="pl-card-label">' . esc_html( $label ) . '</span><strong class="pl-card-value">' . self::fmt( $value, $type ) . '</strong>'; // phpcs:ignore WordPress.Security.EscapeOutput
			$old = $prev[ $key ];
			if ( abs( $old ) > 0.005 ) {
				$pct = ( $value - $old ) / abs( $old ) * 100;
				$up  = $pct >= 0;
				$cls = ( $up === $good_up ) ? 'pl-delta-good' : 'pl-delta-bad';
				if ( ! in_array( $key, array( 'revenue', 'profit', 'margin', 'aov', 'ppo' ), true ) ) {
					$cls = 'pl-delta-neutral';
				}
				echo '<span class="pl-delta ' . esc_attr( $cls ) . '">' . ( $up ? '&#9650; ' : '&#9660; ' ) . esc_html( number_format_i18n( abs( $pct ), 1 ) ) . '% <em>' . esc_html__( 'vs previous period', 'profitlens' ) . '</em></span>';
			}
			echo '</div>';
		}
		echo '</div>';

		echo '<p class="pl-kpi-foot">' . esc_html(
			sprintf(
				/* translators: 1: orders, 2: shipping income, 3: tax */
				__( '%1$s orders. Revenue is net of refunds and tax and includes %2$s of shipping charged. Tax collected (not counted as revenue): %3$s.', 'profitlens' ),
				number_format_i18n( $k['orders'] ),
				wp_strip_all_tags( wc_price( $k['shipping_income'] ) ),
				wp_strip_all_tags( wc_price( $k['tax'] ) )
			)
		) . '</p>';

		if ( $k['missing_orders'] ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html(
				sprintf(
					/* translators: %d: number of orders */
					_n( '%d order in this period contains a product with no cost. Add costs under Product costs to get accurate profit.', '%d orders in this period contain a product with no cost. Add costs under Product costs to get accurate profit.', $k['missing_orders'], 'profitlens' ),
					$k['missing_orders']
				)
			) . '</p></div>';
		}
		if ( abs( $k['unallocated'] ) > 0.005 ) {
			echo '<div class="notice notice-info inline"><p>' . esc_html(
				sprintf(
					/* translators: %s: amount */
					__( '%s of ad spend and fixed costs fell on days without orders. It is included in net profit above but cannot be attributed to individual orders or products.', 'profitlens' ),
					wp_strip_all_tags( wc_price( $k['unallocated'] ) )
				)
			) . '</p></div>';
		}

		// Trend chart.
		$trend = ProfitLens_Reports::trend( $f['from'], $f['to'] );
		echo '<div class="pl-panel"><h2>' . esc_html__( 'Revenue and net profit', 'profitlens' ) . ' <small>(' . esc_html( 'month' === $trend['unit'] ? __( 'by month', 'profitlens' ) : __( 'by day', 'profitlens' ) ) . ')</small></h2>';
		echo '<div class="pl-chart-wrap"><canvas class="pl-chart" role="img" aria-label="' . esc_attr__( 'Chart of revenue and net profit over the selected period', 'profitlens' ) . '" data-pl-chart="' . esc_attr( wp_json_encode( $trend ) ) . '"></canvas><div class="pl-tooltip" hidden></div></div>';
		echo '<p class="pl-legend"><span class="pl-key pl-key-rev"></span>' . esc_html__( 'Revenue', 'profitlens' ) . ' <span class="pl-key pl-key-pos"></span>' . esc_html__( 'Profit', 'profitlens' ) . ' <span class="pl-key pl-key-neg"></span>' . esc_html__( 'Loss', 'profitlens' ) . '</p></div>';

		// Breakdowns.
		echo '<div class="pl-panel"><h2>' . esc_html__( 'Breakdown', 'profitlens' ) . '</h2><ul class="subsubsub pl-dims">';
		$dims  = ProfitLens_Reports::dimensions();
		$count = count( $dims );
		$n     = 0;
		foreach ( $dims as $key => $label ) {
			++$n;
			$url = add_query_arg(
				array(
					'page'   => self::PAGE,
					'tab'    => 'reports',
					'preset' => $f['preset'],
					'from'   => $f['from'],
					'to'     => $f['to'],
					'dim'    => $key,
				),
				admin_url( 'admin.php' )
			);
			echo '<li><a href="' . esc_url( $url ) . '"' . ( $key === $f['dim'] ? ' class="current"' : '' ) . '>' . esc_html( $label ) . '</a>' . ( $n < $count ? ' |' : '' ) . '</li> ';
		}
		echo '</ul><div class="clear"></div>';
		self::breakdown_table( $f );
		echo '</div>';
	}

	/**
	 * Date filter form.
	 *
	 * @param array $f Filter.
	 */
	private static function filter_form( $f ) {
		echo '<form method="get" class="pl-filter"><input type="hidden" name="page" value="' . esc_attr( self::PAGE ) . '"><input type="hidden" name="tab" value="reports"><input type="hidden" name="dim" value="' . esc_attr( $f['dim'] ) . '">';
		echo '<label class="screen-reader-text" for="pl-preset">' . esc_html__( 'Date range', 'profitlens' ) . '</label><select name="preset" id="pl-preset">';
		foreach ( ProfitLens_Reports::presets() as $key => $label ) {
			echo '<option value="' . esc_attr( $key ) . '"' . selected( $f['preset'], $key, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select> <span class="pl-custom-dates"><label>' . esc_html__( 'From', 'profitlens' ) . ' <input type="date" name="from" value="' . esc_attr( $f['from'] ) . '"></label> <label>' . esc_html__( 'To', 'profitlens' ) . ' <input type="date" name="to" value="' . esc_attr( $f['to'] ) . '"></label></span> ';
		echo '<button class="button button-primary" type="submit">' . esc_html__( 'Apply', 'profitlens' ) . '</button>';
		echo ' <span class="pl-range-label">' . esc_html( $f['from'] . '  -  ' . $f['to'] ) . '</span></form>';
	}

	/**
	 * Breakdown table.
	 *
	 * @param array $f Filter.
	 */
	private static function breakdown_table( $f ) {
		$limit = 200;
		$data  = ProfitLens_Reports::breakdown( $f['dim'], $f['from'], $f['to'], $f['orderby'], $f['order'], $limit );
		$cols  = ProfitLens_Reports::columns( $f['dim'] );
		$base  = array(
			'page'   => self::PAGE,
			'tab'    => 'reports',
			'preset' => $f['preset'],
			'from'   => $f['from'],
			'to'     => $f['to'],
			'dim'    => $f['dim'],
		);
		$export = wp_nonce_url(
			add_query_arg(
				array_merge(
					$base,
					array(
						'action'  => 'pl_export_report',
						'orderby' => $f['orderby'],
						'order'   => $f['order'],
					)
				),
				admin_url( 'admin-post.php' )
			),
			'pl_export_report'
		);
		echo '<p><a class="button" href="' . esc_url( $export ) . '">' . esc_html__( 'Export CSV', 'profitlens' ) . '</a></p>';

		if ( ! $data['rows'] ) {
			echo '<p>' . esc_html__( 'No data for this period yet. If you have existing orders, run the backfill under Tools.', 'profitlens' ) . '</p>';
			return;
		}
		echo '<div class="pl-table-scroll"><table class="widefat striped pl-table"><thead><tr>';
		foreach ( $cols as $key => $def ) {
			$is_cur = ( $key === $f['orderby'] );
			$next   = ( $is_cur && 'desc' === $f['order'] ) ? 'asc' : 'desc';
			if ( 'label' === $key && ! $is_cur ) {
				$next = 'asc';
			}
			$url   = add_query_arg( array_merge( $base, array( 'orderby' => $key, 'order' => $next ) ), admin_url( 'admin.php' ) );
			$arrow = $is_cur ? ( 'desc' === $f['order'] ? ' &#9660;' : ' &#9650;' ) : '';
			$cls   = 'label' === $key ? '' : ' class="pl-num"';
			echo '<th scope="col"' . $cls . ' aria-sort="' . esc_attr( $is_cur ? ( 'desc' === $f['order'] ? 'descending' : 'ascending' ) : 'none' ) . '"><a href="' . esc_url( $url ) . '">' . esc_html( $def[0] ) . $arrow . '</a></th>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</tr></thead><tbody>';
		foreach ( $data['rows'] as $row ) {
			$loss = ( $row['profit'] < 0 );
			echo '<tr' . ( $loss ? ' class="pl-loss"' : '' ) . '>';
			foreach ( $cols as $key => $def ) {
				if ( 'label' === $key ) {
					echo '<td>' . esc_html( $row['label'] );
					if ( $loss && in_array( $f['dim'], array( 'product', 'category' ), true ) ) {
						echo ' <span class="pl-badge-loss">' . esc_html__( 'Negative margin', 'profitlens' ) . '</span>';
					}
					if ( ! empty( $row['est'] ) && in_array( $f['dim'], array( 'product', 'category' ), true ) ) {
						echo ' <span class="pl-badge-warn" title="' . esc_attr__( 'Some sales of this product had no cost set.', 'profitlens' ) . '">' . esc_html__( 'No cost', 'profitlens' ) . '</span>';
					}
					echo '</td>';
					continue;
				}
				$extra = '';
				if ( 'profit' === $key || 'margin' === $key ) {
					$extra = $loss ? ' pl-neg' : '';
				}
				echo '<td class="pl-num' . esc_attr( $extra ) . '">' . self::fmt( $row[ $key ], $def[1] ) . '</td>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo '</tr>';
		}
		echo '</tbody></table></div>';
		if ( $data['total'] > $limit ) {
			echo '<p class="description">' . esc_html(
				sprintf(
					/* translators: 1: shown, 2: total */
					__( 'Showing %1$d of %2$d rows. Export the CSV to get everything.', 'profitlens' ),
					$limit,
					$data['total']
				)
			) . '</p>';
		}
		if ( in_array( $f['dim'], array( 'coupon' ), true ) ) {
			echo '<p class="description">' . esc_html__( 'Orders that used several coupons appear once under each coupon.', 'profitlens' ) . '</p>';
		}
		if ( in_array( $f['dim'], array( 'product', 'category' ), true ) ) {
			echo '<p class="description">' . esc_html__( 'Product and category revenue excludes shipping. Order-level costs (fees, shipping, ads) are shared between the items of an order by revenue. A product is counted in its first category.', 'profitlens' ) . '</p>';
		}
	}

	/**
	 * CSV export of the current breakdown.
	 */
	public static function handle_export() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'profitlens' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'pl_export_report' );
		$f    = self::request_filter();
		$data = ProfitLens_Reports::breakdown( $f['dim'], $f['from'], $f['to'], $f['orderby'], $f['order'], 0 );
		$cols = ProfitLens_Reports::columns( $f['dim'] );

		$head = array();
		foreach ( $cols as $def ) {
			$head[] = $def[0];
		}
		$head[] = __( 'Negative margin', 'profitlens' );
		$out    = array();
		foreach ( $data['rows'] as $row ) {
			$line = array();
			foreach ( $cols as $key => $def ) {
				if ( 'label' === $key ) {
					$line[] = $row['label'];
				} elseif ( 'int' === $def[1] ) {
					$line[] = 0 + round( $row[ $key ], 4 );
				} else {
					$line[] = number_format( (float) $row[ $key ], 2, '.', '' );
				}
			}
			$line[] = $row['profit'] < 0 ? __( 'Yes', 'profitlens' ) : '';
			$out[]  = $line;
		}
		ProfitLens_CSV::download( 'profitlens-' . $f['dim'] . '-' . $f['from'] . '-to-' . $f['to'] . '.csv', $head, $out );
	}

	/**
	 * Expenses tab.
	 */
	private static function tab_expenses() {
		global $wpdb;
		$exp = ProfitLens_Install::table( 'expenses' );
		$rec = ProfitLens_Install::table( 'recurring' );
		$sym = get_woocommerce_currency_symbol();

		echo '<div class="pl-grid">';

		// Add entry.
		echo '<div class="pl-panel"><h2>' . esc_html__( 'Add ad spend or expense', 'profitlens' ) . '</h2>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="pl-form"><input type="hidden" name="action" value="pl_add_expense">';
		wp_nonce_field( 'pl_add_expense' );
		echo '<p><label>' . esc_html__( 'Type', 'profitlens' ) . '<select name="kind"><option value="ad">' . esc_html__( 'Ad spend', 'profitlens' ) . '</option><option value="overhead">' . esc_html__( 'Other overhead (not a recurring cost)', 'profitlens' ) . '</option></select></label></p>';
		echo '<p><label>' . esc_html__( 'Applies to', 'profitlens' ) . '<select name="mode" class="pl-mode"><option value="daily">' . esc_html__( 'A single day', 'profitlens' ) . '</option><option value="monthly">' . esc_html__( 'A whole month (spread evenly)', 'profitlens' ) . '</option></select></label></p>';
		echo '<p class="pl-mode-daily"><label>' . esc_html__( 'Date', 'profitlens' ) . '<input type="date" name="date" value="' . esc_attr( wp_date( 'Y-m-d' ) ) . '"></label></p>';
		echo '<p class="pl-mode-monthly" hidden><label>' . esc_html__( 'Month', 'profitlens' ) . '<input type="month" name="month" value="' . esc_attr( wp_date( 'Y-m' ) ) . '"></label></p>';
		echo '<p><label>' . esc_html__( 'Channel', 'profitlens' ) . '<select name="source">';
		foreach ( ProfitLens_Expenses::sources() as $key => $label ) {
			echo '<option value="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</option>';
		}
		echo '</select></label></p>';
		/* translators: %s: currency symbol */
		echo '<p><label>' . esc_html( sprintf( __( 'Amount (%s)', 'profitlens' ), $sym ) ) . '<input type="text" name="amount" class="wc_input_price" required></label></p>';
		echo '<p><label>' . esc_html__( 'Campaign / description', 'profitlens' ) . '<input type="text" name="campaign" maxlength="190"></label></p>';
		echo '<p><button class="button button-primary" type="submit">' . esc_html__( 'Add entry', 'profitlens' ) . '</button></p></form></div>';

		// Import.
		echo '<div class="pl-panel"><h2>' . esc_html__( 'Import ad spend (CSV)', 'profitlens' ) . '</h2>';
		echo '<p>' . esc_html__( 'Upload a Meta Ads or Google Ads export, or any CSV with date, campaign and spend columns. Re-importing the same file updates existing rows instead of duplicating them.', 'profitlens' ) . '</p>';
		echo '<form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="pl-form"><input type="hidden" name="action" value="pl_import_ads">';
		wp_nonce_field( 'pl_import_ads' );
		echo '<p><label>' . esc_html__( 'Channel', 'profitlens' ) . '<select name="source">';
		foreach ( array( 'meta', 'google', 'tiktok', 'other' ) as $key ) {
			echo '<option value="' . esc_attr( $key ) . '">' . esc_html( ProfitLens_Expenses::sources()[ $key ] ) . '</option>';
		}
		echo '</select></label></p>';
		echo '<p><label>' . esc_html__( 'Date format in the file', 'profitlens' ) . '<select name="date_format"><option value="auto">' . esc_html__( 'Detect (2025-03-31 or 31/03/2025)', 'profitlens' ) . '</option><option value="dmy">' . esc_html__( 'Day/Month/Year', 'profitlens' ) . '</option><option value="mdy">' . esc_html__( 'Month/Day/Year', 'profitlens' ) . '</option></select></label></p>';
		echo '<p><input type="file" name="pl_file" accept=".csv,text/csv" required></p>';
		echo '<p><button class="button button-primary" type="submit">' . esc_html__( 'Import CSV', 'profitlens' ) . '</button></p></form>';
		echo '<p class="description">' . esc_html__( 'Recognised columns: Date / Day / Reporting starts (and optionally Reporting ends), Campaign / Campaign name, Spend / Cost / Amount spent.', 'profitlens' ) . '</p></div>';
		echo '</div>';

		// Recurring costs.
		echo '<div class="pl-panel"><h2>' . esc_html__( 'Recurring fixed costs', 'profitlens' ) . '</h2>';
		echo '<p>' . esc_html__( 'Subscriptions, rent, salaries. Each cost is converted to a daily amount and shared between that day\'s orders in proportion to revenue.', 'profitlens' ) . '</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="pl-inline-form"><input type="hidden" name="action" value="pl_save_recurring">';
		wp_nonce_field( 'pl_save_recurring' );
		echo '<input type="text" name="name" placeholder="' . esc_attr__( 'Name (e.g. Shopify plan)', 'profitlens' ) . '" required maxlength="190"> ';
		echo '<input type="text" name="amount" class="wc_input_price" placeholder="' . esc_attr__( 'Amount', 'profitlens' ) . '" required style="width:100px"> ';
		echo '<select name="period">';
		foreach ( ProfitLens_Expenses::periods() as $key => $label ) {
			echo '<option value="' . esc_attr( $key ) . '"' . selected( 'monthly', $key, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select> <label>' . esc_html__( 'From', 'profitlens' ) . ' <input type="date" name="date_start" value="' . esc_attr( wp_date( 'Y-m-01' ) ) . '" required></label> <label>' . esc_html__( 'Until (optional)', 'profitlens' ) . ' <input type="date" name="date_end"></label> ';
		echo '<button class="button" type="submit">' . esc_html__( 'Add recurring cost', 'profitlens' ) . '</button></form>';

		$items = $wpdb->get_results( "SELECT * FROM {$rec} ORDER BY date_start DESC, id DESC" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( $items ) {
			echo '<table class="widefat striped pl-table"><thead><tr><th>' . esc_html__( 'Name', 'profitlens' ) . '</th><th class="pl-num">' . esc_html__( 'Amount', 'profitlens' ) . '</th><th>' . esc_html__( 'Period', 'profitlens' ) . '</th><th>' . esc_html__( 'From', 'profitlens' ) . '</th><th>' . esc_html__( 'Until', 'profitlens' ) . '</th><th></th></tr></thead><tbody>';
			foreach ( $items as $item ) {
				$del = wp_nonce_url( admin_url( 'admin-post.php?action=pl_delete_recurring&id=' . (int) $item->id ), 'pl_delete_recurring_' . (int) $item->id );
				echo '<tr><td>' . esc_html( $item->name ) . '</td><td class="pl-num">' . wp_kses_post( wc_price( $item->amount ) ) . '</td><td>' . esc_html( isset( ProfitLens_Expenses::periods()[ $item->period ] ) ? ProfitLens_Expenses::periods()[ $item->period ] : $item->period ) . '</td><td>' . esc_html( $item->date_start ) . '</td><td>' . esc_html( $item->date_end ? $item->date_end : '-' ) . '</td><td><a class="pl-confirm" href="' . esc_url( $del ) . '">' . esc_html__( 'Delete', 'profitlens' ) . '</a></td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';

		// Ledger.
		$rows = $wpdb->get_results( "SELECT * FROM {$exp} ORDER BY date_start DESC, id DESC LIMIT 200" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		echo '<div class="pl-panel"><h2>' . esc_html__( 'Ledger (latest 200 entries)', 'profitlens' ) . '</h2>';
		if ( ! $rows ) {
			echo '<p>' . esc_html__( 'No entries yet.', 'profitlens' ) . '</p>';
		} else {
			echo '<div class="pl-table-scroll"><table class="widefat striped pl-table"><thead><tr><th>' . esc_html__( 'Date', 'profitlens' ) . '</th><th>' . esc_html__( 'Type', 'profitlens' ) . '</th><th>' . esc_html__( 'Channel', 'profitlens' ) . '</th><th>' . esc_html__( 'Campaign / note', 'profitlens' ) . '</th><th class="pl-num">' . esc_html__( 'Amount', 'profitlens' ) . '</th><th></th></tr></thead><tbody>';
			foreach ( $rows as $row ) {
				$del  = wp_nonce_url( admin_url( 'admin-post.php?action=pl_delete_expense&id=' . (int) $row->id ), 'pl_delete_expense_' . (int) $row->id );
				$date = $row->date_start === $row->date_end ? $row->date_start : $row->date_start . ' - ' . $row->date_end;
				$src  = isset( ProfitLens_Expenses::sources()[ $row->source ] ) ? ProfitLens_Expenses::sources()[ $row->source ] : $row->source;
				echo '<tr><td>' . esc_html( $date ) . '</td><td>' . esc_html( 'ad' === $row->kind ? __( 'Ad spend', 'profitlens' ) : __( 'Overhead', 'profitlens' ) ) . '</td><td>' . esc_html( $src ) . '</td><td>' . esc_html( trim( $row->campaign . ' ' . $row->note ) ) . '</td><td class="pl-num">' . wp_kses_post( wc_price( $row->amount ) ) . '</td><td><a class="pl-confirm" href="' . esc_url( $del ) . '">' . esc_html__( 'Delete', 'profitlens' ) . '</a></td></tr>';
			}
			echo '</tbody></table></div>';
		}
		echo '</div>';
	}

	/**
	 * Costs tab.
	 */
	private static function tab_costs() {
		global $wpdb;
		$with = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = %s AND pm.meta_value <> '' AND p.post_status <> 'trash'", ProfitLens_Costs::META_KEY ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		echo '<div class="pl-grid"><div class="pl-panel"><h2>' . esc_html__( 'Product costs', 'profitlens' ) . '</h2>';
		echo '<p>' . esc_html(
			sprintf(
				/* translators: %d: number of products with a cost */
				_n( '%d product or variation has a ProfitLens cost.', '%d products and variations have a ProfitLens cost.', $with, 'profitlens' ),
				$with
			)
		) . '</p>';
		echo '<p>' . esc_html__( 'Set a cost on the product edit screen (General tab, and each variation). Costs from WooCommerce\'s built-in cost of goods feature and the meta keys listed in the settings are used when no ProfitLens cost is set.', 'profitlens' ) . '</p>';
		$export = wp_nonce_url( admin_url( 'admin-post.php?action=pl_export_costs' ), 'pl_export_costs' );
		echo '<p><a class="button" href="' . esc_url( $export ) . '">' . esc_html__( 'Export costs (CSV)', 'profitlens' ) . '</a></p></div>';

		echo '<div class="pl-panel"><h2>' . esc_html__( 'Import costs (CSV)', 'profitlens' ) . '</h2>';
		echo '<p>' . esc_html__( 'Columns: product_id or sku, and cost. Use the export as a template. A blank cost clears the cost of that product. Variations can be matched by their own ID or SKU.', 'profitlens' ) . '</p>';
		echo '<form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="pl-form"><input type="hidden" name="action" value="pl_import_costs">';
		wp_nonce_field( 'pl_import_costs' );
		echo '<p><input type="file" name="pl_file" accept=".csv,text/csv" required></p><p><button class="button button-primary" type="submit">' . esc_html__( 'Import costs', 'profitlens' ) . '</button></p></form></div></div>';

		// Missing costs.
		$ids = get_posts(
			array(
				'post_type'      => array( 'product', 'product_variation' ),
				'post_status'    => array( 'publish', 'private' ),
				'posts_per_page' => 300,
				'fields'         => 'ids',
				'orderby'        => 'ID',
				'order'          => 'DESC',
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery
					array(
						'key'     => ProfitLens_Costs::META_KEY,
						'compare' => 'NOT EXISTS',
					),
				),
			)
		);
		$missing = array();
		foreach ( $ids as $id ) {
			$product = wc_get_product( $id );
			if ( ! $product || $product->is_type( 'variable' ) || $product->is_type( 'grouped' ) ) {
				continue;
			}
			$parent = $product->get_parent_id();
			if ( null !== ProfitLens_Costs::unit_cost( $parent ? $parent : $id, $parent ? $id : 0 ) ) {
				continue;
			}
			$missing[] = $product;
			if ( count( $missing ) >= 25 ) {
				break;
			}
		}
		echo '<div class="pl-panel"><h2>' . esc_html__( 'Products without a cost', 'profitlens' ) . '</h2>';
		if ( ! $missing ) {
			echo '<p>' . esc_html__( 'Every product checked has a cost. Nice.', 'profitlens' ) . '</p>';
		} else {
			echo '<p class="description">' . esc_html__( 'Most recent first (first 25 found).', 'profitlens' ) . '</p><ul class="pl-list">';
			foreach ( $missing as $product ) {
				$edit_id = $product->get_parent_id() ? $product->get_parent_id() : $product->get_id();
				echo '<li><a href="' . esc_url( get_edit_post_link( $edit_id ) ) . '">' . esc_html( wp_strip_all_tags( $product->get_formatted_name() ) ) . '</a></li>';
			}
			echo '</ul>';
		}
		echo '</div>';
	}

	/**
	 * Tools tab.
	 */
	private static function tab_tools() {
		global $wpdb;
		$rows = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . ProfitLens_Install::table( 'orders' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
		$last = (int) get_option( 'pl_last_backfill', 0 );

		echo '<div class="pl-grid"><div class="pl-panel"><h2>' . esc_html__( 'Calculate profit for existing orders', 'profitlens' ) . '</h2>';
		echo '<p>' . esc_html__( 'New orders are calculated automatically. Run this once after installing, and again after you change costs or settings that should apply to past orders. Orders are processed in batches of 200.', 'profitlens' ) . '</p>';
		echo '<p><label><input type="checkbox" id="pl-refresh"> ' . esc_html__( 'Re-read product costs (replaces the cost saved at the time of each sale)', 'profitlens' ) . '</label></p>';
		echo '<p><button type="button" class="button button-primary" id="pl-backfill">' . esc_html__( 'Start calculation', 'profitlens' ) . '</button></p>';
		echo '<div class="pl-progress" hidden><div class="pl-progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><span></span></div></div><p id="pl-backfill-status" aria-live="polite"></p>';
		echo '<p class="description">' . esc_html(
			sprintf(
				/* translators: 1: number of orders stored, 2: last run */
				__( 'Orders stored: %1$s. Last full run: %2$s.', 'profitlens' ),
				number_format_i18n( $rows ),
				$last ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $last ) : __( 'never', 'profitlens' )
			)
		) . '</p></div>';

		echo '<div class="pl-panel"><h2>' . esc_html__( 'Weekly email', 'profitlens' ) . '</h2>';
		echo '<p>' . esc_html(
			'yes' === ProfitLens_Settings::get( 'weekly_email' )
				? __( 'The weekly summary is enabled.', 'profitlens' )
				: __( 'The weekly summary is switched off. Turn it on in the ProfitLens settings.', 'profitlens' )
		) . '</p>';
		echo '<p><a class="button" href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=profitlens&section=email' ) ) . '">' . esc_html__( 'Email settings', 'profitlens' ) . '</a> ';
		$test = wp_nonce_url( admin_url( 'admin-post.php?action=pl_test_email' ), 'pl_test_email' );
		echo '<a class="button" href="' . esc_url( $test ) . '">' . esc_html__( 'Send a test summary now', 'profitlens' ) . '</a></p></div></div>';
	}
}
