<?php
/**
 * Ad spend / expense ledger and recurring fixed costs.
 *
 * @package ProfitLens
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Expenses.
 */
class ProfitLens_Expenses {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_post_pl_add_expense', array( __CLASS__, 'handle_add_expense' ) );
		add_action( 'admin_post_pl_delete_expense', array( __CLASS__, 'handle_delete_expense' ) );
		add_action( 'admin_post_pl_import_ads', array( __CLASS__, 'handle_import_ads' ) );
		add_action( 'admin_post_pl_save_recurring', array( __CLASS__, 'handle_save_recurring' ) );
		add_action( 'admin_post_pl_delete_recurring', array( __CLASS__, 'handle_delete_recurring' ) );
	}

	/**
	 * Permission guard shared by all handlers.
	 *
	 * @param string $nonce_action Nonce action.
	 */
	private static function guard( $nonce_action ) {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'profitlens' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( $nonce_action );
	}

	/**
	 * Redirect back to the expenses tab.
	 */
	private static function back() {
		wp_safe_redirect( admin_url( 'admin.php?page=profitlens&tab=expenses' ) );
		exit;
	}

	/**
	 * Sources available for ad spend.
	 *
	 * @return array
	 */
	public static function sources() {
		return array(
			'manual' => __( 'Manual', 'profitlens' ),
			'meta'   => __( 'Meta Ads', 'profitlens' ),
			'google' => __( 'Google Ads', 'profitlens' ),
			'tiktok' => __( 'TikTok Ads', 'profitlens' ),
			'other'  => __( 'Other', 'profitlens' ),
		);
	}

	/**
	 * Recurring periods.
	 *
	 * @return array
	 */
	public static function periods() {
		return array(
			'daily'   => __( 'Daily', 'profitlens' ),
			'weekly'  => __( 'Weekly', 'profitlens' ),
			'monthly' => __( 'Monthly', 'profitlens' ),
			'yearly'  => __( 'Yearly', 'profitlens' ),
		);
	}

	/**
	 * Per-day expense totals for a date range.
	 *
	 * @param string $from  Y-m-d.
	 * @param string $to    Y-m-d.
	 * @param bool   $clip  Ignore days after today.
	 * @return array date => array( 'ad' => float, 'fixed' => float )
	 */
	public static function daily_totals( $from, $to, $clip = false ) {
		global $wpdb;
		if ( $clip ) {
			$today = wp_date( 'Y-m-d' );
			if ( $to > $today ) {
				$to = $today;
			}
		}
		$out = array();
		if ( $from > $to ) {
			return $out;
		}
		$cur = new DateTime( $from );
		$end = new DateTime( $to );
		while ( $cur <= $end ) {
			$out[ $cur->format( 'Y-m-d' ) ] = array(
				'ad'    => 0.0,
				'fixed' => 0.0,
			);
			$cur->modify( '+1 day' );
		}

		$table = ProfitLens_Install::table( 'expenses' );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT date_start, date_end, kind, amount FROM {$table} WHERE date_start <= %s AND date_end >= %s", $to, $from ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		foreach ( (array) $rows as $row ) {
			$start = new DateTime( $row->date_start );
			$stop  = new DateTime( $row->date_end );
			$days  = (int) $start->diff( $stop )->days + 1;
			$per   = (float) $row->amount / $days;
			$key   = 'ad' === $row->kind ? 'ad' : 'fixed';
			$d1    = max( $row->date_start, $from );
			$d2    = min( $row->date_end, $to );
			$cur   = new DateTime( $d1 );
			$last  = new DateTime( $d2 );
			while ( $cur <= $last ) {
				$k = $cur->format( 'Y-m-d' );
				if ( isset( $out[ $k ] ) ) {
					$out[ $k ][ $key ] += $per;
				}
				$cur->modify( '+1 day' );
			}
		}

		$rec = $wpdb->get_results( 'SELECT amount, period, date_start, date_end FROM ' . ProfitLens_Install::table( 'recurring' ) . ' WHERE active = 1' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
		foreach ( (array) $rec as $item ) {
			foreach ( $out as $day => $vals ) {
				if ( $day < $item->date_start || ( $item->date_end && $day > $item->date_end ) ) {
					continue;
				}
				$out[ $day ]['fixed'] += self::daily_amount( (float) $item->amount, $item->period, $day );
			}
		}
		return $out;
	}

	/**
	 * Daily share of a recurring amount.
	 *
	 * @param float  $amount Amount per period.
	 * @param string $period daily|weekly|monthly|yearly.
	 * @param string $day    Y-m-d.
	 * @return float
	 */
	public static function daily_amount( $amount, $period, $day ) {
		$ts = strtotime( $day . ' 12:00:00 UTC' );
		switch ( $period ) {
			case 'daily':
				return $amount;
			case 'weekly':
				return $amount / 7;
			case 'yearly':
				return $amount / ( (int) gmdate( 'L', $ts ) ? 366 : 365 );
			case 'monthly':
			default:
				return $amount / (int) gmdate( 't', $ts );
		}
	}

	/**
	 * Re-run day allocation for a date range.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 */
	private static function refresh( $from, $to ) {
		ProfitLens_Engine::reallocate_range( $from, $to );
	}

	/**
	 * Add a manual ledger entry.
	 */
	public static function handle_add_expense() {
		self::guard( 'pl_add_expense' );
		global $wpdb;

		$kind   = isset( $_POST['kind'] ) && 'overhead' === sanitize_key( wp_unslash( $_POST['kind'] ) ) ? 'overhead' : 'ad';
		$mode   = isset( $_POST['mode'] ) && 'monthly' === sanitize_key( wp_unslash( $_POST['mode'] ) ) ? 'monthly' : 'daily';
		$source = isset( $_POST['source'] ) ? sanitize_key( wp_unslash( $_POST['source'] ) ) : 'manual';
		if ( ! isset( self::sources()[ $source ] ) ) {
			$source = 'manual';
		}
		$campaign = isset( $_POST['campaign'] ) ? mb_substr( sanitize_text_field( wp_unslash( $_POST['campaign'] ) ), 0, 190 ) : '';
		$note     = isset( $_POST['note'] ) ? mb_substr( sanitize_text_field( wp_unslash( $_POST['note'] ) ), 0, 255 ) : '';
		$amount   = isset( $_POST['amount'] ) ? (float) wc_format_decimal( wp_unslash( $_POST['amount'] ) ) : 0; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( $amount <= 0 ) {
			ProfitLens_Admin::flash( 'error', __( 'Enter an amount greater than zero.', 'profitlens' ) );
			self::back();
		}

		if ( 'monthly' === $mode ) {
			$month = isset( $_POST['month'] ) ? sanitize_text_field( wp_unslash( $_POST['month'] ) ) : '';
			if ( ! preg_match( '/^\d{4}-\d{2}$/', $month ) || ! checkdate( (int) substr( $month, 5, 2 ), 1, (int) substr( $month, 0, 4 ) ) ) {
				ProfitLens_Admin::flash( 'error', __( 'Choose a valid month.', 'profitlens' ) );
				self::back();
			}
			$start = $month . '-01';
			$end   = gmdate( 'Y-m-t', strtotime( $start . ' 12:00:00 UTC' ) );
		} else {
			$date  = isset( $_POST['date'] ) ? ProfitLens_CSV::parse_date( sanitize_text_field( wp_unslash( $_POST['date'] ) ), 'auto' ) : null;
			$start = $date;
			$end   = $date;
			if ( ! $date ) {
				ProfitLens_Admin::flash( 'error', __( 'Choose a valid date.', 'profitlens' ) );
				self::back();
			}
		}

		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			ProfitLens_Install::table( 'expenses' ),
			array(
				'date_start' => $start,
				'date_end'   => $end,
				'kind'       => $kind,
				'source'     => 'ad' === $kind ? $source : 'manual',
				'campaign'   => $campaign,
				'amount'     => $amount,
				'note'       => $note,
				'created_at' => current_time( 'mysql', true ),
			)
		);
		self::refresh( $start, $end );
		ProfitLens_Admin::flash( 'success', __( 'Expense saved and profit re-allocated.', 'profitlens' ) );
		self::back();
	}

	/**
	 * Delete a ledger entry.
	 */
	public static function handle_delete_expense() {
		$id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- verified in guard().
		self::guard( 'pl_delete_expense_' . $id );
		global $wpdb;
		$table = ProfitLens_Install::table( 'expenses' );
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT date_start, date_end FROM {$table} WHERE id = %d", $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( $row ) {
			$wpdb->delete( $table, array( 'id' => $id ), array( '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			self::refresh( $row->date_start, $row->date_end );
			ProfitLens_Admin::flash( 'success', __( 'Entry deleted.', 'profitlens' ) );
		}
		self::back();
	}

	/**
	 * Match a header cell against candidate names.
	 *
	 * @param array $header     Normalised header.
	 * @param array $exact      Exact names.
	 * @param array $prefixes   Name prefixes.
	 * @return int|null
	 */
	private static function find_header( array $header, array $exact, array $prefixes = array() ) {
		foreach ( $exact as $name ) {
			$pos = array_search( $name, $header, true );
			if ( false !== $pos ) {
				return (int) $pos;
			}
		}
		foreach ( $header as $i => $cell ) {
			foreach ( $prefixes as $prefix ) {
				if ( 0 === strpos( $cell, $prefix ) ) {
					return (int) $i;
				}
			}
		}
		return null;
	}

	/**
	 * Import an ads export (Meta Ads, Google Ads or any CSV with date/campaign/spend).
	 */
	public static function handle_import_ads() {
		self::guard( 'pl_import_ads' );
		global $wpdb;

		$path = ProfitLens_CSV::uploaded_path();
		if ( is_wp_error( $path ) ) {
			ProfitLens_Admin::flash( 'error', $path->get_error_message() );
			self::back();
		}
		$rows = ProfitLens_CSV::read( $path );
		if ( is_wp_error( $rows ) ) {
			ProfitLens_Admin::flash( 'error', $rows->get_error_message() );
			self::back();
		}
		$source = isset( $_POST['source'] ) ? sanitize_key( wp_unslash( $_POST['source'] ) ) : 'meta';
		if ( ! isset( self::sources()[ $source ] ) ) {
			$source = 'other';
		}
		$format = isset( $_POST['date_format'] ) ? sanitize_key( wp_unslash( $_POST['date_format'] ) ) : 'auto';
		if ( ! in_array( $format, array( 'auto', 'dmy', 'mdy' ), true ) ) {
			$format = 'auto';
		}

		// Find the header row (Google exports have title rows above it).
		$hdr_at = null;
		$cols   = array();
		foreach ( array_slice( $rows, 0, 15, true ) as $n => $row ) {
			$norm  = array_map( 'strtolower', $row );
			$date  = self::find_header( $norm, array( 'date', 'day', 'reporting starts', 'reporting_starts', 'date start', 'start date' ) );
			$spend = self::find_header( $norm, array( 'spend', 'cost', 'amount spent', 'amount_spent', 'total spend' ), array( 'amount spent', 'cost' ) );
			if ( null !== $date && null !== $spend ) {
				$hdr_at = $n;
				$cols   = array(
					'date'     => $date,
					'spend'    => $spend,
					'campaign' => self::find_header( $norm, array( 'campaign', 'campaign name', 'campaign_name' ), array( 'campaign' ) ),
					'end'      => self::find_header( $norm, array( 'reporting ends', 'reporting_ends', 'end date', 'date end' ) ),
				);
				break;
			}
		}
		if ( null === $hdr_at ) {
			ProfitLens_Admin::flash( 'error', __( 'Could not find the columns. The CSV needs a date column (Date / Day / Reporting starts) and a spend column (Spend / Cost / Amount spent).', 'profitlens' ) );
			self::back();
		}

		$table    = ProfitLens_Install::table( 'expenses' );
		$inserted = 0;
		$updated  = 0;
		$skipped  = 0;
		$min      = null;
		$max      = null;
		foreach ( array_slice( $rows, $hdr_at + 1 ) as $row ) {
			$start = isset( $row[ $cols['date'] ] ) ? ProfitLens_CSV::parse_date( $row[ $cols['date'] ], $format ) : null;
			$spend = isset( $row[ $cols['spend'] ] ) ? ProfitLens_CSV::parse_number( $row[ $cols['spend'] ] ) : null;
			if ( ! $start || null === $spend || $spend <= 0 ) {
				++$skipped;
				continue;
			}
			$end = $start;
			if ( null !== $cols['end'] && ! empty( $row[ $cols['end'] ] ) ) {
				$maybe = ProfitLens_CSV::parse_date( $row[ $cols['end'] ], $format );
				if ( $maybe && $maybe >= $start && ( strtotime( $maybe ) - strtotime( $start ) ) <= 400 * DAY_IN_SECONDS ) {
					$end = $maybe;
				}
			}
			$campaign = ( null !== $cols['campaign'] && isset( $row[ $cols['campaign'] ] ) ) ? mb_substr( sanitize_text_field( $row[ $cols['campaign'] ] ), 0, 190 ) : '';
			$existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE kind = 'ad' AND source = %s AND campaign = %s AND date_start = %s AND date_end = %s", $source, $campaign, $start, $end ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			if ( $existing ) {
				$wpdb->update( $table, array( 'amount' => $spend ), array( 'id' => (int) $existing ), array( '%f' ), array( '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				++$updated;
			} else {
				$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
					$table,
					array(
						'date_start' => $start,
						'date_end'   => $end,
						'kind'       => 'ad',
						'source'     => $source,
						'campaign'   => $campaign,
						'amount'     => $spend,
						'note'       => '',
						'created_at' => current_time( 'mysql', true ),
					)
				);
				++$inserted;
			}
			$min = ( null === $min || $start < $min ) ? $start : $min;
			$max = ( null === $max || $end > $max ) ? $end : $max;
		}
		if ( $min ) {
			self::refresh( $min, $max );
		}
		ProfitLens_Admin::flash(
			( $inserted + $updated ) ? 'success' : 'warning',
			sprintf(
				/* translators: 1: new rows, 2: updated rows, 3: skipped rows */
				__( 'Ad spend import finished: %1$d added, %2$d updated, %3$d skipped (blank, zero or total rows).', 'profitlens' ),
				$inserted,
				$updated,
				$skipped
			)
		);
		self::back();
	}

	/**
	 * Save a recurring cost.
	 */
	public static function handle_save_recurring() {
		self::guard( 'pl_save_recurring' );
		global $wpdb;

		$name   = isset( $_POST['name'] ) ? mb_substr( sanitize_text_field( wp_unslash( $_POST['name'] ) ), 0, 190 ) : '';
		$amount = isset( $_POST['amount'] ) ? (float) wc_format_decimal( wp_unslash( $_POST['amount'] ) ) : 0; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$period = isset( $_POST['period'] ) ? sanitize_key( wp_unslash( $_POST['period'] ) ) : 'monthly';
		$start  = isset( $_POST['date_start'] ) ? ProfitLens_CSV::parse_date( sanitize_text_field( wp_unslash( $_POST['date_start'] ) ) ) : null;
		$end    = ( isset( $_POST['date_end'] ) && '' !== $_POST['date_end'] ) ? ProfitLens_CSV::parse_date( sanitize_text_field( wp_unslash( $_POST['date_end'] ) ) ) : null;
		if ( '' === $name || $amount <= 0 || ! $start || ! isset( self::periods()[ $period ] ) || ( $end && $end < $start ) ) {
			ProfitLens_Admin::flash( 'error', __( 'Please enter a name, a positive amount, a period and valid dates.', 'profitlens' ) );
			self::back();
		}
		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			ProfitLens_Install::table( 'recurring' ),
			array(
				'name'       => $name,
				'amount'     => $amount,
				'period'     => $period,
				'date_start' => $start,
				'date_end'   => $end,
				'active'     => 1,
			)
		);
		self::refresh( $start, $end ? $end : wp_date( 'Y-m-d' ) );
		ProfitLens_Admin::flash( 'success', __( 'Recurring cost saved and profit re-allocated.', 'profitlens' ) );
		self::back();
	}

	/**
	 * Delete a recurring cost.
	 */
	public static function handle_delete_recurring() {
		$id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- verified in guard().
		self::guard( 'pl_delete_recurring_' . $id );
		global $wpdb;
		$table = ProfitLens_Install::table( 'recurring' );
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT date_start, date_end FROM {$table} WHERE id = %d", $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( $row ) {
			$wpdb->delete( $table, array( 'id' => $id ), array( '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			self::refresh( $row->date_start, $row->date_end ? $row->date_end : wp_date( 'Y-m-d' ) );
			ProfitLens_Admin::flash( 'success', __( 'Recurring cost deleted.', 'profitlens' ) );
		}
		self::back();
	}
}
