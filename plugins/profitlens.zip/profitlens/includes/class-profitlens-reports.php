<?php
/**
 * Report queries.
 *
 * @package ProfitLens
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reports.
 */
class ProfitLens_Reports {

	/**
	 * Date presets.
	 *
	 * @return array
	 */
	public static function presets() {
		return array(
			'today'      => __( 'Today', 'profitlens' ),
			'yesterday'  => __( 'Yesterday', 'profitlens' ),
			'last7'      => __( 'Last 7 days', 'profitlens' ),
			'last30'     => __( 'Last 30 days', 'profitlens' ),
			'this_month' => __( 'This month', 'profitlens' ),
			'last_month' => __( 'Last month', 'profitlens' ),
			'this_year'  => __( 'This year', 'profitlens' ),
			'last_year'  => __( 'Last year', 'profitlens' ),
			'custom'     => __( 'Custom range', 'profitlens' ),
		);
	}

	/**
	 * Resolve a preset or custom dates into a from/to pair (site timezone, Y-m-d).
	 *
	 * @param string $preset Preset key.
	 * @param string $from   Custom from.
	 * @param string $to     Custom to.
	 * @return array [ from, to, preset ]
	 */
	public static function resolve_range( $preset, $from = '', $to = '' ) {
		$now = new DateTimeImmutable( 'now', wp_timezone() );
		switch ( $preset ) {
			case 'today':
				$a = $now;
				$b = $now;
				break;
			case 'yesterday':
				$a = $now->modify( '-1 day' );
				$b = $a;
				break;
			case 'last7':
				$a = $now->modify( '-6 days' );
				$b = $now;
				break;
			case 'this_month':
				$a = $now->modify( 'first day of this month' );
				$b = $now;
				break;
			case 'last_month':
				$a = $now->modify( 'first day of last month' );
				$b = $now->modify( 'last day of last month' );
				break;
			case 'this_year':
				$a = $now->setDate( (int) $now->format( 'Y' ), 1, 1 );
				$b = $now;
				break;
			case 'last_year':
				$y = (int) $now->format( 'Y' ) - 1;
				$a = $now->setDate( $y, 1, 1 );
				$b = $now->setDate( $y, 12, 31 );
				break;
			case 'custom':
				$f = ProfitLens_CSV::parse_date( $from, 'auto' );
				$t = ProfitLens_CSV::parse_date( $to, 'auto' );
				if ( $f && $t ) {
					if ( $t < $f ) {
						list( $f, $t ) = array( $t, $f );
					}
					return array( $f, $t, 'custom' );
				}
				// Fall through to the default.
			default:
				$preset = 'last30';
				$a      = $now->modify( '-29 days' );
				$b      = $now;
		}
		return array( $a->format( 'Y-m-d' ), $b->format( 'Y-m-d' ), $preset );
	}

	/**
	 * Headline numbers for a date range.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 * @return array
	 */
	public static function kpis( $from, $to ) {
		global $wpdb;
		$t = ProfitLens_Install::table( 'orders' );
		$r = $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT COUNT(*) AS orders, COALESCE(SUM(revenue),0) AS revenue, COALESCE(SUM(cogs),0) AS cogs,
				COALESCE(SUM(gateway_fee),0) AS fees, COALESCE(SUM(shipping_cost),0) AS shipping_cost,
				COALESCE(SUM(shipping_income),0) AS shipping_income, COALESCE(SUM(tax_collected),0) AS tax,
				COALESCE(SUM(packaging_cost + other_expenses),0) AS other, COALESCE(SUM(refunded),0) AS refunded,
				COALESCE(SUM(ad_allocation),0) AS ad_alloc, COALESCE(SUM(fixed_allocation),0) AS fixed_alloc,
				COALESCE(SUM(net_profit),0) AS profit_alloc, COALESCE(SUM(CASE WHEN missing_cost_items > 0 THEN 1 ELSE 0 END),0) AS missing_orders
				FROM {$t} WHERE order_day BETWEEN %s AND %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$from,
				$to
			),
			ARRAY_A
		);
		$days  = ProfitLens_Expenses::daily_totals( $from, $to, true );
		$ad    = 0.0;
		$fixed = 0.0;
		foreach ( $days as $d ) {
			$ad    += $d['ad'];
			$fixed += $d['fixed'];
		}
		$orders = (int) $r['orders'];
		$profit = (float) $r['profit_alloc'] + (float) $r['ad_alloc'] + (float) $r['fixed_alloc'] - $ad - $fixed;
		$rev    = (float) $r['revenue'];
		return array(
			'orders'          => $orders,
			'revenue'         => $rev,
			'cogs'            => (float) $r['cogs'],
			'fees'            => (float) $r['fees'],
			'shipping_cost'   => (float) $r['shipping_cost'],
			'shipping_income' => (float) $r['shipping_income'],
			'tax'             => (float) $r['tax'],
			'other'           => (float) $r['other'],
			'refunded'        => (float) $r['refunded'],
			'ad'              => $ad,
			'fixed'           => $fixed,
			'unallocated'     => ( $ad + $fixed ) - ( (float) $r['ad_alloc'] + (float) $r['fixed_alloc'] ),
			'profit'          => $profit,
			'margin'          => $rev > 0 ? $profit / $rev * 100 : 0,
			'aov'             => $orders ? $rev / $orders : 0,
			'ppo'             => $orders ? $profit / $orders : 0,
			'missing_orders'  => (int) $r['missing_orders'],
		);
	}

	/**
	 * The previous period of the same length.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 * @return array [ from, to ]
	 */
	public static function previous_range( $from, $to ) {
		$a    = new DateTimeImmutable( $from );
		$b    = new DateTimeImmutable( $to );
		$days = (int) $a->diff( $b )->days + 1;
		return array( $a->modify( "-{$days} days" )->format( 'Y-m-d' ), $a->modify( '-1 day' )->format( 'Y-m-d' ) );
	}

	/**
	 * Revenue / profit time series.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 * @return array { unit, points: [ [label, revenue, profit, orders], ... ] }
	 */
	public static function trend( $from, $to ) {
		global $wpdb;
		$t    = ProfitLens_Install::table( 'orders' );
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT order_day AS d, COUNT(*) AS c, SUM(revenue) AS r, SUM(net_profit + ad_allocation + fixed_allocation) AS p FROM {$t} WHERE order_day BETWEEN %s AND %s GROUP BY order_day", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$from,
				$to
			)
		);
		$by_day = array();
		foreach ( (array) $rows as $row ) {
			$by_day[ $row->d ] = $row;
		}
		$exp   = ProfitLens_Expenses::daily_totals( $from, $to, true );
		$start = new DateTime( $from );
		$end   = new DateTime( $to );
		$span  = (int) $start->diff( $end )->days + 1;
		$unit  = $span > 92 ? 'month' : 'day';

		$points = array();
		$cur    = clone $start;
		while ( $cur <= $end ) {
			$day = $cur->format( 'Y-m-d' );
			$key = 'month' === $unit ? $cur->format( 'Y-m' ) : $day;
			if ( ! isset( $points[ $key ] ) ) {
				$points[ $key ] = array( $key, 0.0, 0.0, 0 );
			}
			if ( isset( $by_day[ $day ] ) ) {
				$points[ $key ][1] += (float) $by_day[ $day ]->r;
				$points[ $key ][2] += (float) $by_day[ $day ]->p;
				$points[ $key ][3] += (int) $by_day[ $day ]->c;
			}
			if ( isset( $exp[ $day ] ) ) {
				$points[ $key ][2] -= $exp[ $day ]['ad'] + $exp[ $day ]['fixed'];
			}
			$cur->modify( '+1 day' );
		}
		$out = array();
		foreach ( $points as $p ) {
			$out[] = array( $p[0], round( $p[1], 2 ), round( $p[2], 2 ), $p[3] );
		}
		return array(
			'unit'   => $unit,
			'points' => $out,
		);
	}

	/**
	 * Breakdown dimensions.
	 *
	 * @return array key => label
	 */
	public static function dimensions() {
		return array(
			'product'  => __( 'Product', 'profitlens' ),
			'category' => __( 'Category', 'profitlens' ),
			'gateway'  => __( 'Gateway', 'profitlens' ),
			'country'  => __( 'Country', 'profitlens' ),
			'coupon'   => __( 'Coupon', 'profitlens' ),
			'customer' => __( 'Customer (LTV)', 'profitlens' ),
		);
	}

	/**
	 * Column definitions for a breakdown.
	 *
	 * @param string $dim Dimension.
	 * @return array key => [label, type]
	 */
	public static function columns( $dim ) {
		$dims = self::dimensions();
		$cols = array(
			'label'    => array( isset( $dims[ $dim ] ) ? $dims[ $dim ] : '', 'text' ),
			'cnt'      => array( in_array( $dim, array( 'product', 'category' ), true ) ? __( 'Units', 'profitlens' ) : __( 'Orders', 'profitlens' ), 'int' ),
			'revenue'  => array( __( 'Revenue', 'profitlens' ), 'money' ),
			'cogs'     => array( __( 'COGS', 'profitlens' ), 'money' ),
			'fees'     => array( __( 'Payment fees', 'profitlens' ), 'money' ),
			'other'    => array( __( 'Shipping & other', 'profitlens' ), 'money' ),
			'overhead' => array( __( 'Ads & fixed', 'profitlens' ), 'money' ),
			'profit'   => array( __( 'Net profit', 'profitlens' ), 'money' ),
			'margin'   => array( __( 'Margin', 'profitlens' ), 'percent' ),
		);
		if ( 'customer' === $dim ) {
			$cols['ltv_orders'] = array( __( 'Lifetime orders', 'profitlens' ), 'int' );
			$cols['ltv_profit'] = array( __( 'Lifetime profit (LTV)', 'profitlens' ), 'money' );
		}
		return $cols;
	}

	/**
	 * Breakdown rows.
	 *
	 * @param string $dim     Dimension.
	 * @param string $from    Y-m-d.
	 * @param string $to      Y-m-d.
	 * @param string $orderby Column key.
	 * @param string $order   asc|desc.
	 * @param int    $limit   Max rows (0 = all).
	 * @return array { rows, total }
	 */
	public static function breakdown( $dim, $from, $to, $orderby = 'profit', $order = 'desc', $limit = 0 ) {
		global $wpdb;
		$o = ProfitLens_Install::table( 'orders' );
		$i = ProfitLens_Install::table( 'items' );

		$orders_cols = 'COUNT(*) AS cnt, SUM(revenue) AS revenue, SUM(cogs) AS cogs, SUM(gateway_fee) AS fees,
			SUM(shipping_cost + packaging_cost + other_expenses) AS other, SUM(ad_allocation + fixed_allocation) AS overhead, SUM(missing_cost_items) AS est';

		$rows = array();
		switch ( $dim ) {
			case 'product':
			case 'category':
				$group = 'product' === $dim ? 'i.product_id' : 'i.category_id';
				$res   = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
					$wpdb->prepare(
						"SELECT {$group} AS k, MAX(i.name) AS name, SUM(i.qty) AS cnt, SUM(i.revenue) AS revenue, SUM(i.cogs) AS cogs,
						SUM(i.share * o.gateway_fee) AS fees,
						SUM(i.share * (o.shipping_cost - o.shipping_income - o.other_income + o.packaging_cost + o.other_expenses)) AS other,
						SUM(i.share * (o.ad_allocation + o.fixed_allocation)) AS overhead, SUM(i.estimated) AS est
						FROM {$i} i INNER JOIN {$o} o ON o.order_id = i.order_id
						WHERE o.order_day BETWEEN %s AND %s GROUP BY {$group}", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
						$from,
						$to
					)
				);
				foreach ( (array) $res as $r ) {
					$rows[] = self::finish_row( $r, self::label_for( $dim, $r->k, $r->name ) );
				}
				break;

			case 'gateway':
			case 'country':
			case 'customer':
				$col = array(
					'gateway'  => 'gateway',
					'country'  => 'country',
					'customer' => 'customer_email',
				);
				$g   = $col[ $dim ];
				$res = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
					$wpdb->prepare(
						"SELECT {$g} AS k, {$orders_cols} FROM {$o} WHERE order_day BETWEEN %s AND %s GROUP BY {$g}", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
						$from,
						$to
					)
				);
				foreach ( (array) $res as $r ) {
					$rows[] = self::finish_row( $r, self::label_for( $dim, $r->k, '' ) );
				}
				break;

			case 'coupon':
				$res  = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
					$wpdb->prepare(
						"SELECT coupons, revenue, cogs, gateway_fee, shipping_cost + packaging_cost + other_expenses AS other, ad_allocation + fixed_allocation AS overhead, missing_cost_items FROM {$o} WHERE order_day BETWEEN %s AND %s AND coupons <> ''", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
						$from,
						$to
					)
				);
				$agg = array();
				foreach ( (array) $res as $r ) {
					foreach ( array_unique( array_filter( explode( ',', $r->coupons ) ) ) as $code ) {
						if ( ! isset( $agg[ $code ] ) ) {
							$agg[ $code ] = (object) array(
								'k' => $code, 'cnt' => 0, 'revenue' => 0, 'cogs' => 0, 'fees' => 0, 'other' => 0, 'overhead' => 0, 'est' => 0,
							);
						}
						$agg[ $code ]->cnt      += 1;
						$agg[ $code ]->revenue  += (float) $r->revenue;
						$agg[ $code ]->cogs     += (float) $r->cogs;
						$agg[ $code ]->fees     += (float) $r->gateway_fee;
						$agg[ $code ]->other    += (float) $r->other;
						$agg[ $code ]->overhead += (float) $r->overhead;
						$agg[ $code ]->est      += (int) $r->missing_cost_items;
					}
				}
				foreach ( $agg as $code => $r ) {
					$rows[] = self::finish_row( $r, strtoupper( $code ) );
				}
				break;
		}

		if ( 'customer' === $dim && $rows ) {
			self::add_ltv( $rows );
		}

		$cols = self::columns( $dim );
		if ( ! isset( $cols[ $orderby ] ) ) {
			$orderby = 'profit';
		}
		$dir = 'asc' === $order ? 1 : -1;
		usort(
			$rows,
			static function ( $a, $b ) use ( $orderby, $dir ) {
				if ( 'label' === $orderby ) {
					return $dir * strnatcasecmp( $a['label'], $b['label'] );
				}
				if ( $a[ $orderby ] === $b[ $orderby ] ) {
					return strnatcasecmp( $a['label'], $b['label'] );
				}
				return $dir * ( ( $a[ $orderby ] < $b[ $orderby ] ) ? -1 : 1 );
			}
		);
		$total = count( $rows );
		if ( $limit > 0 ) {
			$rows = array_slice( $rows, 0, $limit );
		}
		return array(
			'rows'  => $rows,
			'total' => $total,
		);
	}

	/**
	 * Turn an aggregate object into a normalised row.
	 *
	 * @param object $r     Aggregate.
	 * @param string $label Label.
	 * @return array
	 */
	private static function finish_row( $r, $label ) {
		$revenue = (float) $r->revenue;
		$profit  = $revenue - (float) $r->cogs - (float) $r->fees - (float) $r->other - (float) $r->overhead;
		return array(
			'key'      => $r->k,
			'label'    => $label,
			'cnt'      => (float) $r->cnt,
			'revenue'  => $revenue,
			'cogs'     => (float) $r->cogs,
			'fees'     => (float) $r->fees,
			'other'    => (float) $r->other,
			'overhead' => (float) $r->overhead,
			'profit'   => $profit,
			'margin'   => $revenue > 0 ? $profit / $revenue * 100 : ( $profit < 0 ? -100.0 : 0.0 ),
			'est'      => (int) $r->est,
		);
	}

	/**
	 * Add lifetime figures to customer rows.
	 *
	 * @param array $rows Rows (by reference).
	 */
	private static function add_ltv( array &$rows ) {
		global $wpdb;
		$o      = ProfitLens_Install::table( 'orders' );
		$emails = array();
		foreach ( $rows as $row ) {
			$emails[] = (string) $row['key'];
		}
		$life = array();
		foreach ( array_chunk( $emails, 500 ) as $chunk ) {
			$ph  = implode( ',', array_fill( 0, count( $chunk ), '%s' ) );
			$res = $wpdb->get_results( $wpdb->prepare( "SELECT customer_email AS k, COUNT(*) AS c, SUM(net_profit) AS p FROM {$o} WHERE customer_email IN ({$ph}) GROUP BY customer_email", $chunk ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
			foreach ( (array) $res as $r ) {
				$life[ $r->k ] = $r;
			}
		}
		foreach ( $rows as $n => $row ) {
			$k                         = (string) $row['key'];
			$rows[ $n ]['ltv_orders'] = isset( $life[ $k ] ) ? (float) $life[ $k ]->c : $row['cnt'];
			$rows[ $n ]['ltv_profit'] = isset( $life[ $k ] ) ? (float) $life[ $k ]->p : $row['profit'];
		}
	}

	/**
	 * Human label for a group key.
	 *
	 * @param string $dim  Dimension.
	 * @param mixed  $key  Group key.
	 * @param string $name Stored name.
	 * @return string
	 */
	private static function label_for( $dim, $key, $name ) {
		switch ( $dim ) {
			case 'product':
				if ( $key ) {
					$title = get_the_title( (int) $key );
					if ( '' !== $title ) {
						return wp_strip_all_tags( $title );
					}
				}
				return '' !== $name ? $name : __( '(deleted product)', 'profitlens' );
			case 'category':
				if ( $key ) {
					$term = get_term( (int) $key, 'product_cat' );
					if ( $term && ! is_wp_error( $term ) ) {
						return $term->name;
					}
				}
				return __( 'Uncategorised', 'profitlens' );
			case 'gateway':
				$gateways = WC()->payment_gateways()->payment_gateways();
				if ( $key && isset( $gateways[ $key ] ) ) {
					return wp_strip_all_tags( $gateways[ $key ]->get_title() ? $gateways[ $key ]->get_title() : $gateways[ $key ]->get_method_title() );
				}
				return $key ? (string) $key : __( '(none)', 'profitlens' );
			case 'country':
				$countries = WC()->countries->get_countries();
				if ( $key && isset( $countries[ $key ] ) ) {
					return html_entity_decode( $countries[ $key ] ) . ' (' . $key . ')';
				}
				return $key ? (string) $key : __( '(unknown)', 'profitlens' );
			case 'customer':
				return $key ? (string) $key : __( '(no email)', 'profitlens' );
		}
		return (string) $key;
	}
}
