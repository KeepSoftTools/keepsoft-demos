<?php
/**
 * Profit calculation engine.
 *
 * @package ProfitLens
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Engine.
 */
class ProfitLens_Engine {

	const BATCH = 200;

	/**
	 * Order IDs waiting to be (re)calculated at shutdown.
	 *
	 * @var array
	 */
	private static $queue = array();

	/**
	 * Order IDs waiting to be removed.
	 *
	 * @var array
	 */
	private static $remove = array();

	/**
	 * Category cache.
	 *
	 * @var array
	 */
	private static $cat_cache = array();

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'woocommerce_new_order', array( __CLASS__, 'queue' ), 20 );
		add_action( 'woocommerce_update_order', array( __CLASS__, 'queue' ), 20 );
		add_action( 'woocommerce_order_status_changed', array( __CLASS__, 'queue' ), 20 );
		add_action( 'woocommerce_order_refunded', array( __CLASS__, 'queue' ), 20 );
		add_action( 'woocommerce_refund_deleted', array( __CLASS__, 'queue_from_refund' ), 20, 2 );
		add_action( 'woocommerce_delete_order', array( __CLASS__, 'queue_remove' ), 20 );
		add_action( 'woocommerce_trash_order', array( __CLASS__, 'queue_remove' ), 20 );
		add_action( 'shutdown', array( __CLASS__, 'process_queue' ), 5 );
		add_action( 'wp_ajax_pl_backfill', array( __CLASS__, 'ajax_backfill' ) );
	}

	/**
	 * Queue an order for recalculation.
	 *
	 * @param int $order_id Order ID.
	 */
	public static function queue( $order_id ) {
		$order_id = absint( $order_id );
		if ( $order_id ) {
			self::$queue[ $order_id ] = true;
			unset( self::$remove[ $order_id ] );
		}
	}

	/**
	 * Queue the parent order of a deleted refund.
	 *
	 * @param int $refund_id Refund ID.
	 * @param int $order_id  Order ID.
	 */
	public static function queue_from_refund( $refund_id, $order_id ) {
		self::queue( $order_id );
	}

	/**
	 * Queue removal of an order's profit row.
	 *
	 * @param int $order_id Order ID.
	 */
	public static function queue_remove( $order_id ) {
		$order_id = absint( $order_id );
		if ( $order_id ) {
			self::$remove[ $order_id ] = true;
			unset( self::$queue[ $order_id ] );
		}
	}

	/**
	 * Process queued orders (runs on shutdown so multi-save requests only calculate once).
	 */
	public static function process_queue() {
		if ( ! self::$queue && ! self::$remove ) {
			return;
		}
		$days = array();
		foreach ( array_keys( self::$remove ) as $id ) {
			$day = self::delete_row( $id );
			if ( $day ) {
				$days[] = $day;
			}
		}
		$queue        = array_keys( self::$queue );
		self::$queue  = array();
		self::$remove = array();
		foreach ( $queue as $id ) {
			$order = wc_get_order( $id );
			if ( ! $order || ! $order instanceof WC_Order || 'shop_order_refund' === $order->get_type() ) {
				continue;
			}
			$days = array_merge( $days, self::calculate_order( $order ) );
		}
		self::reallocate_days( $days );
	}

	/**
	 * Calculate one order and store the result (no day allocation).
	 *
	 * @param WC_Order $order Order.
	 * @param array    $args  refresh_costs (bool).
	 * @return array Days (Y-m-d) whose allocation needs refreshing.
	 */
	public static function calculate_order( $order, $args = array() ) {
		global $wpdb;
		$days = array();
		$prev = $wpdb->get_var( $wpdb->prepare( 'SELECT order_day FROM ' . ProfitLens_Install::table( 'orders' ) . ' WHERE order_id = %d', $order->get_id() ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
		if ( $prev ) {
			$days[] = $prev;
		}
		$data = self::compute( $order, $args );
		if ( ! $data ) {
			self::delete_row( $order->get_id() );
			return $days;
		}
		self::store( $data );
		$days[] = $data['order']['order_day'];
		return $days;
	}

	/**
	 * Compute the profit figures for an order without saving.
	 *
	 * @param WC_Order $order Order.
	 * @param array    $args  refresh_costs (bool), persist_snapshots (bool).
	 * @return array|false Array with 'order' and 'items', or false when the order does not count.
	 */
	public static function compute( $order, $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'refresh_costs'      => false,
				'persist_snapshots'  => true,
			)
		);
		if ( ! in_array( $order->get_status(), ProfitLens_Settings::counted_statuses(), true ) ) {
			return false;
		}

		$total        = (float) $order->get_total();
		$total_tax    = (float) $order->get_total_tax();
		// Sum the refund objects directly: WooCommerce caches get_total_refunded() and the cache can be stale right after a refund is deleted.
		$refunded      = 0.0;
		$refunded_tax  = 0.0;
		$refunded_ship = 0.0;
		foreach ( $order->get_refunds() as $refund ) {
			$refunded      += abs( (float) $refund->get_amount() );
			$refunded_tax  += abs( (float) $refund->get_total_tax() );
			$refunded_ship += abs( (float) $refund->get_shipping_total() );
		}

		$tax_collected   = $total_tax - $refunded_tax;
		$revenue         = ( $total - $refunded ) - $tax_collected;
		$ship_gross      = (float) $order->get_shipping_total();
		$ship_income     = $ship_gross - $refunded_ship;
		$recover         = 'yes' === ProfitLens_Settings::get( 'recover_cogs_refund' );
		$margin_fallback = ProfitLens_Settings::get( 'default_margin' );

		$items_out   = array();
		$cogs        = 0.0;
		$items_rev   = 0.0;
		$missing     = 0;
		$has_physical = false;

		foreach ( $order->get_items( 'line_item' ) as $item_id => $item ) {
			$product_id   = (int) $item->get_product_id();
			$variation_id = (int) $item->get_variation_id();
			$qty          = (float) $item->get_quantity();
			$qty_refunded = abs( (float) $order->get_qty_refunded_for_item( $item_id ) );
			$net_qty      = max( 0, $qty - $qty_refunded );
			$line_total   = (float) $item->get_total();
			$line_rev     = max( 0, $line_total - (float) $order->get_total_refunded_for_item( $item_id ) );
			$cost_qty     = $recover ? $net_qty : $qty;

			$unit_cost = null;
			$estimated = 0;
			if ( ! $args['refresh_costs'] ) {
				$snap = $item->get_meta( '_pl_unit_cost', true );
				if ( '' !== $snap && is_numeric( $snap ) ) {
					$unit_cost = (float) $snap;
				}
			}
			if ( null === $unit_cost ) {
				$unit_cost = ProfitLens_Costs::unit_cost( $product_id, $variation_id );
				if ( null !== $unit_cost && $args['persist_snapshots'] ) {
					$item->update_meta_data( '_pl_unit_cost', $unit_cost );
					$item->save_meta_data();
				}
			}
			if ( null === $unit_cost ) {
				++$missing;
				$estimated = 1;
				if ( '' !== $margin_fallback && $qty > 0 ) {
					$unit_cost = ( $line_total / $qty ) * ( 1 - (float) $margin_fallback / 100 );
				} else {
					$unit_cost = 0.0;
				}
			}
			$line_cogs = round( $unit_cost * $cost_qty, 4 );

			$product = $item->get_product();
			if ( ! $product || ! $product->is_virtual() ) {
				$has_physical = true;
			}

			$cogs      += $line_cogs;
			$items_rev += $line_rev;
			$items_out[] = array(
				'item_id'      => (int) $item_id,
				'product_id'   => $product_id,
				'variation_id' => $variation_id,
				'category_id'  => self::primary_category( $product_id ),
				'name'         => mb_substr( wp_strip_all_tags( $item->get_name() ), 0, 255 ),
				'qty'          => $net_qty,
				'revenue'      => round( $line_rev, 4 ),
				'cogs'         => $line_cogs,
				'share'        => 0,
				'estimated'    => $estimated,
			);
		}

		$count = count( $items_out );
		foreach ( $items_out as $i => $row ) {
			if ( $items_rev > 0 ) {
				$items_out[ $i ]['share'] = round( $row['revenue'] / $items_rev, 8 );
			} elseif ( $count ) {
				$items_out[ $i ]['share'] = round( 1 / $count, 8 );
			}
		}

		list( $fee )  = ProfitLens_Fees::gateway_fee( $order );
		list( $ship ) = ProfitLens_Fees::shipping_cost( $order, $ship_gross );

		$packaging = (float) ProfitLens_Settings::get( 'packaging_cost' );
		if ( 'yes' === ProfitLens_Settings::get( 'packaging_physical' ) && ! $has_physical ) {
			$packaging = 0.0;
		}
		$other = (float) $order->get_meta( '_pl_other_expenses', true );

		$other_income = $revenue - $items_rev - $ship_income;

		$date    = $order->get_date_created();
		$country = $order->get_billing_country();
		if ( 'shipping' === ProfitLens_Settings::get( 'country_source' ) && $order->get_shipping_country() ) {
			$country = $order->get_shipping_country();
		}

		$net = $revenue - $cogs - $fee - $ship - $packaging - $other;

		$row = array(
			'order_id'           => $order->get_id(),
			'order_date'         => $date ? $date->date( 'Y-m-d H:i:s' ) : current_time( 'mysql' ),
			'order_day'          => $date ? $date->date( 'Y-m-d' ) : wp_date( 'Y-m-d' ),
			'status'             => $order->get_status(),
			'currency'           => $order->get_currency(),
			'gross_total'        => $total,
			'revenue'            => $revenue,
			'cogs'               => $cogs,
			'gateway_fee'        => $fee,
			'shipping_cost'      => $ship,
			'shipping_income'    => $ship_income,
			'other_income'       => $other_income,
			'tax_collected'      => $tax_collected,
			'packaging_cost'     => $packaging,
			'other_expenses'     => $other,
			'ad_allocation'      => 0,
			'fixed_allocation'   => 0,
			'net_profit'         => $net,
			'margin'             => $revenue > 0 ? $net / $revenue * 100 : 0,
			'refunded'           => $refunded,
			'missing_cost_items' => $missing,
			'gateway'            => mb_substr( (string) $order->get_payment_method(), 0, 100 ),
			'country'            => mb_substr( (string) $country, 0, 10 ),
			'coupons'            => mb_substr( implode( ',', array_map( 'wc_strtolower', $order->get_coupon_codes() ) ), 0, 255 ),
			'customer_email'     => mb_substr( strtolower( (string) $order->get_billing_email() ), 0, 190 ),
			'customer_id'        => (int) $order->get_customer_id(),
			'calculated_at'      => current_time( 'mysql', true ),
		);

		return apply_filters(
			'pl_order_profit_data',
			array(
				'order' => $row,
				'items' => $items_out,
			),
			$order
		);
	}

	/**
	 * First product category ID (0 when none).
	 *
	 * @param int $product_id Product.
	 * @return int
	 */
	private static function primary_category( $product_id ) {
		if ( ! $product_id ) {
			return 0;
		}
		if ( isset( self::$cat_cache[ $product_id ] ) ) {
			return self::$cat_cache[ $product_id ];
		}
		$terms = wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) );
		$id    = ( ! is_wp_error( $terms ) && $terms ) ? (int) min( $terms ) : 0;
		self::$cat_cache[ $product_id ] = $id;
		return $id;
	}

	/**
	 * Persist computed figures.
	 *
	 * @param array $data Result of compute().
	 */
	private static function store( $data ) {
		global $wpdb;
		$row = $data['order'];
		foreach ( array( 'gross_total', 'revenue', 'cogs', 'gateway_fee', 'shipping_cost', 'shipping_income', 'other_income', 'tax_collected', 'packaging_cost', 'other_expenses', 'ad_allocation', 'fixed_allocation', 'net_profit', 'margin', 'refunded' ) as $key ) {
			$row[ $key ] = sprintf( '%.4F', $row[ $key ] );
		}
		// Keep any existing allocation until the day is re-allocated.
		$existing = $wpdb->get_row( $wpdb->prepare( 'SELECT ad_allocation, fixed_allocation FROM ' . ProfitLens_Install::table( 'orders' ) . ' WHERE order_id = %d', $row['order_id'] ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
		if ( $existing ) {
			$row['ad_allocation']    = $existing->ad_allocation;
			$row['fixed_allocation'] = $existing->fixed_allocation;
			$row['net_profit']       = sprintf( '%.4F', (float) $row['net_profit'] - (float) $existing->ad_allocation - (float) $existing->fixed_allocation );
		}
		$wpdb->replace( ProfitLens_Install::table( 'orders' ), $row ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		$items_table = ProfitLens_Install::table( 'items' );
		$wpdb->delete( $items_table, array( 'order_id' => $row['order_id'] ), array( '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		foreach ( $data['items'] as $item ) {
			$item['order_id'] = $row['order_id'];
			$wpdb->insert( $items_table, $item ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		}
	}

	/**
	 * Delete the stored rows for an order.
	 *
	 * @param int $order_id Order ID.
	 * @return string|null The day the order belonged to.
	 */
	public static function delete_row( $order_id ) {
		global $wpdb;
		$table = ProfitLens_Install::table( 'orders' );
		$day   = $wpdb->get_var( $wpdb->prepare( "SELECT order_day FROM {$table} WHERE order_id = %d", $order_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->delete( $table, array( 'order_id' => $order_id ), array( '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->delete( ProfitLens_Install::table( 'items' ), array( 'order_id' => $order_id ), array( '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return $day ? $day : null;
	}

	/**
	 * Re-allocate ad spend and fixed costs for all orders on a date range.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 */
	public static function reallocate_range( $from, $to ) {
		global $wpdb;
		$table = ProfitLens_Install::table( 'orders' );
		$days  = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT order_day FROM {$table} WHERE order_day BETWEEN %s AND %s", $from, $to ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		self::reallocate_days( $days );
	}

	/**
	 * Allocate each day's ad spend and fixed costs across that day's orders, proportional to revenue.
	 *
	 * @param array $days List of Y-m-d.
	 */
	public static function reallocate_days( array $days ) {
		global $wpdb;
		$days = array_values( array_unique( array_filter( $days ) ) );
		if ( ! $days ) {
			return;
		}
		sort( $days );
		wc_set_time_limit( 0 );
		$table  = ProfitLens_Install::table( 'orders' );
		$totals = ProfitLens_Expenses::daily_totals( $days[0], $days[ count( $days ) - 1 ] );

		foreach ( $days as $day ) {
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT order_id, revenue, cogs, gateway_fee, shipping_cost, packaging_cost, other_expenses, ad_allocation, fixed_allocation FROM {$table} WHERE order_day = %s ORDER BY order_id ASC", $day ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			if ( ! $rows ) {
				continue;
			}
			$ad    = isset( $totals[ $day ] ) ? $totals[ $day ]['ad'] : 0.0;
			$fixed = isset( $totals[ $day ] ) ? $totals[ $day ]['fixed'] : 0.0;
			$sum   = 0.0;
			foreach ( $rows as $r ) {
				$sum += max( 0, (float) $r->revenue );
			}
			$n         = count( $rows );
			$ad_left   = round( $ad, 4 );
			$fixed_left = round( $fixed, 4 );
			foreach ( $rows as $i => $r ) {
				if ( $i === $n - 1 ) {
					$a = $ad_left;
					$f = $fixed_left;
				} else {
					$w = $sum > 0 ? max( 0, (float) $r->revenue ) / $sum : 1 / $n;
					$a = round( $ad * $w, 4 );
					$f = round( $fixed * $w, 4 );
				}
				$ad_left    = round( $ad_left - $a, 4 );
				$fixed_left = round( $fixed_left - $f, 4 );

				if ( abs( $a - (float) $r->ad_allocation ) < 0.00005 && abs( $f - (float) $r->fixed_allocation ) < 0.00005 ) {
					continue;
				}
				$net    = (float) $r->revenue - (float) $r->cogs - (float) $r->gateway_fee - (float) $r->shipping_cost - (float) $r->packaging_cost - (float) $r->other_expenses - $a - $f;
				$margin = (float) $r->revenue > 0 ? $net / (float) $r->revenue * 100 : 0;
				$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
					$table,
					array(
						'ad_allocation'    => sprintf( '%.4F', $a ),
						'fixed_allocation' => sprintf( '%.4F', $f ),
						'net_profit'       => sprintf( '%.4F', $net ),
						'margin'           => sprintf( '%.4F', $margin ),
					),
					array( 'order_id' => (int) $r->order_id )
				);
			}
		}
	}

	/**
	 * Recalculate a single order immediately (used by the order metabox and tests).
	 *
	 * @param int|WC_Order $order Order or ID.
	 * @param array        $args  See compute().
	 * @return bool
	 */
	public static function recalculate_now( $order, $args = array() ) {
		$order = $order instanceof WC_Order ? $order : wc_get_order( $order );
		if ( ! $order ) {
			return false;
		}
		$days = self::calculate_order( $order, $args );
		self::reallocate_days( $days );
		return true;
	}

	/**
	 * Stored row for an order.
	 *
	 * @param int $order_id Order ID.
	 * @return object|null
	 */
	public static function get_row( $order_id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ProfitLens_Install::table( 'orders' ) . ' WHERE order_id = %d', $order_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
	}

	/**
	 * AJAX: process one batch of the backfill.
	 */
	public static function ajax_backfill() {
		check_ajax_referer( 'pl_backfill', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'profitlens' ) ), 403 );
		}
		$page    = isset( $_POST['page'] ) ? max( 1, absint( $_POST['page'] ) ) : 1;
		$refresh = ! empty( $_POST['refresh'] ) && '1' === sanitize_text_field( wp_unslash( $_POST['refresh'] ) );

		wc_set_time_limit( 120 );
		$result = wc_get_orders(
			array(
				'limit'    => self::BATCH,
				'paged'    => $page,
				'type'     => 'shop_order',
				'paginate' => true,
				'return'   => 'ids',
				'orderby'  => 'ID',
				'order'    => 'ASC',
			)
		);
		$days = array();
		foreach ( $result->orders as $id ) {
			$order = wc_get_order( $id );
			if ( $order instanceof WC_Order ) {
				$days = array_merge( $days, self::calculate_order( $order, array( 'refresh_costs' => $refresh ) ) );
			}
		}
		self::reallocate_days( $days );

		$total     = (int) $result->total;
		$processed = min( $total, ( $page - 1 ) * self::BATCH + count( $result->orders ) );
		$done      = $page >= (int) $result->max_num_pages || ! $result->orders;
		if ( $done ) {
			update_option( 'pl_last_backfill', time(), false );
		}
		wp_send_json_success(
			array(
				'total'     => $total,
				'processed' => $processed,
				'done'      => $done,
				'next_page' => $page + 1,
			)
		);
	}
}
