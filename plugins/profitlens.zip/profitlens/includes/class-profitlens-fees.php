<?php
/**
 * Payment gateway fees and shipping cost resolution.
 *
 * @package ProfitLens
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Fee helpers.
 */
class ProfitLens_Fees {

	/**
	 * Order meta keys where gateways store the real fee.
	 *
	 * @return array
	 */
	public static function actual_fee_keys() {
		$keys = array(
			'_stripe_fee',
			'Stripe Fee',
			'_paypal_transaction_fee',
			'PayPal Transaction Fee',
			'_ppcp_paypal_fees',
			'_square_fee',
		);
		$keys = array_merge( $keys, ProfitLens_Settings::parse_keys( (string) ProfitLens_Settings::get( 'fee_meta_keys' ) ) );
		return array_values( array_unique( apply_filters( 'pl_actual_fee_meta_keys', $keys ) ) );
	}

	/**
	 * Read the actual fee a gateway stored on the order.
	 *
	 * @param WC_Order $order Order.
	 * @return float|null
	 */
	public static function actual_fee( $order ) {
		foreach ( self::actual_fee_keys() as $key ) {
			$raw = $order->get_meta( $key, true );
			if ( is_array( $raw ) ) {
				// WooCommerce PayPal Payments: array( 'paypal_fee' => array( 'value' => '1.23' ) ).
				if ( isset( $raw['paypal_fee']['value'] ) ) {
					$raw = $raw['paypal_fee']['value'];
				} elseif ( isset( $raw['value'] ) ) {
					$raw = $raw['value'];
				} else {
					continue;
				}
			}
			if ( is_scalar( $raw ) && '' !== trim( (string) $raw ) && is_numeric( $raw ) ) {
				return abs( (float) $raw );
			}
		}
		return null;
	}

	/**
	 * Calculate gateway fee for an order.
	 *
	 * @param WC_Order $order Order.
	 * @return array [ fee (float), source (string) ].
	 */
	public static function gateway_fee( $order ) {
		$override = $order->get_meta( '_pl_gateway_fee', true );
		if ( '' !== $override && is_numeric( $override ) ) {
			return array( max( 0, (float) $override ), 'manual' );
		}
		if ( 'yes' === ProfitLens_Settings::get( 'use_actual_fees' ) ) {
			$actual = self::actual_fee( $order );
			if ( null !== $actual ) {
				return array( $actual, 'actual' );
			}
		}
		$total = (float) $order->get_total();
		if ( $total <= 0 ) {
			return array( 0.0, 'none' );
		}
		$rules   = ProfitLens_Settings::get( 'gateway_fees' );
		$gateway = $order->get_payment_method();
		if ( $gateway && isset( $rules[ $gateway ] ) ) {
			$fee = $total * ( (float) $rules[ $gateway ]['percent'] / 100 ) + (float) $rules[ $gateway ]['fixed'];
			return array( round( $fee, 4 ), 'rule' );
		}
		return array( 0.0, 'none' );
	}

	/**
	 * Shipping cost actually paid for an order.
	 *
	 * @param WC_Order $order           Order.
	 * @param float    $shipping_income Shipping charged to the customer before refunds.
	 * @return array [ cost, source ].
	 */
	public static function shipping_cost( $order, $shipping_income ) {
		$override = $order->get_meta( '_pl_shipping_cost', true );
		if ( '' !== $override && is_numeric( $override ) ) {
			return array( max( 0, (float) $override ), 'manual' );
		}
		$defaults = ProfitLens_Settings::get( 'shipping_costs' );
		$total    = 0.0;
		$found    = false;
		foreach ( $order->get_shipping_methods() as $line ) {
			$method   = $line->get_method_id();
			$instance = $line->get_instance_id();
			$keys     = array();
			if ( $instance ) {
				$keys[] = strtolower( $method . ':' . $instance );
			}
			$keys[] = strtolower( $method );
			foreach ( $keys as $key ) {
				if ( isset( $defaults[ $key ] ) ) {
					$total += (float) $defaults[ $key ];
					$found  = true;
					break;
				}
			}
		}
		if ( $found ) {
			return array( $total, 'method' );
		}
		if ( 'income' === ProfitLens_Settings::get( 'shipping_fallback' ) ) {
			return array( max( 0, $shipping_income ), 'passthrough' );
		}
		return array( 0.0, 'none' );
	}

	/**
	 * Rows for the shipping cost settings table (key => label).
	 *
	 * @return array
	 */
	public static function shipping_method_rows() {
		$rows  = array();
		$zones = WC_Shipping_Zones::get_zones();
		$zones[0] = array(
			'zone_name'        => __( 'Locations not covered by your other zones', 'profitlens' ),
			'shipping_methods' => ( new WC_Shipping_Zone( 0 ) )->get_shipping_methods(),
		);
		foreach ( $zones as $zone ) {
			foreach ( $zone['shipping_methods'] as $method ) {
				$key          = strtolower( $method->id . ':' . $method->get_instance_id() );
				$rows[ $key ] = $zone['zone_name'] . ' - ' . $method->get_title();
			}
		}
		foreach ( WC()->shipping()->get_shipping_methods() as $id => $method ) {
			$rows[ strtolower( $id ) ] = sprintf(
				/* translators: %s: shipping method name */
				__( 'All %s methods', 'profitlens' ),
				wp_strip_all_tags( $method->get_method_title() )
			);
		}
		return $rows;
	}
}
