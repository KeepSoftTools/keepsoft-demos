<?php
/**
 * Order edit screen metabox and orders list column.
 *
 * @package ProfitLens
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Order UI.
 */
class ProfitLens_Order_UI {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_metabox' ) );
		add_action( 'woocommerce_process_shop_order_meta', array( __CLASS__, 'save_metabox' ), 50 );
		add_filter( 'woocommerce_hidden_order_itemmeta', array( __CLASS__, 'hide_item_meta' ) );

		// Orders list: HPOS and legacy screens.
		add_filter( 'manage_woocommerce_page_wc-orders_columns', array( __CLASS__, 'add_column' ) );
		add_action( 'manage_woocommerce_page_wc-orders_custom_column', array( __CLASS__, 'render_column_hpos' ), 10, 2 );
		add_filter( 'manage_edit-shop_order_columns', array( __CLASS__, 'add_column' ) );
		add_action( 'manage_shop_order_posts_custom_column', array( __CLASS__, 'render_column_legacy' ), 10, 2 );
	}

	/**
	 * Hide the stored unit cost snapshot from the order item display.
	 *
	 * @param array $hidden Hidden meta keys.
	 * @return array
	 */
	public static function hide_item_meta( $hidden ) {
		$hidden[] = '_pl_unit_cost';
		return $hidden;
	}

	/**
	 * Register the metabox on whichever order screen is in use.
	 */
	public static function add_metabox() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		$screens = array( 'shop_order' );
		if ( function_exists( 'wc_get_page_screen_id' ) ) {
			$screens[] = wc_get_page_screen_id( 'shop-order' );
		}
		foreach ( array_unique( $screens ) as $screen ) {
			add_meta_box( 'pl_order_profit', __( 'Profit (ProfitLens)', 'profitlens' ), array( __CLASS__, 'render_metabox' ), $screen, 'side', 'default' );
		}
	}

	/**
	 * Money formatting in the order's currency.
	 *
	 * @param float  $value    Amount.
	 * @param string $currency Currency.
	 * @return string
	 */
	private static function money( $value, $currency ) {
		return wc_price( $value, array( 'currency' => $currency ) );
	}

	/**
	 * Render the metabox.
	 *
	 * @param WP_Post|WC_Order $post_or_order Post or order object.
	 */
	public static function render_metabox( $post_or_order ) {
		$order = ( $post_or_order instanceof WC_Order ) ? $post_or_order : wc_get_order( $post_or_order->ID );
		if ( ! $order ) {
			return;
		}
		$row = ProfitLens_Engine::get_row( $order->get_id() );
		if ( ! $row ) {
			$calc = ProfitLens_Engine::compute( $order, array( 'persist_snapshots' => false ) );
			if ( ! $calc ) {
				echo '<p>' . esc_html__( 'This order status is not included in profit reports.', 'profitlens' ) . '</p>';
				return;
			}
			$row = (object) $calc['order'];
			echo '<p class="description">' . esc_html__( 'Preview. Saved when the order is updated or recalculated.', 'profitlens' ) . '</p>';
		}
		$c = $row->currency;

		$lines = array(
			array( __( 'Revenue (net of refunds, ex. tax)', 'profitlens' ), $row->revenue, 1 ),
			array( __( 'Cost of goods', 'profitlens' ), -$row->cogs, 0 ),
			array( __( 'Payment fee', 'profitlens' ), -$row->gateway_fee, 0 ),
			array( __( 'Shipping cost paid', 'profitlens' ), -$row->shipping_cost, 0 ),
			array( __( 'Packaging', 'profitlens' ), -$row->packaging_cost, 0 ),
			array( __( 'Other expenses', 'profitlens' ), -$row->other_expenses, 0 ),
			array( __( 'Ad spend (allocated)', 'profitlens' ), -$row->ad_allocation, 0 ),
			array( __( 'Fixed costs (allocated)', 'profitlens' ), -$row->fixed_allocation, 0 ),
		);
		echo '<table class="pl-metabox-table"><tbody>';
		foreach ( $lines as $line ) {
			echo '<tr><td>' . esc_html( $line[0] ) . '</td><td class="pl-num">' . wp_kses_post( self::money( $line[1], $c ) ) . '</td></tr>';
		}
		$class = (float) $row->net_profit < 0 ? 'pl-neg' : 'pl-pos';
		echo '<tr class="pl-total"><td>' . esc_html__( 'Net profit', 'profitlens' ) . '</td><td class="pl-num ' . esc_attr( $class ) . '">' . wp_kses_post( self::money( $row->net_profit, $c ) ) . '</td></tr>';
		echo '<tr><td>' . esc_html__( 'Margin', 'profitlens' ) . '</td><td class="pl-num ' . esc_attr( $class ) . '">' . esc_html( number_format_i18n( (float) $row->margin, 1 ) ) . '%</td></tr>';
		echo '<tr class="pl-info"><td>' . esc_html__( 'Shipping charged (in revenue)', 'profitlens' ) . '</td><td class="pl-num">' . wp_kses_post( self::money( $row->shipping_income, $c ) ) . '</td></tr>';
		echo '<tr class="pl-info"><td>' . esc_html__( 'Tax collected (not revenue)', 'profitlens' ) . '</td><td class="pl-num">' . wp_kses_post( self::money( $row->tax_collected, $c ) ) . '</td></tr>';
		echo '</tbody></table>';

		if ( (int) $row->missing_cost_items > 0 ) {
			echo '<p class="pl-warn">' . esc_html(
				sprintf(
					/* translators: %d: number of items */
					_n( '%d item has no cost set, so profit may be overstated.', '%d items have no cost set, so profit may be overstated.', (int) $row->missing_cost_items, 'profitlens' ),
					(int) $row->missing_cost_items
				)
			) . '</p>';
		}

		wp_nonce_field( 'pl_save_order_' . $order->get_id(), 'pl_order_nonce' );
		$fields = array(
			'_pl_shipping_cost' => __( 'Shipping cost actually paid', 'profitlens' ),
			'_pl_gateway_fee'   => __( 'Payment fee override', 'profitlens' ),
			'_pl_other_expenses' => __( 'Other expenses for this order', 'profitlens' ),
		);
		echo '<hr><p><strong>' . esc_html__( 'Per-order costs', 'profitlens' ) . '</strong></p>';
		foreach ( $fields as $key => $label ) {
			$val = $order->get_meta( $key, true );
			echo '<p class="pl-field"><label for="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label><input type="text" class="wc_input_price" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $val ) . '" placeholder="' . esc_attr__( 'Automatic', 'profitlens' ) . '"></p>';
		}
		echo '<p class="description">' . esc_html__( 'Leave blank to use your settings. Saved when you update the order.', 'profitlens' ) . '</p>';
	}

	/**
	 * Save the per-order cost fields.
	 *
	 * @param int $order_id Order ID.
	 */
	public static function save_metabox( $order_id ) {
		if ( ! isset( $_POST['pl_order_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['pl_order_nonce'] ) ), 'pl_save_order_' . absint( $order_id ) ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		foreach ( array( '_pl_shipping_cost', '_pl_gateway_fee', '_pl_other_expenses' ) as $key ) {
			$raw = isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';
			if ( '' === trim( $raw ) ) {
				$order->delete_meta_data( $key );
			} else {
				$order->update_meta_data( $key, max( 0, (float) wc_format_decimal( $raw ) ) );
			}
		}
		$order->save();
		ProfitLens_Engine::queue( $order_id );
	}

	/**
	 * Add the Profit column after the total.
	 *
	 * @param array $columns Columns.
	 * @return array
	 */
	public static function add_column( $columns ) {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return $columns;
		}
		$out = array();
		foreach ( $columns as $key => $label ) {
			$out[ $key ] = $label;
			if ( 'order_total' === $key ) {
				$out['pl_profit'] = __( 'Profit', 'profitlens' );
			}
		}
		if ( ! isset( $out['pl_profit'] ) ) {
			$out['pl_profit'] = __( 'Profit', 'profitlens' );
		}
		return $out;
	}

	/**
	 * HPOS column renderer.
	 *
	 * @param string   $column Column.
	 * @param WC_Order $order  Order.
	 */
	public static function render_column_hpos( $column, $order ) {
		if ( 'pl_profit' === $column && $order ) {
			self::print_cell( is_object( $order ) ? $order->get_id() : (int) $order );
		}
	}

	/**
	 * Legacy column renderer.
	 *
	 * @param string $column  Column.
	 * @param int    $post_id Post ID.
	 */
	public static function render_column_legacy( $column, $post_id ) {
		if ( 'pl_profit' === $column ) {
			self::print_cell( (int) $post_id );
		}
	}

	/**
	 * Output a profit cell.
	 *
	 * @param int $order_id Order ID.
	 */
	private static function print_cell( $order_id ) {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		$row = ProfitLens_Engine::get_row( $order_id );
		if ( ! $row ) {
			echo '<span aria-hidden="true">&ndash;</span>';
			return;
		}
		$class = (float) $row->net_profit < 0 ? 'pl-neg' : 'pl-pos';
		echo '<span class="' . esc_attr( $class ) . '">' . wp_kses_post( self::money( $row->net_profit, $row->currency ) ) . '</span> <small>(' . esc_html( number_format_i18n( (float) $row->margin, 1 ) ) . '%)</small>';
	}
}
