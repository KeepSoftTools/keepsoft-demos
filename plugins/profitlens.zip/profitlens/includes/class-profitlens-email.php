<?php
/**
 * Weekly email summary.
 *
 * @package ProfitLens
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Email.
 */
class ProfitLens_Email {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'pl_weekly_summary', array( __CLASS__, 'cron_send' ) );
		add_action( 'admin_post_pl_test_email', array( __CLASS__, 'handle_test' ) );
	}

	/**
	 * Cron callback: only sends when enabled.
	 */
	public static function cron_send() {
		if ( 'yes' === ProfitLens_Settings::get( 'weekly_email' ) ) {
			self::send();
		}
	}

	/**
	 * Admin-post handler for the "send test email" button.
	 */
	public static function handle_test() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'profitlens' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'pl_test_email' );
		$ok = self::send();
		ProfitLens_Admin::flash( $ok ? 'success' : 'error', $ok ? __( 'Summary email sent.', 'profitlens' ) : __( 'The email could not be sent. Check your recipients and mail setup.', 'profitlens' ) );
		wp_safe_redirect( admin_url( 'admin.php?page=profitlens&tab=tools' ) );
		exit;
	}

	/**
	 * Recipients.
	 *
	 * @return array
	 */
	public static function recipients() {
		$raw = (string) ProfitLens_Settings::get( 'email_to' );
		$out = array();
		foreach ( explode( ',', $raw ) as $addr ) {
			$addr = sanitize_email( trim( $addr ) );
			if ( $addr && is_email( $addr ) ) {
				$out[] = $addr;
			}
		}
		if ( ! $out ) {
			$out[] = get_option( 'admin_email' );
		}
		return $out;
	}

	/**
	 * Send the summary.
	 *
	 * @return bool
	 */
	public static function send() {
		$mail = self::build();
		add_filter( 'wp_mail_content_type', array( __CLASS__, 'html_type' ) );
		$ok = wp_mail( self::recipients(), $mail['subject'], $mail['html'] );
		remove_filter( 'wp_mail_content_type', array( __CLASS__, 'html_type' ) );
		return (bool) $ok;
	}

	/**
	 * Content type filter.
	 *
	 * @return string
	 */
	public static function html_type() {
		return 'text/html';
	}

	/**
	 * Build the email.
	 *
	 * @return array { subject, html }
	 */
	public static function build() {
		$now  = new DateTimeImmutable( 'now', wp_timezone() );
		$to   = $now->modify( '-1 day' )->format( 'Y-m-d' );
		$from = $now->modify( '-7 days' )->format( 'Y-m-d' );
		list( $pf, $pt ) = ProfitLens_Reports::previous_range( $from, $to );

		$k    = ProfitLens_Reports::kpis( $from, $to );
		$p    = ProfitLens_Reports::kpis( $pf, $pt );
		$top  = ProfitLens_Reports::breakdown( 'product', $from, $to, 'profit', 'desc', 5 );
		$loss = ProfitLens_Reports::breakdown( 'product', $from, $to, 'profit', 'asc', 5 );

		$money = static function ( $v ) {
			return wp_strip_all_tags( wc_price( $v ) );
		};
		$delta = static function ( $now_v, $prev_v ) {
			if ( abs( $prev_v ) < 0.005 ) {
				return '';
			}
			$pct = ( $now_v - $prev_v ) / abs( $prev_v ) * 100;
			return sprintf( '%s%s%%', $pct >= 0 ? '+' : '', number_format_i18n( $pct, 1 ) );
		};

		$site    = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		/* translators: 1: site name, 2: net profit */
		$subject = sprintf( __( '[%1$s] Weekly profit summary: %2$s net profit', 'profitlens' ), $site, $money( $k['profit'] ) );

		$cells = array(
			array( __( 'Revenue', 'profitlens' ), $money( $k['revenue'] ), $delta( $k['revenue'], $p['revenue'] ) ),
			array( __( 'Net profit', 'profitlens' ), $money( $k['profit'] ), $delta( $k['profit'], $p['profit'] ) ),
			array( __( 'Margin', 'profitlens' ), number_format_i18n( $k['margin'], 1 ) . '%', '' ),
			array( __( 'Orders', 'profitlens' ), number_format_i18n( $k['orders'] ), $delta( $k['orders'], $p['orders'] ) ),
			array( __( 'Ad spend', 'profitlens' ), $money( $k['ad'] ), '' ),
			array( __( 'Profit per order', 'profitlens' ), $money( $k['ppo'] ), '' ),
		);

		$h  = '<div style="font-family:Arial,Helvetica,sans-serif;max-width:600px;margin:0 auto;color:#1d2327">';
		$h .= '<h2 style="margin:0 0 4px">' . esc_html__( 'Your weekly profit summary', 'profitlens' ) . '</h2>';
		$h .= '<p style="margin:0 0 16px;color:#646970">' . esc_html( $from . ' - ' . $to ) . '</p>';
		$h .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse">';
		foreach ( $cells as $c ) {
			$h .= '<tr><td style="padding:8px 0;border-bottom:1px solid #dcdcde">' . esc_html( $c[0] ) . '</td><td style="padding:8px 0;border-bottom:1px solid #dcdcde;text-align:right"><strong>' . esc_html( $c[1] ) . '</strong>';
			if ( $c[2] ) {
				$h .= ' <span style="color:#646970;font-size:12px">' . esc_html( $c[2] ) . ' ' . esc_html__( 'vs previous week', 'profitlens' ) . '</span>';
			}
			$h .= '</td></tr>';
		}
		$h .= '</table>';

		$block = static function ( $title, $rows, $money ) {
			if ( ! $rows ) {
				return '';
			}
			$o = '<h3 style="margin:20px 0 6px">' . esc_html( $title ) . '</h3><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse">';
			foreach ( $rows as $r ) {
				$color = $r['profit'] < 0 ? '#b32d2e' : '#1d2327';
				$o    .= '<tr><td style="padding:6px 0;border-bottom:1px solid #f0f0f1">' . esc_html( $r['label'] ) . '</td><td style="padding:6px 0;border-bottom:1px solid #f0f0f1;text-align:right;color:' . $color . '">' . esc_html( $money( $r['profit'] ) ) . ' (' . esc_html( number_format_i18n( $r['margin'], 1 ) ) . '%)</td></tr>';
			}
			return $o . '</table>';
		};
		$h .= $block( __( 'Top products by profit', 'profitlens' ), $top['rows'], $money );
		$losers = array_filter(
			$loss['rows'],
			static function ( $r ) {
				return $r['profit'] < 0;
			}
		);
		$h .= $block( __( 'Products losing money', 'profitlens' ), $losers, $money );
		if ( $k['missing_orders'] ) {
			$h .= '<p style="margin-top:20px;color:#996800">' . esc_html(
				sprintf(
					/* translators: %d: number of orders */
					_n( '%d order contains products without a cost, so its profit may be overstated.', '%d orders contain products without a cost, so their profit may be overstated.', $k['missing_orders'], 'profitlens' ),
					$k['missing_orders']
				)
			) . '</p>';
		}
		$h .= '<p style="margin-top:24px"><a href="' . esc_url( admin_url( 'admin.php?page=profitlens' ) ) . '">' . esc_html__( 'Open full profit report', 'profitlens' ) . '</a></p></div>';

		return array(
			'subject' => $subject,
			'html'    => $h,
		);
	}
}
