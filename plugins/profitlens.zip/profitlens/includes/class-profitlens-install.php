<?php
/**
 * Installation, database schema and upgrades.
 *
 * @package ProfitLens
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Install routines.
 */
class ProfitLens_Install {

	/**
	 * Table names (without prefix).
	 *
	 * @param string $key orders|items|expenses|recurring.
	 * @return string
	 */
	public static function table( $key ) {
		global $wpdb;
		$map = array(
			'orders'    => 'pl_order_profit',
			'items'     => 'pl_order_items',
			'expenses'  => 'pl_expenses',
			'recurring' => 'pl_recurring',
		);
		return $wpdb->prefix . $map[ $key ];
	}

	/**
	 * Activation.
	 */
	public static function activate() {
		self::create_tables();
		update_option( 'pl_db_version', PL_DB_VERSION );
		if ( false === get_option( 'pl_delete_data', false ) ) {
			add_option( 'pl_delete_data', 'no' );
		}
		self::schedule_cron();
	}

	/**
	 * Deactivation.
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( 'pl_weekly_summary' );
	}

	/**
	 * Run the schema upgrade when the stored version is older.
	 */
	public static function maybe_upgrade() {
		if ( get_option( 'pl_db_version' ) !== PL_DB_VERSION ) {
			self::create_tables();
			update_option( 'pl_db_version', PL_DB_VERSION );
		}
		self::schedule_cron();
	}

	/**
	 * Make sure the weekly event exists (it only sends when enabled).
	 */
	public static function schedule_cron() {
		if ( ! wp_next_scheduled( 'pl_weekly_summary' ) ) {
			$next  = new DateTimeImmutable( 'next monday 08:00', wp_timezone() );
			$start = $next->getTimestamp();
			wp_schedule_event( max( $start, time() + 300 ), 'weekly', 'pl_weekly_summary' );
		}
	}

	/**
	 * Create or update custom tables.
	 */
	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();

		$orders = self::table( 'orders' );
		$items  = self::table( 'items' );
		$exp    = self::table( 'expenses' );
		$rec    = self::table( 'recurring' );

		dbDelta(
			"CREATE TABLE {$orders} (
			order_id BIGINT(20) UNSIGNED NOT NULL,
			order_date DATETIME NOT NULL,
			order_day DATE NOT NULL,
			status VARCHAR(40) NOT NULL DEFAULT '',
			currency VARCHAR(10) NOT NULL DEFAULT '',
			gross_total DECIMAL(18,4) NOT NULL DEFAULT 0,
			revenue DECIMAL(18,4) NOT NULL DEFAULT 0,
			cogs DECIMAL(18,4) NOT NULL DEFAULT 0,
			gateway_fee DECIMAL(18,4) NOT NULL DEFAULT 0,
			shipping_cost DECIMAL(18,4) NOT NULL DEFAULT 0,
			shipping_income DECIMAL(18,4) NOT NULL DEFAULT 0,
			other_income DECIMAL(18,4) NOT NULL DEFAULT 0,
			tax_collected DECIMAL(18,4) NOT NULL DEFAULT 0,
			packaging_cost DECIMAL(18,4) NOT NULL DEFAULT 0,
			other_expenses DECIMAL(18,4) NOT NULL DEFAULT 0,
			ad_allocation DECIMAL(18,4) NOT NULL DEFAULT 0,
			fixed_allocation DECIMAL(18,4) NOT NULL DEFAULT 0,
			net_profit DECIMAL(18,4) NOT NULL DEFAULT 0,
			margin DECIMAL(12,4) NOT NULL DEFAULT 0,
			refunded DECIMAL(18,4) NOT NULL DEFAULT 0,
			missing_cost_items INT(11) NOT NULL DEFAULT 0,
			gateway VARCHAR(100) NOT NULL DEFAULT '',
			country VARCHAR(10) NOT NULL DEFAULT '',
			coupons VARCHAR(255) NOT NULL DEFAULT '',
			customer_email VARCHAR(190) NOT NULL DEFAULT '',
			customer_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			calculated_at DATETIME NOT NULL,
			PRIMARY KEY  (order_id),
			KEY order_day (order_day),
			KEY gateway (gateway),
			KEY country (country),
			KEY customer_email (customer_email)
		) {$charset};"
		);

		dbDelta(
			"CREATE TABLE {$items} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			order_id BIGINT(20) UNSIGNED NOT NULL,
			item_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			product_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			variation_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			category_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			name VARCHAR(255) NOT NULL DEFAULT '',
			qty DECIMAL(18,4) NOT NULL DEFAULT 0,
			revenue DECIMAL(18,4) NOT NULL DEFAULT 0,
			cogs DECIMAL(18,4) NOT NULL DEFAULT 0,
			share DECIMAL(12,8) NOT NULL DEFAULT 0,
			estimated TINYINT(1) NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY order_id (order_id),
			KEY product_id (product_id),
			KEY category_id (category_id)
		) {$charset};"
		);

		dbDelta(
			"CREATE TABLE {$exp} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			date_start DATE NOT NULL,
			date_end DATE NOT NULL,
			kind VARCHAR(20) NOT NULL DEFAULT 'ad',
			source VARCHAR(40) NOT NULL DEFAULT 'manual',
			campaign VARCHAR(190) NOT NULL DEFAULT '',
			amount DECIMAL(18,4) NOT NULL DEFAULT 0,
			note VARCHAR(255) NOT NULL DEFAULT '',
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY date_start (date_start),
			KEY date_end (date_end),
			KEY kind (kind)
		) {$charset};"
		);

		dbDelta(
			"CREATE TABLE {$rec} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(190) NOT NULL DEFAULT '',
			amount DECIMAL(18,4) NOT NULL DEFAULT 0,
			period VARCHAR(20) NOT NULL DEFAULT 'monthly',
			date_start DATE NOT NULL,
			date_end DATE NULL DEFAULT NULL,
			active TINYINT(1) NOT NULL DEFAULT 1,
			PRIMARY KEY  (id)
		) {$charset};"
		);
	}
}
