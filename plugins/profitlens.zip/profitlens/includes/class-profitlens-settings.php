<?php
/**
 * Settings storage and the WooCommerce settings tab.
 *
 * @package ProfitLens
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings helper.
 */
class ProfitLens_Settings {

	/**
	 * Default values for every option (without the pl_ prefix).
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'counted_statuses'    => array( 'wc-completed', 'wc-processing', 'wc-on-hold', 'wc-refunded' ),
			'default_margin'      => '',
			'cost_meta_keys'      => '_cogs_total_value, _wc_cog_cost, _alg_wc_cog_cost, yith_cog_cost',
			'recover_cogs_refund' => 'yes',
			'country_source'      => 'billing',
			'use_actual_fees'     => 'yes',
			'fee_meta_keys'       => '',
			'gateway_fees'        => array(),
			'shipping_costs'      => array(),
			'shipping_fallback'   => 'income',
			'packaging_cost'      => '0',
			'packaging_physical'  => 'yes',
			'weekly_email'        => 'no',
			'email_to'            => '',
			'delete_data'         => 'no',
		);
	}

	/**
	 * Get a setting.
	 *
	 * @param string $key Key without prefix.
	 * @return mixed
	 */
	public static function get( $key ) {
		$defaults = self::defaults();
		$default  = isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
		$value    = get_option( 'pl_' . $key, $default );
		if ( is_array( $default ) && ! is_array( $value ) ) {
			return $default;
		}
		return $value;
	}

	/**
	 * Order statuses (without wc- prefix) that count towards profit.
	 *
	 * @return array
	 */
	public static function counted_statuses() {
		$out = array();
		foreach ( (array) self::get( 'counted_statuses' ) as $status ) {
			$out[] = preg_replace( '/^wc-/', '', sanitize_key( $status ) );
		}
		$out = array_values( array_unique( array_filter( $out ) ) );
		if ( ! $out ) {
			$out = array( 'completed', 'processing', 'on-hold', 'refunded' );
		}
		return $out;
	}

	/**
	 * Hook the WooCommerce settings tab.
	 */
	public static function init() {
		add_filter( 'woocommerce_get_settings_pages', array( __CLASS__, 'register_page' ) );
		add_filter( 'woocommerce_admin_settings_sanitize_option_pl_gateway_fees', array( __CLASS__, 'sanitize_gateway_fees' ), 10, 3 );
		add_filter( 'woocommerce_admin_settings_sanitize_option_pl_shipping_costs', array( __CLASS__, 'sanitize_shipping_costs' ), 10, 3 );
		add_filter( 'woocommerce_admin_settings_sanitize_option_pl_cost_meta_keys', array( __CLASS__, 'sanitize_meta_keys' ), 10, 3 );
		add_filter( 'woocommerce_admin_settings_sanitize_option_pl_fee_meta_keys', array( __CLASS__, 'sanitize_meta_keys' ), 10, 3 );
		add_filter( 'woocommerce_admin_settings_sanitize_option_pl_default_margin', array( __CLASS__, 'sanitize_percent' ), 10, 3 );
		add_filter( 'woocommerce_admin_settings_sanitize_option_pl_packaging_cost', array( __CLASS__, 'sanitize_money' ), 10, 3 );
		add_action( 'woocommerce_admin_field_pl_gateway_fees', array( __CLASS__, 'field_gateway_fees' ) );
		add_action( 'woocommerce_admin_field_pl_shipping_costs', array( __CLASS__, 'field_shipping_costs' ) );
	}

	/**
	 * Register the settings page object.
	 *
	 * @param array $pages Pages.
	 * @return array
	 */
	public static function register_page( $pages ) {
		require_once PL_PATH . 'includes/class-profitlens-settings-page.php';
		$pages[] = new ProfitLens_Settings_Page();
		return $pages;
	}

	/**
	 * Sanitise a percentage setting.
	 *
	 * @param mixed $value Value.
	 * @return string
	 */
	public static function sanitize_percent( $value ) {
		$value = is_scalar( $value ) ? trim( (string) $value ) : '';
		if ( '' === $value ) {
			return '';
		}
		return (string) max( 0, min( 99.99, (float) wc_format_decimal( $value ) ) );
	}

	/**
	 * Sanitise a money setting.
	 *
	 * @param mixed $value Value.
	 * @return string
	 */
	public static function sanitize_money( $value ) {
		$value = is_scalar( $value ) ? trim( (string) $value ) : '';
		return (string) max( 0, (float) wc_format_decimal( $value ) );
	}

	/**
	 * Sanitise a list of meta keys; stored as a comma separated string.
	 *
	 * @param mixed $value Value.
	 * @return string
	 */
	public static function sanitize_meta_keys( $value ) {
		return implode( ', ', self::parse_keys( $value ) );
	}

	/**
	 * Parse comma/newline separated meta keys.
	 *
	 * @param mixed $value Raw string.
	 * @return array
	 */
	public static function parse_keys( $value ) {
		if ( ! is_string( $value ) ) {
			return array();
		}
		$parts = preg_split( '/[\s,]+/', $value );
		$out   = array();
		foreach ( (array) $parts as $part ) {
			$part = preg_replace( '/[^A-Za-z0-9_\-\. ]/', '', $part );
			if ( '' !== $part ) {
				$out[] = $part;
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Sanitise gateway fee rules.
	 *
	 * @param mixed $value Posted array.
	 * @return array
	 */
	public static function sanitize_gateway_fees( $value ) {
		$out = array();
		if ( is_array( $value ) ) {
			foreach ( $value as $gateway => $rule ) {
				$gateway = sanitize_key( $gateway );
				if ( '' === $gateway || ! is_array( $rule ) ) {
					continue;
				}
				$percent = isset( $rule['percent'] ) ? (float) wc_format_decimal( $rule['percent'] ) : 0;
				$fixed   = isset( $rule['fixed'] ) ? (float) wc_format_decimal( $rule['fixed'] ) : 0;
				if ( $percent > 0 || $fixed > 0 ) {
					$out[ $gateway ] = array(
						'percent' => max( 0, min( 100, $percent ) ),
						'fixed'   => max( 0, $fixed ),
					);
				}
			}
		}
		return $out;
	}

	/**
	 * Sanitise shipping method default costs.
	 *
	 * @param mixed $value Posted array.
	 * @return array
	 */
	public static function sanitize_shipping_costs( $value ) {
		$out = array();
		if ( is_array( $value ) ) {
			foreach ( $value as $key => $amount ) {
				$key = preg_replace( '/[^a-z0-9_:\-]/', '', strtolower( (string) $key ) );
				if ( '' === $key || ! is_scalar( $amount ) || '' === trim( (string) $amount ) ) {
					continue;
				}
				$out[ $key ] = max( 0, (float) wc_format_decimal( $amount ) );
			}
		}
		return $out;
	}

	/**
	 * Render the gateway fee table.
	 *
	 * @param array $field Field definition.
	 */
	public static function field_gateway_fees( $field ) {
		$rules    = self::get( 'gateway_fees' );
		$gateways = WC()->payment_gateways()->payment_gateways();
		?>
		<tr valign="top">
			<th scope="row" class="titledesc"><?php echo esc_html( $field['title'] ); ?></th>
			<td class="forminp">
				<table class="widefat" style="max-width:640px">
					<thead><tr>
						<th><?php esc_html_e( 'Payment gateway', 'profitlens' ); ?></th>
						<th><?php esc_html_e( 'Percentage fee (%)', 'profitlens' ); ?></th>
						<th><?php esc_html_e( 'Fixed fee per order', 'profitlens' ); ?></th>
					</tr></thead>
					<tbody>
					<?php foreach ( $gateways as $id => $gateway ) : ?>
						<?php
						$rule = isset( $rules[ $id ] ) ? $rules[ $id ] : array(
							'percent' => '',
							'fixed'   => '',
						);
						?>
						<tr>
							<td><strong><?php echo esc_html( wp_strip_all_tags( $gateway->get_method_title() ) ); ?></strong><br><code><?php echo esc_html( $id ); ?></code></td>
							<td><input type="text" class="wc_input_decimal" style="width:90px" name="pl_gateway_fees[<?php echo esc_attr( $id ); ?>][percent]" value="<?php echo esc_attr( $rule['percent'] ); ?>" placeholder="0"></td>
							<td><input type="text" class="wc_input_price" style="width:90px" name="pl_gateway_fees[<?php echo esc_attr( $id ); ?>][fixed]" value="<?php echo esc_attr( $rule['fixed'] ); ?>" placeholder="0"></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<p class="description"><?php echo esc_html( $field['desc'] ); ?></p>
			</td>
		</tr>
		<?php
	}

	/**
	 * Render the shipping method cost table.
	 *
	 * @param array $field Field definition.
	 */
	public static function field_shipping_costs( $field ) {
		$costs = self::get( 'shipping_costs' );
		$rows  = ProfitLens_Fees::shipping_method_rows();
		?>
		<tr valign="top">
			<th scope="row" class="titledesc"><?php echo esc_html( $field['title'] ); ?></th>
			<td class="forminp">
				<table class="widefat" style="max-width:640px">
					<thead><tr>
						<th><?php esc_html_e( 'Shipping method', 'profitlens' ); ?></th>
						<th><?php esc_html_e( 'Your cost per order', 'profitlens' ); ?></th>
					</tr></thead>
					<tbody>
					<?php foreach ( $rows as $key => $label ) : ?>
						<tr>
							<td><?php echo esc_html( $label ); ?><br><code><?php echo esc_html( $key ); ?></code></td>
							<td><input type="text" class="wc_input_price" style="width:100px" name="pl_shipping_costs[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( isset( $costs[ $key ] ) ? $costs[ $key ] : '' ); ?>" placeholder="-"></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<p class="description"><?php echo esc_html( $field['desc'] ); ?></p>
			</td>
		</tr>
		<?php
	}
}
