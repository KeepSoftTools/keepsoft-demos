<?php
/**
 * Product cost of goods: fields, lookup and CSV import/export.
 *
 * @package ProfitLens
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Costs.
 */
class ProfitLens_Costs {

	const META_KEY = '_pl_cost';

	/**
	 * Per-request cache.
	 *
	 * @var array
	 */
	private static $cache = array();

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'woocommerce_product_options_pricing', array( __CLASS__, 'render_product_field' ) );
		add_action( 'woocommerce_process_product_meta', array( __CLASS__, 'save_product_field' ) );
		add_action( 'woocommerce_variation_options_pricing', array( __CLASS__, 'render_variation_field' ), 10, 3 );
		add_action( 'woocommerce_save_product_variation', array( __CLASS__, 'save_variation_field' ), 10, 2 );
		add_action( 'admin_post_pl_export_costs', array( __CLASS__, 'handle_export' ) );
		add_action( 'admin_post_pl_import_costs', array( __CLASS__, 'handle_import' ) );
	}

	/**
	 * Currency-aware label.
	 *
	 * @return string
	 */
	private static function label() {
		/* translators: %s: currency symbol */
		return sprintf( __( 'Cost of goods (%s)', 'profitlens' ), get_woocommerce_currency_symbol() );
	}

	/**
	 * Cost field on the simple product General tab.
	 */
	public static function render_product_field() {
		global $post;
		if ( ! $post ) {
			return;
		}
		woocommerce_wp_text_input(
			array(
				'id'          => '_pl_cost',
				'value'       => get_post_meta( $post->ID, self::META_KEY, true ),
				'label'       => self::label(),
				'data_type'   => 'price',
				'desc_tip'    => true,
				'description' => __( 'What this product costs you. Used by ProfitLens to calculate profit.', 'profitlens' ),
			)
		);
	}

	/**
	 * Save the simple product cost. WooCommerce has already verified its nonce and capability.
	 *
	 * @param int $post_id Product ID.
	 */
	public static function save_product_field( $post_id ) {
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		if ( isset( $_POST['_pl_cost'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified by WooCommerce.
			self::set_cost( $post_id, wp_unslash( $_POST['_pl_cost'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised in set_cost().
		}
	}

	/**
	 * Cost field on a variation.
	 *
	 * @param int     $loop           Loop index.
	 * @param array   $variation_data Data.
	 * @param WP_Post $variation      Variation post.
	 */
	public static function render_variation_field( $loop, $variation_data, $variation ) {
		woocommerce_wp_text_input(
			array(
				'id'            => '_pl_cost_' . $loop,
				'name'          => '_pl_cost[' . $loop . ']',
				'value'         => get_post_meta( $variation->ID, self::META_KEY, true ),
				'label'         => self::label(),
				'data_type'     => 'price',
				'wrapper_class' => 'form-row form-row-first',
				'placeholder'   => __( 'Same as parent', 'profitlens' ),
			)
		);
	}

	/**
	 * Save variation cost. WooCommerce verifies the nonce for the variation save request.
	 *
	 * @param int $variation_id Variation ID.
	 * @param int $i            Loop index.
	 */
	public static function save_variation_field( $variation_id, $i ) {
		if ( ! current_user_can( 'edit_post', $variation_id ) ) {
			return;
		}
		if ( isset( $_POST['_pl_cost'][ $i ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified by WooCommerce.
			self::set_cost( $variation_id, wp_unslash( $_POST['_pl_cost'][ $i ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised in set_cost().
		}
	}

	/**
	 * Store (or clear) a cost.
	 *
	 * @param int   $product_id Product or variation ID.
	 * @param mixed $value      Raw value.
	 */
	public static function set_cost( $product_id, $value ) {
		$value = is_scalar( $value ) ? trim( (string) $value ) : '';
		if ( '' === $value ) {
			delete_post_meta( $product_id, self::META_KEY );
		} else {
			update_post_meta( $product_id, self::META_KEY, wc_format_decimal( $value ) );
		}
		unset( self::$cache[ $product_id ] );
	}

	/**
	 * Cost stored directly on one product/variation post (ProfitLens key, then mapped keys).
	 *
	 * @param int $id Post ID.
	 * @return float|null
	 */
	public static function own_cost( $id ) {
		if ( ! $id ) {
			return null;
		}
		if ( array_key_exists( $id, self::$cache ) ) {
			return self::$cache[ $id ];
		}
		$keys = array_merge( array( self::META_KEY ), ProfitLens_Settings::parse_keys( (string) ProfitLens_Settings::get( 'cost_meta_keys' ) ) );
		$cost = null;
		foreach ( $keys as $key ) {
			$raw = get_post_meta( $id, $key, true );
			if ( is_scalar( $raw ) && '' !== trim( (string) $raw ) && is_numeric( $raw ) ) {
				$cost = (float) $raw;
				break;
			}
		}
		self::$cache[ $id ] = $cost;
		return $cost;
	}

	/**
	 * Unit cost for an order line: variation first, then parent product.
	 *
	 * @param int $product_id   Parent product ID.
	 * @param int $variation_id Variation ID (0 if none).
	 * @return float|null Null when no cost is known.
	 */
	public static function unit_cost( $product_id, $variation_id = 0 ) {
		$cost = null;
		if ( $variation_id ) {
			$cost = self::own_cost( (int) $variation_id );
		}
		if ( null === $cost && $product_id ) {
			$cost = self::own_cost( (int) $product_id );
		}
		return apply_filters( 'pl_unit_cost', $cost, $product_id, $variation_id );
	}

	/**
	 * Clear the lookup cache (used by long-running imports).
	 */
	public static function flush_cache() {
		self::$cache = array();
	}

	/**
	 * Export all products/variations with their costs.
	 */
	public static function handle_export() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'profitlens' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'pl_export_costs' );

		$rows = array();
		$page = 1;
		do {
			$ids = wc_get_products(
				array(
					'status' => array( 'publish', 'draft', 'private', 'pending' ),
					'limit'  => 200,
					'page'   => $page,
					'return' => 'ids',
					'type'    => array_keys( wc_get_product_types() ),
					'orderby' => 'ID',
					'order'   => 'ASC',
				)
			);
			foreach ( $ids as $id ) {
				$product = wc_get_product( $id );
				if ( ! $product ) {
					continue;
				}
				$rows[] = self::export_row( $product );
				if ( $product->is_type( 'variable' ) ) {
					foreach ( $product->get_children() as $child_id ) {
						$child = wc_get_product( $child_id );
						if ( $child ) {
							$rows[] = self::export_row( $child );
						}
					}
				}
			}
			++$page;
		} while ( count( $ids ) === 200 );

		ProfitLens_CSV::download(
			'profitlens-costs-' . gmdate( 'Y-m-d' ) . '.csv',
			array( 'product_id', 'parent_id', 'sku', 'name', 'type', 'price', 'cost' ),
			$rows
		);
	}

	/**
	 * One export row.
	 *
	 * @param WC_Product $product Product.
	 * @return array
	 */
	private static function export_row( $product ) {
		$cost = get_post_meta( $product->get_id(), self::META_KEY, true );
		return array(
			$product->get_id(),
			$product->get_parent_id(),
			$product->get_sku(),
			wp_strip_all_tags( $product->get_name() ),
			$product->get_type(),
			$product->get_price(),
			'' === $cost ? '' : $cost,
		);
	}

	/**
	 * Import costs from a CSV. Accepts product_id and/or sku plus a cost column.
	 */
	public static function handle_import() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'profitlens' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'pl_import_costs' );

		$redirect = admin_url( 'admin.php?page=profitlens&tab=costs' );
		$path     = ProfitLens_CSV::uploaded_path();
		if ( is_wp_error( $path ) ) {
			ProfitLens_Admin::flash( 'error', $path->get_error_message() );
			wp_safe_redirect( $redirect );
			exit;
		}
		$rows = ProfitLens_CSV::read( $path );
		if ( is_wp_error( $rows ) || count( $rows ) < 2 ) {
			ProfitLens_Admin::flash( 'error', is_wp_error( $rows ) ? $rows->get_error_message() : __( 'The CSV needs a header row and at least one data row.', 'profitlens' ) );
			wp_safe_redirect( $redirect );
			exit;
		}

		$header = array_map( 'strtolower', array_shift( $rows ) );
		$idx    = array(
			'id'   => self::find_col( $header, array( 'product_id', 'id', 'variation_id' ) ),
			'sku'  => self::find_col( $header, array( 'sku' ) ),
			'cost' => self::find_col( $header, array( 'cost', 'cost_price', 'cogs', 'cost of goods', 'unit_cost' ) ),
		);
		if ( null === $idx['cost'] || ( null === $idx['id'] && null === $idx['sku'] ) ) {
			ProfitLens_Admin::flash( 'error', __( 'The CSV must contain a "cost" column and a "product_id" or "sku" column.', 'profitlens' ) );
			wp_safe_redirect( $redirect );
			exit;
		}

		$updated = 0;
		$cleared = 0;
		$skipped = 0;
		$errors  = array();
		foreach ( $rows as $n => $row ) {
			$line = $n + 2;
			$id   = 0;
			if ( null !== $idx['id'] && isset( $row[ $idx['id'] ] ) && ctype_digit( $row[ $idx['id'] ] ) ) {
				$id = (int) $row[ $idx['id'] ];
			}
			if ( ! $id && null !== $idx['sku'] && ! empty( $row[ $idx['sku'] ] ) ) {
				$id = (int) wc_get_product_id_by_sku( $row[ $idx['sku'] ] );
			}
			$product = $id ? wc_get_product( $id ) : false;
			if ( ! $product ) {
				++$skipped;
				if ( count( $errors ) < 10 ) {
					/* translators: %d: CSV line number */
					$errors[] = sprintf( __( 'Line %d: product not found.', 'profitlens' ), $line );
				}
				continue;
			}
			$raw = isset( $row[ $idx['cost'] ] ) ? $row[ $idx['cost'] ] : '';
			if ( '' === $raw ) {
				self::set_cost( $id, '' );
				++$cleared;
				continue;
			}
			$cost = ProfitLens_CSV::parse_number( $raw );
			if ( null === $cost || $cost < 0 ) {
				++$skipped;
				if ( count( $errors ) < 10 ) {
					/* translators: %d: CSV line number */
					$errors[] = sprintf( __( 'Line %d: invalid cost.', 'profitlens' ), $line );
				}
				continue;
			}
			self::set_cost( $id, (string) $cost );
			++$updated;
		}

		$msg = sprintf(
			/* translators: 1: updated count, 2: cleared count, 3: skipped count */
			__( 'Cost import finished: %1$d updated, %2$d cleared, %3$d skipped.', 'profitlens' ),
			$updated,
			$cleared,
			$skipped
		);
		if ( $errors ) {
			$msg .= ' ' . implode( ' ', $errors );
		}
		ProfitLens_Admin::flash( $skipped ? 'warning' : 'success', $msg );
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Find a column index by candidate names.
	 *
	 * @param array $header Lower-case header.
	 * @param array $names  Candidate names.
	 * @return int|null
	 */
	public static function find_col( array $header, array $names ) {
		foreach ( $names as $name ) {
			$pos = array_search( $name, $header, true );
			if ( false !== $pos ) {
				return (int) $pos;
			}
		}
		return null;
	}
}
