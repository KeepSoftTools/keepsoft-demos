<?php
/**
 * CSV helpers (reading, writing, number parsing).
 *
 * @package ProfitLens
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CSV utilities.
 */
class ProfitLens_CSV {

	/**
	 * Neutralise spreadsheet formulas in text cells.
	 *
	 * @param mixed $value Cell value.
	 * @return mixed
	 */
	public static function safe_cell( $value ) {
		if ( is_string( $value ) && '' !== $value && ! is_numeric( $value ) && preg_match( '/^[=+\-@\t\r]/', $value ) ) {
			return "'" . $value;
		}
		return $value;
	}

	/**
	 * Send a CSV download and exit.
	 *
	 * @param string $filename Download name.
	 * @param array  $header   Header row.
	 * @param array  $rows     Data rows.
	 */
	public static function download( $filename, array $header, array $rows ) {
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $filename ) . '"' );
		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
		fputcsv( $out, $header ); // phpcs:ignore
		foreach ( $rows as $row ) {
			fputcsv( $out, array_map( array( __CLASS__, 'safe_cell' ), $row ) ); // phpcs:ignore
		}
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		exit;
	}

	/**
	 * Read an uploaded CSV file into an array of rows.
	 *
	 * @param string $path Temp file path.
	 * @return array|WP_Error
	 */
	public static function read( $path ) {
		$raw = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( false === $raw || '' === $raw ) {
			return new WP_Error( 'pl_empty', __( 'The file is empty or unreadable.', 'profitlens' ) );
		}
		if ( 0 === strpos( $raw, "\xEF\xBB\xBF" ) ) {
			$raw = substr( $raw, 3 );
		}
		if ( 0 === strpos( $raw, "\xFF\xFE" ) && function_exists( 'mb_convert_encoding' ) ) {
			$raw = mb_convert_encoding( substr( $raw, 2 ), 'UTF-8', 'UTF-16LE' );
		} elseif ( function_exists( 'mb_check_encoding' ) && ! mb_check_encoding( $raw, 'UTF-8' ) ) {
			$raw = mb_convert_encoding( $raw, 'UTF-8', 'Windows-1252' );
		}
		$raw   = str_replace( array( "\r\n", "\r" ), "\n", $raw );
		$lines = explode( "\n", $raw, 12 );
		$delim = ',';
		$best  = 0;
		foreach ( array( ',', ';', "\t" ) as $candidate ) {
			$count = 0;
			foreach ( array_slice( $lines, 0, 10 ) as $line ) {
				$count += substr_count( $line, $candidate );
			}
			if ( $count > $best ) {
				$best  = $count;
				$delim = $candidate;
			}
		}
		$rows = array();
		$h    = fopen( 'php://temp', 'r+' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		fwrite( $h, $raw ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
		rewind( $h );
		while ( false !== ( $row = fgetcsv( $h, 0, $delim ) ) ) { // phpcs:ignore WordPress.CodeAnalysis.AssignmentInCondition
			if ( array( null ) === $row ) {
				continue;
			}
			$rows[] = array_map( 'trim', array_map( 'strval', $row ) );
		}
		fclose( $h ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		return $rows;
	}

	/**
	 * Validate the uploaded file in $_FILES and return its temp path.
	 *
	 * @param string $field Field name.
	 * @return string|WP_Error
	 */
	public static function uploaded_path( $field = 'pl_file' ) {
		if ( empty( $_FILES[ $field ]['tmp_name'] ) || ! empty( $_FILES[ $field ]['error'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return new WP_Error( 'pl_nofile', __( 'Please choose a CSV file to upload.', 'profitlens' ) );
		}
		$tmp  = $_FILES[ $field ]['tmp_name']; // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput
		$name = isset( $_FILES[ $field ]['name'] ) ? sanitize_file_name( wp_unslash( $_FILES[ $field ]['name'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( ! is_uploaded_file( $tmp ) ) {
			return new WP_Error( 'pl_nofile', __( 'The upload could not be verified.', 'profitlens' ) );
		}
		$ext = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
		if ( ! in_array( $ext, array( 'csv', 'txt', 'tsv' ), true ) ) {
			return new WP_Error( 'pl_ext', __( 'Only .csv files are accepted.', 'profitlens' ) );
		}
		if ( filesize( $tmp ) > 10 * MB_IN_BYTES ) {
			return new WP_Error( 'pl_size', __( 'The file is larger than 10 MB.', 'profitlens' ) );
		}
		return $tmp;
	}

	/**
	 * Parse a money value from exports ("$1,234.56", "1.234,56", "(12.00)").
	 *
	 * @param string $value Raw text.
	 * @return float|null Null when not a number.
	 */
	public static function parse_number( $value ) {
		$value = trim( (string) $value );
		if ( '' === $value ) {
			return null;
		}
		$neg = false;
		if ( preg_match( '/^\((.*)\)$/', $value, $m ) ) {
			$neg   = true;
			$value = $m[1];
		}
		// Strip currency symbols, 3-letter currency codes and spaces; anything else is not a number.
		$value = preg_replace( '/\p{Sc}|\s|\x{00A0}/u', '', $value );
		$value = preg_replace( '/^[A-Za-z]{1,3}|[A-Za-z]{1,3}$/', '', $value );
		if ( ! preg_match( '/^-?[0-9][0-9,.]*$|^-?[.,][0-9]+$/', $value ) ) {
			return null;
		}
		if ( 0 === strpos( $value, '-' ) ) {
			$neg   = true;
			$value = ltrim( $value, '-' );
		}
		$value = str_replace( '-', '', $value );
		$comma = strrpos( $value, ',' );
		$dot   = strrpos( $value, '.' );
		if ( false !== $comma && false !== $dot ) {
			if ( $comma > $dot ) {
				$value = str_replace( '.', '', $value );
				$value = str_replace( ',', '.', $value );
			} else {
				$value = str_replace( ',', '', $value );
			}
		} elseif ( false !== $comma ) {
			if ( preg_match( '/,\d{1,2}$/', $value ) && 1 === substr_count( $value, ',' ) ) {
				$value = str_replace( ',', '.', $value );
			} else {
				$value = str_replace( ',', '', $value );
			}
		}
		$number = (float) $value;
		return $neg ? -$number : $number;
	}

	/**
	 * Parse a date string from an export into Y-m-d.
	 *
	 * @param string $value  Raw date.
	 * @param string $format auto|dmy|mdy.
	 * @return string|null
	 */
	public static function parse_date( $value, $format = 'auto' ) {
		$value = trim( (string) $value );
		if ( '' === $value ) {
			return null;
		}
		if ( preg_match( '/^(\d{4})-(\d{1,2})-(\d{1,2})/', $value, $m ) || preg_match( '/^(\d{4})\/(\d{1,2})\/(\d{1,2})/', $value, $m ) ) {
			return checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ? sprintf( '%04d-%02d-%02d', $m[1], $m[2], $m[3] ) : null;
		}
		if ( preg_match( '/^(\d{1,2})[\/\.\-](\d{1,2})[\/\.\-](\d{2,4})/', $value, $m ) ) {
			$a = (int) $m[1];
			$b = (int) $m[2];
			$y = (int) $m[3];
			if ( $y < 100 ) {
				$y += 2000;
			}
			$day   = $a;
			$month = $b;
			if ( 'mdy' === $format ) {
				$day   = $b;
				$month = $a;
			} elseif ( 'auto' === $format && $b > 12 && $a <= 12 ) {
				$day   = $b;
				$month = $a;
			}
			return checkdate( $month, $day, $y ) ? sprintf( '%04d-%02d-%02d', $y, $month, $day ) : null;
		}
		$ts = strtotime( $value );
		return $ts ? gmdate( 'Y-m-d', $ts ) : null;
	}
}
