<?php
/**
 * Uninstall ProfitLens.
 *
 * Data is only removed when "Delete data on uninstall" is ticked in
 * WooCommerce > Settings > ProfitLens > Data. Otherwise everything is kept
 * so that re-installing the plugin does not lose costs or expenses.
 *
 * @package ProfitLens
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Remove ProfitLens data from the current site.
 */
function pl_uninstall_site() {
	global $wpdb;

	wp_clear_scheduled_hook( 'pl_weekly_summary' );

	if ( 'yes' !== get_option( 'pl_delete_data', 'no' ) ) {
		return;
	}

	// Custom tables.
	foreach ( array( 'pl_order_profit', 'pl_order_items', 'pl_expenses', 'pl_recurring' ) as $table ) {
		$wpdb->query( 'DROP TABLE IF EXISTS `' . esc_sql( $wpdb->prefix . $table ) . '`' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
	}

	// Product costs (products and variations are posts).
	$wpdb->delete( $wpdb->postmeta, array( 'meta_key' => '_pl_cost' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery, WordPress.DB.DirectDatabaseQuery

	// Per-order fields: legacy post meta and HPOS meta table.
	foreach ( array( '_pl_shipping_cost', '_pl_gateway_fee', '_pl_other_expenses' ) as $key ) {
		$wpdb->delete( $wpdb->postmeta, array( 'meta_key' => $key ) ); // phpcs:ignore WordPress.DB.SlowDBQuery, WordPress.DB.DirectDatabaseQuery
		$hpos_meta = $wpdb->prefix . 'wc_orders_meta';
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $hpos_meta ) ) === $hpos_meta ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->delete( $hpos_meta, array( 'meta_key' => $key ) ); // phpcs:ignore WordPress.DB.SlowDBQuery, WordPress.DB.DirectDatabaseQuery
		}
	}

	// Cost snapshots saved on order items.
	$wpdb->delete( $wpdb->prefix . 'woocommerce_order_itemmeta', array( 'meta_key' => '_pl_unit_cost' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery, WordPress.DB.DirectDatabaseQuery

	// Options and transients.
	$options = array(
		'counted_statuses', 'default_margin', 'cost_meta_keys', 'recover_cogs_refund', 'country_source', 'use_actual_fees',
		'fee_meta_keys', 'gateway_fees', 'shipping_costs', 'shipping_fallback', 'packaging_cost', 'packaging_physical',
		'weekly_email', 'email_to', 'delete_data', 'db_version', 'last_backfill',
	);
	foreach ( $options as $option ) {
		delete_option( 'pl_' . $option );
	}
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $wpdb->esc_like( '_transient_pl_flash_' ) . '%', $wpdb->esc_like( '_transient_timeout_pl_flash_' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
}

if ( is_multisite() ) {
	$pl_sites = get_sites(
		array(
			'fields' => 'ids',
			'number' => 0,
		)
	);
	foreach ( $pl_sites as $pl_site_id ) {
		switch_to_blog( $pl_site_id );
		pl_uninstall_site();
		restore_current_blog();
	}
} else {
	pl_uninstall_site();
}
