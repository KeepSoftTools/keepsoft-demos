<?php
/**
 * Plugin Name:          ProfitLens – Net Profit & Margin Reports for WooCommerce
 * Plugin URI:           https://keepsofttools.github.io/keepsoft-demos/
 * Description:          See your real net profit per order, product, category, gateway, country, coupon and customer. Tracks cost of goods, payment fees, shipping, ad spend and fixed costs.
 * Version:              1.0.0
 * Requires at least:    5.8
 * Requires PHP:         7.4
 * Requires Plugins:     woocommerce
 * WC requires at least: 7.0
 * WC tested up to:      11.2
 * Author:               Keepsoft
 * Author URI:           https://keepsofttools.github.io/keepsoft-demos/
 * License:              GPL-2.0-or-later
 * License URI:          https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:          profitlens
 * Domain Path:          /languages
 *
 * @package ProfitLens
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'PL_VERSION', '1.0.0' );
define( 'PL_DB_VERSION', '1.0' );
define( 'PL_FILE', __FILE__ );
define( 'PL_PATH', plugin_dir_path( __FILE__ ) );
define( 'PL_URL', plugin_dir_url( __FILE__ ) );

// Declare compatibility with High-Performance Order Storage (HPOS).
add_action(
	'before_woocommerce_init',
	static function () {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', PL_FILE, true );
		}
	}
);

require_once PL_PATH . 'includes/class-profitlens-install.php';
require_once PL_PATH . 'includes/class-profitlens-settings.php';
require_once PL_PATH . 'includes/class-profitlens-csv.php';
require_once PL_PATH . 'includes/class-profitlens-costs.php';
require_once PL_PATH . 'includes/class-profitlens-fees.php';
require_once PL_PATH . 'includes/class-profitlens-expenses.php';
require_once PL_PATH . 'includes/class-profitlens-engine.php';
require_once PL_PATH . 'includes/class-profitlens-reports.php';
require_once PL_PATH . 'includes/class-profitlens-email.php';
require_once PL_PATH . 'includes/class-profitlens-order-ui.php';
require_once PL_PATH . 'includes/class-profitlens-admin.php';

register_activation_hook( PL_FILE, array( 'ProfitLens_Install', 'activate' ) );
register_deactivation_hook( PL_FILE, array( 'ProfitLens_Install', 'deactivate' ) );

/**
 * Boot the plugin once all plugins are loaded and WooCommerce is available.
 */
function pl_boot() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', 'pl_missing_woocommerce_notice' );
		return;
	}

	ProfitLens_Install::maybe_upgrade();
	ProfitLens_Settings::init();
	ProfitLens_Costs::init();
	ProfitLens_Engine::init();
	ProfitLens_Expenses::init();
	ProfitLens_Email::init();
	ProfitLens_Order_UI::init();
	ProfitLens_Admin::init();
}
add_action( 'plugins_loaded', 'pl_boot', 20 );

/**
 * Load the translation files.
 */
function pl_load_textdomain() {
	load_plugin_textdomain( 'profitlens', false, dirname( plugin_basename( PL_FILE ) ) . '/languages' );
}
add_action( 'init', 'pl_load_textdomain' );

/**
 * Admin notice shown when WooCommerce is not active.
 */
function pl_missing_woocommerce_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	echo '<div class="notice notice-error"><p>' . esc_html__( 'ProfitLens requires WooCommerce to be installed and active.', 'profitlens' ) . '</p></div>';
}

/**
 * Add quick links on the plugins screen.
 *
 * @param array $links Existing links.
 * @return array
 */
function pl_action_links( $links ) {
	$extra = array(
		'<a href="' . esc_url( admin_url( 'admin.php?page=profitlens' ) ) . '">' . esc_html__( 'Reports', 'profitlens' ) . '</a>',
		'<a href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=profitlens' ) ) . '">' . esc_html__( 'Settings', 'profitlens' ) . '</a>',
	);
	return array_merge( $extra, $links );
}
add_filter( 'plugin_action_links_' . plugin_basename( PL_FILE ), 'pl_action_links' );
