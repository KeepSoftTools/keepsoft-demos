<?php
/**
 * Uninstall: remove data only if the owner opted in (Settings > Data).
 *
 * @package AccessFix
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$af_settings = get_option( 'af_settings', array() );
wp_clear_scheduled_hook( 'af_cron_scan' );
wp_clear_scheduled_hook( 'af_cron_batch' );

if ( is_array( $af_settings ) && ! empty( $af_settings['delete_data'] ) ) {
	global $wpdb;
	foreach ( array( 'issues', 'audit', 'scans', 'pages' ) as $af_t ) {
		$wpdb->query( 'DROP TABLE IF EXISTS `' . $wpdb->prefix . 'af_' . $af_t . '`' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
	}
	foreach ( array( 'af_settings', 'af_statement', 'af_statement_page', 'af_eaa_manual', 'af_scan_secret', 'af_db_version' ) as $af_o ) {
		delete_option( $af_o );
	}
	// Decorative flags on attachments.
	$wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key = '_af_decorative'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	// Cached stylesheet transients.
	$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_af\_css\_%' OR option_name LIKE '\_transient\_timeout\_af\_css\_%'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
}
