/* AccessFix: select the block that contains the reported element. Vanilla JS. */
(function () {
	'use strict';
	if (typeof afEditor === 'undefined' || !window.wp || !wp.data) { return; }

	function unescapeHtml(s) {
		var t = document.createElement('textarea');
		t.innerHTML = s;
		return t.value;
	}

	function find(blocks, needle) {
		for (var i = 0; i < blocks.length; i++) {
			var b = blocks[i];
			var hay = unescapeHtml((b.originalContent || '') + ' ' + JSON.stringify(b.attributes || {}));
			var inner = b.innerBlocks && b.innerBlocks.length ? find(b.innerBlocks, needle) : null;
			if (inner) { return inner; }
			if (needle && hay.indexOf(needle) !== -1) { return b; }
		}
		return null;
	}

	var tries = 0;
	function attempt() {
		var sel = wp.data.select('core/block-editor');
		if (!sel) { return; }
		var blocks = sel.getBlocks();
		if (!blocks.length && tries++ < 40) { window.setTimeout(attempt, 250); return; }
		var base = (afEditor.needle || '').split('/').pop();
		var hit = find(blocks, afEditor.needle) || (base ? find(blocks, base) : null);
		var notices = wp.data.dispatch('core/notices');
		if (hit) {
			wp.data.dispatch('core/block-editor').selectBlock(hit.clientId);
			window.setTimeout(function () {
				var el = document.getElementById('block-' + hit.clientId);
				if (el && el.scrollIntoView) { el.scrollIntoView({ block: 'center' }); }
			}, 300);
			notices.createNotice('warning', afEditor.message + (afEditor.help ? ' ' + afEditor.help : ''), { isDismissible: true });
		} else {
			notices.createNotice('info', afEditor.message + ' ' + afEditor.miss, { isDismissible: true });
		}
	}
	wp.domReady(function () { window.setTimeout(attempt, 600); });
})();
