/* AccessFix admin scripts (vanilla JS). */
(function () {
	'use strict';
	if (typeof afData === 'undefined') { return; }

	function fmt(s) {
		var args = Array.prototype.slice.call(arguments, 1), i = 0;
		return s.replace(/%(\d+\$)?d/g, function () { return args[i++]; });
	}

	function api(path, body) {
		return fetch(afData.root + path, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': afData.nonce },
			body: JSON.stringify(body || {})
		}).then(function (r) {
			return r.json().then(function (j) {
				if (!r.ok) { throw new Error(j && j.message ? j.message : ('HTTP ' + r.status)); }
				return j;
			});
		});
	}

	// Scan button.
	var btn = document.getElementById('af-scan-btn');
	if (btn) {
		var status = document.getElementById('af-scan-status');
		var bar = document.getElementById('af-progress-bar');
		var wrap = bar ? bar.parentNode : null;
		var setProgress = function (done, total) {
			var pct = total ? Math.round(100 * done / total) : 0;
			if (wrap) { wrap.hidden = false; }
			bar.style.width = pct + '%';
			bar.setAttribute('aria-valuenow', String(pct));
		};
		var step = function (p) {
			setProgress(p.done, p.total);
			if (p.status === 'running') {
				status.textContent = fmt(afData.i18n.progress, p.done, p.total);
				return api('scan/batch', { scan_id: p.scan_id }).then(step);
			}
			status.textContent = fmt(afData.i18n.done, p.done, p.errors);
			window.setTimeout(function () { window.location.reload(); }, 800);
		};
		btn.addEventListener('click', function () {
			btn.disabled = true;
			status.textContent = afData.i18n.starting;
			api('scan/start').then(function (p) {
				if (!p.total) { status.textContent = '0 pages.'; btn.disabled = false; return; }
				return step(p);
			}).catch(function (e) {
				status.textContent = afData.i18n.error + ' ' + e.message;
				btn.disabled = false;
			});
		});
	}

	// Rescan one page.
	Array.prototype.forEach.call(document.querySelectorAll('.af-rescan'), function (b) {
		b.addEventListener('click', function () {
			b.disabled = true;
			b.textContent = afData.i18n.rescan;
			api('scan/page', { post_id: parseInt(b.getAttribute('data-post'), 10) || 0 }).then(function () {
				window.location.reload();
			}).catch(function (e) { b.textContent = afData.i18n.error + ' ' + e.message; });
		});
	});

	// Decorative toggles disable the alt field.
	Array.prototype.forEach.call(document.querySelectorAll('.af-dec'), function (c) {
		c.addEventListener('change', function () {
			var f = document.getElementById(c.getAttribute('data-alt'));
			if (f) { f.disabled = c.checked; if (c.checked) { f.value = ''; } }
		});
	});

	// AI suggestions.
	Array.prototype.forEach.call(document.querySelectorAll('.af-suggest'), function (b) {
		b.addEventListener('click', function () {
			var st = b.parentNode.querySelector('.af-suggest-status');
			var field = document.getElementById(b.getAttribute('data-target'));
			b.disabled = true;
			st.textContent = afData.i18n.suggest;
			api('alt/suggest', { id: parseInt(b.getAttribute('data-id'), 10) }).then(function (j) {
				field.disabled = false;
				field.value = j.alt;
				st.textContent = afData.i18n.suggested;
				field.focus();
			}).catch(function (e) {
				st.textContent = afData.i18n.error + ' ' + e.message;
			}).then(function () { b.disabled = false; });
		});
	});
})();
