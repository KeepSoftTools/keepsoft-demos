<?php
/**
 * REST API (used by the admin screens).
 *
 * @package AccessFix
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * REST routes.
 */
class AccessFix_REST {

	const NS = 'accessfix/v1';

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	/**
	 * Permission check.
	 *
	 * @return bool
	 */
	public static function can() {
		return current_user_can( AccessFix_Admin::cap() );
	}

	/**
	 * Register routes.
	 *
	 * @return void
	 */
	public static function routes() {
		$perm = array( __CLASS__, 'can' );
		register_rest_route( self::NS, '/scan/start', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'start' ), 'permission_callback' => $perm ) );
		register_rest_route(
			self::NS,
			'/scan/batch',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'batch' ),
				'permission_callback' => $perm,
				'args'                => array( 'scan_id' => array( 'required' => true, 'sanitize_callback' => 'absint' ) ),
			)
		);
		register_rest_route(
			self::NS,
			'/scan/page',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'page' ),
				'permission_callback' => $perm,
				'args'                => array( 'post_id' => array( 'required' => true, 'sanitize_callback' => 'absint' ) ),
			)
		);
		register_rest_route(
			self::NS,
			'/alt/suggest',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'suggest' ),
				'permission_callback' => $perm,
				'args'                => array( 'id' => array( 'required' => true, 'sanitize_callback' => 'absint' ) ),
			)
		);
	}

	/**
	 * Start a scan.
	 *
	 * @return WP_REST_Response
	 */
	public static function start() {
		$id = AccessFix_Runner::start( 'manual' );
		global $wpdb;
		$scan = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . AccessFix_Install::table( 'scans' ) . ' WHERE id = %d', $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return rest_ensure_response( AccessFix_Runner::progress( $scan ) );
	}

	/**
	 * Process a batch.
	 *
	 * @param WP_REST_Request $req Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function batch( $req ) {
		$r = AccessFix_Runner::run_batch( (int) $req['scan_id'], 3 );
		return is_wp_error( $r ) ? $r : rest_ensure_response( $r );
	}

	/**
	 * Rescan one page.
	 *
	 * @param WP_REST_Request $req Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function page( $req ) {
		$post_id = (int) $req['post_id'];
		if ( $post_id ) {
			if ( 'publish' !== get_post_status( $post_id ) ) {
				return new WP_Error( 'af_not_published', __( 'Only published pages can be scanned.', 'accessfix' ), array( 'status' => 400 ) );
			}
			$url   = get_permalink( $post_id );
			$title = get_the_title( $post_id );
		} else {
			$url   = home_url( '/' );
			$title = __( 'Home page', 'accessfix' );
		}
		$last = AccessFix_Dashboard::last_scan();
		$r    = AccessFix_Runner::scan_url( $post_id, $url, $title, $last ? (int) $last->id : 0 );
		if ( is_wp_error( $r ) ) {
			return new WP_Error( 'af_scan_failed', $r->get_error_message(), array( 'status' => 502 ) );
		}
		return rest_ensure_response( $r );
	}

	/**
	 * Suggest alt text.
	 *
	 * @param WP_REST_Request $req Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function suggest( $req ) {
		$id = (int) $req['id'];
		if ( ! current_user_can( 'edit_post', $id ) ) {
			return new WP_Error( 'af_forbidden', __( 'You cannot edit this image.', 'accessfix' ), array( 'status' => 403 ) );
		}
		$t = AccessFix_Media::suggest( $id );
		if ( is_wp_error( $t ) ) {
			return new WP_Error( $t->get_error_code(), $t->get_error_message(), array( 'status' => 400 ) );
		}
		return rest_ensure_response( array( 'alt' => $t ) );
	}
}
