<?php
/**
 * Admin screens.
 *
 * @package AccessFix
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin.
 */
class AccessFix_Admin {

	/**
	 * Capability required to use the plugin.
	 *
	 * @return string
	 */
	public static function cap() {
		return apply_filters( 'accessfix_capability', 'manage_options' );
	}

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_af_save_settings', array( __CLASS__, 'save_settings' ) );
		add_action( 'admin_post_af_issue_action', array( __CLASS__, 'issue_action' ) );
		add_action( 'admin_post_af_export', array( __CLASS__, 'export' ) );
		add_action( 'admin_post_af_save_eaa', array( __CLASS__, 'save_eaa' ) );
		add_action( 'enqueue_block_editor_assets', array( __CLASS__, 'editor_assets' ) );
		add_action( 'admin_notices', array( __CLASS__, 'editor_notice' ) );
	}

	/**
	 * Menu.
	 *
	 * @return void
	 */
	public static function menu() {
		$cap  = self::cap();
		$icon = 'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="#a7aaad" d="M10 1a9 9 0 100 18 9 9 0 000-18zm0 3a1.5 1.5 0 110 3 1.5 1.5 0 010-3zm5 4.5l-3.5.6v2.4l1.4 4.1-1.4.5L10.5 13h-1l-1 3.1-1.4-.5 1.4-4.1V9.1L5 8.5V7l5 .8 5-.8v1.5z"/></svg>' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
		add_menu_page( __( 'AccessFix', 'accessfix' ), __( 'AccessFix', 'accessfix' ), $cap, 'accessfix', array( 'AccessFix_Dashboard', 'render' ), $icon, 80 );
		add_submenu_page( 'accessfix', __( 'Dashboard', 'accessfix' ), __( 'Dashboard', 'accessfix' ), $cap, 'accessfix', array( 'AccessFix_Dashboard', 'render' ) );
		add_submenu_page( 'accessfix', __( 'Issues', 'accessfix' ), __( 'Issues', 'accessfix' ), $cap, 'accessfix-issues', array( __CLASS__, 'page_issues' ) );
		add_submenu_page( 'accessfix', __( 'Alt Text', 'accessfix' ), __( 'Alt Text', 'accessfix' ), $cap, 'accessfix-alt', array( __CLASS__, 'page_alt' ) );
		add_submenu_page( 'accessfix', __( 'Audit Log', 'accessfix' ), __( 'Audit Log', 'accessfix' ), $cap, 'accessfix-audit', array( __CLASS__, 'page_audit' ) );
		add_submenu_page( 'accessfix', __( 'Statement', 'accessfix' ), __( 'Statement', 'accessfix' ), $cap, 'accessfix-statement', array( 'AccessFix_Statement', 'render_admin' ) );
		add_submenu_page( 'accessfix', __( 'Settings', 'accessfix' ), __( 'Settings', 'accessfix' ), $cap, 'accessfix-settings', array( __CLASS__, 'page_settings' ) );
	}

	/**
	 * Enqueue admin assets on our screens only.
	 *
	 * @param string $hook Hook suffix.
	 * @return void
	 */
	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, 'accessfix' ) ) {
			return;
		}
		wp_enqueue_style( 'accessfix-admin', AF_URL . 'assets/admin.css', array(), AF_VERSION );
		wp_enqueue_script( 'accessfix-admin', AF_URL . 'assets/admin.js', array(), AF_VERSION, true );
		wp_localize_script(
			'accessfix-admin',
			'afData',
			array(
				'root'  => esc_url_raw( rest_url( AccessFix_REST::NS . '/' ) ),
				'nonce' => wp_create_nonce( 'wp_rest' ),
				'i18n'  => array(
					'starting' => __( 'Starting scan…', 'accessfix' ),
					/* translators: 1: done, 2: total */
					'progress' => __( 'Scanned %1$d of %2$d pages…', 'accessfix' ),
					/* translators: 1: pages, 2: errors */
					'done'     => __( 'Scan complete: %1$d pages, %2$d errors. Reloading…', 'accessfix' ),
					'error'    => __( 'Something went wrong:', 'accessfix' ),
					'rescan'   => __( 'Rescanning…', 'accessfix' ),
					'suggest'  => __( 'Thinking…', 'accessfix' ),
					'suggested' => __( 'Suggestion added. Please check it before saving.', 'accessfix' ),
				),
			)
		);
	}

	// ------------------------------------------------------------- helpers.

	/**
	 * Common nav tabs line.
	 *
	 * @param string $title Title.
	 * @return void
	 */
	protected static function head( $title ) {
		echo '<div class="wrap af-wrap"><h1>' . esc_html( $title ) . '</h1>';
	}

	/**
	 * Severity pill.
	 *
	 * @param string $sev Severity.
	 * @return string
	 */
	public static function sev_pill( $sev ) {
		$labels = array( 'critical' => __( 'Critical', 'accessfix' ), 'serious' => __( 'Serious', 'accessfix' ), 'moderate' => __( 'Moderate', 'accessfix' ), 'minor' => __( 'Minor', 'accessfix' ) );
		return '<span class="af-sev af-sev--' . esc_attr( $sev ) . '">' . esc_html( isset( $labels[ $sev ] ) ? $labels[ $sev ] : $sev ) . '</span>';
	}

	/**
	 * Where does an issue live: post content or theme?
	 *
	 * @param object $i Issue row.
	 * @return string content|theme
	 */
	public static function locate( $i ) {
		if ( in_array( $i->check_id, array( 'html-lang', 'page-title', 'skip-link', 'main-landmark', 'meta-viewport' ), true ) || ! $i->post_id ) {
			return 'theme';
		}
		$content = (string) get_post_field( 'post_content', $i->post_id );
		$needle  = (string) $i->needle;
		if ( '' === $needle || '' === $content ) {
			return 'theme';
		}
		foreach ( array( $needle, htmlspecialchars( $needle, ENT_QUOTES ), esc_url( $needle ), basename( wp_parse_url( $needle, PHP_URL_PATH ) ? wp_parse_url( $needle, PHP_URL_PATH ) : $needle ) ) as $try ) {
			if ( '' !== $try && false !== stripos( $content, $try ) ) {
				return 'content';
			}
		}
		return 'theme';
	}

	// --------------------------------------------------------------- issues.

	/**
	 * Issues screen.
	 *
	 * @return void
	 */
	public static function page_issues() {
		global $wpdb;
		$t = AccessFix_Install::table( 'issues' );
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only filters.
		$status    = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : 'open';
		$criterion = isset( $_GET['criterion'] ) ? preg_replace( '/[^0-9.]/', '', wp_unslash( $_GET['criterion'] ) ) : '';
		$severity  = isset( $_GET['severity'] ) ? sanitize_key( wp_unslash( $_GET['severity'] ) ) : '';
		$post_id   = isset( $_GET['post_id'] ) && '' !== $_GET['post_id'] ? absint( $_GET['post_id'] ) : -1;
		$check     = isset( $_GET['check'] ) ? sanitize_key( wp_unslash( $_GET['check'] ) ) : '';
		$paged     = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		$msg       = isset( $_GET['af_msg'] ) ? sanitize_key( wp_unslash( $_GET['af_msg'] ) ) : '';
		// phpcs:enable
		$w    = array( '1=1' );
		$args = array();
		if ( in_array( $status, array( 'open', 'fixed', 'fixed-manually', 'ignored' ), true ) ) {
			$w[]    = 'status = %s';
			$args[] = $status;
		} else {
			$status = 'all';
		}
		if ( '' !== $criterion ) {
			$w[]    = 'criterion = %s';
			$args[] = $criterion;
		}
		if ( in_array( $severity, array( 'critical', 'serious', 'moderate', 'minor' ), true ) ) {
			$w[]    = 'severity = %s';
			$args[] = $severity;
		}
		if ( $post_id >= 0 ) {
			$w[]    = 'post_id = %d';
			$args[] = $post_id;
		}
		if ( '' !== $check ) {
			$w[]    = 'check_id = %s';
			$args[] = $check;
		}
		$where = implode( ' AND ', $w );
		$per   = 30;
		$sql_c = "SELECT COUNT(*) FROM $t WHERE $where";
		$total = (int) ( $args ? $wpdb->get_var( $wpdb->prepare( $sql_c, $args ) ) : $wpdb->get_var( $sql_c ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$args2 = array_merge( $args, array( $per, ( $paged - 1 ) * $per ) );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $t WHERE $where ORDER BY CASE severity WHEN 'critical' THEN 1 WHEN 'serious' THEN 2 WHEN 'moderate' THEN 3 ELSE 4 END, id DESC LIMIT %d OFFSET %d", $args2 ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		self::head( __( 'Issues', 'accessfix' ) );
		if ( 'done' === $msg ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Issue updated.', 'accessfix' ) . '</p></div>';
		}
		$counts = AccessFix_Dashboard::status_counts();
		echo '<ul class="subsubsub">';
		$tabs = array( 'open' => __( 'Open', 'accessfix' ), 'fixed' => __( 'Auto-fixed', 'accessfix' ), 'fixed-manually' => __( 'Fixed manually', 'accessfix' ), 'ignored' => __( 'Ignored', 'accessfix' ) );
		$i    = 0;
		foreach ( $tabs as $k => $label ) {
			echo '<li><a href="' . esc_url( add_query_arg( array( 'page' => 'accessfix-issues', 'status' => $k ), admin_url( 'admin.php' ) ) ) . '"' . ( $status === $k ? ' class="current" aria-current="page"' : '' ) . '>' . esc_html( $label ) . ' <span class="count">(' . (int) $counts[ $k ] . ')</span></a>' . ( ++$i < count( $tabs ) ? ' |' : '' ) . '</li> ';
		}
		echo '</ul><div class="clear"></div>';

		echo '<form method="get" class="af-filter"><input type="hidden" name="page" value="accessfix-issues" /><input type="hidden" name="status" value="' . esc_attr( $status ) . '" />';
		echo '<label for="af-f-sev" class="screen-reader-text">' . esc_html__( 'Severity', 'accessfix' ) . '</label><select id="af-f-sev" name="severity"><option value="">' . esc_html__( 'All severities', 'accessfix' ) . '</option>';
		foreach ( array( 'critical', 'serious', 'moderate', 'minor' ) as $s ) {
			echo '<option value="' . esc_attr( $s ) . '"' . selected( $severity, $s, false ) . '>' . esc_html( ucfirst( $s ) ) . '</option>';
		}
		echo '</select> <label for="af-f-check" class="screen-reader-text">' . esc_html__( 'Problem type', 'accessfix' ) . '</label><select id="af-f-check" name="check"><option value="">' . esc_html__( 'All problem types', 'accessfix' ) . '</option>';
		foreach ( AccessFix_Checks::all() as $c ) {
			echo '<option value="' . esc_attr( $c['id'] ) . '"' . selected( $check, $c['id'], false ) . '>' . esc_html( $c['title'] ) . '</option>';
		}
		echo '</select> <label for="af-f-sc" class="screen-reader-text">' . esc_html__( 'WCAG criterion', 'accessfix' ) . '</label><input id="af-f-sc" type="text" name="criterion" value="' . esc_attr( $criterion ) . '" placeholder="' . esc_attr__( 'WCAG e.g. 1.1.1', 'accessfix' ) . '" size="12" /> ';
		echo '<button class="button">' . esc_html__( 'Filter', 'accessfix' ) . '</button> <a class="button-link" href="' . esc_url( admin_url( 'admin.php?page=accessfix-issues' ) ) . '">' . esc_html__( 'Reset', 'accessfix' ) . '</a> ';
		echo '<a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=af_export&type=issues' ), 'af_export' ) ) . '">' . esc_html__( 'Export issues (CSV)', 'accessfix' ) . '</a></form>';

		if ( ! $rows ) {
			echo '<p>' . esc_html__( 'No issues match. Run a scan from the dashboard if you have not already.', 'accessfix' ) . '</p></div>';
			return;
		}
		echo '<table class="widefat striped af-table af-issues"><thead><tr><th scope="col">' . esc_html__( 'Severity', 'accessfix' ) . '</th><th scope="col">' . esc_html__( 'Problem', 'accessfix' ) . '</th><th scope="col">' . esc_html__( 'Page and element', 'accessfix' ) . '</th><th scope="col">' . esc_html__( 'Actions', 'accessfix' ) . '</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$def = AccessFix_Checks::get( $r->check_id );
			echo '<tr><td>' . wp_kses_post( self::sev_pill( $r->severity ) ) . '</td><td><strong>' . esc_html( $def ? $def['title'] : $r->check_id ) . '</strong><br />';
			echo '<a href="' . esc_url( AccessFix_Checks::sc_url( $r->criterion ) ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( AccessFix_Checks::sc_label( $r->criterion ) ) . '<span class="screen-reader-text"> ' . esc_html__( '(opens in a new tab)', 'accessfix' ) . '</span></a>';
			echo '<p class="af-msg">' . esc_html( $r->message ) . '</p>';
			if ( $def && 'open' === $r->status ) {
				echo '<p class="description">' . esc_html( $def['help'] ) . '</p>';
			}
			echo '</td><td><a href="' . esc_url( $r->url ) . '">' . esc_html( wp_parse_url( $r->url, PHP_URL_PATH ) ? wp_parse_url( $r->url, PHP_URL_PATH ) : '/' ) . '</a><br />';
			echo '<code class="af-snippet">' . esc_html( $r->snippet ) . '</code>';
			if ( 'fixed' === $r->status && $r->after_html ) {
				echo '<br /><span class="af-after">' . esc_html__( 'Served as:', 'accessfix' ) . '</span> <code class="af-snippet af-snippet--after">' . esc_html( $r->after_html ) . '</code>';
			}
			if ( 'ignored' === $r->status && $r->ignore_reason ) {
				echo '<p class="description">' . esc_html__( 'Reason:', 'accessfix' ) . ' ' . esc_html( $r->ignore_reason ) . '</p>';
			}
			echo '<br /><span class="description">' . esc_html( $r->selector ) . '</span></td><td class="af-actions">';
			if ( 'open' === $r->status ) {
				if ( 'content' === self::locate( $r ) && $r->post_id ) {
					echo '<a class="button button-small" href="' . esc_url( add_query_arg( 'af_issue', (int) $r->id, get_edit_post_link( $r->post_id, 'raw' ) ) ) . '">' . esc_html__( 'Fix in editor', 'accessfix' ) . '</a><br />';
				} elseif ( $r->post_id ) {
					$tl = function_exists( 'wp_is_block_theme' ) && wp_is_block_theme() ? admin_url( 'site-editor.php' ) : admin_url( 'customize.php' );
					echo '<a class="button button-small" href="' . esc_url( add_query_arg( 'af_issue', (int) $r->id, get_edit_post_link( $r->post_id, 'raw' ) ) ) . '">' . esc_html__( 'Open page', 'accessfix' ) . '</a> <a class="button button-small" href="' . esc_url( $tl ) . '">' . esc_html__( 'Theme / template', 'accessfix' ) . '</a><br /><span class="description">' . esc_html__( 'Probably in the theme or a widget.', 'accessfix' ) . '</span><br />';
				} else {
					$tl = function_exists( 'wp_is_block_theme' ) && wp_is_block_theme() ? admin_url( 'site-editor.php' ) : admin_url( 'customize.php' );
					echo '<a class="button button-small" href="' . esc_url( $tl ) . '">' . esc_html__( 'Theme / template', 'accessfix' ) . '</a><br />';
				}
				echo '<details class="af-ignore"><summary>' . esc_html__( 'Ignore…', 'accessfix' ) . '</summary>';
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
				wp_nonce_field( 'af_issue_action' );
				echo '<input type="hidden" name="action" value="af_issue_action" /><input type="hidden" name="op" value="ignore" /><input type="hidden" name="id" value="' . (int) $r->id . '" />';
				echo '<label for="af-r-' . (int) $r->id . '" class="screen-reader-text">' . esc_html__( 'Reason for ignoring', 'accessfix' ) . '</label><input id="af-r-' . (int) $r->id . '" type="text" name="reason" required placeholder="' . esc_attr__( 'Reason (recorded in the log)', 'accessfix' ) . '" /> <button class="button button-small">' . esc_html__( 'Ignore', 'accessfix' ) . '</button></form></details>';
			} elseif ( 'ignored' === $r->status ) {
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
				wp_nonce_field( 'af_issue_action' );
				echo '<input type="hidden" name="action" value="af_issue_action" /><input type="hidden" name="op" value="reopen" /><input type="hidden" name="id" value="' . (int) $r->id . '" /><button class="button button-small">' . esc_html__( 'Re-open', 'accessfix' ) . '</button></form>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';
		$pages = (int) ceil( $total / $per );
		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">' . wp_kses_post(
				paginate_links(
					array(
						'base'    => add_query_arg( 'paged', '%#%' ),
						'format'  => '',
						'current' => $paged,
						'total'   => $pages,
					)
				)
			) . '</div></div>';
		}
		echo '</div>';
	}

	/**
	 * Ignore / re-open an issue.
	 *
	 * @return void
	 */
	public static function issue_action() {
		if ( ! current_user_can( self::cap() ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'accessfix' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'af_issue_action' );
		global $wpdb;
		$t   = AccessFix_Install::table( 'issues' );
		$id  = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$op  = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE id = %d", $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( $row ) {
			if ( 'ignore' === $op ) {
				$reason = isset( $_POST['reason'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['reason'] ) ) ) : '';
				if ( '' === $reason ) {
					wp_safe_redirect( add_query_arg( array( 'page' => 'accessfix-issues' ), admin_url( 'admin.php' ) ) );
					exit;
				}
				$wpdb->update( $t, array( 'status' => 'ignored', 'ignore_reason' => $reason, 'resolved_at' => current_time( 'mysql', true ) ), array( 'id' => $id ) );
				AccessFix_Audit::log( array( 'post_id' => $row->post_id, 'url' => $row->url, 'check_id' => $row->check_id, 'criterion' => $row->criterion, 'action' => 'ignored', 'reason' => $reason, 'before' => $row->snippet ) );
			} elseif ( 'reopen' === $op ) {
				$wpdb->update( $t, array( 'status' => 'open', 'ignore_reason' => null, 'resolved_at' => null ), array( 'id' => $id ) );
				AccessFix_Audit::log( array( 'post_id' => $row->post_id, 'url' => $row->url, 'check_id' => $row->check_id, 'criterion' => $row->criterion, 'action' => 'reopened', 'reason' => __( 'Re-opened by a user.', 'accessfix' ), 'before' => $row->snippet ) );
			}
		}
		wp_safe_redirect( add_query_arg( array( 'page' => 'accessfix-issues', 'af_msg' => 'done' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	// ------------------------------------------------------------ alt text.

	/**
	 * Alt text screen.
	 *
	 * @return void
	 */
	public static function page_alt() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only filters.
		$view   = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : 'missing';
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$paged  = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		$saved  = isset( $_GET['af_saved'] ) ? absint( $_GET['af_saved'] ) : -1;
		// phpcs:enable
		if ( ! in_array( $view, array( 'all', 'missing', 'decorative', 'filled' ), true ) ) {
			$view = 'missing';
		}
		$q   = AccessFix_Media::query( $view, $search, $paged );
		$cov = AccessFix_Media::coverage();
		$ai  = AccessFix_Settings::get( 'ai_enabled' ) && '' !== AccessFix_Settings::get( 'ai_key' );
		self::head( __( 'Alt text editor', 'accessfix' ) );
		if ( $saved >= 0 ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( sprintf( /* translators: %d: number of changes */ _n( '%d change saved and logged.', '%d changes saved and logged.', $saved, 'accessfix' ), $saved ) ) . '</p></div>';
		}
		echo '<p>' . esc_html( sprintf( /* translators: 1: missing, 2: total */ __( '%1$d of %2$d images in the Media Library have no alt text and are not marked decorative.', 'accessfix' ), $cov['missing'], $cov['total'] ) ) . ' ' . esc_html__( 'Describe what the image conveys in the context where it is used. If it is purely decorative, tick "Decorative" and AccessFix will output alt="" wherever the image is used.', 'accessfix' ) . '</p>';
		echo '<ul class="subsubsub">';
		$tabs = array( 'missing' => __( 'Missing alt', 'accessfix' ), 'filled' => __( 'Has alt', 'accessfix' ), 'decorative' => __( 'Decorative', 'accessfix' ), 'all' => __( 'All', 'accessfix' ) );
		$i    = 0;
		foreach ( $tabs as $k => $label ) {
			echo '<li><a href="' . esc_url( add_query_arg( array( 'page' => 'accessfix-alt', 'view' => $k ), admin_url( 'admin.php' ) ) ) . '"' . ( $view === $k ? ' class="current" aria-current="page"' : '' ) . '>' . esc_html( $label ) . '</a>' . ( ++$i < count( $tabs ) ? ' |' : '' ) . '</li> ';
		}
		echo '</ul><form method="get" class="search-form" style="float:right"><input type="hidden" name="page" value="accessfix-alt" /><input type="hidden" name="view" value="' . esc_attr( $view ) . '" /><label class="screen-reader-text" for="af-alt-s">' . esc_html__( 'Search images', 'accessfix' ) . '</label><input type="search" id="af-alt-s" name="s" value="' . esc_attr( $search ) . '" /> <button class="button">' . esc_html__( 'Search', 'accessfix' ) . '</button></form><div class="clear"></div>';
		if ( ! $q->have_posts() ) {
			echo '<p>' . esc_html__( 'No images in this view.', 'accessfix' ) . '</p></div>';
			return;
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'af_save_alt' );
		echo '<input type="hidden" name="action" value="af_save_alt" />';
		echo '<table class="widefat striped af-table af-alt"><thead><tr><th scope="col">' . esc_html__( 'Image', 'accessfix' ) . '</th><th scope="col">' . esc_html__( 'Alt text', 'accessfix' ) . '</th><th scope="col">' . esc_html__( 'Decorative', 'accessfix' ) . '</th><th scope="col">' . esc_html__( 'Used in', 'accessfix' ) . '</th></tr></thead><tbody>';
		foreach ( $q->posts as $p ) {
			$id   = (int) $p->ID;
			$alt  = (string) get_post_meta( $id, '_wp_attachment_image_alt', true );
			$dec  = '1' === (string) get_post_meta( $id, '_af_decorative', true );
			$used = AccessFix_Media::used_in( $id );
			echo '<tr><td class="af-alt__img"><input type="hidden" name="ids[]" value="' . $id . '" />';
			echo wp_get_attachment_image( $id, array( 96, 96 ), false, array( 'alt' => '' ) );
			echo '<br /><span class="description">' . esc_html( wp_basename( (string) get_attached_file( $id ) ) ) . '</span>';
			if ( $p->post_title && sanitize_title( $p->post_title ) !== sanitize_title( pathinfo( (string) get_attached_file( $id ), PATHINFO_FILENAME ) ) ) {
				echo '<br /><span class="description">' . esc_html( $p->post_title ) . '</span>';
			}
			echo '</td><td><label class="screen-reader-text" for="af-alt-' . $id . '">' . esc_html( sprintf( /* translators: %s: file name */ __( 'Alt text for %s', 'accessfix' ), wp_basename( (string) get_attached_file( $id ) ) ) ) . '</label>';
			echo '<input type="text" class="large-text" id="af-alt-' . $id . '" name="alt[' . $id . ']" value="' . esc_attr( $alt ) . '"' . disabled( $dec, true, false ) . ' />';
			if ( $ai ) {
				echo '<p><button type="button" class="button button-small af-suggest" data-id="' . $id . '" data-target="af-alt-' . $id . '">' . esc_html__( 'Suggest with AI', 'accessfix' ) . '</button> <span class="af-suggest-status description" role="status"></span></p>';
			}
			if ( $p->post_excerpt ) {
				echo '<p class="description">' . esc_html__( 'Caption:', 'accessfix' ) . ' ' . esc_html( wp_trim_words( $p->post_excerpt, 20 ) ) . '</p>';
			}
			echo '</td><td><label><input type="checkbox" class="af-dec" data-alt="af-alt-' . $id . '" name="dec[' . $id . ']" value="1"' . checked( $dec, true, false ) . ' /> ' . esc_html__( 'Decorative', 'accessfix' ) . '</label></td><td>';
			if ( $used ) {
				echo '<ul class="af-used">';
				foreach ( $used as $u ) {
					echo '<li><a href="' . esc_url( get_edit_post_link( $u->ID, 'raw' ) ) . '">' . esc_html( '' !== $u->post_title ? $u->post_title : '#' . $u->ID ) . '</a> <span class="description">(' . esc_html( $u->post_type ) . ( 'publish' !== $u->post_status ? ', ' . esc_html( $u->post_status ) : '' ) . ')</span></li>';
				}
				echo '</ul>';
			} else {
				echo '<span class="description">' . esc_html__( 'Not found in post content.', 'accessfix' ) . '</span>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table><p class="submit"><button class="button button-primary">' . esc_html__( 'Save changes', 'accessfix' ) . '</button></p></form>';
		if ( $q->max_num_pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">' . wp_kses_post( paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'current' => $paged, 'total' => $q->max_num_pages ) ) ) . '</div></div>';
		}
		echo '</div>';
	}

	// ----------------------------------------------------------- audit log.

	/**
	 * Audit screen.
	 *
	 * @return void
	 */
	public static function page_audit() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only filters.
		$f = array(
			'action'    => isset( $_GET['action_f'] ) ? sanitize_key( wp_unslash( $_GET['action_f'] ) ) : '',
			'criterion' => isset( $_GET['criterion'] ) ? preg_replace( '/[^0-9.]/', '', wp_unslash( $_GET['criterion'] ) ) : '',
			'search'    => isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '',
			'from'      => isset( $_GET['from'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', wp_unslash( $_GET['from'] ) ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '',
			'to'        => isset( $_GET['to'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', wp_unslash( $_GET['to'] ) ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '',
		);
		$paged = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		// phpcs:enable
		if ( ! isset( AccessFix_Audit::actions()[ $f['action'] ] ) ) {
			$f['action'] = '';
		}
		$per   = 40;
		$total = AccessFix_Audit::count( $f );
		$rows  = AccessFix_Audit::query( $f, $per, ( $paged - 1 ) * $per );
		self::head( __( 'Audit log', 'accessfix' ) );
		echo '<p>' . esc_html__( 'Append-only record of what was detected, fixed and ignored, with the person or process responsible. Entries cannot be edited or deleted from this screen.', 'accessfix' ) . '</p>';
		echo '<div class="af-export"><a class="button button-primary" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=af_export&type=audit' ), 'af_export' ) ) . '">' . esc_html__( 'Download audit log (CSV)', 'accessfix' ) . '</a> ';
		echo '<a class="button button-primary" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=af_export&type=pdf' ), 'af_export' ) ) . '">' . esc_html__( 'Download evidence report (PDF)', 'accessfix' ) . '</a></div>';
		echo '<form method="get" class="af-filter"><input type="hidden" name="page" value="accessfix-audit" />';
		echo '<label class="screen-reader-text" for="af-a-act">' . esc_html__( 'Action', 'accessfix' ) . '</label><select id="af-a-act" name="action_f"><option value="">' . esc_html__( 'All actions', 'accessfix' ) . '</option>';
		foreach ( AccessFix_Audit::actions() as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $f['action'], $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select> <label class="screen-reader-text" for="af-a-sc">' . esc_html__( 'WCAG criterion', 'accessfix' ) . '</label><input id="af-a-sc" type="text" name="criterion" size="10" placeholder="' . esc_attr__( 'WCAG', 'accessfix' ) . '" value="' . esc_attr( $f['criterion'] ) . '" /> ';
		echo '<label for="af-a-from">' . esc_html__( 'From', 'accessfix' ) . '</label> <input id="af-a-from" type="date" name="from" value="' . esc_attr( $f['from'] ) . '" /> <label for="af-a-to">' . esc_html__( 'To', 'accessfix' ) . '</label> <input id="af-a-to" type="date" name="to" value="' . esc_attr( $f['to'] ) . '" /> ';
		echo '<label class="screen-reader-text" for="af-a-s">' . esc_html__( 'Search', 'accessfix' ) . '</label><input id="af-a-s" type="search" name="s" value="' . esc_attr( $f['search'] ) . '" placeholder="' . esc_attr__( 'Search', 'accessfix' ) . '" /> <button class="button">' . esc_html__( 'Filter', 'accessfix' ) . '</button></form>';
		if ( ! $rows ) {
			echo '<p>' . esc_html__( 'No entries yet.', 'accessfix' ) . '</p></div>';
			return;
		}
		echo '<p class="description">' . esc_html( sprintf( /* translators: %d: rows */ _n( '%d entry', '%d entries', $total, 'accessfix' ), $total ) ) . '</p>';
		echo '<table class="widefat striped af-table"><thead><tr><th scope="col">' . esc_html__( 'When (UTC)', 'accessfix' ) . '</th><th scope="col">' . esc_html__( 'Action', 'accessfix' ) . '</th><th scope="col">' . esc_html__( 'WCAG', 'accessfix' ) . '</th><th scope="col">' . esc_html__( 'Page', 'accessfix' ) . '</th><th scope="col">' . esc_html__( 'By', 'accessfix' ) . '</th><th scope="col">' . esc_html__( 'Detail', 'accessfix' ) . '</th></tr></thead><tbody>';
		$labels = AccessFix_Audit::actions();
		foreach ( $rows as $r ) {
			echo '<tr><td>' . esc_html( $r->logged_at ) . '</td><td><span class="af-act af-act--' . esc_attr( $r->action ) . '">' . esc_html( isset( $labels[ $r->action ] ) ? $labels[ $r->action ] : $r->action ) . '</span></td><td>' . esc_html( $r->criterion ) . '</td>';
			echo '<td><a href="' . esc_url( $r->url ) . '">' . esc_html( preg_replace( '#^https?://[^/]+#', '', $r->url ) ?: '/' ) . '</a></td><td>' . esc_html( $r->user_login ) . '</td><td>' . esc_html( $r->reason );
			if ( $r->before_html || $r->after_html ) {
				echo '<details><summary>' . esc_html__( 'Before / after', 'accessfix' ) . '</summary>';
				if ( $r->before_html ) {
					echo '<p><strong>' . esc_html__( 'Before', 'accessfix' ) . '</strong><br /><code class="af-snippet">' . esc_html( $r->before_html ) . '</code></p>';
				}
				if ( $r->after_html ) {
					echo '<p><strong>' . esc_html__( 'After', 'accessfix' ) . '</strong><br /><code class="af-snippet af-snippet--after">' . esc_html( $r->after_html ) . '</code></p>';
				}
				echo '</details>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';
		$pages = (int) ceil( $total / $per );
		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">' . wp_kses_post( paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'current' => $paged, 'total' => $pages ) ) ) . '</div></div>';
		}
		echo '</div>';
	}

	/**
	 * CSV / PDF export.
	 *
	 * @return void
	 */
	public static function export() {
		if ( ! current_user_can( self::cap() ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'accessfix' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'af_export' );
		$type = isset( $_GET['type'] ) ? sanitize_key( wp_unslash( $_GET['type'] ) ) : '';
		if ( 'pdf' === $type ) {
			$pdf = AccessFix_Audit::pdf_report();
			nocache_headers();
			header( 'Content-Type: application/pdf' );
			header( 'Content-Disposition: attachment; filename="accessibility-evidence-report-' . gmdate( 'Ymd' ) . '.pdf"' );
			header( 'Content-Length: ' . strlen( $pdf ) );
			echo $pdf; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Binary PDF.
			exit;
		}
		if ( 'issues' === $type ) {
			AccessFix_Audit::export_csv( 'issues' );
		}
		AccessFix_Audit::export_csv( 'audit' );
	}

	/**
	 * Save EAA manual checklist.
	 *
	 * @return void
	 */
	public static function save_eaa() {
		if ( ! current_user_can( self::cap() ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'accessfix' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'af_save_eaa' );
		$in   = isset( $_POST['eaa'] ) && is_array( $_POST['eaa'] ) ? array_keys( wp_unslash( $_POST['eaa'] ) ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$keys = array( 'scope', 'keyboard', 'reader', 'zoom', 'media', 'forms', 'docs', 'owner' );
		$out  = array();
		foreach ( $in as $k ) {
			$k = sanitize_key( $k );
			if ( in_array( $k, $keys, true ) ) {
				$out[ $k ] = 1;
			}
		}
		update_option( 'af_eaa_manual', $out, false );
		wp_safe_redirect( add_query_arg( array( 'page' => 'accessfix', 'af_msg' => 'eaa' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	// ------------------------------------------------------------- settings.

	/**
	 * Settings screen.
	 *
	 * @return void
	 */
	public static function page_settings() {
		$s   = AccessFix_Settings::all();
		$msg = isset( $_GET['af_msg'] ) ? sanitize_key( wp_unslash( $_GET['af_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		self::head( __( 'AccessFix settings', 'accessfix' ) );
		if ( 'saved' === $msg ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Settings saved.', 'accessfix' ) . '</p></div>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'af_save_settings' );
		echo '<input type="hidden" name="action" value="af_save_settings" />';

		echo '<h2>' . esc_html__( 'Automatic fixes (applied when the page is served)', 'accessfix' ) . '</h2>';
		echo '<p class="description">' . esc_html__( 'These corrections are made to the HTML on the server before it is sent. They do not edit your stored content, and nothing runs in the visitor\'s browser. Every fix is recorded in the audit log the next time the page is scanned. Fixing at the source (in the editor or theme) is always better; use these as a safety net.', 'accessfix' ) . '</p><fieldset class="af-fixers"><legend class="screen-reader-text">' . esc_html__( 'Automatic fixes', 'accessfix' ) . '</legend>';
		foreach ( AccessFix_Settings::fixer_labels() as $k => $label ) {
			echo '<label><input type="checkbox" name="s[' . esc_attr( $k ) . ']" value="1"' . checked( ! empty( $s[ $k ] ), true, false ) . ' /> ' . esc_html( $label ) . '</label><br />';
		}
		echo '</fieldset><table class="form-table" role="presentation">';
		echo '<tr><th scope="row"><label for="s_focus_color">' . esc_html__( 'Focus outline colour', 'accessfix' ) . '</label></th><td><input type="text" id="s_focus_color" name="s[focus_color]" value="' . esc_attr( $s['focus_color'] ) . '" size="9" pattern="#[0-9a-fA-F]{3,6}" /> <span class="description">' . esc_html__( 'Hex colour. Must contrast at least 3:1 with your backgrounds.', 'accessfix' ) . '</span></td></tr>';
		echo '<tr><th scope="row"><label for="s_icon_map">' . esc_html__( 'Icon link labels', 'accessfix' ) . '</label></th><td><textarea id="s_icon_map" name="s[icon_map]" rows="5" class="large-text code">' . esc_textarea( $s['icon_map'] ) . '</textarea><p class="description">' . esc_html__( 'One rule per line: "href:substring = Label" or "class:token = Label". Applies to links that contain only an icon and have no name. Social and mailto/tel links are covered by built-in rules.', 'accessfix' ) . '</p></td></tr>';
		echo '<tr><th scope="row"><label for="s_iframe_map">' . esc_html__( 'iframe titles', 'accessfix' ) . '</label></th><td><textarea id="s_iframe_map" name="s[iframe_map]" rows="4" class="large-text code">' . esc_textarea( $s['iframe_map'] ) . '</textarea><p class="description">' . esc_html__( 'One rule per line: "src substring = Title". Unmatched iframes get "Embedded content from <host>".', 'accessfix' ) . '</p></td></tr></table>';

		echo '<h2>' . esc_html__( 'Scanner', 'accessfix' ) . '</h2><table class="form-table" role="presentation">';
		echo '<tr><th scope="row">' . esc_html__( 'Post types to scan', 'accessfix' ) . '</th><td>';
		foreach ( get_post_types( array( 'public' => true ), 'objects' ) as $pt ) {
			if ( 'attachment' === $pt->name ) {
				continue;
			}
			echo '<label><input type="checkbox" name="s[post_types][]" value="' . esc_attr( $pt->name ) . '"' . checked( in_array( $pt->name, (array) $s['post_types'], true ), true, false ) . ' /> ' . esc_html( $pt->labels->name ) . '</label> ';
		}
		echo '</td></tr>';
		echo '<tr><th scope="row"><label for="s_max">' . esc_html__( 'Maximum pages per scan', 'accessfix' ) . '</label></th><td><input type="number" min="1" max="5000" id="s_max" name="s[max_pages]" value="' . (int) $s['max_pages'] . '" /></td></tr>';
		echo '<tr><th scope="row"><label for="s_auth">' . esc_html__( 'Scanner access (HTTP basic auth)', 'accessfix' ) . '</label></th><td><input type="text" id="s_auth" name="s[scan_auth]" value="' . esc_attr( $s['scan_auth'] ) . '" class="regular-text" autocomplete="off" placeholder="user:password" /><p class="description">' . esc_html__( 'Only needed if the site is password protected (for example a staging site). Stored in the database in plain text.', 'accessfix' ) . '</p></td></tr>';
		echo '<tr><th scope="row">' . esc_html__( 'SSL verification', 'accessfix' ) . '</th><td><label><input type="checkbox" name="s[sslverify]" value="1"' . checked( ! empty( $s['sslverify'] ), true, false ) . ' /> ' . esc_html__( 'Verify the SSL certificate when scanning (turn off only for local development sites)', 'accessfix' ) . '</label></td></tr></table>';

		echo '<h2>' . esc_html__( 'Scheduled scans and email', 'accessfix' ) . '</h2><table class="form-table" role="presentation">';
		echo '<tr><th scope="row"><label for="s_cron">' . esc_html__( 'Rescan', 'accessfix' ) . '</label></th><td><select id="s_cron" name="s[cron_freq]">';
		foreach ( array( 'off' => __( 'Never (manual only)', 'accessfix' ), 'daily' => __( 'Daily', 'accessfix' ), 'weekly' => __( 'Weekly', 'accessfix' ) ) as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $s['cron_freq'], $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select> <span class="description">' . esc_html__( 'Uses WP-Cron, which runs when the site receives visits. For reliable timing use a real server cron job that calls wp-cron.php.', 'accessfix' ) . '</span></td></tr>';
		echo '<tr><th scope="row">' . esc_html__( 'Email summary', 'accessfix' ) . '</th><td><label><input type="checkbox" name="s[email_enabled]" value="1"' . checked( ! empty( $s['email_enabled'] ), true, false ) . ' /> ' . esc_html__( 'Email a summary after each scheduled scan', 'accessfix' ) . '</label><br /><label for="s_email">' . esc_html__( 'Recipients (comma separated; blank = site admin email)', 'accessfix' ) . '</label><br /><input type="text" id="s_email" name="s[email_to]" value="' . esc_attr( $s['email_to'] ) . '" class="regular-text" /></td></tr></table>';

		echo '<h2>' . esc_html__( 'AI alt-text suggestions (optional)', 'accessfix' ) . '</h2><p class="description">' . esc_html__( 'Works with any OpenAI-compatible chat completions API that accepts images. When enabled, the image you click "Suggest" on is sent to the service you configure. Suggestions are never saved automatically: a person must review them. Machine-written alt text can be wrong or miss context.', 'accessfix' ) . '</p><table class="form-table" role="presentation">';
		echo '<tr><th scope="row">' . esc_html__( 'Enable', 'accessfix' ) . '</th><td><label><input type="checkbox" name="s[ai_enabled]" value="1"' . checked( ! empty( $s['ai_enabled'] ), true, false ) . ' /> ' . esc_html__( 'Show "Suggest with AI" buttons', 'accessfix' ) . '</label></td></tr>';
		echo '<tr><th scope="row"><label for="s_ai_ep">' . esc_html__( 'API endpoint', 'accessfix' ) . '</label></th><td><input type="url" id="s_ai_ep" name="s[ai_endpoint]" value="' . esc_attr( $s['ai_endpoint'] ) . '" class="regular-text" /></td></tr>';
		echo '<tr><th scope="row"><label for="s_ai_key">' . esc_html__( 'API key', 'accessfix' ) . '</label></th><td><input type="password" id="s_ai_key" name="s[ai_key]" value="' . esc_attr( '' !== $s['ai_key'] ? '••••••••' . substr( $s['ai_key'], -4 ) : '' ) . '" class="regular-text" autocomplete="off" /><p class="description">' . esc_html__( 'Stored in the options table in plain text. Use a key with a spending limit.', 'accessfix' ) . '</p></td></tr>';
		echo '<tr><th scope="row"><label for="s_ai_model">' . esc_html__( 'Model', 'accessfix' ) . '</label></th><td><input type="text" id="s_ai_model" name="s[ai_model]" value="' . esc_attr( $s['ai_model'] ) . '" class="regular-text" /></td></tr>';
		echo '<tr><th scope="row"><label for="s_ai_prompt">' . esc_html__( 'Prompt', 'accessfix' ) . '</label></th><td><textarea id="s_ai_prompt" name="s[ai_prompt]" rows="3" class="large-text">' . esc_textarea( $s['ai_prompt'] ) . '</textarea></td></tr></table>';

		echo '<h2>' . esc_html__( 'Data', 'accessfix' ) . '</h2><table class="form-table" role="presentation"><tr><th scope="row">' . esc_html__( 'On uninstall', 'accessfix' ) . '</th><td><label><input type="checkbox" name="s[delete_data]" value="1"' . checked( ! empty( $s['delete_data'] ), true, false ) . ' /> ' . esc_html__( 'Delete all AccessFix data (scan results, audit log, settings) when the plugin is deleted', 'accessfix' ) . '</label><p class="description">' . esc_html__( 'Off by default so your audit trail survives. Export the audit log first if you may need it as evidence.', 'accessfix' ) . '</p></td></tr></table>';
		echo '<p class="submit"><button class="button button-primary">' . esc_html__( 'Save settings', 'accessfix' ) . '</button></p></form></div>';
	}

	/**
	 * Save settings.
	 *
	 * @return void
	 */
	public static function save_settings() {
		if ( ! current_user_can( self::cap() ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'accessfix' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'af_save_settings' );
		$in = isset( $_POST['s'] ) && is_array( $_POST['s'] ) ? wp_unslash( $_POST['s'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitised in AccessFix_Settings::sanitize().
		update_option( AccessFix_Settings::OPTION, AccessFix_Settings::sanitize( $in ), false );
		AccessFix_Runner::reschedule();
		wp_safe_redirect( add_query_arg( array( 'page' => 'accessfix-settings', 'af_msg' => 'saved' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	// ----------------------------------------------- "Fix in editor" support.

	/**
	 * The issue referenced by ?af_issue= on the post edit screen.
	 *
	 * @return object|null
	 */
	protected static function editor_issue() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only; capability checked.
		if ( empty( $_GET['af_issue'] ) || ! current_user_can( self::cap() ) ) {
			return null;
		}
		global $wpdb;
		$t = AccessFix_Install::table( 'issues' );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE id = %d", absint( $_GET['af_issue'] ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Load the block-selecting script in the editor.
	 *
	 * @return void
	 */
	public static function editor_assets() {
		$i = self::editor_issue();
		if ( ! $i ) {
			return;
		}
		$def = AccessFix_Checks::get( $i->check_id );
		wp_enqueue_script( 'accessfix-editor', AF_URL . 'assets/editor.js', array( 'wp-data', 'wp-dom-ready' ), AF_VERSION, true );
		wp_localize_script(
			'accessfix-editor',
			'afEditor',
			array(
				'needle'  => (string) $i->needle,
				'message' => ( $def ? $def['title'] : $i->check_id ) . ' - ' . $i->message,
				'help'    => $def ? $def['help'] : '',
				'miss'    => __( 'AccessFix could not find this element in the post blocks. It probably comes from the theme, a template or a widget.', 'accessfix' ),
			)
		);
	}

	/**
	 * Notice on the classic editor / above the block editor.
	 *
	 * @return void
	 */
	public static function editor_notice() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || 'post' !== $screen->base ) {
			return;
		}
		$i = self::editor_issue();
		if ( ! $i ) {
			return;
		}
		$def = AccessFix_Checks::get( $i->check_id );
		echo '<div class="notice notice-warning"><p><strong>AccessFix:</strong> ' . esc_html( ( $def ? $def['title'] : $i->check_id ) . ' (WCAG ' . $i->criterion . ')' ) . '<br />' . esc_html( $i->message ) . '<br /><code>' . esc_html( $i->snippet ) . '</code></p>';
		if ( $def ) {
			echo '<p>' . esc_html( $def['help'] ) . '</p>';
		}
		echo '</div>';
	}
}
