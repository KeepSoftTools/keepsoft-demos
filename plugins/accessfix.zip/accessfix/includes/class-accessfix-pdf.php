<?php
/**
 * Minimal PDF writer (text, rectangles, tables) – no external library.
 * Uses the built-in Helvetica fonts with WinAnsi encoding.
 *
 * @package AccessFix
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tiny PDF generator.
 */
class AccessFix_PDF {

	const W = 595.28;
	const H = 841.89;

	/** @var array Page content streams. */
	protected $pages = array();
	/** @var int Current page index. */
	protected $cur = -1;
	/** @var float Cursor y measured from the top. */
	public $y = 0;
	public $margin = 46;
	public $footer = '';
	protected $info = array();

	/** @var int[] Helvetica widths for ASCII 32..126 (per 1000 em). */
	protected static $w = array(
		278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278,
		556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556,
		1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778,
		667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556,
		333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556,
		556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584,
	);

	/**
	 * Constructor.
	 *
	 * @param array $info title, author, subject.
	 */
	public function __construct( $info = array() ) {
		$this->info = $info;
		$this->add_page();
	}

	/**
	 * Convert UTF-8 text to WinAnsi bytes.
	 *
	 * @param string $s Text.
	 * @return string
	 */
	protected static function enc( $s ) {
		$s = (string) $s;
		$s = str_replace( array( "\r", "\t" ), array( '', '    ' ), $s );
		$s = preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $s );
		$s = str_replace( array( '“', '”', '‘', '’', '–', '—', '…', '•', '→' ), array( '"', '"', "'", "'", '-', '-', '...', '*', '->' ), $s );
		if ( function_exists( 'iconv' ) ) {
			$t = @iconv( 'UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $s ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			if ( false !== $t ) {
				return $t;
			}
		}
		return preg_replace( '/[^\x20-\x7E\n]/', '?', $s );
	}

	/**
	 * Escape for a PDF string.
	 *
	 * @param string $s Encoded bytes.
	 * @return string
	 */
	protected static function esc( $s ) {
		return str_replace( array( '\\', '(', ')' ), array( '\\\\', '\\(', '\\)' ), $s );
	}

	/**
	 * Width of text in points.
	 *
	 * @param string $s    Text (UTF-8).
	 * @param float  $size Font size.
	 * @param bool   $bold Bold.
	 * @return float
	 */
	public function width( $s, $size, $bold = false ) {
		$s   = self::enc( $s );
		$sum = 0;
		$n   = strlen( $s );
		for ( $i = 0; $i < $n; $i++ ) {
			$o    = ord( $s[ $i ] );
			$sum += ( $o >= 32 && $o <= 126 ) ? self::$w[ $o - 32 ] : 556;
		}
		return $sum / 1000 * $size * ( $bold ? 1.06 : 1 );
	}

	/**
	 * Start a new page.
	 *
	 * @return void
	 */
	public function add_page() {
		$this->pages[] = '';
		$this->cur     = count( $this->pages ) - 1;
		$this->y       = $this->margin;
	}

	/**
	 * Ensure there is room for $h points else new page.
	 *
	 * @param float $h Height needed.
	 * @return void
	 */
	public function need( $h ) {
		if ( $this->y + $h > self::H - $this->margin - 20 ) {
			$this->add_page();
		}
	}

	/**
	 * Emit raw content.
	 *
	 * @param string $c Operators.
	 * @return void
	 */
	protected function emit( $c ) {
		$this->pages[ $this->cur ] .= $c . "\n";
	}

	/**
	 * Convert hex colour to PDF rgb operands.
	 *
	 * @param string $hex #rrggbb.
	 * @return string
	 */
	protected static function rgb( $hex ) {
		$hex = ltrim( $hex, '#' );
		return sprintf( '%.3F %.3F %.3F', hexdec( substr( $hex, 0, 2 ) ) / 255, hexdec( substr( $hex, 2, 2 ) ) / 255, hexdec( substr( $hex, 4, 2 ) ) / 255 );
	}

	/**
	 * Draw a filled rectangle (y from the top).
	 *
	 * @param float  $x X.
	 * @param float  $y Y from top.
	 * @param float  $w Width.
	 * @param float  $h Height.
	 * @param string $fill Hex colour.
	 * @return void
	 */
	public function rect( $x, $y, $w, $h, $fill ) {
		$this->emit( sprintf( '%s rg %.2F %.2F %.2F %.2F re f', self::rgb( $fill ), $x, self::H - $y - $h, $w, $h ) );
	}

	/**
	 * Place a line of text at absolute position (y = baseline from top).
	 *
	 * @param float  $x     X.
	 * @param float  $y     Baseline from top.
	 * @param string $s     Text.
	 * @param float  $size  Size.
	 * @param bool   $bold  Bold.
	 * @param string $color Hex colour.
	 * @return void
	 */
	public function text_at( $x, $y, $s, $size = 10, $bold = false, $color = '#1d2327' ) {
		$this->emit( sprintf( 'BT /%s %.2F Tf %s rg %.2F %.2F Td (%s) Tj ET', $bold ? 'F2' : 'F1', $size, self::rgb( $color ), $x, self::H - $y, self::esc( self::enc( $s ) ) ) );
	}

	/**
	 * Word-wrap text to a width.
	 *
	 * @param string $s     Text.
	 * @param float  $width Max width.
	 * @param float  $size  Font size.
	 * @param bool   $bold  Bold.
	 * @return string[]
	 */
	public function wrap( $s, $width, $size, $bold = false ) {
		$lines = array();
		foreach ( preg_split( '/\n/', (string) $s ) as $para ) {
			$words = preg_split( '/\s+/', trim( $para ) );
			$line  = '';
			foreach ( $words as $w ) {
				if ( '' === $w ) {
					continue;
				}
				// Break very long tokens.
				while ( $this->width( $w, $size, $bold ) > $width && strlen( $w ) > 1 ) {
					$cut = strlen( $w );
					while ( $cut > 1 && $this->width( substr( $w, 0, $cut ), $size, $bold ) > $width ) {
						$cut--;
					}
					if ( '' !== $line ) {
						$lines[] = $line;
						$line    = '';
					}
					$lines[] = substr( $w, 0, $cut );
					$w       = substr( $w, $cut );
				}
				$try = '' === $line ? $w : $line . ' ' . $w;
				if ( $this->width( $try, $size, $bold ) <= $width ) {
					$line = $try;
				} else {
					$lines[] = $line;
					$line    = $w;
				}
			}
			$lines[] = $line;
		}
		return $lines;
	}

	/**
	 * Paragraph at the cursor.
	 *
	 * @param string $s     Text.
	 * @param float  $size  Size.
	 * @param bool   $bold  Bold.
	 * @param string $color Colour.
	 * @param float  $gap   Space after.
	 * @return void
	 */
	public function p( $s, $size = 10, $bold = false, $color = '#1d2327', $gap = 6 ) {
		$width = self::W - 2 * $this->margin;
		$lh    = $size * 1.35;
		foreach ( $this->wrap( $s, $width, $size, $bold ) as $line ) {
			$this->need( $lh );
			$this->text_at( $this->margin, $this->y + $size, $line, $size, $bold, $color );
			$this->y += $lh;
		}
		$this->y += $gap;
	}

	/**
	 * Section heading.
	 *
	 * @param string $s Text.
	 * @return void
	 */
	public function h2( $s ) {
		$this->need( 40 );
		$this->y += 8;
		$this->p( $s, 13, true, '#0b3d6b', 3 );
		$this->rect( $this->margin, $this->y - 1, self::W - 2 * $this->margin, 0.8, '#c3c4c7' );
		$this->y += 6;
	}

	/**
	 * Table with wrapped cells.
	 *
	 * @param string[] $head   Header labels.
	 * @param array    $rows   Rows of strings.
	 * @param float[]  $widths Column widths (sum = content width).
	 * @param float    $size   Font size.
	 * @return void
	 */
	public function table( $head, $rows, $widths, $size = 8 ) {
		$lh = $size * 1.3;
		$this->draw_row( $head, $widths, $size, true, $lh );
		$zebra = false;
		foreach ( $rows as $r ) {
			$this->draw_row( $r, $widths, $size, false, $lh, $zebra, $head, true );
			$zebra = ! $zebra;
		}
		$this->y += 6;
	}

	/**
	 * Draw one table row.
	 *
	 * @param array  $cells  Cells.
	 * @param array  $widths Widths.
	 * @param float  $size   Size.
	 * @param bool   $head   Is header.
	 * @param float  $lh     Line height.
	 * @param bool   $zebra  Shade.
	 * @param array  $rehead Header to repeat after a page break.
	 * @param bool   $repeat Whether to repeat header.
	 * @return void
	 */
	protected function draw_row( $cells, $widths, $size, $head, $lh, $zebra = false, $rehead = array(), $repeat = false ) {
		$wrapped = array();
		$max     = 1;
		foreach ( $cells as $i => $c ) {
			$wrapped[ $i ] = $this->wrap( $c, $widths[ $i ] - 6, $size, $head );
			if ( count( $wrapped[ $i ] ) > 6 ) {
				$wrapped[ $i ] = array_slice( $wrapped[ $i ], 0, 6 );
				$wrapped[ $i ][5] = rtrim( $wrapped[ $i ][5], '. ' ) . '...';
			}
			$max = max( $max, count( $wrapped[ $i ] ) );
		}
		$h = $max * $lh + 5;
		if ( $this->y + $h > self::H - $this->margin - 20 ) {
			$this->add_page();
			if ( $repeat && $rehead ) {
				$this->draw_row( $rehead, $widths, $size, true, $lh );
			}
		}
		if ( $head ) {
			$this->rect( $this->margin, $this->y, array_sum( $widths ), $h, '#0b3d6b' );
		} elseif ( $zebra ) {
			$this->rect( $this->margin, $this->y, array_sum( $widths ), $h, '#f3f5f7' );
		}
		$x = $this->margin;
		foreach ( $wrapped as $i => $lines ) {
			$yy = $this->y + 3 + $size;
			foreach ( $lines as $line ) {
				$this->text_at( $x + 3, $yy, $line, $size, $head, $head ? '#ffffff' : '#1d2327' );
				$yy += $lh;
			}
			$x += $widths[ $i ];
		}
		$this->y += $h;
	}

	/**
	 * Build the PDF file contents.
	 *
	 * @return string
	 */
	public function output() {
		$total = count( $this->pages );
		foreach ( $this->pages as $i => $c ) {
			$this->cur = $i;
			$this->rect( $this->margin, self::H - 36, self::W - 2 * $this->margin, 0.5, '#c3c4c7' );
			$this->text_at( $this->margin, self::H - 26, $this->footer, 7.5, false, '#646970' );
			$label = sprintf( 'Page %d of %d', $i + 1, $total );
			$this->text_at( self::W - $this->margin - $this->width( $label, 7.5 ), self::H - 26, $label, 7.5, false, '#646970' );
		}
		$objs   = array();
		$objs[] = '<< /Type /Catalog /Pages 2 0 R >>';
		$kids   = array();
		for ( $i = 0; $i < $total; $i++ ) {
			$kids[] = ( 5 + $i * 2 ) . ' 0 R';
		}
		$objs[] = '<< /Type /Pages /Count ' . $total . ' /Kids [' . implode( ' ', $kids ) . '] >>';
		$objs[] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
		$objs[] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
		foreach ( $this->pages as $i => $c ) {
			$objs[] = sprintf( '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %.2F %.2F] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents %d 0 R >>', self::W, self::H, 6 + $i * 2 );
			$objs[] = '<< /Length ' . strlen( $c ) . " >>\nstream\n" . $c . 'endstream';
		}
		$info_id = count( $objs ) + 1;
		$objs[]  = '<< /Title (' . self::esc( self::enc( isset( $this->info['title'] ) ? $this->info['title'] : '' ) ) . ') /Producer (AccessFix) /Creator (AccessFix) /CreationDate (D:' . gmdate( 'YmdHis' ) . 'Z) >>';
		$pdf     = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
		$offsets = array();
		foreach ( $objs as $n => $o ) {
			$offsets[ $n + 1 ] = strlen( $pdf );
			$pdf              .= ( $n + 1 ) . " 0 obj\n" . $o . "\nendobj\n";
		}
		$xref = strlen( $pdf );
		$pdf .= "xref\n0 " . ( count( $objs ) + 1 ) . "\n";
		$pdf .= "0000000000 65535 f \n";
		foreach ( $offsets as $off ) {
			$pdf .= sprintf( "%010d 00000 n \n", $off );
		}
		$pdf .= 'trailer << /Size ' . ( count( $objs ) + 1 ) . ' /Root 1 0 R /Info ' . $info_id . " 0 R >>\nstartxref\n" . $xref . "\n%%EOF";
		return $pdf;
	}
}
