<?php
/**
 * HTML scanner: runs every check against rendered HTML using DOMDocument.
 *
 * @package AccessFix
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Scanner.
 */
class AccessFix_Scanner {

	/** @var DOMDocument */
	protected $dom;
	/** @var DOMXPath */
	protected $xp;
	/** @var array */
	protected $issues = array();
	/** @var array */
	protected $counts = array();
	/** @var AccessFix_CSS */
	protected $css;
	/** @var SplObjectStorage */
	protected $computed;
	/** @var array */
	protected $opts;

	const CAP = 40;

	/**
	 * Scan HTML and return issues.
	 *
	 * @param string $html HTML source.
	 * @param array  $opts css (array of extra stylesheet strings), contrast (bool).
	 * @return array List of issues.
	 */
	public static function scan( $html, $opts = array() ) {
		$s = new self();
		return $s->run( $html, $opts );
	}

	/**
	 * Find stylesheet URLs and inline style blocks in HTML.
	 *
	 * @param string $html HTML.
	 * @return array links => [], inline => [].
	 */
	public static function style_sources( $html ) {
		$out = array( 'links' => array(), 'inline' => array() );
		if ( preg_match_all( '/<link\b[^>]*>/i', $html, $m ) ) {
			foreach ( $m[0] as $tag ) {
				if ( preg_match( '/rel=["\']?stylesheet/i', $tag ) && preg_match( '/href=(["\'])(.*?)\1/i', $tag, $h ) ) {
					$out['links'][] = html_entity_decode( $h[2], ENT_QUOTES );
				}
			}
		}
		return $out;
	}

	/**
	 * Run the checks.
	 *
	 * @param string $html HTML.
	 * @param array  $opts Options.
	 * @return array
	 */
	public function run( $html, $opts = array() ) {
		$this->opts = array_merge( array( 'css' => array(), 'contrast' => true ), $opts );
		$prev       = libxml_use_internal_errors( true );
		$this->dom  = new DOMDocument();
		$this->dom->loadHTML( '<?xml encoding="utf-8" ?>' . $html, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING );
		libxml_clear_errors();
		libxml_use_internal_errors( $prev );
		$this->xp = new DOMXPath( $this->dom );

		$this->check_page();
		$this->check_images();
		$this->check_links();
		$this->check_buttons_and_inputs();
		$this->check_headings();
		$this->check_ids();
		$this->check_iframes();
		$this->check_tables();
		$this->check_media();
		$this->check_inline_styles();
		$this->check_landmarks();
		if ( $this->opts['contrast'] ) {
			$this->check_contrast();
		}
		return apply_filters( 'accessfix_scan_issues', $this->issues, $this->dom );
	}

	// ---------------------------------------------------------------- helpers.

	/**
	 * XPath query excluding noscript/template content.
	 *
	 * @param string $expr XPath expression selecting elements (without a leading //).
	 * @return DOMElement[]
	 */
	protected function q( $expr ) {
		$out = array();
		$res = $this->xp->query( '//' . $expr . '[not(ancestor::noscript) and not(ancestor::template)]' );
		if ( $res ) {
			foreach ( $res as $n ) {
				$out[] = $n;
			}
		}
		return $out;
	}

	/**
	 * Add an issue (honours the per-check cap).
	 *
	 * @param string          $check Check id.
	 * @param DOMElement|null $el    Element.
	 * @param string          $msg   Message.
	 * @param array           $extra Extra fields.
	 * @return void
	 */
	protected function add( $check, $el, $msg, $extra = array() ) {
		$cap = 'contrast' === $check ? 30 : self::CAP;
		if ( ! isset( $this->counts[ $check ] ) ) {
			$this->counts[ $check ] = 0;
		}
		if ( $this->counts[ $check ] >= $cap ) {
			return;
		}
		$this->counts[ $check ]++;
		$def = AccessFix_Checks::get( $check );
		$row = array(
			'check'    => $check,
			'sc'       => $def ? $def['sc'] : '',
			'severity' => $def ? $def['severity'] : 'moderate',
			'message'  => $msg,
			'selector' => $el ? $this->selector( $el ) : 'html',
			'snippet'  => $el ? $this->snippet( $el ) : '',
			'needle'   => $el ? $this->needle( $el ) : '',
		);
		$this->issues[] = array_merge( $row, $extra );
	}

	/**
	 * Short CSS-ish path to an element.
	 *
	 * @param DOMElement $el Element.
	 * @return string
	 */
	protected function selector( $el ) {
		$parts = array();
		$node  = $el;
		$depth = 0;
		while ( $node instanceof DOMElement && $depth < 5 ) {
			$tag = strtolower( $node->nodeName );
			if ( 'html' === $tag ) {
				break;
			}
			$id = $node->getAttribute( 'id' );
			if ( '' !== $id && preg_match( '/^[A-Za-z][\w:.-]*$/', $id ) ) {
				array_unshift( $parts, $tag . '#' . $id );
				break;
			}
			$n = 1;
			for ( $s = $node->previousSibling; $s; $s = $s->previousSibling ) {
				if ( $s instanceof DOMElement && $s->nodeName === $node->nodeName ) {
					$n++;
				}
			}
			$part = $tag;
			$cls  = preg_split( '/\s+/', trim( $node->getAttribute( 'class' ) ) );
			if ( ! empty( $cls[0] ) && preg_match( '/^[A-Za-z_-][\w-]*$/', $cls[0] ) ) {
				$part .= '.' . $cls[0];
			}
			if ( $n > 1 ) {
				$part .= ':nth-of-type(' . $n . ')';
			}
			array_unshift( $parts, $part );
			$node = $node->parentNode;
			$depth++;
		}
		return implode( ' > ', $parts );
	}

	/**
	 * Compact outer HTML.
	 *
	 * @param DOMElement $el Element.
	 * @return string
	 */
	protected function snippet( $el ) {
		$tag = strtolower( $el->nodeName );
		if ( in_array( $tag, array( 'html', 'body', 'head', 'main', 'table' ), true ) ) {
			$h = $this->open_tag( $el );
			if ( 'table' === $tag ) {
				$h = $this->compact( $this->dom->saveHTML( $el ) );
			}
		} else {
			$h = $this->compact( $this->dom->saveHTML( $el ) );
		}
		return $this->trunc( $h, 400 );
	}

	/**
	 * Opening tag text.
	 *
	 * @param DOMElement $el Element.
	 * @return string
	 */
	protected function open_tag( $el ) {
		$s = '<' . strtolower( $el->nodeName );
		foreach ( $el->attributes as $a ) {
			$s .= ' ' . $a->nodeName . '="' . $this->trunc( $a->nodeValue, 80 ) . '"';
		}
		return $s . '>';
	}

	/**
	 * Collapse whitespace.
	 *
	 * @param string $h HTML.
	 * @return string
	 */
	protected function compact( $h ) {
		return trim( preg_replace( '/\s+/', ' ', (string) $h ) );
	}

	/**
	 * Truncate on characters.
	 *
	 * @param string $s   String.
	 * @param int    $len Max length.
	 * @return string
	 */
	protected function trunc( $s, $len ) {
		if ( function_exists( 'mb_strlen' ) && mb_strlen( $s ) > $len ) {
			return mb_substr( $s, 0, $len ) . '…';
		}
		return strlen( $s ) > $len ? substr( $s, 0, $len ) . '…' : $s;
	}

	/**
	 * A string that identifies the element inside post content (used by "Fix in editor").
	 *
	 * @param DOMElement $el Element.
	 * @return string
	 */
	protected function needle( $el ) {
		foreach ( array( 'src', 'href', 'id', 'name' ) as $a ) {
			$v = $el->getAttribute( $a );
			if ( '' !== $v ) {
				return $this->trunc( $v, 120 );
			}
		}
		return $this->trunc( $this->compact( $el->textContent ), 60 );
	}

	/**
	 * Is the element hidden from everyone (display:none, hidden attribute)?
	 *
	 * @param DOMElement $el Element.
	 * @return bool
	 */
	protected function is_hidden( $el ) {
		for ( $n = $el; $n instanceof DOMElement; $n = $n->parentNode ) {
			if ( $n->hasAttribute( 'hidden' ) ) {
				return true;
			}
			$st = $n->getAttribute( 'style' );
			if ( '' !== $st && preg_match( '/display\s*:\s*none|visibility\s*:\s*hidden/i', $st ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Text a screen reader would read from a node's content.
	 *
	 * @param DOMNode $node Node.
	 * @return string
	 */
	protected function text_of( $node ) {
		$out = '';
		foreach ( $node->childNodes as $c ) {
			if ( XML_TEXT_NODE === $c->nodeType || XML_CDATA_SECTION_NODE === $c->nodeType ) {
				$out .= $c->nodeValue;
			} elseif ( $c instanceof DOMElement ) {
				$tag = strtolower( $c->nodeName );
				if ( in_array( $tag, array( 'script', 'style', 'noscript', 'template' ), true ) ) {
					continue;
				}
				if ( 'true' === strtolower( $c->getAttribute( 'aria-hidden' ) ) || $c->hasAttribute( 'hidden' ) ) {
					continue;
				}
				if ( preg_match( '/display\s*:\s*none/i', $c->getAttribute( 'style' ) ) ) {
					continue;
				}
				if ( '' !== trim( $c->getAttribute( 'aria-label' ) ) ) {
					$out .= ' ' . $c->getAttribute( 'aria-label' ) . ' ';
				} elseif ( 'img' === $tag ) {
					$out .= ' ' . $c->getAttribute( 'alt' ) . ' ';
				} elseif ( 'input' === $tag && 'image' === strtolower( $c->getAttribute( 'type' ) ) ) {
					$out .= ' ' . $c->getAttribute( 'alt' ) . ' ';
				} elseif ( 'svg' === $tag ) {
					foreach ( $c->childNodes as $sc ) {
						if ( $sc instanceof DOMElement && 'title' === strtolower( $sc->nodeName ) ) {
							$out .= ' ' . $sc->textContent . ' ';
						}
					}
				} else {
					$out .= ' ' . $this->text_of( $c ) . ' ';
				}
			}
		}
		return trim( preg_replace( '/\s+/u', ' ', $out ) );
	}

	/**
	 * Accessible name (simplified accname algorithm).
	 *
	 * @param DOMElement $el Element.
	 * @return string
	 */
	protected function name_of( $el ) {
		$lb = trim( $el->getAttribute( 'aria-labelledby' ) );
		if ( '' !== $lb ) {
			$t = '';
			foreach ( preg_split( '/\s+/', $lb ) as $id ) {
				$ref = $this->dom->getElementById( $id );
				if ( ! $ref ) {
					$r = $this->xp->query( '//*[@id=' . $this->xq( $id ) . ']' );
					$ref = $r && $r->length ? $r->item( 0 ) : null;
				}
				if ( $ref ) {
					$t .= ' ' . ( '' !== trim( $ref->getAttribute( 'aria-label' ) ) ? $ref->getAttribute( 'aria-label' ) : $this->text_of( $ref ) );
				}
			}
			if ( '' !== trim( $t ) ) {
				return trim( $t );
			}
		}
		if ( '' !== trim( $el->getAttribute( 'aria-label' ) ) ) {
			return trim( $el->getAttribute( 'aria-label' ) );
		}
		$tag  = strtolower( $el->nodeName );
		$type = strtolower( $el->getAttribute( 'type' ) );
		if ( 'img' === $tag && '' !== trim( $el->getAttribute( 'alt' ) ) ) {
			return trim( $el->getAttribute( 'alt' ) );
		}
		if ( 'input' === $tag ) {
			if ( 'image' === $type && '' !== trim( $el->getAttribute( 'alt' ) ) ) {
				return trim( $el->getAttribute( 'alt' ) );
			}
			if ( in_array( $type, array( 'button', 'submit', 'reset' ), true ) ) {
				if ( '' !== trim( $el->getAttribute( 'value' ) ) ) {
					return trim( $el->getAttribute( 'value' ) );
				}
				if ( 'button' !== $type ) {
					return 'submit' === $type ? 'Submit' : 'Reset';
				}
			}
		} else {
			$t = $this->text_of( $el );
			if ( '' !== $t ) {
				return $t;
			}
		}
		return trim( $el->getAttribute( 'title' ) );
	}

	/**
	 * Quote a string for XPath.
	 *
	 * @param string $s String.
	 * @return string
	 */
	protected function xq( $s ) {
		if ( false === strpos( $s, "'" ) ) {
			return "'" . $s . "'";
		}
		if ( false === strpos( $s, '"' ) ) {
			return '"' . $s . '"';
		}
		return "concat('" . str_replace( "'", "',\"'\",'", $s ) . "')";
	}

	// ----------------------------------------------------------------- checks.

	/**
	 * Page-level: lang, title, viewport.
	 *
	 * @return void
	 */
	protected function check_page() {
		$html = $this->dom->documentElement;
		if ( $html ) {
			$lang = trim( $html->getAttribute( 'lang' ) );
			if ( '' === $lang ) {
				$lang = trim( $html->getAttribute( 'xml:lang' ) );
			}
			if ( '' === $lang ) {
				$this->add( 'html-lang', $html, __( 'The <html> element has no lang attribute.', 'accessfix' ) );
			}
		}
		$title = $this->xp->query( '//head/title' );
		if ( ! $title || ! $title->length || '' === trim( $title->item( 0 )->textContent ) ) {
			$this->add( 'page-title', $html, __( 'The page has no <title> or it is empty.', 'accessfix' ) );
		}
		foreach ( $this->xp->query( '//meta[translate(@name,"VIEWPORT","viewport")="viewport"]' ) as $m ) {
			$c = strtolower( $m->getAttribute( 'content' ) );
			$bad = false;
			if ( preg_match( '/user-scalable\s*=\s*(no|0)/', $c ) ) {
				$bad = true;
			}
			if ( preg_match( '/maximum-scale\s*=\s*([0-9.]+)/', $c, $mm ) && (float) $mm[1] < 2 ) {
				$bad = true;
			}
			if ( $bad ) {
				$this->add( 'meta-viewport', $m, __( 'The viewport meta tag prevents pinch-zoom.', 'accessfix' ) );
			}
		}
	}

	/**
	 * Images.
	 *
	 * @return void
	 */
	protected function check_images() {
		foreach ( $this->q( 'img' ) as $img ) {
			if ( $this->is_hidden( $img ) || 'true' === strtolower( $img->getAttribute( 'aria-hidden' ) ) && $img->hasAttribute( 'alt' ) ) {
				continue;
			}
			$role     = strtolower( $img->getAttribute( 'role' ) );
			$presentational = in_array( $role, array( 'presentation', 'none' ), true ) || 'true' === strtolower( $img->getAttribute( 'aria-hidden' ) );
			$w        = $img->getAttribute( 'width' );
			$h        = $img->getAttribute( 'height' );
			$tiny     = ( '' !== $w && is_numeric( $w ) && (float) $w <= 2 ) || ( '' !== $h && is_numeric( $h ) && (float) $h <= 2 );
			$named    = '' !== trim( $img->getAttribute( 'aria-label' ) ) || '' !== trim( $img->getAttribute( 'aria-labelledby' ) ) || '' !== trim( $img->getAttribute( 'title' ) );
			if ( ! $img->hasAttribute( 'alt' ) ) {
				if ( $named ) {
					continue;
				}
				if ( $presentational || $tiny ) {
					$this->add( 'img-alt-decorative', $img, __( 'Decorative image without alt="".', 'accessfix' ) );
				} else {
					$this->add( 'img-alt-missing', $img, __( 'Image has no alt attribute.', 'accessfix' ) );
				}
				continue;
			}
			$alt = trim( $img->getAttribute( 'alt' ) );
			if ( '' !== $alt && in_array( $role, array( 'presentation', 'none' ), true ) ) {
				$this->add( 'img-alt-decorative', $img, __( 'Image is marked as presentational but has alt text.', 'accessfix' ) );
			} elseif ( '' !== $alt && ( preg_match( '/\.(jpe?g|png|gif|webp|svg|avif|bmp)$/i', $alt ) || preg_match( '/^(img|dsc|image|photo|screenshot|pic|picture)[-_ ]?\d+/i', $alt ) || preg_match( '/^\d{3,}$/', $alt ) ) ) {
				$this->add( 'img-alt-filename', $img, __( 'Alt text looks like a file name.', 'accessfix' ) );
			}
		}
		foreach ( $this->q( 'input[translate(@type,"IMAGE","image")="image"]' ) as $in ) {
			if ( '' === $this->name_of( $in ) ) {
				$this->add( 'img-alt-missing', $in, __( 'Image button has no alt text.', 'accessfix' ) );
			}
		}
		foreach ( $this->q( 'svg[@role="img"]' ) as $svg ) {
			if ( '' === $this->name_of( $svg ) && '' === $this->text_of( $svg ) ) {
				$this->add( 'img-alt-missing', $svg, __( 'SVG with role="img" has no accessible name.', 'accessfix' ) );
			}
		}
	}

	/**
	 * Links.
	 *
	 * @return void
	 */
	protected function check_links() {
		$vague = array( 'click here', 'here', 'read more', 'more', 'learn more', 'link', 'this', 'click', 'details', 'continue', 'more info', 'more information', 'tap here', 'this link', 'click this link', 'read on', 'view more', 'see more' );
		foreach ( $this->q( 'a[@href]' ) as $a ) {
			if ( $this->is_hidden( $a ) ) {
				continue;
			}
			$name = $this->name_of( $a );
			if ( '' === $name ) {
				$has_content = false;
				foreach ( $a->childNodes as $c ) {
					if ( $c instanceof DOMElement || ( XML_TEXT_NODE === $c->nodeType && '' !== trim( $c->nodeValue ) ) ) {
						$has_content = true;
						break;
					}
				}
				if ( $has_content ) {
					$this->add( 'link-name', $a, __( 'Link has no accessible name (icon or image without text).', 'accessfix' ) );
				} else {
					$this->add( 'link-empty', $a, __( 'Link is empty.', 'accessfix' ) );
				}
			} else {
				$norm = strtolower( trim( preg_replace( '/[\s\p{P}]+/u', ' ', $name ) ) );
				if ( in_array( $norm, $vague, true ) ) {
					$this->add( 'link-vague', $a, sprintf( /* translators: %s: link text */ __( 'Link text "%s" does not describe the destination.', 'accessfix' ), $this->trunc( $name, 40 ) ) );
				}
			}
			if ( '_blank' === strtolower( $a->getAttribute( 'target' ) ) ) {
				$hint = $name . ' ' . $a->getAttribute( 'title' ) . ' ' . $a->getAttribute( 'aria-describedby' );
				if ( ! preg_match( '/new (tab|window)|opens? in|external (link|site)|neues fenster|nouvel onglet|nueva (pesta|ventana)/iu', $hint ) ) {
					$this->add( 'new-window', $a, __( 'Link opens in a new tab without telling the user.', 'accessfix' ) );
				}
			}
		}
	}

	/**
	 * Buttons, inputs, tap targets.
	 *
	 * @return void
	 */
	protected function check_buttons_and_inputs() {
		$btns = array_merge( $this->q( 'button' ), $this->q( 'input[translate(@type,"BUTONSMITRE","butonsmitre")="button" or translate(@type,"SUBMIT","submit")="submit" or translate(@type,"RESET","reset")="reset"]' ), $this->q( '*[@role="button"]' ) );
		foreach ( $btns as $b ) {
			if ( $this->is_hidden( $b ) ) {
				continue;
			}
			if ( '' === $this->name_of( $b ) ) {
				$this->add( 'button-name', $b, __( 'Button has no accessible name.', 'accessfix' ) );
			}
		}
		// Labels.
		$for = array();
		foreach ( $this->q( 'label[@for]' ) as $l ) {
			if ( '' !== $this->text_of( $l ) || $l->getElementsByTagName( 'img' )->length ) {
				$for[ $l->getAttribute( 'for' ) ] = true;
			}
		}
		$fields = array_merge( $this->q( 'input' ), $this->q( 'select' ), $this->q( 'textarea' ) );
		foreach ( $fields as $f ) {
			$tag  = strtolower( $f->nodeName );
			$type = strtolower( $f->getAttribute( 'type' ) );
			if ( 'input' === $tag && in_array( $type, array( 'hidden', 'submit', 'reset', 'button', 'image' ), true ) ) {
				continue;
			}
			if ( $this->is_hidden( $f ) ) {
				continue;
			}
			$labelled = false;
			$id       = $f->getAttribute( 'id' );
			if ( '' !== $id && isset( $for[ $id ] ) ) {
				$labelled = true;
			}
			if ( ! $labelled ) {
				for ( $n = $f->parentNode; $n instanceof DOMElement; $n = $n->parentNode ) {
					if ( 'label' === strtolower( $n->nodeName ) && '' !== $this->text_of( $n ) ) {
						$labelled = true;
						break;
					}
				}
			}
			if ( ! $labelled && ( '' !== trim( $f->getAttribute( 'aria-label' ) ) || '' !== $this->aria_labelledby_text( $f ) || '' !== trim( $f->getAttribute( 'title' ) ) ) ) {
				$labelled = true;
			}
			if ( ! $labelled ) {
				$msg = '' !== trim( $f->getAttribute( 'placeholder' ) )
					? __( 'Form field relies on a placeholder instead of a label.', 'accessfix' )
					: __( 'Form field has no label.', 'accessfix' );
				$this->add( 'input-label', $f, $msg );
			}
		}
		// Tap targets with inline size.
		foreach ( array_merge( $this->q( 'a[@href]' ), $this->q( 'button' ), $this->q( 'select' ), $this->q( 'input[@type="checkbox" or @type="radio" or @type="button" or @type="submit"]' ) ) as $el ) {
			$st = $el->getAttribute( 'style' );
			if ( '' === $st ) {
				continue;
			}
			$d = AccessFix_CSS::parse_decls( $st );
			$small = false;
			foreach ( array( 'width', 'height' ) as $dim ) {
				if ( isset( $d[ $dim ] ) && preg_match( '/^([0-9.]+)px$/', trim( $d[ $dim ][0] ), $m ) && (float) $m[1] < 24 ) {
					$small = true;
				}
			}
			if ( $small ) {
				$this->add( 'tap-target', $el, __( 'Inline size is smaller than 24x24 CSS pixels.', 'accessfix' ) );
			}
		}
	}

	/**
	 * Text of aria-labelledby targets.
	 *
	 * @param DOMElement $el Element.
	 * @return string
	 */
	protected function aria_labelledby_text( $el ) {
		$lb = trim( $el->getAttribute( 'aria-labelledby' ) );
		if ( '' === $lb ) {
			return '';
		}
		$t = '';
		foreach ( preg_split( '/\s+/', $lb ) as $id ) {
			$r = $this->xp->query( '//*[@id=' . $this->xq( $id ) . ']' );
			if ( $r && $r->length ) {
				$t .= $this->text_of( $r->item( 0 ) ) . $r->item( 0 )->getAttribute( 'aria-label' );
			}
		}
		return trim( $t );
	}

	/**
	 * Headings.
	 *
	 * @return void
	 */
	protected function check_headings() {
		$list = $this->xp->query( '//*[self::h1 or self::h2 or self::h3 or self::h4 or self::h5 or self::h6 or @role="heading"][not(ancestor::noscript) and not(ancestor::template)]' );
		$prev = 0;
		$h1s  = array();
		foreach ( $list as $h ) {
			if ( $this->is_hidden( $h ) ) {
				continue;
			}
			$tag = strtolower( $h->nodeName );
			if ( preg_match( '/^h([1-6])$/', $tag, $m ) ) {
				$lvl = (int) $m[1];
			} else {
				$lvl = (int) $h->getAttribute( 'aria-level' );
				$lvl = $lvl >= 1 && $lvl <= 6 ? $lvl : 2;
			}
			if ( '' === $this->name_of( $h ) ) {
				$this->add( 'heading-empty', $h, __( 'Heading has no text.', 'accessfix' ) );
				continue;
			}
			if ( 1 === $lvl ) {
				$h1s[] = $h;
			}
			if ( $prev > 0 && $lvl > $prev + 1 ) {
				$this->add( 'heading-skip', $h, sprintf( /* translators: 1: previous level, 2: this level */ __( 'Heading level jumps from H%1$d to H%2$d.', 'accessfix' ), $prev, $lvl ) );
			}
			$prev = $lvl;
		}
		if ( ! $h1s ) {
			$this->add( 'h1-missing', $this->dom->getElementsByTagName( 'body' )->item( 0 ), __( 'The page has no H1 heading.', 'accessfix' ) );
		} elseif ( count( $h1s ) > 1 ) {
			$this->add( 'h1-multiple', $h1s[1], sprintf( /* translators: %d: number of H1s */ __( 'The page has %d H1 headings.', 'accessfix' ), count( $h1s ) ) );
		}
	}

	/**
	 * Duplicate ids.
	 *
	 * @return void
	 */
	protected function check_ids() {
		$seen = array();
		foreach ( $this->q( '*[@id]' ) as $el ) {
			$id = $el->getAttribute( 'id' );
			if ( '' === $id ) {
				continue;
			}
			if ( isset( $seen[ $id ] ) ) {
				$this->add( 'duplicate-id', $el, sprintf( /* translators: %s: id */ __( 'The id "%s" is used more than once.', 'accessfix' ), $id ), array( 'needle' => 'id="' . $id . '"' ) );
			}
			$seen[ $id ] = true;
		}
	}

	/**
	 * Iframes.
	 *
	 * @return void
	 */
	protected function check_iframes() {
		foreach ( $this->q( 'iframe' ) as $f ) {
			$st = $f->getAttribute( 'style' );
			if ( $this->is_hidden( $f ) || 'true' === $f->getAttribute( 'aria-hidden' ) || '0' === $f->getAttribute( 'width' ) || '0' === $f->getAttribute( 'height' ) || preg_match( '/(width|height)\s*:\s*0(px)?\s*(;|$)/i', $st ) ) {
				continue;
			}
			if ( '' === trim( $f->getAttribute( 'title' ) ) && '' === trim( $f->getAttribute( 'aria-label' ) ) && '' === trim( $f->getAttribute( 'aria-labelledby' ) ) ) {
				$this->add( 'iframe-title', $f, __( 'iframe has no title.', 'accessfix' ) );
			}
		}
	}

	/**
	 * Tables.
	 *
	 * @return void
	 */
	protected function check_tables() {
		foreach ( $this->q( 'table' ) as $t ) {
			$role = strtolower( $t->getAttribute( 'role' ) );
			if ( in_array( $role, array( 'presentation', 'none' ), true ) ) {
				continue;
			}
			$rows = $t->getElementsByTagName( 'tr' );
			$cols = 0;
			foreach ( $rows as $r ) {
				$cols = max( $cols, $r->getElementsByTagName( 'td' )->length + $r->getElementsByTagName( 'th' )->length );
			}
			if ( $rows->length < 2 || $cols < 2 ) {
				continue;
			}
			$has_th = $t->getElementsByTagName( 'th' )->length > 0;
			if ( ! $has_th ) {
				foreach ( $this->xp->query( './/*[@role="columnheader" or @role="rowheader"]', $t ) as $x ) {
					$has_th = true;
				}
			}
			if ( ! $has_th ) {
				$this->add( 'table-headers', $t, __( 'Data table has no header cells (th).', 'accessfix' ) );
			}
		}
	}

	/**
	 * Autoplay.
	 *
	 * @return void
	 */
	protected function check_media() {
		foreach ( $this->q( 'audio[@autoplay]' ) as $m ) {
			$this->add( 'autoplay', $m, __( 'Audio starts automatically.', 'accessfix' ) );
		}
		foreach ( $this->q( 'video[@autoplay]' ) as $v ) {
			if ( ! $v->hasAttribute( 'muted' ) ) {
				$this->add( 'autoplay', $v, __( 'Video starts automatically with sound.', 'accessfix' ) );
			} elseif ( ! $v->hasAttribute( 'controls' ) ) {
				$this->add( 'autoplay', $v, __( 'Muted video plays automatically with no pause control.', 'accessfix' ), array( 'sc' => '2.2.2', 'severity' => 'moderate' ) );
			}
		}
		foreach ( $this->q( 'iframe[contains(@src,"autoplay=1")]' ) as $f ) {
			$this->add( 'autoplay', $f, __( 'Embedded player is set to autoplay.', 'accessfix' ) );
		}
	}

	/**
	 * Checks driven by inline styles/attributes.
	 *
	 * @return void
	 */
	protected function check_inline_styles() {
		foreach ( $this->q( '*[@tabindex]' ) as $el ) {
			if ( (int) $el->getAttribute( 'tabindex' ) > 0 ) {
				$this->add( 'tabindex-positive', $el, __( 'Positive tabindex changes the natural focus order.', 'accessfix' ) );
			}
		}
		foreach ( $this->q( '*[@style]' ) as $el ) {
			$st = $el->getAttribute( 'style' );
			if ( preg_match( '/outline(-style)?\s*:\s*(none|0)\b/i', $st ) && ! preg_match( '/box-shadow|border/i', $st ) && in_array( strtolower( $el->nodeName ), array( 'a', 'button', 'input', 'select', 'textarea' ), true ) ) {
				$this->add( 'focus-outline', $el, __( 'Inline style removes the focus outline.', 'accessfix' ) );
			}
		}
	}

	/**
	 * Landmarks and skip link.
	 *
	 * @return void
	 */
	protected function check_landmarks() {
		$body = $this->dom->getElementsByTagName( 'body' )->item( 0 );
		if ( ! $body ) {
			return;
		}
		if ( ! $this->xp->query( '//main | //*[@role="main"]' )->length ) {
			$this->add( 'main-landmark', $body, __( 'The page has no main landmark.', 'accessfix' ) );
		}
		$links = $this->xp->query( '//body//a[@href]' );
		$i     = 0;
		$ok    = false;
		foreach ( $links as $a ) {
			if ( $i++ >= 10 ) {
				break;
			}
			$href = $a->getAttribute( 'href' );
			if ( strlen( $href ) > 1 && '#' === $href[0] && preg_match( '/skip|jump|go to|main|content/i', $this->name_of( $a ) . ' ' . $a->getAttribute( 'class' ) ) ) {
				$target = substr( $href, 1 );
				$r      = $this->xp->query( '//*[@id=' . $this->xq( $target ) . ' or @name=' . $this->xq( $target ) . ']' );
				if ( $r && $r->length ) {
					$ok = true;
					break;
				}
			}
		}
		if ( ! $ok ) {
			$this->add( 'skip-link', $body, __( 'No working skip link among the first links on the page.', 'accessfix' ) );
		}
	}

	// ---------------------------------------------------------------- contrast.

	/**
	 * Build the stylesheet model.
	 *
	 * @return void
	 */
	protected function load_css() {
		$this->css      = new AccessFix_CSS();
		$this->computed = new SplObjectStorage();
		foreach ( (array) $this->opts['css'] as $css ) {
			$this->css->add( $css );
		}
		foreach ( $this->xp->query( '//style' ) as $st ) {
			$this->css->add( $st->textContent );
		}
	}

	/**
	 * Computed (approximate) style of an element.
	 *
	 * @param DOMElement $el Element.
	 * @return array color, bg, size, bold, hidden, unknown.
	 */
	protected function computed( $el ) {
		if ( $this->computed->contains( $el ) ) {
			return $this->computed[ $el ];
		}
		$parent = $el->parentNode instanceof DOMElement ? $this->computed( $el->parentNode ) : array(
			'color' => array( 0, 0, 0, 1 ), 'color_known' => true, 'size' => 16.0, 'bold' => false, 'hidden' => false, 'opacity' => false,
		);
		$d   = $this->css->declared( $el );
		$tag = strtolower( $el->nodeName );
		$out = $parent;

		// Colour (inherited).
		if ( isset( $d['color'] ) ) {
			$v = strtolower( trim( $d['color'] ) );
			if ( 'inherit' === $v || 'currentcolor' === $v || 'initial' === $v || 'unset' === $v ) {
				$out['color'] = $parent['color'];
			} else {
				$c = AccessFix_Color::parse( $v );
				if ( $c ) {
					$out['color']       = $c;
					$out['color_known'] = true;
				} else {
					$out['color_known'] = false;
				}
			}
		} elseif ( 'a' === $tag && $el->hasAttribute( 'href' ) ) {
			$out['color_known'] = false; // Browser default link colour depends on UA/theme.
		}

		// Font size.
		$out['size'] = $parent['size'];
		if ( isset( $d['font-size'] ) && preg_match( '/^([0-9.]+)(px|pt|rem|em|%)$/i', trim( $d['font-size'] ), $m ) ) {
			$n = (float) $m[1];
			switch ( strtolower( $m[2] ) ) {
				case 'px':
					$out['size'] = $n;
					break;
				case 'pt':
					$out['size'] = $n * 4 / 3;
					break;
				case 'rem':
					$out['size'] = $n * 16;
					break;
				case 'em':
					$out['size'] = $n * $parent['size'];
					break;
				case '%':
					$out['size'] = $n / 100 * $parent['size'];
					break;
			}
		} elseif ( ! isset( $d['font-size'] ) ) {
			$ua = array( 'h1' => 2, 'h2' => 1.5, 'h3' => 1.17, 'h4' => 1, 'h5' => 0.83, 'h6' => 0.67, 'small' => 0.83 );
			if ( isset( $ua[ $tag ] ) ) {
				$out['size'] = $parent['size'] * $ua[ $tag ];
			}
		}

		// Weight.
		if ( isset( $d['font-weight'] ) ) {
			$w = strtolower( trim( $d['font-weight'] ) );
			$out['bold'] = in_array( $w, array( 'bold', 'bolder' ), true ) || ( is_numeric( $w ) && (float) $w >= 700 );
		} elseif ( in_array( $tag, array( 'b', 'strong', 'th', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ), true ) ) {
			$out['bold'] = true;
		}

		// Visibility.
		if ( $el->hasAttribute( 'hidden' ) || ( isset( $d['display'] ) && 'none' === strtolower( trim( $d['display'] ) ) ) || ( isset( $d['visibility'] ) && 'hidden' === strtolower( trim( $d['visibility'] ) ) ) ) {
			$out['hidden'] = true;
		}
		if ( isset( $d['clip'] ) || isset( $d['clip-path'] ) || ( isset( $d['width'] ) && '1px' === trim( $d['width'] ) && isset( $d['height'] ) && '1px' === trim( $d['height'] ) ) ) {
			$out['hidden'] = true;
		}
		if ( isset( $d['opacity'] ) && (float) $d['opacity'] < 1 ) {
			$out['opacity'] = true;
		}

		// Background (not inherited; resolved by walking up when needed).
		$out['bg'] = $this->own_background( $d );
		$this->computed->attach( $el, $out );
		return $out;
	}

	/**
	 * Background declared on this element.
	 *
	 * @param array $d Declarations.
	 * @return array|string|null null = none, 'unknown', or rgba.
	 */
	protected function own_background( $d ) {
		if ( isset( $d['background-image'] ) && ! preg_match( '/^(none|initial|unset)$/i', trim( $d['background-image'] ) ) ) {
			return 'unknown';
		}
		$val = null;
		if ( isset( $d['background-color'] ) ) {
			$val = $d['background-color'];
		} elseif ( isset( $d['background'] ) ) {
			$val = $d['background'];
			if ( preg_match( '/url\(|gradient\(/i', $val ) ) {
				return 'unknown';
			}
		}
		if ( null === $val ) {
			return null;
		}
		$val = trim( $val );
		if ( preg_match( '/^(none|initial|unset|inherit)$/i', $val ) ) {
			return null;
		}
		if ( false !== strpos( $val, 'var(' ) ) {
			return 'unknown';
		}
		$c = AccessFix_Color::parse( $val );
		if ( ! $c && preg_match_all( '/(#[0-9a-f]{3,8}\b|rgba?\([^)]*\)|hsla?\([^)]*\)|\b[a-z]+\b)/i', $val, $m ) ) {
			foreach ( $m[1] as $tok ) {
				$c = AccessFix_Color::parse( $tok );
				if ( $c ) {
					break;
				}
			}
		}
		if ( ! $c ) {
			return 'unknown';
		}
		return $c;
	}

	/**
	 * Effective opaque background colour behind an element.
	 *
	 * @param DOMElement $el Element.
	 * @return array|null Null when it cannot be determined.
	 */
	protected function effective_bg( $el ) {
		$layers = array();
		for ( $n = $el; $n instanceof DOMElement; $n = $n->parentNode ) {
			$c = $this->computed( $n );
			if ( ! empty( $c['opacity'] ) ) {
				return null;
			}
			$bg = $c['bg'];
			if ( 'unknown' === $bg ) {
				return null;
			}
			if ( is_array( $bg ) && $bg[3] > 0 ) {
				$layers[] = $bg;
				if ( $bg[3] >= 1 ) {
					break;
				}
			}
		}
		$base = array( 255, 255, 255, 1 );
		if ( $layers && $layers[ count( $layers ) - 1 ][3] >= 1 ) {
			$base = array_pop( $layers );
		}
		while ( $layers ) {
			$base = AccessFix_Color::over( array_pop( $layers ), $base );
		}
		return $base;
	}

	/**
	 * Low contrast text.
	 *
	 * @return void
	 */
	protected function check_contrast() {
		$this->load_css();
		$seen  = array();
		$limit = 2500;
		$nodes = $this->xp->query( '//body//*[not(self::script) and not(self::style) and not(self::noscript) and not(self::template) and not(self::svg) and not(self::option) and not(ancestor::svg) and not(ancestor::noscript) and not(ancestor::template)][text()[normalize-space()]]' );
		foreach ( $nodes as $el ) {
			if ( $limit-- <= 0 ) {
				break;
			}
			if ( $el->hasAttribute( 'disabled' ) ) {
				continue;
			}
			$c = $this->computed( $el );
			if ( $c['hidden'] || ! $c['color_known'] || ! empty( $c['opacity'] ) ) {
				continue;
			}
			$bg = $this->effective_bg( $el );
			if ( ! $bg ) {
				continue;
			}
			$fg = $c['color'];
			if ( $fg[3] < 1 ) {
				$fg = AccessFix_Color::over( $fg, $bg );
			}
			$ratio = floor( AccessFix_Color::ratio( $fg, $bg ) * 100 ) / 100;
			$large = $c['size'] >= 24 || ( $c['bold'] && $c['size'] >= 18.66 );
			$need  = $large ? 3.0 : 4.5;
			if ( $ratio >= $need ) {
				continue;
			}
			$key = AccessFix_Color::hex( $fg ) . '|' . AccessFix_Color::hex( $bg ) . '|' . ( $large ? 'L' : 'N' );
			if ( isset( $seen[ $key ] ) ) {
				$this->issues[ $seen[ $key ] ]['extra_count'] = ( isset( $this->issues[ $seen[ $key ] ]['extra_count'] ) ? $this->issues[ $seen[ $key ] ]['extra_count'] : 0 ) + 1;
				continue;
			}
			$before = count( $this->issues );
			$this->add(
				'contrast',
				$el,
				sprintf(
					/* translators: 1: ratio, 2: required ratio, 3: foreground hex, 4: background hex */
					__( 'Contrast %1$s:1 is below the required %2$s:1 (text %3$s on %4$s).', 'accessfix' ),
					number_format( $ratio, 2, '.', '' ),
					number_format( $need, 1, '.', '' ),
					AccessFix_Color::hex( $fg ),
					AccessFix_Color::hex( $bg )
				),
				array( 'needle' => $this->trunc( $this->compact( $el->textContent ), 60 ) )
			);
			if ( count( $this->issues ) > $before ) {
				$seen[ $key ] = count( $this->issues ) - 1;
			}
		}
	}
}
