<?php
/**
 * Dashboard data and rendering.
 *
 * @package AccessFix
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Dashboard.
 */
class AccessFix_Dashboard {

	/**
	 * Average score of scanned pages (null when nothing scanned).
	 *
	 * @return int|null
	 */
	public static function site_score() {
		global $wpdb;
		$t = AccessFix_Install::table( 'pages' );
		$v = $wpdb->get_var( "SELECT AVG(score) FROM $t WHERE (error IS NULL OR error = '')" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return null === $v ? null : (int) round( (float) $v );
	}

	/**
	 * Latest finished (or running) scan.
	 *
	 * @return object|null
	 */
	public static function last_scan() {
		global $wpdb;
		$t = AccessFix_Install::table( 'scans' );
		return $wpdb->get_row( "SELECT * FROM $t WHERE status = 'done' ORDER BY id DESC LIMIT 1" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Counts by status.
	 *
	 * @return array
	 */
	public static function status_counts() {
		global $wpdb;
		$t   = AccessFix_Install::table( 'issues' );
		$out = array( 'open' => 0, 'fixed' => 0, 'fixed-manually' => 0, 'ignored' => 0 );
		foreach ( (array) $wpdb->get_results( "SELECT status, COUNT(*) AS n FROM $t GROUP BY status" ) as $r ) { // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$out[ $r->status ] = (int) $r->n;
		}
		return $out;
	}

	/**
	 * Open issues grouped by criterion.
	 *
	 * @return array
	 */
	public static function by_criterion() {
		global $wpdb;
		$t = AccessFix_Install::table( 'issues' );
		return (array) $wpdb->get_results( "SELECT criterion, COUNT(*) AS n, COUNT(DISTINCT check_id) AS checks FROM $t WHERE status = 'open' GROUP BY criterion ORDER BY n DESC" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Open issues by severity.
	 *
	 * @return array
	 */
	public static function by_severity() {
		global $wpdb;
		$t   = AccessFix_Install::table( 'issues' );
		$out = array( 'critical' => 0, 'serious' => 0, 'moderate' => 0, 'minor' => 0 );
		foreach ( (array) $wpdb->get_results( "SELECT severity, COUNT(*) AS n FROM $t WHERE status = 'open' GROUP BY severity" ) as $r ) { // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$out[ $r->severity ] = (int) $r->n;
		}
		return $out;
	}

	/**
	 * Scan history for the trend chart.
	 *
	 * @param int $n Number of scans.
	 * @return array Oldest first.
	 */
	public static function trend( $n = 20 ) {
		global $wpdb;
		$t    = AccessFix_Install::table( 'scans' );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, finished_at, score, open_issues, fixed_issues FROM $t WHERE status = 'done' ORDER BY id DESC LIMIT %d", $n ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return array_reverse( (array) $rows );
	}

	/**
	 * Pages with scores, worst first.
	 *
	 * @param int $limit Limit.
	 * @return array
	 */
	public static function pages( $limit = 50 ) {
		global $wpdb;
		$t = AccessFix_Install::table( 'pages' );
		return (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $t ORDER BY (CASE WHEN error IS NOT NULL AND error <> '' THEN 1 ELSE 0 END) DESC, score ASC, open_count DESC LIMIT %d", $limit ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * EAA readiness checklist.
	 *
	 * @return array items: id, label, type(auto|manual), done(bool), detail.
	 */
	public static function checklist() {
		global $wpdb;
		$t      = AccessFix_Install::table( 'issues' );
		$scan   = self::last_scan();
		$manual = get_option( 'af_eaa_manual', array() );
		$manual = is_array( $manual ) ? $manual : array();
		$open   = function ( $where ) use ( $wpdb, $t ) {
			return (int) $wpdb->get_var( "SELECT COUNT(*) FROM $t WHERE status = 'open' AND $where" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		};
		$stmt   = AccessFix_Statement::published_page();
		$sd     = AccessFix_Statement::data();
		$audit  = AccessFix_Audit::count();
		$recent = $scan && $scan->finished_at && ( time() - strtotime( $scan->finished_at . ' UTC' ) ) < 30 * DAY_IN_SECONDS;
		$sev    = self::by_severity();
		$cov    = AccessFix_Media::coverage();

		$items = array(
			array( 'id' => 'scan', 'type' => 'auto', 'done' => (bool) $recent, 'label' => __( 'The site was scanned in the last 30 days', 'accessfix' ), 'detail' => $scan ? sprintf( /* translators: %s: date */ __( 'Last scan: %s', 'accessfix' ), get_date_from_gmt( $scan->finished_at, get_option( 'date_format' ) ) ) : __( 'No scan yet.', 'accessfix' ) ),
			array( 'id' => 'critical', 'type' => 'auto', 'done' => $scan && 0 === $sev['critical'], 'label' => __( 'No open critical issues', 'accessfix' ), 'detail' => sprintf( /* translators: %d: count */ __( '%d open', 'accessfix' ), $sev['critical'] ) ),
			array( 'id' => 'serious', 'type' => 'auto', 'done' => $scan && 0 === $sev['serious'], 'label' => __( 'No open serious issues', 'accessfix' ), 'detail' => sprintf( /* translators: %d: count */ __( '%d open', 'accessfix' ), $sev['serious'] ) ),
			array( 'id' => 'structure', 'type' => 'auto', 'done' => $scan && 0 === $open( "check_id IN ('html-lang','page-title','main-landmark','skip-link','h1-missing')" ), 'label' => __( 'Page language, title, main landmark, skip link and H1 are present', 'accessfix' ), 'detail' => '' ),
			array( 'id' => 'images', 'type' => 'auto', 'done' => $scan && 0 === $open( "check_id = 'img-alt-missing'" ) && 0 === $cov['missing'], 'label' => __( 'Every image has alt text or is marked decorative', 'accessfix' ), 'detail' => sprintf( /* translators: 1: images missing alt, 2: total images */ __( '%1$d of %2$d Media Library images still need alt text', 'accessfix' ), $cov['missing'], $cov['total'] ) ),
			array( 'id' => 'forms', 'type' => 'auto', 'done' => $scan && 0 === $open( "check_id IN ('input-label','button-name')" ), 'label' => __( 'Form fields and buttons have accessible names', 'accessfix' ), 'detail' => '' ),
			array( 'id' => 'statement', 'type' => 'auto', 'done' => (bool) $stmt, 'label' => __( 'An accessibility statement is published', 'accessfix' ), 'detail' => $stmt ? get_the_title( $stmt ) : __( 'Create one under Statement.', 'accessfix' ) ),
			array( 'id' => 'feedback', 'type' => 'auto', 'done' => ! empty( $sd['email'] ) && ! empty( get_option( AccessFix_Statement::OPTION ) ), 'label' => __( 'A feedback contact is given in the statement', 'accessfix' ), 'detail' => '' ),
			array( 'id' => 'evidence', 'type' => 'auto', 'done' => $audit > 0, 'label' => __( 'An audit trail exists (evidence of detection and remediation)', 'accessfix' ), 'detail' => sprintf( /* translators: %d: rows */ __( '%d log entries', 'accessfix' ), $audit ) ),
		);
		$man = array(
			'scope'    => __( 'I have checked whether the European Accessibility Act applies to my business (for example consumer e-commerce, and whether the micro-enterprise exemption applies) and recorded the decision', 'accessfix' ),
			'keyboard' => __( 'I tested the main journeys (navigation, forms, checkout) using only the keyboard', 'accessfix' ),
			'reader'   => __( 'I tested key templates with a screen reader (NVDA, JAWS or VoiceOver)', 'accessfix' ),
			'zoom'     => __( 'I tested 200% zoom and 320 px wide reflow without loss of content', 'accessfix' ),
			'media'    => __( 'Videos have captions, and audio-only content has a transcript', 'accessfix' ),
			'forms'    => __( 'Form errors are described in text and not by colour alone; no step relies on a cognitive test (WCAG 3.3.8)', 'accessfix' ),
			'docs'     => __( 'PDFs, downloads and transactional emails are accessible or an accessible alternative is offered', 'accessfix' ),
			'owner'    => __( 'A named person is responsible for handling accessibility feedback', 'accessfix' ),
		);
		foreach ( $man as $k => $label ) {
			$items[] = array( 'id' => 'm_' . $k, 'type' => 'manual', 'done' => ! empty( $manual[ $k ] ), 'label' => $label, 'detail' => '', 'key' => $k );
		}
		return $items;
	}

	/**
	 * Render the dashboard.
	 *
	 * @return void
	 */
	public static function render() {
		$score  = self::site_score();
		$scan   = self::last_scan();
		$counts = self::status_counts();
		$sev    = self::by_severity();
		$pages  = self::pages( 40 );
		$crit   = self::by_criterion();
		$trend  = self::trend( 20 );
		$list   = self::checklist();
		$done   = count( array_filter( wp_list_pluck( $list, 'done' ) ) );
		$msg    = isset( $_GET['af_msg'] ) ? sanitize_key( wp_unslash( $_GET['af_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		echo '<div class="wrap af-wrap"><h1>' . esc_html__( 'AccessFix dashboard', 'accessfix' ) . '</h1>';
		if ( 'eaa' === $msg ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Checklist saved.', 'accessfix' ) . '</p></div>';
		}

		echo '<div class="af-cards">';
		echo '<section class="af-card af-card--score" aria-labelledby="af-h-score"><h2 id="af-h-score">' . esc_html__( 'Site score', 'accessfix' ) . '</h2>';
		if ( null === $score ) {
			echo '<p class="af-big">&ndash;</p><p class="af-sub">' . esc_html__( 'Run a scan to get your score.', 'accessfix' ) . '</p>';
		} else {
			echo '<p class="af-big af-score-' . esc_attr( self::band( $score ) ) . '">' . (int) $score . '<span class="af-of"> / 100</span></p><p class="af-sub">' . esc_html( self::band_label( $score ) ) . '</p>';
		}
		echo '</section>';
		self::card( __( 'Open issues', 'accessfix' ), (string) $counts['open'], sprintf( /* translators: 1: critical, 2: serious */ __( '%1$d critical, %2$d serious', 'accessfix' ), $sev['critical'], $sev['serious'] ) );
		self::card( __( 'Fixed automatically', 'accessfix' ), (string) $counts['fixed'], __( 'recorded fixes applied at render time', 'accessfix' ) );
		self::card( __( 'Fixed manually / ignored', 'accessfix' ), $counts['fixed-manually'] . ' / ' . $counts['ignored'], __( 'resolved by editing / accepted with a reason', 'accessfix' ) );
		self::card( __( 'Pages scanned', 'accessfix' ), $scan ? (string) (int) $scan->pages_done : '0', $scan ? sprintf( /* translators: %s: date */ __( 'last scan %s', 'accessfix' ), get_date_from_gmt( $scan->finished_at, 'j M Y H:i' ) ) : __( 'never', 'accessfix' ) );
		echo '</div>';

		// Scan panel.
		echo '<section class="af-panel" aria-labelledby="af-h-scan"><h2 id="af-h-scan">' . esc_html__( 'Scan the site', 'accessfix' ) . '</h2>';
		echo '<p>' . esc_html__( 'Every published page, post and product is requested over HTTP and checked against WCAG 2.2. Automatic fixes are verified against the served HTML.', 'accessfix' ) . '</p>';
		echo '<p><button type="button" class="button button-primary" id="af-scan-btn">' . esc_html__( 'Scan now', 'accessfix' ) . '</button> ';
		echo '<span id="af-scan-status" class="af-scan-status" role="status" aria-live="polite"></span></p>';
		echo '<div class="af-progress" hidden><div class="af-progress__bar" id="af-progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" aria-label="' . esc_attr__( 'Scan progress', 'accessfix' ) . '"></div></div>';
		echo '</section>';

		// Trend + criteria.
		echo '<div class="af-two">';
		echo '<section class="af-panel" aria-labelledby="af-h-trend"><h2 id="af-h-trend">' . esc_html__( 'Trend over scans', 'accessfix' ) . '</h2>';
		self::trend_chart( $trend );
		echo '</section>';
		echo '<section class="af-panel" aria-labelledby="af-h-crit"><h2 id="af-h-crit">' . esc_html__( 'Open issues by WCAG criterion', 'accessfix' ) . '</h2>';
		if ( $crit ) {
			$max = max( wp_list_pluck( $crit, 'n' ) );
			echo '<ul class="af-bars">';
			foreach ( $crit as $r ) {
				$w = max( 3, round( 100 * $r->n / $max ) );
				echo '<li><a href="' . esc_url( admin_url( 'admin.php?page=accessfix-issues&criterion=' . rawurlencode( $r->criterion ) ) ) . '"><span class="af-bars__label">' . esc_html( AccessFix_Checks::sc_label( $r->criterion ) ) . '</span><span class="af-bars__track" aria-hidden="true"><span class="af-bars__fill" style="width:' . (int) $w . '%"></span></span><span class="af-bars__n">' . (int) $r->n . '</span></a></li>';
			}
			echo '</ul>';
		} else {
			echo '<p>' . esc_html( $scan ? __( 'No open issues. Nice. Remember that automated checks cover only part of WCAG.', 'accessfix' ) : __( 'No data yet.', 'accessfix' ) ) . '</p>';
		}
		echo '</section></div>';

		// Pages table.
		echo '<section class="af-panel" aria-labelledby="af-h-pages"><h2 id="af-h-pages">' . esc_html__( 'Score per page', 'accessfix' ) . '</h2>';
		if ( $pages ) {
			echo '<table class="widefat striped af-table"><thead><tr><th scope="col">' . esc_html__( 'Page', 'accessfix' ) . '</th><th scope="col">' . esc_html__( 'Score', 'accessfix' ) . '</th><th scope="col">' . esc_html__( 'Open', 'accessfix' ) . '</th><th scope="col">' . esc_html__( 'Auto-fixed', 'accessfix' ) . '</th><th scope="col">' . esc_html__( 'Actions', 'accessfix' ) . '</th></tr></thead><tbody>';
			foreach ( $pages as $p ) {
				echo '<tr><td><a href="' . esc_url( $p->url ) . '">' . esc_html( '' !== $p->title ? $p->title : $p->url ) . '</a></td>';
				if ( ! empty( $p->error ) ) {
					echo '<td colspan="3"><span class="af-pill af-pill--bad">' . esc_html__( 'Scan failed', 'accessfix' ) . '</span> ' . esc_html( $p->error ) . '</td>';
				} else {
					echo '<td><span class="af-pill af-pill--' . esc_attr( self::band( $p->score ) ) . '">' . (int) $p->score . '</span></td><td>' . (int) $p->open_count . '</td><td>' . (int) $p->fixed_count . '</td>';
				}
				echo '<td><a href="' . esc_url( admin_url( 'admin.php?page=accessfix-issues&post_id=' . (int) $p->post_id ) ) . '">' . esc_html__( 'Issues', 'accessfix' ) . '</a> | <button type="button" class="button-link af-rescan" data-post="' . (int) $p->post_id . '">' . esc_html__( 'Rescan', 'accessfix' ) . '</button></td></tr>';
			}
			echo '</tbody></table>';
		} else {
			echo '<p>' . esc_html__( 'No pages scanned yet.', 'accessfix' ) . '</p>';
		}
		echo '</section>';

		// EAA checklist.
		echo '<section class="af-panel" aria-labelledby="af-h-eaa"><h2 id="af-h-eaa">' . esc_html__( 'EAA readiness checklist', 'accessfix' ) . '</h2>';
		echo '<p>' . sprintf(
			/* translators: 1: done, 2: total */
			esc_html__( '%1$d of %2$d items complete. Items marked "automatic" are derived from scan data; the others are manual confirmations that only you can make.', 'accessfix' ),
			(int) $done,
			count( $list )
		) . '</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'af_save_eaa' );
		echo '<input type="hidden" name="action" value="af_save_eaa" /><ul class="af-checklist">';
		foreach ( $list as $it ) {
			echo '<li class="' . ( $it['done'] ? 'is-done' : '' ) . '">';
			if ( 'manual' === $it['type'] ) {
				echo '<label><input type="checkbox" name="eaa[' . esc_attr( $it['key'] ) . ']" value="1"' . checked( $it['done'], true, false ) . ' /> ' . esc_html( $it['label'] ) . '</label> <span class="af-tag">' . esc_html__( 'manual', 'accessfix' ) . '</span>';
			} else {
				echo '<span class="af-check" aria-hidden="true">' . ( $it['done'] ? '&#10003;' : '&#9675;' ) . '</span> <span class="screen-reader-text">' . esc_html( $it['done'] ? __( 'Done:', 'accessfix' ) : __( 'Not done:', 'accessfix' ) ) . '</span>' . esc_html( $it['label'] ) . ' <span class="af-tag">' . esc_html__( 'automatic', 'accessfix' ) . '</span>';
				if ( '' !== $it['detail'] ) {
					echo ' <span class="af-detail">' . esc_html( $it['detail'] ) . '</span>';
				}
			}
			echo '</li>';
		}
		echo '</ul><p><button type="submit" class="button">' . esc_html__( 'Save manual confirmations', 'accessfix' ) . '</button></p></form>';
		echo '<p class="description">' . esc_html__( 'This checklist is a planning aid, not legal advice. The European Accessibility Act (Directive (EU) 2019/882) has applied since 28 June 2025 to specified consumer products and services, including e-commerce; scope and exemptions depend on your business and country.', 'accessfix' ) . '</p>';
		echo '</section>';

		echo '<p class="af-footnote">' . esc_html__( 'Automated testing finds only a portion of accessibility problems. A score of 100 does not mean the site conforms to WCAG or any law.', 'accessfix' ) . '</p></div>';
	}

	/**
	 * Band name for a score.
	 *
	 * @param int $s Score.
	 * @return string
	 */
	public static function band( $s ) {
		return $s >= 90 ? 'good' : ( $s >= 70 ? 'fair' : 'bad' );
	}

	/**
	 * Band label.
	 *
	 * @param int $s Score.
	 * @return string
	 */
	public static function band_label( $s ) {
		return $s >= 90 ? __( 'Good: few automated findings', 'accessfix' ) : ( $s >= 70 ? __( 'Needs work', 'accessfix' ) : __( 'Poor: significant barriers found', 'accessfix' ) );
	}

	/**
	 * Stat card.
	 *
	 * @param string $title Title.
	 * @param string $value Value.
	 * @param string $sub   Sub text.
	 * @return void
	 */
	protected static function card( $title, $value, $sub ) {
		echo '<section class="af-card"><h2>' . esc_html( $title ) . '</h2><p class="af-big">' . esc_html( $value ) . '</p><p class="af-sub">' . esc_html( $sub ) . '</p></section>';
	}

	/**
	 * Inline SVG line chart with a table alternative.
	 *
	 * @param array $trend Scan rows.
	 * @return void
	 */
	protected static function trend_chart( $trend ) {
		if ( count( $trend ) < 1 ) {
			echo '<p>' . esc_html__( 'Run at least two scans to see a trend.', 'accessfix' ) . '</p>';
			return;
		}
		$w = 520; $h = 200; $l = 34; $r = 12; $t = 12; $b = 26;
		$n = count( $trend );
		$pts = array();
		foreach ( $trend as $i => $s ) {
			$x     = $l + ( $n > 1 ? ( $w - $l - $r ) * $i / ( $n - 1 ) : ( $w - $l - $r ) / 2 );
			$y     = $t + ( $h - $t - $b ) * ( 1 - $s->score / 100 );
			$pts[] = array( $x, $y, $s );
		}
		$poly = implode( ' ', array_map( function ( $p ) { return round( $p[0], 1 ) . ',' . round( $p[1], 1 ); }, $pts ) );
		$last = end( $trend );
		$first = reset( $trend );
		/* translators: 1: number of scans, 2: first score, 3: last score */
		$desc = sprintf( __( 'Line chart of the site score over %1$d scans, from %2$d to %3$d out of 100.', 'accessfix' ), $n, $first->score, $last->score );
		echo '<svg class="af-trend" viewBox="0 0 ' . (int) $w . ' ' . (int) $h . '" role="img" aria-label="' . esc_attr( $desc ) . '">';
		foreach ( array( 0, 50, 100 ) as $g ) {
			$y = $t + ( $h - $t - $b ) * ( 1 - $g / 100 );
			echo '<line x1="' . (int) $l . '" x2="' . (int) ( $w - $r ) . '" y1="' . esc_attr( round( $y, 1 ) ) . '" y2="' . esc_attr( round( $y, 1 ) ) . '" class="af-grid" /><text x="' . ( $l - 6 ) . '" y="' . esc_attr( round( $y + 4, 1 ) ) . '" text-anchor="end" class="af-axis">' . (int) $g . '</text>';
		}
		echo '<polyline fill="none" class="af-line" points="' . esc_attr( $poly ) . '" />';
		foreach ( $pts as $i => $p ) {
			echo '<circle cx="' . esc_attr( round( $p[0], 1 ) ) . '" cy="' . esc_attr( round( $p[1], 1 ) ) . '" r="4" class="af-dot"><title>' . esc_html( get_date_from_gmt( $p[2]->finished_at, 'j M Y' ) . ': ' . $p[2]->score ) . '</title></circle>';
		}
		echo '<text x="' . (int) $l . '" y="' . ( $h - 6 ) . '" class="af-axis">' . esc_html( get_date_from_gmt( $first->finished_at, 'j M' ) ) . '</text>';
		if ( $n > 1 ) {
			echo '<text x="' . (int) ( $w - $r ) . '" y="' . ( $h - 6 ) . '" text-anchor="end" class="af-axis">' . esc_html( get_date_from_gmt( $last->finished_at, 'j M' ) ) . '</text>';
		}
		echo '</svg>';
		echo '<details class="af-details"><summary>' . esc_html__( 'Show data table', 'accessfix' ) . '</summary><table class="widefat striped"><thead><tr><th scope="col">' . esc_html__( 'Scan finished', 'accessfix' ) . '</th><th scope="col">' . esc_html__( 'Score', 'accessfix' ) . '</th><th scope="col">' . esc_html__( 'Open issues', 'accessfix' ) . '</th><th scope="col">' . esc_html__( 'Auto-fixed', 'accessfix' ) . '</th></tr></thead><tbody>';
		foreach ( array_reverse( $trend ) as $s ) {
			echo '<tr><td>' . esc_html( get_date_from_gmt( $s->finished_at, 'j M Y H:i' ) ) . '</td><td>' . (int) $s->score . '</td><td>' . (int) $s->open_issues . '</td><td>' . (int) $s->fixed_issues . '</td></tr>';
		}
		echo '</tbody></table></details>';
	}
}
