<?php
/**
 * Settings storage and sanitising.
 *
 * @package AccessFix
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings helper.
 */
class AccessFix_Settings {

	const OPTION = 'af_settings';

	/**
	 * Toggle keys for the fixers.
	 *
	 * @return array key => label.
	 */
	public static function fixer_labels() {
		return array(
			'fix_lang'      => __( 'Add missing lang attribute to <html>', 'accessfix' ),
			'fix_title'     => __( 'Add a missing or empty <title>', 'accessfix' ),
			'fix_viewport'  => __( 'Allow pinch-zoom (strip user-scalable=no / maximum-scale from the viewport meta)', 'accessfix' ),
			'fix_main'      => __( 'Add role="main" to the main content container when the theme has no <main>', 'accessfix' ),
			'fix_skip'      => __( 'Add a "Skip to main content" link when none exists', 'accessfix' ),
			'fix_alt'       => __( 'Fill missing image alt text from the Media Library; apply "decorative" flags', 'accessfix' ),
			'fix_iconlinks' => __( 'Add aria-label to icon-only links (uses the map below plus common social/contact links)', 'accessfix' ),
			'fix_iframes'   => __( 'Add a title to iframes that have none', 'accessfix' ),
			'fix_newwindow' => __( 'Warn about links that open in a new tab and add rel="noopener noreferrer"', 'accessfix' ),
			'fix_tables'    => __( 'Turn a bold first row of a data table into proper column headers (<th scope="col">)', 'accessfix' ),
			'fix_dupids'    => __( 'Make duplicate id attributes unique (the first one is kept)', 'accessfix' ),
			'fix_autoplay'  => __( 'Stop audio/video that autoplays with sound (removes autoplay, adds controls)', 'accessfix' ),
			'fix_focus'     => __( 'Add a visible keyboard focus style (:focus-visible)', 'accessfix' ),
			'fix_motion'    => __( 'Respect prefers-reduced-motion (shortens animations and smooth scrolling)', 'accessfix' ),
		);
	}

	/**
	 * Default values.
	 *
	 * @return array
	 */
	public static function defaults() {
		$d = array(
			'focus_color'    => '#005fcc',
			'icon_map'       => "href:facebook.com = Facebook\nhref:instagram.com = Instagram\nclass:fa-linkedin = LinkedIn",
			'iframe_map'     => "youtube.com = YouTube video player\nvimeo.com = Vimeo video player",
			'post_types'     => array( 'post', 'page', 'product' ),
			'max_pages'      => 300,
			'cron_freq'      => 'off',
			'email_enabled'  => 0,
			'email_to'       => '',
			'ai_enabled'     => 0,
			'ai_endpoint'    => 'https://api.openai.com/v1/chat/completions',
			'ai_key'         => '',
			'ai_model'       => 'gpt-4o-mini',
			'ai_prompt'      => 'Write concise alt text (max 125 characters) describing this image for a blind visitor. Do not start with "image of". Reply with the alt text only.',
			'scan_auth'      => '',
			'sslverify'      => 1,
			'delete_data'    => 0,
		);
		foreach ( array_keys( self::fixer_labels() ) as $k ) {
			$d[ $k ] = 1;
		}
		return $d;
	}

	/**
	 * All settings merged with defaults.
	 *
	 * @return array
	 */
	public static function all() {
		$saved = get_option( self::OPTION, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		return array_merge( self::defaults(), $saved );
	}

	/**
	 * Get one setting.
	 *
	 * @param string $key     Key.
	 * @param mixed  $default Fallback.
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		$all = self::all();
		return isset( $all[ $key ] ) ? $all[ $key ] : $default;
	}

	/**
	 * Sanitise a settings array from a form.
	 *
	 * @param array $in Raw input (already unslashed).
	 * @return array
	 */
	public static function sanitize( $in ) {
		$old = self::all();
		$out = array();
		foreach ( array_keys( self::fixer_labels() ) as $k ) {
			$out[ $k ] = empty( $in[ $k ] ) ? 0 : 1;
		}
		$color               = isset( $in['focus_color'] ) ? sanitize_hex_color( $in['focus_color'] ) : '';
		$out['focus_color']  = $color ? $color : '#005fcc';
		$out['icon_map']     = isset( $in['icon_map'] ) ? sanitize_textarea_field( $in['icon_map'] ) : '';
		$out['iframe_map']   = isset( $in['iframe_map'] ) ? sanitize_textarea_field( $in['iframe_map'] ) : '';
		$types               = isset( $in['post_types'] ) ? (array) $in['post_types'] : array();
		$types               = array_values( array_intersect( array_map( 'sanitize_key', $types ), get_post_types( array( 'public' => true ) ) ) );
		$out['post_types']   = $types ? $types : array( 'post', 'page' );
		$out['max_pages']    = isset( $in['max_pages'] ) ? max( 1, min( 5000, absint( $in['max_pages'] ) ) ) : 300;
		$freq                = isset( $in['cron_freq'] ) ? sanitize_key( $in['cron_freq'] ) : 'off';
		$out['cron_freq']    = in_array( $freq, array( 'off', 'daily', 'weekly' ), true ) ? $freq : 'off';
		$out['email_enabled'] = empty( $in['email_enabled'] ) ? 0 : 1;
		$out['email_to']     = isset( $in['email_to'] ) ? sanitize_text_field( $in['email_to'] ) : '';
		$emails              = array_filter( array_map( 'sanitize_email', array_map( 'trim', explode( ',', $out['email_to'] ) ) ) );
		$out['email_to']     = implode( ', ', $emails );
		$out['ai_enabled']   = empty( $in['ai_enabled'] ) ? 0 : 1;
		$out['ai_endpoint']  = isset( $in['ai_endpoint'] ) ? esc_url_raw( trim( $in['ai_endpoint'] ), array( 'https', 'http' ) ) : '';
		// Keep the stored key when the masked placeholder is posted back.
		$key = isset( $in['ai_key'] ) ? trim( sanitize_text_field( $in['ai_key'] ) ) : '';
		if ( '' !== $key && false !== strpos( $key, '•' ) ) {
			$key = $old['ai_key'];
		}
		$out['ai_key']       = $key;
		$out['ai_model']     = isset( $in['ai_model'] ) ? sanitize_text_field( $in['ai_model'] ) : '';
		$out['ai_prompt']    = isset( $in['ai_prompt'] ) ? sanitize_textarea_field( $in['ai_prompt'] ) : '';
		$out['scan_auth']    = isset( $in['scan_auth'] ) ? sanitize_text_field( $in['scan_auth'] ) : '';
		$out['sslverify']    = empty( $in['sslverify'] ) ? 0 : 1;
		$out['delete_data']  = empty( $in['delete_data'] ) ? 0 : 1;
		return $out;
	}

	/**
	 * Parse "key = value" lines.
	 *
	 * @param string $text Multi-line text.
	 * @return array list of [key, value].
	 */
	public static function parse_map( $text ) {
		$rows = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || '#' === $line[0] || false === strpos( $line, '=' ) ) {
				continue;
			}
			list( $k, $v ) = array_map( 'trim', explode( '=', $line, 2 ) );
			if ( '' !== $k && '' !== $v ) {
				$rows[] = array( $k, $v );
			}
		}
		return $rows;
	}
}
