<?php
/**
 * Media Library alt-text tools: bulk editor, decorative flag, optional AI suggestions.
 *
 * @package AccessFix
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Media tools.
 */
class AccessFix_Media {

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_post_af_save_alt', array( __CLASS__, 'handle_save' ) );
	}

	/**
	 * Posts that use an attachment.
	 *
	 * @param int $id Attachment id.
	 * @return array List of WP_Post-like objects (ID, post_title, post_type, post_status).
	 */
	public static function used_in( $id ) {
		global $wpdb;
		$id   = (int) $id;
		$file = get_post_meta( $id, '_wp_attached_file', true );
		$like = array(
			'%' . $wpdb->esc_like( 'wp-image-' . $id . '"' ) . '%',
			'%' . $wpdb->esc_like( 'wp-image-' . $id . ' ' ) . '%',
			'%' . $wpdb->esc_like( '"id":' . $id . ',' ) . '%',
			'%' . $wpdb->esc_like( '"id":' . $id . '}' ) . '%',
		);
		$sql  = "post_content LIKE %s OR post_content LIKE %s OR post_content LIKE %s OR post_content LIKE %s";
		if ( $file ) {
			$base   = pathinfo( $file, PATHINFO_FILENAME );
			$like[] = '%' . $wpdb->esc_like( '/' . $base ) . '%';
			$sql   .= ' OR post_content LIKE %s';
		}
		$like[] = $id;
		$q      = "SELECT ID, post_title, post_type, post_status FROM {$wpdb->posts}
			WHERE post_type NOT IN ('attachment','revision','nav_menu_item','customize_changeset','oembed_cache')
			AND post_status IN ('publish','draft','pending','private','future')
			AND ( ($sql) OR ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_thumbnail_id' AND meta_value = %d) )
			ORDER BY post_modified DESC LIMIT 6";
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		return (array) $wpdb->get_results( $wpdb->prepare( $q, $like ) );
	}

	/**
	 * Query attachments for the editor.
	 *
	 * @param string $view   all|missing|decorative|filled.
	 * @param string $search Search.
	 * @param int    $paged  Page.
	 * @return WP_Query
	 */
	public static function query( $view, $search, $paged ) {
		$args = array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'post_mime_type' => 'image',
			'posts_per_page' => 20,
			'paged'          => max( 1, (int) $paged ),
			'orderby'        => 'date',
			'order'          => 'DESC',
		);
		if ( '' !== $search ) {
			$args['s'] = $search;
		}
		$no_alt = array(
			'relation' => 'OR',
			array( 'key' => '_wp_attachment_image_alt', 'compare' => 'NOT EXISTS' ),
			array( 'key' => '_wp_attachment_image_alt', 'value' => '', 'compare' => '=' ),
		);
		$not_dec = array(
			'relation' => 'OR',
			array( 'key' => '_af_decorative', 'compare' => 'NOT EXISTS' ),
			array( 'key' => '_af_decorative', 'value' => '1', 'compare' => '!=' ),
		);
		if ( 'missing' === $view ) {
			$args['meta_query'] = array( 'relation' => 'AND', $no_alt, $not_dec ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		} elseif ( 'decorative' === $view ) {
			$args['meta_query'] = array( array( 'key' => '_af_decorative', 'value' => '1' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		} elseif ( 'filled' === $view ) {
			$args['meta_query'] = array( array( 'key' => '_wp_attachment_image_alt', 'value' => '', 'compare' => '!=' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		}
		return new WP_Query( $args );
	}

	/**
	 * Count images without alt (and not decorative).
	 *
	 * @return array total, missing, decorative.
	 */
	public static function coverage() {
		$total = (int) self::query( 'all', '', 1 )->found_posts;
		$miss  = (int) self::query( 'missing', '', 1 )->found_posts;
		$dec   = (int) self::query( 'decorative', '', 1 )->found_posts;
		return array( 'total' => $total, 'missing' => $miss, 'decorative' => $dec );
	}

	/**
	 * Save the bulk editor.
	 *
	 * @return void
	 */
	public static function handle_save() {
		if ( ! current_user_can( AccessFix_Admin::cap() ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'accessfix' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'af_save_alt' );
		$ids = isset( $_POST['ids'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['ids'] ) ) : array();
		$alt = isset( $_POST['alt'] ) && is_array( $_POST['alt'] ) ? wp_unslash( $_POST['alt'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitised per item below.
		$dec = isset( $_POST['dec'] ) && is_array( $_POST['dec'] ) ? array_map( 'absint', array_keys( wp_unslash( $_POST['dec'] ) ) ) : array();
		$n   = 0;
		foreach ( $ids as $id ) {
			if ( ! $id || 'attachment' !== get_post_type( $id ) || ! current_user_can( 'edit_post', $id ) ) {
				continue;
			}
			$old_alt = (string) get_post_meta( $id, '_wp_attachment_image_alt', true );
			$old_dec = '1' === (string) get_post_meta( $id, '_af_decorative', true );
			$new_dec = in_array( $id, $dec, true );
			$new_alt = isset( $alt[ $id ] ) ? trim( sanitize_text_field( $alt[ $id ] ) ) : $old_alt;
			if ( $new_dec ) {
				$new_alt = '';
			}
			$url = (string) wp_get_attachment_url( $id );
			if ( $new_dec !== $old_dec ) {
				if ( $new_dec ) {
					update_post_meta( $id, '_af_decorative', '1' );
				} else {
					delete_post_meta( $id, '_af_decorative' );
				}
				AccessFix_Audit::log(
					array(
						'post_id'   => $id,
						'url'       => $url,
						'check_id'  => 'img-alt-missing',
						'criterion' => '1.1.1',
						'action'    => 'manually-fixed',
						'reason'    => $new_dec ? __( 'Image marked as decorative (alt="").', 'accessfix' ) : __( 'Decorative flag removed.', 'accessfix' ),
						'before'    => $old_dec ? 'decorative' : 'alt="' . $old_alt . '"',
						'after'     => $new_dec ? 'alt=""' : 'not decorative',
					)
				);
				$n++;
			}
			if ( $new_alt !== $old_alt ) {
				update_post_meta( $id, '_wp_attachment_image_alt', wp_slash( $new_alt ) );
				if ( ! $new_dec ) {
					AccessFix_Audit::log(
						array(
							'post_id'   => $id,
							'url'       => $url,
							'check_id'  => 'img-alt-missing',
							'criterion' => '1.1.1',
							'action'    => 'manually-fixed',
							'reason'    => __( 'Alt text edited in the AccessFix bulk editor.', 'accessfix' ),
							'before'    => 'alt="' . $old_alt . '"',
							'after'     => 'alt="' . $new_alt . '"',
						)
					);
				}
				$n++;
			}
		}
		$back = wp_get_referer() ? wp_get_referer() : admin_url( 'admin.php?page=accessfix-alt' );
		wp_safe_redirect( add_query_arg( 'af_saved', $n, remove_query_arg( 'af_saved', $back ) ) );
		exit;
	}

	/**
	 * Generate suggested alt text. Never saves anything.
	 *
	 * @param int $id Attachment id.
	 * @return string|WP_Error
	 */
	public static function suggest( $id ) {
		$id = (int) $id;
		if ( 'attachment' !== get_post_type( $id ) ) {
			return new WP_Error( 'af_bad_id', __( 'Not an attachment.', 'accessfix' ) );
		}
		$custom = apply_filters( 'accessfix_generate_alt', null, $id );
		if ( is_string( $custom ) && '' !== trim( $custom ) ) {
			return self::tidy( $custom );
		}
		$s = AccessFix_Settings::all();
		if ( empty( $s['ai_enabled'] ) || '' === $s['ai_key'] || '' === $s['ai_endpoint'] ) {
			return new WP_Error( 'af_ai_off', __( 'AI suggestions are not configured. Add an API key under AccessFix > Settings, or edit the text yourself.', 'accessfix' ) );
		}
		$img = self::image_payload( $id );
		if ( ! $img ) {
			return new WP_Error( 'af_no_file', __( 'The image file could not be read.', 'accessfix' ) );
		}
		$body = array(
			'model'      => $s['ai_model'],
			'max_tokens' => 120,
			'messages'   => array(
				array(
					'role'    => 'user',
					'content' => array(
						array( 'type' => 'text', 'text' => $s['ai_prompt'] ),
						array( 'type' => 'image_url', 'image_url' => array( 'url' => $img ) ),
					),
				),
			),
		);
		$r = wp_remote_post(
			$s['ai_endpoint'],
			array(
				'timeout' => 45,
				'headers' => array(
					'Authorization' => 'Bearer ' . $s['ai_key'],
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( $body ),
			)
		);
		if ( is_wp_error( $r ) ) {
			return new WP_Error( 'af_ai_http', __( 'The AI service could not be reached.', 'accessfix' ) . ' ' . $r->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $r );
		$j    = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( $code < 200 || $code >= 300 || ! is_array( $j ) ) {
			$msg = is_array( $j ) && isset( $j['error']['message'] ) ? (string) $j['error']['message'] : '';
			/* translators: 1: HTTP code, 2: message */
			return new WP_Error( 'af_ai_resp', sprintf( __( 'The AI service answered with HTTP %1$d. %2$s', 'accessfix' ), $code, wp_strip_all_tags( $msg ) ) );
		}
		$text = isset( $j['choices'][0]['message']['content'] ) ? (string) $j['choices'][0]['message']['content'] : '';
		if ( '' === trim( $text ) ) {
			return new WP_Error( 'af_ai_empty', __( 'The AI service returned no text.', 'accessfix' ) );
		}
		return self::tidy( $text );
	}

	/**
	 * Clean a suggestion.
	 *
	 * @param string $t Text.
	 * @return string
	 */
	protected static function tidy( $t ) {
		$t = trim( wp_strip_all_tags( $t ), " \t\n\r\0\x0B\"'" );
		$t = preg_replace( '/^(image|picture|photo) of\s+/i', '', $t );
		if ( function_exists( 'mb_substr' ) && mb_strlen( $t ) > 125 ) {
			$t = rtrim( mb_substr( $t, 0, 122 ) ) . '...';
		}
		return $t;
	}

	/**
	 * data: URL (preferred, works on private sites) for the image.
	 *
	 * @param int $id Attachment id.
	 * @return string
	 */
	protected static function image_payload( $id ) {
		$file = get_attached_file( $id );
		$info = image_get_intermediate_size( $id, 'large' );
		if ( $info && $file ) {
			$cand = path_join( dirname( $file ), $info['file'] );
			if ( file_exists( $cand ) ) {
				$file = $cand;
			}
		}
		if ( $file && file_exists( $file ) && filesize( $file ) < 4 * MB_IN_BYTES ) {
			$mime = wp_check_filetype( $file )['type'];
			if ( $mime && 0 === strpos( $mime, 'image/' ) && 'image/svg+xml' !== $mime ) {
				return 'data:' . $mime . ';base64,' . base64_encode( file_get_contents( $file ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents, WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
			}
		}
		return (string) wp_get_attachment_url( $id );
	}
}
