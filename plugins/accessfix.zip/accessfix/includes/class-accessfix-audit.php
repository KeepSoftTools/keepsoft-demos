<?php
/**
 * Append-only audit log, CSV export and PDF evidence report.
 *
 * There is intentionally no update or delete method in this class: rows can
 * only be added. The table is removed only by uninstall.php when the site owner
 * has opted in to data removal.
 *
 * @package AccessFix
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Audit log.
 */
class AccessFix_Audit {

	/**
	 * Allowed actions.
	 *
	 * @return array slug => label.
	 */
	public static function actions() {
		return array(
			'detected'      => __( 'Detected', 'accessfix' ),
			'auto-fixed'    => __( 'Auto-fixed', 'accessfix' ),
			'manually-fixed' => __( 'Manually fixed', 'accessfix' ),
			'ignored'       => __( 'Ignored', 'accessfix' ),
			'reopened'      => __( 'Re-opened', 'accessfix' ),
		);
	}

	/**
	 * Append a row.
	 *
	 * @param array $a post_id, url, check_id, criterion, action, reason, before, after, user_id.
	 * @return int|false Insert id.
	 */
	public static function log( $a ) {
		global $wpdb;
		$a       = wp_parse_args(
			$a,
			array(
				'post_id'   => 0,
				'url'       => '',
				'check_id'  => '',
				'criterion' => '',
				'action'    => 'detected',
				'reason'    => '',
				'before'    => '',
				'after'     => '',
				'user_id'   => null,
			)
		);
		$user_id = null === $a['user_id'] ? get_current_user_id() : (int) $a['user_id'];
		$login   = '';
		if ( $user_id ) {
			$u     = get_userdata( $user_id );
			$login = $u ? $u->user_login : '';
		} else {
			$login = 'system';
		}
		if ( ! isset( self::actions()[ $a['action'] ] ) ) {
			return false;
		}
		$ok = $wpdb->insert(
			AccessFix_Install::table( 'audit' ),
			array(
				'logged_at'   => current_time( 'mysql', true ),
				'user_id'     => $user_id,
				'user_login'  => $login,
				'post_id'     => (int) $a['post_id'],
				'url'         => substr( (string) $a['url'], 0, 500 ),
				'check_id'    => sanitize_key( $a['check_id'] ),
				'criterion'   => preg_replace( '/[^0-9.]/', '', (string) $a['criterion'] ),
				'action'      => $a['action'],
				'reason'      => (string) $a['reason'],
				'before_html' => (string) $a['before'],
				'after_html'  => (string) $a['after'],
			)
		);
		return $ok ? (int) $wpdb->insert_id : false;
	}

	/**
	 * Build a WHERE clause from filters.
	 *
	 * @param array $f action, criterion, search, from, to.
	 * @return array [sql, args].
	 */
	protected static function where( $f ) {
		global $wpdb;
		$w    = array( '1=1' );
		$args = array();
		if ( ! empty( $f['action'] ) ) {
			$w[]    = 'action = %s';
			$args[] = $f['action'];
		}
		if ( ! empty( $f['criterion'] ) ) {
			$w[]    = 'criterion = %s';
			$args[] = $f['criterion'];
		}
		if ( ! empty( $f['search'] ) ) {
			$like   = '%' . $wpdb->esc_like( $f['search'] ) . '%';
			$w[]    = '(url LIKE %s OR reason LIKE %s OR before_html LIKE %s OR after_html LIKE %s)';
			$args   = array_merge( $args, array( $like, $like, $like, $like ) );
		}
		if ( ! empty( $f['from'] ) ) {
			$w[]    = 'logged_at >= %s';
			$args[] = $f['from'] . ' 00:00:00';
		}
		if ( ! empty( $f['to'] ) ) {
			$w[]    = 'logged_at <= %s';
			$args[] = $f['to'] . ' 23:59:59';
		}
		return array( implode( ' AND ', $w ), $args );
	}

	/**
	 * Query rows.
	 *
	 * @param array $f      Filters.
	 * @param int   $limit  Limit.
	 * @param int   $offset Offset.
	 * @return array
	 */
	public static function query( $f = array(), $limit = 50, $offset = 0 ) {
		global $wpdb;
		$t                 = AccessFix_Install::table( 'audit' );
		list( $where, $args ) = self::where( $f );
		$args[]            = (int) $limit;
		$args[]            = (int) $offset;
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $t WHERE $where ORDER BY id DESC LIMIT %d OFFSET %d", $args ) );
	}

	/**
	 * Count rows.
	 *
	 * @param array $f Filters.
	 * @return int
	 */
	public static function count( $f = array() ) {
		global $wpdb;
		$t                 = AccessFix_Install::table( 'audit' );
		list( $where, $args ) = self::where( $f );
		$sql               = "SELECT COUNT(*) FROM $t WHERE $where";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return (int) ( $args ? $wpdb->get_var( $wpdb->prepare( $sql, $args ) ) : $wpdb->get_var( $sql ) );
	}

	/**
	 * Neutralise spreadsheet formulas.
	 *
	 * @param string $v Cell.
	 * @return string
	 */
	public static function csv_cell( $v ) {
		$v = (string) $v;
		if ( '' !== $v && in_array( $v[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) ) {
			$v = "'" . $v;
		}
		return $v;
	}

	/**
	 * Stream a CSV and exit.
	 *
	 * @param string $type audit|issues.
	 * @param array  $f    Filters (audit only).
	 * @return void
	 */
	public static function export_csv( $type, $f = array() ) {
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="accessfix-' . $type . '-' . gmdate( 'Ymd-His' ) . '.csv"' );
		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
		if ( 'audit' === $type ) {
			fputcsv( $out, array( 'id', 'timestamp_utc', 'user', 'post_id', 'page_url', 'check', 'wcag_criterion', 'action', 'reason', 'before', 'after' ) );
			$offset = 0;
			do {
				$rows = self::query( $f, 500, $offset );
				foreach ( $rows as $r ) {
					fputcsv( $out, array_map( array( __CLASS__, 'csv_cell' ), array( $r->id, $r->logged_at, $r->user_login, $r->post_id, $r->url, $r->check_id, $r->criterion, $r->action, $r->reason, $r->before_html, $r->after_html ) ) );
				}
				$offset += 500;
			} while ( count( $rows ) === 500 );
		} else {
			global $wpdb;
			$t = AccessFix_Install::table( 'issues' );
			fputcsv( $out, array( 'id', 'status', 'severity', 'wcag_criterion', 'check', 'page_url', 'selector', 'message', 'snippet', 'first_seen_utc', 'last_seen_utc', 'ignore_reason' ) );
			$rows = $wpdb->get_results( "SELECT * FROM $t ORDER BY status, criterion, id" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			foreach ( $rows as $r ) {
				fputcsv( $out, array_map( array( __CLASS__, 'csv_cell' ), array( $r->id, $r->status, $r->severity, $r->criterion, $r->check_id, $r->url, $r->selector, $r->message, $r->snippet, $r->first_seen, $r->last_seen, $r->ignore_reason ) ) );
			}
		}
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		exit;
	}

	/**
	 * Build the evidence report PDF.
	 *
	 * @return string PDF bytes.
	 */
	public static function pdf_report() {
		global $wpdb;
		$issues = AccessFix_Install::table( 'issues' );
		$site   = html_entity_decode( get_bloginfo( 'name' ), ENT_QUOTES, 'UTF-8' );
		$pdf    = new AccessFix_PDF( array( 'title' => 'Accessibility Evidence Report - ' . $site ) );
		$pdf->footer = 'Accessibility Evidence Report - ' . $site . ' - generated by AccessFix ' . AF_VERSION;

		// Header band.
		$pdf->rect( 0, 0, AccessFix_PDF::W, 92, '#0b3d6b' );
		$pdf->text_at( 46, 44, 'Accessibility Evidence Report', 22, true, '#ffffff' );
		$pdf->text_at( 46, 64, $site . '  -  ' . home_url(), 10, false, '#dbe7f3' );
		$pdf->text_at( 46, 80, 'Generated ' . wp_date( 'j F Y, H:i T' ) . '  -  Target: WCAG 2.2 Level AA', 9, false, '#dbe7f3' );
		$pdf->y = 112;

		$counts = array();
		foreach ( (array) $wpdb->get_results( "SELECT status, COUNT(*) AS n FROM $issues GROUP BY status" ) as $r ) { // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$counts[ $r->status ] = (int) $r->n;
		}
		$score = AccessFix_Dashboard::site_score();
		$scan  = AccessFix_Dashboard::last_scan();

		$pdf->h2( '1. Summary' );
		$pdf->p( sprintf( 'Site accessibility score: %s / 100. Pages scanned in the last scan: %d. Last scan: %s.', null === $score ? 'n/a' : $score, $scan ? (int) $scan->pages_done : 0, $scan && $scan->finished_at ? get_date_from_gmt( $scan->finished_at, 'j F Y, H:i' ) : 'never' ), 10 );
		$pdf->table(
			array( 'Status', 'Issues' ),
			array(
				array( 'Open (not yet fixed)', (string) ( isset( $counts['open'] ) ? $counts['open'] : 0 ) ),
				array( 'Fixed automatically at render time', (string) ( isset( $counts['fixed'] ) ? $counts['fixed'] : 0 ) ),
				array( 'Fixed manually (no longer detected)', (string) ( isset( $counts['fixed-manually'] ) ? $counts['fixed-manually'] : 0 ) ),
				array( 'Ignored with a recorded reason', (string) ( isset( $counts['ignored'] ) ? $counts['ignored'] : 0 ) ),
			),
			array( 300, 195 ),
			9
		);

		$pdf->h2( '2. Scope and method' );
		$pdf->p( 'The scanner requested each published page over HTTP, parsed the rendered HTML and ran automated checks mapped to WCAG 2.2 success criteria. Automated testing detects only a subset of accessibility problems; many criteria (for example meaningful alt text quality, keyboard operability of custom widgets, captions, reading order and cognitive load) need human testing. Colour contrast is evaluated only where colours can be derived from inline styles and simple CSS rules.', 9 );
		$pdf->p( 'Automatic fixes are applied to the HTML as it is served and are recorded in the audit log. They do not change stored content, so removing the plugin removes the fixes.', 9 );

		$pdf->h2( '3. Open issues by WCAG criterion' );
		$rows = array();
		$q    = $wpdb->get_results( "SELECT criterion, check_id, severity, COUNT(*) AS n, COUNT(DISTINCT post_id) AS pages FROM $issues WHERE status = 'open' GROUP BY criterion, check_id, severity ORDER BY criterion, n DESC" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		foreach ( (array) $q as $r ) {
			$c      = AccessFix_Checks::get( $r->check_id );
			$rows[] = array( AccessFix_Checks::sc_label( $r->criterion ), $c ? $c['title'] : $r->check_id, ucfirst( $r->severity ), (string) $r->n, (string) $r->pages );
		}
		if ( $rows ) {
			$pdf->table( array( 'Criterion', 'Problem', 'Severity', 'Issues', 'Pages' ), $rows, array( 135, 215, 55, 45, 45 ), 8 );
		} else {
			$pdf->p( 'No open issues were recorded by the last scan.', 9 );
		}

		$pdf->h2( '4. Fixes applied at render time' );
		$rows = array();
		$q    = $wpdb->get_results( "SELECT criterion, check_id, COUNT(*) AS n, COUNT(DISTINCT post_id) AS pages FROM $issues WHERE status = 'fixed' GROUP BY criterion, check_id ORDER BY criterion, n DESC" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		foreach ( (array) $q as $r ) {
			$c      = AccessFix_Checks::get( $r->check_id );
			$rows[] = array( AccessFix_Checks::sc_label( $r->criterion ), $c ? $c['title'] : $r->check_id, (string) $r->n, (string) $r->pages );
		}
		if ( $rows ) {
			$pdf->table( array( 'Criterion', 'Problem fixed', 'Times', 'Pages' ), $rows, array( 150, 245, 50, 50 ), 8 );
		} else {
			$pdf->p( 'No automatic fixes are currently recorded.', 9 );
		}

		$pdf->h2( '5. Audit log (most recent 150 entries)' );
		$rows = array();
		foreach ( self::query( array(), 150, 0 ) as $r ) {
			$what   = $r->reason;
			if ( '' === $what && '' !== $r->after_html ) {
				$what = 'After: ' . $r->after_html;
			}
			if ( '' === $what ) {
				$what = $r->before_html;
			}
			$rows[] = array( get_date_from_gmt( $r->logged_at, 'Y-m-d H:i' ), $r->action, $r->criterion, preg_replace( '#^https?://#', '', $r->url ), $r->user_login, $what );
		}
		if ( $rows ) {
			$pdf->table( array( 'Time', 'Action', 'SC', 'Page', 'By', 'Detail' ), $rows, array( 62, 52, 28, 100, 40, 213 ), 7 );
		} else {
			$pdf->p( 'The audit log is empty.', 9 );
		}
		$pdf->p( 'The complete log, including before/after snippets, is available as a CSV export from the AccessFix admin screen.', 8, false, '#646970' );

		$pdf->h2( '6. Important notice' );
		$pdf->p( 'This report documents the results of automated checks and the actions taken by the site operator. It is evidence of effort and process, not a certificate or a guarantee of conformance with WCAG 2.2, EN 301 549, the European Accessibility Act or any other law. Legal compliance depends on your jurisdiction, your content and a full manual evaluation.', 9 );
		return apply_filters( 'accessfix_pdf_report', $pdf->output() );
	}
}
