<?php
/**
 * Render-time fixers.
 *
 * These are NOT an overlay: no JavaScript runs in the visitor's browser and no
 * widget is injected. The HTML that WordPress produces is corrected on the
 * server before it is sent, every change is recorded (in scan mode), and the
 * scanner verifies the result by re-reading the served HTML.
 *
 * @package AccessFix
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Fixers.
 */
class AccessFix_Fixers {

	/** @var array Fix records collected during this request. */
	protected static $fixes = array();
	/** @var array Settings snapshot. */
	protected static $s = array();
	/** @var bool Scan mode (signed request from the scanner). */
	protected static $scan_mode = false;
	/** @var array Used ids. */
	protected static $ids = array();
	/** @var int Attachment lookups by URL done this request. */
	protected static $lookups = 0;

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'start' ), 0 );
		add_action( 'wp_head', array( __CLASS__, 'print_css' ), 99 );
	}

	/**
	 * Is this request a signed scanner request?
	 *
	 * @return bool
	 */
	public static function is_scan_request() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Signed HMAC token, verified below.
		if ( empty( $_GET['accessfix_scan'] ) || ! is_string( $_GET['accessfix_scan'] ) ) {
			return false;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return AccessFix_Runner::token_valid( sanitize_text_field( wp_unslash( $_GET['accessfix_scan'] ) ) );
	}

	/**
	 * Should fixers run for this request?
	 *
	 * @return bool
	 */
	protected static function enabled() {
		if ( is_admin() || is_feed() || is_robots() || is_trackback() || is_embed() || ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return false;
		}
		if ( function_exists( 'is_customize_preview' ) && is_customize_preview() ) {
			return false;
		}
		return (bool) apply_filters( 'accessfix_apply_fixes', true );
	}

	/**
	 * Start output buffering.
	 *
	 * @return void
	 */
	public static function start() {
		if ( ! self::enabled() ) {
			return;
		}
		self::$scan_mode = self::is_scan_request();
		if ( self::$scan_mode ) {
			nocache_headers();
			header( 'X-Robots-Tag: noindex, nofollow' );
			if ( ! defined( 'DONOTCACHEPAGE' ) ) {
				define( 'DONOTCACHEPAGE', true );
			}
		}
		ob_start( array( __CLASS__, 'process' ) );
	}

	/**
	 * Buffer callback.
	 *
	 * @param string $html Buffer.
	 * @return string
	 */
	public static function process( $html ) {
		if ( strlen( $html ) < 30 || false === stripos( $html, '<html' ) ) {
			return $html;
		}
		foreach ( headers_list() as $h ) {
			if ( 0 === stripos( $h, 'content-type:' ) && false === stripos( $h, 'html' ) ) {
				return $html;
			}
		}
		try {
			self::$s     = AccessFix_Settings::all();
			self::$fixes = array();
			self::$ids   = array();
			$out         = self::apply( $html );
		} catch ( \Throwable $e ) {
			return $html;
		}
		if ( self::$scan_mode ) {
			$out .= '<!--af-fixes:' . base64_encode( wp_json_encode( array_slice( self::$fixes, 0, 400 ) ) ) . '-->'; // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
		}
		return $out;
	}

	/**
	 * Run all fixers on an HTML document (public so tests and developers can call it).
	 *
	 * @param string $html Document.
	 * @param array  $s    Optional settings override.
	 * @return string
	 */
	public static function apply( $html, $s = null ) {
		if ( null !== $s ) {
			self::$s = array_merge( AccessFix_Settings::all(), $s );
		} elseif ( ! self::$s ) {
			self::$s = AccessFix_Settings::all();
		}
		$s = self::$s;

		if ( ! empty( $s['fix_lang'] ) ) {
			$html = self::fix_lang( $html );
		}
		if ( ! empty( $s['fix_title'] ) ) {
			$html = self::fix_title( $html );
		}
		if ( ! empty( $s['fix_viewport'] ) ) {
			$html = self::fix_viewport( $html );
		}
		if ( ! empty( $s['fix_main'] ) ) {
			$html = self::fix_main( $html );
		}
		if ( ! empty( $s['fix_skip'] ) ) {
			$html = self::fix_skip( $html );
		}
		if ( ! empty( $s['fix_dupids'] ) ) {
			preg_match_all( '/\sid\s*=\s*(?:"([^"]*)"|\'([^\']*)\')/i', $html, $m );
			foreach ( array_merge( $m[1], $m[2] ) as $id ) {
				if ( '' !== $id ) {
					self::$ids[ $id ] = 0;
				}
			}
			self::$ids['__seen'] = array();
		}
		$html = self::each_segment( $html, array( __CLASS__, 'segment' ) );

		if ( false !== strpos( $html, 'id="accessfix-css"' ) ) {
			if ( ! empty( $s['fix_focus'] ) ) {
				self::rec( 'focus-visible', '', ':focus-visible { outline: 3px solid ' . $s['focus_color'] . ' }', __( 'Added a visible keyboard focus outline for links, buttons and form fields.', 'accessfix' ) );
			}
			if ( ! empty( $s['fix_motion'] ) ) {
				self::rec( 'reduced-motion', '', '@media (prefers-reduced-motion: reduce) { animations and transitions shortened }', __( 'Animations and smooth scrolling are shortened for visitors who prefer reduced motion.', 'accessfix' ) );
			}
		}
		return $html;
	}

	/**
	 * Apply a callback only to the parts of the document that are not script/style/comments.
	 *
	 * @param string   $html Document.
	 * @param callable $cb   Callback.
	 * @return string
	 */
	protected static function each_segment( $html, $cb ) {
		$parts = preg_split( '#(<script\b.*?</script>|<style\b.*?</style>|<textarea\b.*?</textarea>|<!--.*?-->|<noscript\b.*?</noscript>)#is', $html, -1, PREG_SPLIT_DELIM_CAPTURE );
		if ( false === $parts ) {
			return $html;
		}
		$n = count( $parts );
		for ( $i = 0; $i < $n; $i += 2 ) {
			$parts[ $i ] = call_user_func( $cb, $parts[ $i ] );
		}
		return implode( '', $parts );
	}

	/**
	 * Per-segment element fixers.
	 *
	 * @param string $h Segment.
	 * @return string
	 */
	protected static function segment( $h ) {
		$s = self::$s;
		if ( ! empty( $s['fix_alt'] ) && false !== stripos( $h, '<img' ) ) {
			$h = preg_replace_callback( '/<img\b[^>]*>/i', array( __CLASS__, 'fix_img' ), $h );
		}
		if ( ( ! empty( $s['fix_iconlinks'] ) || ! empty( $s['fix_newwindow'] ) ) && false !== stripos( $h, '<a' ) ) {
			$h = preg_replace_callback( '/<a\b([^>]*)>(.*?)<\/a>/is', array( __CLASS__, 'fix_link' ), $h );
		}
		if ( ! empty( $s['fix_iframes'] ) && false !== stripos( $h, '<iframe' ) ) {
			$h = preg_replace_callback( '/<iframe\b[^>]*>/i', array( __CLASS__, 'fix_iframe' ), $h );
		}
		if ( ! empty( $s['fix_tables'] ) && false !== stripos( $h, '<table' ) ) {
			$h = preg_replace_callback( '/<table\b[^>]*>.*?<\/table>/is', array( __CLASS__, 'fix_table' ), $h );
		}
		if ( ! empty( $s['fix_autoplay'] ) && preg_match( '/<(video|audio)\b/i', $h ) ) {
			$h = preg_replace_callback( '/<(video|audio)\b[^>]*>/i', array( __CLASS__, 'fix_media' ), $h );
		}
		if ( ! empty( $s['fix_dupids'] ) && false !== stripos( $h, ' id' ) ) {
			$h = preg_replace_callback( '/<([a-zA-Z][\w:-]*)\b[^>]*\sid\s*=[^>]*>/', array( __CLASS__, 'fix_dup' ), $h );
		}
		return $h;
	}

	// -------------------------------------------------------------- utilities.

	/**
	 * Record a fix (kept in memory, emitted only for scanner requests).
	 *
	 * @param string $check  Check id.
	 * @param string $before Before snippet.
	 * @param string $after  After snippet.
	 * @param string $note   Human note.
	 * @return void
	 */
	protected static function rec( $check, $before, $after, $note = '' ) {
		if ( ! self::$scan_mode ) {
			return;
		}
		self::$fixes[] = array(
			'check'  => $check,
			'before' => self::cut( $before ),
			'after'  => self::cut( $after ),
			'note'   => $note,
		);
	}

	/**
	 * Truncate for storage.
	 *
	 * @param string $s String.
	 * @return string
	 */
	protected static function cut( $s ) {
		$s = trim( preg_replace( '/\s+/', ' ', (string) $s ) );
		return function_exists( 'mb_substr' ) && mb_strlen( $s ) > 400 ? mb_substr( $s, 0, 400 ) . '…' : $s;
	}

	/**
	 * Read an attribute from a tag string.
	 *
	 * @param string $tag  Tag HTML.
	 * @param string $name Attribute name.
	 * @return string|null Null when absent, '' for a bare/empty attribute.
	 */
	public static function attr_get( $tag, $name ) {
		$q = preg_quote( $name, '/' );
		if ( preg_match( '/\s' . $q . '\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s"\'>]+))/i', $tag, $m ) ) {
			$v = isset( $m[3] ) && '' !== $m[3] ? $m[3] : ( isset( $m[2] ) && '' !== $m[2] ? $m[2] : $m[1] );
			return html_entity_decode( $v, ENT_QUOTES );
		}
		if ( preg_match( '/\s' . $q . '(?=[\s\/>])/i', $tag ) ) {
			return '';
		}
		return null;
	}

	/**
	 * Set (add or replace) an attribute.
	 *
	 * @param string $tag   Tag HTML.
	 * @param string $name  Attribute.
	 * @param string $value Value (unescaped).
	 * @return string
	 */
	public static function attr_set( $tag, $name, $value ) {
		$q   = preg_quote( $name, '/' );
		$new = $name . '="' . esc_attr( $value ) . '"';
		if ( preg_match( '/\s' . $q . '\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s"\'>]+)/i', $tag ) ) {
			return preg_replace_callback(
				'/(\s)' . $q . '\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s"\'>]+)/i',
				function ( $m ) use ( $new ) {
					return $m[1] . $new;
				},
				$tag,
				1
			);
		}
		if ( preg_match( '/\s' . $q . '(?=[\s\/>])/i', $tag ) ) {
			return preg_replace_callback(
				'/(\s)' . $q . '(?=[\s\/>])/i',
				function ( $m ) use ( $new ) {
					return $m[1] . $new;
				},
				$tag,
				1
			);
		}
		return preg_replace_callback(
			'/(\s*\/?>)$/',
			function ( $m ) use ( $new ) {
				return ' ' . $new . $m[1];
			},
			$tag,
			1
		);
	}

	/**
	 * Remove an attribute.
	 *
	 * @param string $tag  Tag.
	 * @param string $name Attribute.
	 * @return string
	 */
	public static function attr_remove( $tag, $name ) {
		$q = preg_quote( $name, '/' );
		return preg_replace( '/\s' . $q . '(?:\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s"\'>]+))?(?=[\s\/>])/i', '', $tag, 1 );
	}

	/**
	 * Replace the first occurrence of a string.
	 *
	 * @param string $search  Needle.
	 * @param string $replace Replacement.
	 * @param string $subject Haystack.
	 * @return string
	 */
	protected static function replace_first( $search, $replace, $subject ) {
		$p = strpos( $subject, $search );
		return false === $p ? $subject : substr_replace( $subject, $replace, $p, strlen( $search ) );
	}

	/**
	 * Visible/announced text of an inner HTML fragment.
	 *
	 * @param string $inner HTML.
	 * @return string
	 */
	protected static function plain( $inner ) {
		$inner = preg_replace( '#<(script|style)\b.*?</\1>#is', '', $inner );
		$inner = preg_replace_callback(
			'/<svg\b.*?<\/svg>/is',
			function ( $m ) {
				$t = '';
				if ( preg_match( '/<title\b[^>]*>(.*?)<\/title>/is', $m[0], $x ) ) {
					$t = $x[1];
				}
				if ( preg_match( '/aria-label=["\']([^"\']+)["\']/i', $m[0], $x ) ) {
					$t .= ' ' . $x[1];
				}
				return ' ' . $t . ' ';
			},
			$inner
		);
		$inner = preg_replace_callback(
			'/<img\b[^>]*>/i',
			function ( $m ) {
				return ' ' . (string) self::attr_get( $m[0], 'alt' ) . ' ';
			},
			$inner
		);
		$inner = preg_replace( '/<[^>]+aria-hidden=["\']true["\'][^>]*>.*?<\/[a-z0-9]+>/is', ' ', $inner );
		$t     = html_entity_decode( wp_strip_all_tags( $inner ), ENT_QUOTES, 'UTF-8' );
		return trim( preg_replace( '/[\s\x{00A0}]+/u', ' ', $t ) );
	}

	// ------------------------------------------------------------ page-level.

	/**
	 * Add lang.
	 *
	 * @param string $html Document.
	 * @return string
	 */
	protected static function fix_lang( $html ) {
		if ( ! preg_match( '/<html\b[^>]*>/i', $html, $m ) ) {
			return $html;
		}
		$tag  = $m[0];
		$lang = self::attr_get( $tag, 'lang' );
		if ( null !== $lang && '' !== trim( $lang ) ) {
			return $html;
		}
		$x = self::attr_get( $tag, 'xml:lang' );
		$l = ( null !== $x && '' !== trim( $x ) ) ? trim( $x ) : str_replace( '_', '-', get_bloginfo( 'language' ) );
		if ( '' === $l ) {
			$l = 'en';
		}
		$new = self::attr_set( $tag, 'lang', $l );
		self::rec( 'html-lang', $tag, $new, sprintf( /* translators: %s: language code */ __( 'Added lang="%s" to the html element.', 'accessfix' ), $l ) );
		return self::replace_first( $tag, $new, $html );
	}

	/**
	 * Add or fill <title>.
	 *
	 * @param string $html Document.
	 * @return string
	 */
	protected static function fix_title( $html ) {
		if ( ! preg_match( '/<head\b.*?<\/head>/is', $html, $hm ) ) {
			return $html;
		}
		$head = $hm[0];
		$text = esc_html( wp_get_document_title() );
		if ( '' === $text ) {
			$text = esc_html( get_bloginfo( 'name' ) );
		}
		if ( preg_match( '/<title\b[^>]*>(.*?)<\/title>/is', $head, $tm ) ) {
			if ( '' !== trim( wp_strip_all_tags( $tm[1] ) ) ) {
				return $html;
			}
			$newhead = self::replace_first( $tm[0], '<title>' . $text . '</title>', $head );
			self::rec( 'page-title', $tm[0], '<title>' . $text . '</title>', __( 'Filled in an empty page title.', 'accessfix' ) );
		} else {
			$newhead = self::replace_first( '</head>', '<title>' . $text . '</title></head>', $head );
			self::rec( 'page-title', '(no <title>)', '<title>' . $text . '</title>', __( 'Added a missing page title.', 'accessfix' ) );
		}
		return self::replace_first( $head, $newhead, $html );
	}

	/**
	 * Allow zoom.
	 *
	 * @param string $html Document.
	 * @return string
	 */
	protected static function fix_viewport( $html ) {
		if ( ! preg_match( '/<meta\b[^>]*name\s*=\s*["\']viewport["\'][^>]*>/i', $html, $m ) ) {
			return $html;
		}
		$tag     = $m[0];
		$content = self::attr_get( $tag, 'content' );
		if ( null === $content ) {
			return $html;
		}
		$keep = array();
		$bad  = false;
		foreach ( preg_split( '/\s*[,;]\s*/', $content ) as $tok ) {
			if ( preg_match( '/^user-scalable\s*=\s*(no|0)$/i', $tok ) ) {
				$bad = true;
				continue;
			}
			if ( preg_match( '/^maximum-scale\s*=\s*([0-9.]+)$/i', $tok, $mm ) && (float) $mm[1] < 2 ) {
				$bad = true;
				continue;
			}
			if ( '' !== $tok ) {
				$keep[] = $tok;
			}
		}
		if ( ! $bad ) {
			return $html;
		}
		$new = self::attr_set( $tag, 'content', implode( ', ', $keep ) );
		self::rec( 'meta-viewport', $tag, $new, __( 'Removed the zoom restriction from the viewport meta tag.', 'accessfix' ) );
		return self::replace_first( $tag, $new, $html );
	}

	/**
	 * Add role="main" to the likely content container.
	 *
	 * @param string $html Document.
	 * @return string
	 */
	protected static function fix_main( $html ) {
		if ( preg_match( '/<main\b/i', $html ) || preg_match( '/\srole\s*=\s*["\']main["\']/i', $html ) ) {
			return $html;
		}
		$body = stripos( $html, '<body' );
		if ( false === $body ) {
			return $html;
		}
		$rest = substr( $html, $body );
		$pats = array(
			'/<(?:div|section|article)\b[^>]*\bid\s*=\s*["\'](?:main|content|primary|site-content|page-content|main-content)["\'][^>]*>/i',
			'/<(?:div|section|article)\b[^>]*\bclass\s*=\s*["\'][^"\']*\b(?:site-main|site-content|main-content|content-area|page-content)\b[^"\']*["\'][^>]*>/i',
		);
		foreach ( $pats as $p ) {
			if ( preg_match( $p, $rest, $m ) ) {
				$new = self::attr_set( $m[0], 'role', 'main' );
				self::rec( 'main-landmark', $m[0], $new, __( 'Marked the main content container with role="main" (the theme has no <main> element).', 'accessfix' ) );
				return substr( $html, 0, $body ) . self::replace_first( $m[0], $new, $rest );
			}
		}
		return $html;
	}

	/**
	 * Add a skip link.
	 *
	 * @param string $html Document.
	 * @return string
	 */
	protected static function fix_skip( $html ) {
		if ( ! preg_match( '/<body\b[^>]*>/i', $html, $bm, PREG_OFFSET_CAPTURE ) ) {
			return $html;
		}
		$bpos = $bm[0][1] + strlen( $bm[0][0] );
		$rest = substr( $html, $bpos );
		// Is there already a working skip link near the top?
		if ( preg_match_all( '/<a\b([^>]*)>(.*?)<\/a>/is', $rest, $links, PREG_SET_ORDER ) ) {
			$i = 0;
			foreach ( $links as $l ) {
				if ( $i++ >= 10 ) {
					break;
				}
				$href = self::attr_get( '<a' . $l[1] . '>', 'href' );
				if ( null !== $href && strlen( $href ) > 1 && '#' === $href[0] && preg_match( '/skip|jump|go to|main|content/i', self::plain( $l[2] ) . ' ' . (string) self::attr_get( '<a' . $l[1] . '>', 'class' ) . ' ' . (string) self::attr_get( '<a' . $l[1] . '>', 'aria-label' ) ) ) {
					$t = substr( $href, 1 );
					if ( preg_match( '/\s(?:id|name)\s*=\s*["\']' . preg_quote( $t, '/' ) . '["\']/', $rest ) ) {
						return $html;
					}
				}
			}
		}
		// Find a target.
		$target = '';
		$main   = null;
		if ( preg_match( '/<main\b[^>]*>/i', $rest, $mm ) ) {
			$main = $mm[0];
		} elseif ( preg_match( '/<[a-z]+\b[^>]*\srole\s*=\s*["\']main["\'][^>]*>/i', $rest, $mm ) ) {
			$main = $mm[0];
		}
		if ( $main ) {
			$id = self::attr_get( $main, 'id' );
			if ( null === $id || '' === $id ) {
				$id      = 'af-main';
				$newmain = self::attr_set( self::attr_set( $main, 'id', $id ), 'tabindex', '-1' );
				$rest    = self::replace_first( $main, $newmain, $rest );
			}
			$target = $id;
		} elseif ( preg_match( '/\sid\s*=\s*["\'](main|content|primary|site-content)["\']/i', $rest, $mm ) ) {
			$target = $mm[1];
		}
		if ( '' === $target ) {
			return substr( $html, 0, $bpos ) . $rest;
		}
		$link = '<a class="af-skip-link" href="#' . esc_attr( $target ) . '">' . esc_html__( 'Skip to main content', 'accessfix' ) . '</a>';
		self::rec( 'skip-link', $bm[0][0], $bm[0][0] . $link, __( 'Added a "Skip to main content" link as the first focusable element.', 'accessfix' ) );
		return substr( $html, 0, $bpos ) . $link . $rest;
	}

	/**
	 * Print the CSS the fixers rely on.
	 *
	 * @return void
	 */
	public static function print_css() {
		if ( ! self::enabled() ) {
			return;
		}
		$s   = AccessFix_Settings::all();
		$css = '';
		if ( ! empty( $s['fix_skip'] ) || ! empty( $s['fix_newwindow'] ) ) {
			$css .= '.af-sr-only{position:absolute!important;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}';
		}
		if ( ! empty( $s['fix_skip'] ) ) {
			$css .= '.af-skip-link{position:absolute;left:-9999px;top:0;z-index:100000;padding:.75em 1.25em;background:#fff;color:#000;font:600 16px/1.2 sans-serif;text-decoration:underline;border:2px solid #000}.af-skip-link:focus{left:8px;top:8px}';
		}
		if ( ! empty( $s['fix_focus'] ) ) {
			$c    = sanitize_hex_color( $s['focus_color'] );
			$css .= ':where(a,button,input,select,textarea,summary,[tabindex]:not([tabindex="-1"])):focus-visible{outline:3px solid ' . ( $c ? $c : '#005fcc' ) . '!important;outline-offset:2px!important}';
		}
		if ( ! empty( $s['fix_motion'] ) ) {
			$css .= '@media (prefers-reduced-motion:reduce){*,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important;scroll-behavior:auto!important}}';
		}
		if ( '' !== $css ) {
			echo '<style id="accessfix-css">' . $css . "</style>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static CSS; colour sanitised above.
		}
	}

	// ------------------------------------------------------- element fixers.

	/**
	 * Attachment id for an <img>.
	 *
	 * @param string $tag Tag.
	 * @return int
	 */
	protected static function img_id( $tag ) {
		$cls = (string) self::attr_get( $tag, 'class' );
		if ( preg_match( '/\bwp-image-(\d+)\b/', $cls, $m ) ) {
			return (int) $m[1];
		}
		$src = (string) self::attr_get( $tag, 'src' );
		if ( '' !== $src && self::$lookups < 20 && false !== strpos( $src, '/uploads/' ) ) {
			self::$lookups++;
			$full = preg_replace( '/-\d+x\d+(\.[a-z]+)$/i', '$1', $src );
			$id   = attachment_url_to_postid( $full );
			return (int) $id;
		}
		return 0;
	}

	/**
	 * Image alt fixer.
	 *
	 * @param array $m Match.
	 * @return string
	 */
	public static function fix_img( $m ) {
		$tag  = $m[0];
		$alt  = self::attr_get( $tag, 'alt' );
		$role = strtolower( (string) self::attr_get( $tag, 'role' ) );
		$need_id = ( null === $alt );
		$cls  = (string) self::attr_get( $tag, 'class' );
		$has_class_id = (bool) preg_match( '/\bwp-image-\d+\b/', $cls );
		$id   = ( $need_id || $has_class_id ) ? self::img_id( $tag ) : 0;
		$dec  = $id ? ( '1' === (string) get_post_meta( $id, '_af_decorative', true ) ) : false;

		if ( $dec && ( null === $alt || '' !== trim( $alt ) ) ) {
			$new = self::attr_set( $tag, 'alt', '' );
			self::rec( null === $alt ? 'img-alt-missing' : 'img-alt-decorative', $tag, $new, __( 'Set alt="" because the image is marked decorative in the Media Library.', 'accessfix' ) );
			return $new;
		}
		if ( null === $alt ) {
			if ( '' !== trim( (string) self::attr_get( $tag, 'aria-label' ) ) || '' !== trim( (string) self::attr_get( $tag, 'aria-labelledby' ) ) ) {
				return $tag;
			}
			if ( $id ) {
				$lib = trim( (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) );
				if ( '' !== $lib ) {
					$new = self::attr_set( $tag, 'alt', $lib );
					self::rec( 'img-alt-missing', $tag, $new, __( 'Filled in the missing alt attribute from the Media Library.', 'accessfix' ) );
					return $new;
				}
			}
			$w = self::attr_get( $tag, 'width' );
			$h = self::attr_get( $tag, 'height' );
			$tiny = ( null !== $w && is_numeric( $w ) && (float) $w <= 2 ) || ( null !== $h && is_numeric( $h ) && (float) $h <= 2 );
			if ( in_array( $role, array( 'presentation', 'none' ), true ) || 'true' === strtolower( (string) self::attr_get( $tag, 'aria-hidden' ) ) || $tiny ) {
				$new = self::attr_set( $tag, 'alt', '' );
				self::rec( 'img-alt-decorative', $tag, $new, __( 'Set alt="" on a decorative image.', 'accessfix' ) );
				return $new;
			}
			return $tag;
		}
		if ( '' !== trim( $alt ) && in_array( $role, array( 'presentation', 'none' ), true ) ) {
			$new = self::attr_set( $tag, 'alt', '' );
			self::rec( 'img-alt-decorative', $tag, $new, __( 'Emptied alt text on an image marked as presentational.', 'accessfix' ) );
			return $new;
		}
		return $tag;
	}

	/**
	 * Built-in icon label rules.
	 *
	 * @return array list of [type, needle, label].
	 */
	protected static function icon_rules() {
		$rules = array();
		foreach ( AccessFix_Settings::parse_map( self::$s['icon_map'] ) as $row ) {
			list( $k, $v ) = $row;
			if ( 0 === strpos( $k, 'class:' ) ) {
				$rules[] = array( 'class', substr( $k, 6 ), $v );
			} elseif ( 0 === strpos( $k, 'href:' ) ) {
				$rules[] = array( 'href', substr( $k, 5 ), $v );
			} else {
				$rules[] = array( 'href', $k, $v );
			}
		}
		$defaults = array(
			array( 'href', 'facebook.com', 'Facebook' ), array( 'href', 'twitter.com', 'X (Twitter)' ), array( 'href', 'x.com/', 'X (Twitter)' ),
			array( 'href', 'instagram.com', 'Instagram' ), array( 'href', 'linkedin.com', 'LinkedIn' ), array( 'href', 'youtube.com', 'YouTube' ),
			array( 'href', 'tiktok.com', 'TikTok' ), array( 'href', 'pinterest.', 'Pinterest' ), array( 'href', 'github.com', 'GitHub' ),
			array( 'href', 'wa.me', 'WhatsApp' ), array( 'href', 'api.whatsapp.com', 'WhatsApp' ), array( 'href', 'mailto:', 'Email' ), array( 'href', 'tel:', 'Phone' ),
			array( 'class', 'fa-facebook', 'Facebook' ), array( 'class', 'fa-twitter', 'X (Twitter)' ), array( 'class', 'fa-instagram', 'Instagram' ),
			array( 'class', 'fa-linkedin', 'LinkedIn' ), array( 'class', 'fa-youtube', 'YouTube' ), array( 'class', 'fa-tiktok', 'TikTok' ),
		);
		return apply_filters( 'accessfix_icon_rules', array_merge( $rules, $defaults ) );
	}

	/**
	 * Link fixer (icon-only names and new-window warning).
	 *
	 * @param array $m Match.
	 * @return string
	 */
	public static function fix_link( $m ) {
		$tag   = '<a' . $m[1] . '>';
		$inner = $m[2];
		$orig  = $m[0];
		$s     = self::$s;
		$href  = self::attr_get( $tag, 'href' );
		if ( null === $href ) {
			return $orig;
		}
		$changed = false;
		$label   = trim( (string) self::attr_get( $tag, 'aria-label' ) );
		$has_name = '' !== $label || '' !== trim( (string) self::attr_get( $tag, 'aria-labelledby' ) ) || '' !== trim( (string) self::attr_get( $tag, 'title' ) );
		$text    = self::plain( $inner );

		if ( ! empty( $s['fix_iconlinks'] ) && ! $has_name && '' === $text && '' !== trim( $inner ) ) {
			$found = '';
			foreach ( self::icon_rules() as $r ) {
				if ( 'href' === $r[0] && '' !== $r[1] && false !== stripos( $href, $r[1] ) ) {
					$found = $r[2];
				} elseif ( 'class' === $r[0] && '' !== $r[1] && false !== stripos( $m[1] . ' ' . $inner, $r[1] ) ) {
					$found = $r[2];
				}
				if ( '' !== $found ) {
					break;
				}
			}
			if ( '' !== $found ) {
				$tag     = self::attr_set( $tag, 'aria-label', $found );
				$label   = $found;
				$changed = true;
				self::rec( 'link-name', $orig, $tag . $inner . '</a>', sprintf( /* translators: %s: label */ __( 'Added aria-label="%s" to an icon-only link.', 'accessfix' ), $found ) );
			}
		}

		if ( ! empty( $s['fix_newwindow'] ) && '_blank' === strtolower( (string) self::attr_get( $tag, 'target' ) ) ) {
			$before_nw = $changed ? $tag . $inner . '</a>' : $orig;
			$hint      = $text . ' ' . $label . ' ' . (string) self::attr_get( $tag, 'title' );
			$warn      = __( 'opens in a new tab', 'accessfix' );
			$touched   = false;
			$rel       = strtolower( (string) self::attr_get( $tag, 'rel' ) );
			$toks      = array_filter( preg_split( '/\s+/', $rel ) );
			foreach ( array( 'noopener', 'noreferrer' ) as $t ) {
				if ( ! in_array( $t, $toks, true ) ) {
					$toks[]  = $t;
					$touched = true;
				}
			}
			if ( $touched ) {
				$tag = self::attr_set( $tag, 'rel', implode( ' ', $toks ) );
			}
			if ( ! preg_match( '/new (tab|window)|opens? in|external (link|site)|neues fenster|nouvel onglet|nueva (pesta|ventana)/iu', $hint ) ) {
				if ( '' !== $label ) {
					$tag = self::attr_set( $tag, 'aria-label', $label . ' (' . $warn . ')' );
				} else {
					$inner .= '<span class="af-sr-only"> (' . esc_html( $warn ) . ')</span>';
				}
				$touched = true;
				self::rec( 'new-window', $before_nw, $tag . $inner . '</a>', __( 'Added a "(opens in a new tab)" warning and rel="noopener noreferrer".', 'accessfix' ) );
			}
			$changed = $changed || $touched;
		}
		return $changed ? $tag . $inner . '</a>' : $orig;
	}

	/**
	 * iframe title fixer.
	 *
	 * @param array $m Match.
	 * @return string
	 */
	public static function fix_iframe( $m ) {
		$tag = $m[0];
		if ( '' !== trim( (string) self::attr_get( $tag, 'title' ) ) || '' !== trim( (string) self::attr_get( $tag, 'aria-label' ) ) || '' !== trim( (string) self::attr_get( $tag, 'aria-labelledby' ) ) ) {
			return $tag;
		}
		$st = (string) self::attr_get( $tag, 'style' );
		if ( null !== self::attr_get( $tag, 'hidden' ) || 'true' === self::attr_get( $tag, 'aria-hidden' ) || '0' === self::attr_get( $tag, 'width' ) || '0' === self::attr_get( $tag, 'height' ) || preg_match( '/display\s*:\s*none|(width|height)\s*:\s*0(px)?\s*(;|$)/i', $st ) ) {
			return $tag;
		}
		$src = (string) self::attr_get( $tag, 'src' );
		if ( '' === $src && '' === (string) self::attr_get( $tag, 'data-src' ) ) {
			return $tag;
		}
		if ( '' === $src ) {
			$src = (string) self::attr_get( $tag, 'data-src' );
		}
		$title = '';
		$rules = array();
		foreach ( AccessFix_Settings::parse_map( self::$s['iframe_map'] ) as $row ) {
			$rules[] = $row;
		}
		$rules = array_merge(
			$rules,
			array(
				array( 'youtube-nocookie.com', 'YouTube video player' ), array( 'youtube.com', 'YouTube video player' ), array( 'youtu.be', 'YouTube video player' ),
				array( 'vimeo.com', 'Vimeo video player' ), array( 'google.com/maps', 'Google Map' ), array( 'maps.google', 'Google Map' ),
			)
		);
		foreach ( $rules as $r ) {
			if ( false !== stripos( $src, $r[0] ) ) {
				$title = $r[1];
				break;
			}
		}
		if ( '' === $title ) {
			$host  = wp_parse_url( $src, PHP_URL_HOST );
			$title = $host ? sprintf( /* translators: %s: host name */ __( 'Embedded content from %s', 'accessfix' ), $host ) : __( 'Embedded content', 'accessfix' );
		}
		$new = self::attr_set( $tag, 'title', $title );
		self::rec( 'iframe-title', $tag, $new, sprintf( /* translators: %s: title */ __( 'Added title="%s" to an iframe.', 'accessfix' ), $title ) );
		return $new;
	}

	/**
	 * Table header fixer.
	 *
	 * @param array $m Match.
	 * @return string
	 */
	public static function fix_table( $m ) {
		$table = $m[0];
		if ( preg_match( '/<th\b/i', $table ) || substr_count( strtolower( $table ), '<table' ) > 1 ) {
			return $table;
		}
		$open = array();
		preg_match( '/^<table\b[^>]*>/i', $table, $open );
		if ( preg_match( '/\srole\s*=\s*["\'](presentation|none)["\']/i', $open[0] ) ) {
			return $table;
		}
		if ( substr_count( strtolower( $table ), '<tr' ) < 2 ) {
			return $table;
		}
		if ( ! preg_match( '/<tr\b[^>]*>(.*?)<\/tr>/is', $table, $tr ) ) {
			return $table;
		}
		if ( ! preg_match_all( '/<td\b([^>]*)>(.*?)<\/td>/is', $tr[1], $cells, PREG_SET_ORDER ) || count( $cells ) < 2 ) {
			return $table;
		}
		$new_row = $tr[1];
		foreach ( $cells as $c ) {
			$inner = trim( $c[2] );
			$bold  = (bool) preg_match( '/^<(strong|b)\b[^>]*>(.*)<\/\1>$/is', $inner ) || (bool) preg_match( '/font-weight\s*:\s*(bold|[7-9]00)/i', $c[1] );
			if ( ! $bold || '' === self::plain( $inner ) ) {
				return $table;
			}
		}
		foreach ( $cells as $c ) {
			$inner = trim( $c[2] );
			if ( preg_match( '/^<(strong|b)\b[^>]*>(.*)<\/\1>$/is', $inner, $im ) ) {
				$inner = $im[2];
			}
			$new_cell = '<th scope="col"' . $c[1] . '>' . $inner . '</th>';
			$new_row  = self::replace_first( $c[0], $new_cell, $new_row );
		}
		$new_tr = self::replace_first( $tr[1], $new_row, $tr[0] );
		self::rec( 'table-headers', $tr[0], $new_tr, __( 'Converted the bold first row into column header cells (th scope="col").', 'accessfix' ) );
		return self::replace_first( $tr[0], $new_tr, $table );
	}

	/**
	 * Autoplay fixer.
	 *
	 * @param array $m Match.
	 * @return string
	 */
	public static function fix_media( $m ) {
		$tag = $m[0];
		if ( null === self::attr_get( $tag, 'autoplay' ) ) {
			return $tag;
		}
		if ( 'video' === strtolower( $m[1] ) && null !== self::attr_get( $tag, 'muted' ) ) {
			return $tag; // Muted background video: left alone (needs a design decision).
		}
		$new = self::attr_remove( $tag, 'autoplay' );
		if ( null === self::attr_get( $new, 'controls' ) ) {
			$new = preg_replace( '/(\s*\/?>)$/', ' controls$1', $new, 1 );
		}
		self::rec( 'autoplay', $tag, $new, __( 'Removed autoplay and added playback controls.', 'accessfix' ) );
		return $new;
	}

	/**
	 * Duplicate id fixer.
	 *
	 * @param array $m Match.
	 * @return string
	 */
	public static function fix_dup( $m ) {
		$tag = $m[0];
		$id  = self::attr_get( $tag, 'id' );
		if ( null === $id || '' === $id ) {
			return $tag;
		}
		$seen = &self::$ids['__seen'];
		if ( ! isset( $seen[ $id ] ) ) {
			$seen[ $id ] = true;
			return $tag;
		}
		$n = 2;
		while ( isset( self::$ids[ $id . '-' . $n ] ) || isset( $seen[ $id . '-' . $n ] ) ) {
			$n++;
		}
		$new_id          = $id . '-' . $n;
		$seen[ $new_id ] = true;
		$new             = self::attr_set( $tag, 'id', $new_id );
		self::rec( 'duplicate-id', $tag, $new, sprintf( /* translators: 1: old id, 2: new id */ __( 'Renamed duplicate id "%1$s" to "%2$s".', 'accessfix' ), $id, $new_id ) );
		return $new;
	}
}
