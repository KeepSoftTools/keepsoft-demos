<?php
/**
 * Accessibility statement generator (EU model statement structure).
 *
 * @package AccessFix
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Statement.
 */
class AccessFix_Statement {

	const OPTION = 'af_statement';

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_shortcode( 'accessfix_statement', array( __CLASS__, 'shortcode' ) );
		add_action( 'admin_post_af_save_statement', array( __CLASS__, 'handle_save' ) );
		add_action( 'admin_post_af_create_statement_page', array( __CLASS__, 'handle_create_page' ) );
	}

	/**
	 * Defaults.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'org'              => get_bloginfo( 'name' ),
			'site_url'         => home_url( '/' ),
			'email'            => get_option( 'admin_email' ),
			'phone'            => '',
			'address'          => '',
			'standard'         => 'wcag22aa',
			'status'           => 'partial',
			'method'           => 'self',
			'assessor'         => '',
			'date_prepared'    => gmdate( 'Y-m-d' ),
			'date_reviewed'    => '',
			'response_time'    => '5 working days',
			'enforcement_name' => '',
			'enforcement_url'  => '',
			'limitations'      => '',
			'disproportionate' => '',
			'out_of_scope'     => '',
		);
	}

	/**
	 * Standards.
	 *
	 * @return array
	 */
	public static function standards() {
		return array(
			'wcag22aa'  => 'Web Content Accessibility Guidelines (WCAG) 2.2 Level AA',
			'wcag21aa'  => 'Web Content Accessibility Guidelines (WCAG) 2.1 Level AA',
			'en301549'  => 'European standard EN 301 549 (V3.2.1), which incorporates WCAG 2.1 Level AA',
			'wcag22a'   => 'Web Content Accessibility Guidelines (WCAG) 2.2 Level A',
		);
	}

	/**
	 * Saved values.
	 *
	 * @return array
	 */
	public static function data() {
		$s = get_option( self::OPTION, array() );
		return array_merge( self::defaults(), is_array( $s ) ? $s : array() );
	}

	/**
	 * Sanitise a form.
	 *
	 * @param array $in Input (unslashed).
	 * @return array
	 */
	public static function sanitize( $in ) {
		$d   = self::defaults();
		$out = array();
		$out['org']      = sanitize_text_field( isset( $in['org'] ) ? $in['org'] : $d['org'] );
		$out['site_url'] = esc_url_raw( isset( $in['site_url'] ) ? $in['site_url'] : $d['site_url'] );
		$out['email']    = sanitize_email( isset( $in['email'] ) ? $in['email'] : '' );
		$out['phone']    = sanitize_text_field( isset( $in['phone'] ) ? $in['phone'] : '' );
		$out['address']  = sanitize_textarea_field( isset( $in['address'] ) ? $in['address'] : '' );
		$st              = isset( $in['standard'] ) ? sanitize_key( $in['standard'] ) : 'wcag22aa';
		$out['standard'] = isset( self::standards()[ $st ] ) ? $st : 'wcag22aa';
		$status          = isset( $in['status'] ) ? sanitize_key( $in['status'] ) : 'partial';
		$out['status']   = in_array( $status, array( 'full', 'partial', 'none' ), true ) ? $status : 'partial';
		$method          = isset( $in['method'] ) ? sanitize_key( $in['method'] ) : 'self';
		$out['method']   = in_array( $method, array( 'self', 'third' ), true ) ? $method : 'self';
		$out['assessor'] = sanitize_text_field( isset( $in['assessor'] ) ? $in['assessor'] : '' );
		foreach ( array( 'date_prepared', 'date_reviewed' ) as $k ) {
			$v         = isset( $in[ $k ] ) ? sanitize_text_field( $in[ $k ] ) : '';
			$out[ $k ] = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) ? $v : '';
		}
		$out['response_time']    = sanitize_text_field( isset( $in['response_time'] ) ? $in['response_time'] : '' );
		$out['enforcement_name'] = sanitize_text_field( isset( $in['enforcement_name'] ) ? $in['enforcement_name'] : '' );
		$out['enforcement_url']  = esc_url_raw( isset( $in['enforcement_url'] ) ? $in['enforcement_url'] : '' );
		foreach ( array( 'limitations', 'disproportionate', 'out_of_scope' ) as $k ) {
			$out[ $k ] = sanitize_textarea_field( isset( $in[ $k ] ) ? $in[ $k ] : '' );
		}
		return $out;
	}

	/**
	 * Draft "known limitations" text from open issues.
	 *
	 * @return string
	 */
	public static function limitations_from_issues() {
		global $wpdb;
		$t    = AccessFix_Install::table( 'issues' );
		$rows = $wpdb->get_results( "SELECT check_id, criterion, COUNT(*) AS n, COUNT(DISTINCT post_id) AS pages FROM $t WHERE status = 'open' GROUP BY check_id, criterion ORDER BY criterion, n DESC" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$lines = array();
		foreach ( (array) $rows as $r ) {
			$c = AccessFix_Checks::get( $r->check_id );
			if ( ! $c ) {
				continue;
			}
			$ex = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT url FROM $t WHERE status = 'open' AND check_id = %s ORDER BY url LIMIT 3", $r->check_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$paths = array();
			foreach ( $ex as $u ) {
				$p       = wp_parse_url( $u, PHP_URL_PATH );
				$paths[] = $p ? $p : '/';
			}
			$lines[] = sprintf(
				/* translators: 1: success criterion, 2: problem, 3: count, 4: pages, 5: example paths */
				_n( 'WCAG %1$s: %2$s - %3$d instance on %4$d page (for example %5$s).', 'WCAG %1$s: %2$s - %3$d instances on %4$d page(s) (for example %5$s).', (int) $r->n, 'accessfix' ),
				AccessFix_Checks::sc_label( $r->criterion ),
				$c['title'],
				(int) $r->n,
				(int) $r->pages,
				implode( ', ', $paths )
			);
		}
		return implode( "\n", $lines );
	}

	/**
	 * Convert a textarea to HTML (bullets for multiple lines).
	 *
	 * @param string $text Text.
	 * @return string Escaped HTML.
	 */
	protected static function block( $text ) {
		$lines = array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) $text ) ), 'strlen' ) );
		if ( ! $lines ) {
			return '';
		}
		if ( 1 === count( $lines ) ) {
			return '<p>' . esc_html( ltrim( $lines[0], "-* \t" ) ) . '</p>';
		}
		$out = '<ul>';
		foreach ( $lines as $l ) {
			$out .= '<li>' . esc_html( ltrim( $l, "-* \t" ) ) . '</li>';
		}
		return $out . '</ul>';
	}

	/**
	 * Format a date for the current locale.
	 *
	 * @param string $ymd Y-m-d.
	 * @return string
	 */
	protected static function fmt_date( $ymd ) {
		if ( ! $ymd ) {
			return '';
		}
		$ts = strtotime( $ymd . ' 12:00:00 UTC' );
		return $ts ? wp_date( get_option( 'date_format' ), $ts, new DateTimeZone( 'UTC' ) ) : $ymd;
	}

	/**
	 * Render the statement HTML.
	 *
	 * @param array|null $d Data (default: saved).
	 * @return string
	 */
	public static function render( $d = null ) {
		$d    = $d ? $d : self::data();
		$std  = self::standards()[ $d['standard'] ];
		$org  = '' !== $d['org'] ? $d['org'] : get_bloginfo( 'name' );
		$url  = '' !== $d['site_url'] ? $d['site_url'] : home_url( '/' );
		$h    = '<div class="accessfix-statement">';
		$h   .= '<h2>' . esc_html__( 'Accessibility statement', 'accessfix' ) . '</h2>';
		$h   .= '<p>' . sprintf(
			/* translators: 1: organisation, 2: website */
			esc_html__( '%1$s is committed to making its website %2$s accessible to as many people as possible, in line with the applicable accessibility legislation.', 'accessfix' ),
			esc_html( $org ),
			'<a href="' . esc_url( $url ) . '">' . esc_html( preg_replace( '#^https?://#', '', untrailingslashit( $url ) ) ) . '</a>'
		) . '</p>';
		$h .= '<p>' . esc_html__( 'This accessibility statement applies to the website at the address above.', 'accessfix' ) . '</p>';

		$h .= '<h3>' . esc_html__( 'Compliance status', 'accessfix' ) . '</h3>';
		if ( 'full' === $d['status'] ) {
			/* translators: %s: standard */
			$h .= '<p>' . sprintf( esc_html__( 'This website is fully compliant with the %s.', 'accessfix' ), esc_html( $std ) ) . '</p>';
		} elseif ( 'none' === $d['status'] ) {
			/* translators: %s: standard */
			$h .= '<p>' . sprintf( esc_html__( 'This website is not compliant with the %s. The non-compliances are listed below.', 'accessfix' ), esc_html( $std ) ) . '</p>';
		} else {
			/* translators: %s: standard */
			$h .= '<p>' . sprintf( esc_html__( 'This website is partially compliant with the %s, due to the non-compliances and exemptions listed below.', 'accessfix' ), esc_html( $std ) ) . '</p>';
		}

		$lim  = self::block( $d['limitations'] );
		$disp = self::block( $d['disproportionate'] );
		$out  = self::block( $d['out_of_scope'] );
		if ( 'full' !== $d['status'] || $lim || $disp || $out ) {
			$h .= '<h3>' . esc_html__( 'Non-accessible content', 'accessfix' ) . '</h3>';
			$h .= '<h4>' . esc_html__( 'Non-compliance with the standard', 'accessfix' ) . '</h4>';
			$h .= $lim ? $lim : '<p>' . esc_html__( 'No specific non-compliances have been recorded at the date of preparation.', 'accessfix' ) . '</p>';
			$h .= '<h4>' . esc_html__( 'Disproportionate burden', 'accessfix' ) . '</h4>';
			$h .= $disp ? $disp : '<p>' . esc_html__( 'No disproportionate burden exemption is claimed.', 'accessfix' ) . '</p>';
			$h .= '<h4>' . esc_html__( 'Content that is not within the scope of the applicable legislation', 'accessfix' ) . '</h4>';
			$h .= $out ? $out : '<p>' . esc_html__( 'None declared.', 'accessfix' ) . '</p>';
		}

		$h .= '<h3>' . esc_html__( 'Preparation of this accessibility statement', 'accessfix' ) . '</h3>';
		$h .= '<p>' . sprintf(
			/* translators: %s: date */
			esc_html__( 'This statement was prepared on %s.', 'accessfix' ),
			esc_html( self::fmt_date( $d['date_prepared'] ) )
		) . ' ';
		if ( 'third' === $d['method'] ) {
			$h .= '' !== $d['assessor']
				? sprintf( /* translators: %s: assessor */ esc_html__( 'The assessment was carried out by a third party: %s.', 'accessfix' ), esc_html( $d['assessor'] ) )
				: esc_html__( 'The assessment was carried out by a third party.', 'accessfix' );
		} else {
			$h .= esc_html__( 'The assessment method was a self-assessment by the website owner, using automated testing (WCAG 2.2 checks run by the AccessFix scanner).', 'accessfix' );
		}
		$h .= '</p>';
		if ( $d['date_reviewed'] ) {
			/* translators: %s: date */
			$h .= '<p>' . sprintf( esc_html__( 'The statement was last reviewed on %s.', 'accessfix' ), esc_html( self::fmt_date( $d['date_reviewed'] ) ) ) . '</p>';
		}

		$h .= '<h3>' . esc_html__( 'Feedback and contact information', 'accessfix' ) . '</h3>';
		$h .= '<p>' . esc_html__( 'If you find an accessibility barrier on this website, or need content in another format, please contact us:', 'accessfix' ) . '</p><ul>';
		if ( $d['email'] ) {
			$h .= '<li>' . esc_html__( 'Email:', 'accessfix' ) . ' <a href="mailto:' . esc_attr( antispambot( $d['email'] ) ) . '">' . esc_html( antispambot( $d['email'] ) ) . '</a></li>';
		}
		if ( $d['phone'] ) {
			$h .= '<li>' . esc_html__( 'Phone:', 'accessfix' ) . ' ' . esc_html( $d['phone'] ) . '</li>';
		}
		if ( $d['address'] ) {
			$h .= '<li>' . esc_html__( 'Postal address:', 'accessfix' ) . ' ' . nl2br( esc_html( $d['address'] ) ) . '</li>';
		}
		$h .= '</ul>';
		if ( $d['response_time'] ) {
			/* translators: %s: response time */
			$h .= '<p>' . sprintf( esc_html__( 'We aim to respond to accessibility feedback within %s.', 'accessfix' ), esc_html( $d['response_time'] ) ) . '</p>';
		}

		$h .= '<h3>' . esc_html__( 'Enforcement procedure', 'accessfix' ) . '</h3>';
		$h .= '<p>' . esc_html__( 'If you are not satisfied with our response, you can contact the body responsible for enforcing accessibility requirements in your country.', 'accessfix' );
		if ( $d['enforcement_name'] || $d['enforcement_url'] ) {
			$label = $d['enforcement_name'] ? $d['enforcement_name'] : $d['enforcement_url'];
			$h    .= ' ' . ( $d['enforcement_url'] ? '<a href="' . esc_url( $d['enforcement_url'] ) . '">' . esc_html( $label ) . '</a>' : esc_html( $label ) ) . '.';
		}
		$h .= '</p></div>';
		return apply_filters( 'accessfix_statement_html', $h, $d );
	}

	/**
	 * Shortcode callback.
	 *
	 * @return string
	 */
	public static function shortcode() {
		return self::render();
	}

	/**
	 * Save handler.
	 *
	 * @return void
	 */
	public static function handle_save() {
		if ( ! current_user_can( AccessFix_Admin::cap() ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'accessfix' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'af_save_statement' );
		$in = isset( $_POST['st'] ) && is_array( $_POST['st'] ) ? wp_unslash( $_POST['st'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitised in sanitize().
		$d  = self::sanitize( $in );
		if ( ! empty( $_POST['af_fill'] ) ) {
			$fill = self::limitations_from_issues();
			$d['limitations'] = '' !== $fill ? $fill : $d['limitations'];
		}
		update_option( self::OPTION, $d, false );
		wp_safe_redirect( add_query_arg( array( 'page' => 'accessfix-statement', 'af_msg' => ! empty( $_POST['af_fill'] ) ? 'filled' : 'saved' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Create a draft page that holds the shortcode.
	 *
	 * @return void
	 */
	public static function handle_create_page() {
		if ( ! current_user_can( AccessFix_Admin::cap() ) || ! current_user_can( 'publish_pages' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'accessfix' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'af_create_statement_page' );
		$id = wp_insert_post(
			array(
				'post_type'    => 'page',
				'post_status'  => 'draft',
				'post_title'   => __( 'Accessibility statement', 'accessfix' ),
				'post_content' => '[accessfix_statement]',
			)
		);
		if ( $id && ! is_wp_error( $id ) ) {
			update_option( 'af_statement_page', (int) $id, false );
			wp_safe_redirect( get_edit_post_link( $id, 'raw' ) );
			exit;
		}
		wp_safe_redirect( add_query_arg( array( 'page' => 'accessfix-statement', 'af_msg' => 'error' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Is the shortcode on a published page?
	 *
	 * @return int Post id or 0.
	 */
	public static function published_page() {
		global $wpdb;
		$id = (int) $wpdb->get_var( "SELECT ID FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ('page','post') AND post_content LIKE '%[accessfix\\_statement%' ORDER BY ID LIMIT 1" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return $id;
	}

	/**
	 * Admin form.
	 *
	 * @return void
	 */
	public static function render_admin() {
		$d    = self::data();
		$page = self::published_page();
		$msg  = isset( $_GET['af_msg'] ) ? sanitize_key( wp_unslash( $_GET['af_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		echo '<div class="wrap af-wrap"><h1>' . esc_html__( 'Accessibility statement', 'accessfix' ) . '</h1>';
		if ( 'saved' === $msg ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Statement saved.', 'accessfix' ) . '</p></div>';
		} elseif ( 'filled' === $msg ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Known limitations were filled in from the open issues. Please review and edit the text before you publish.', 'accessfix' ) . '</p></div>';
		}
		echo '<p class="description">' . esc_html__( 'Generates a statement that follows the structure of the EU model accessibility statement (Implementing Decision (EU) 2018/1523). Review every sentence: the statement is a public declaration and must be accurate. It is not legal advice.', 'accessfix' ) . '</p>';
		if ( $page ) {
			echo '<div class="notice notice-info inline"><p>' . sprintf(
				/* translators: %s: link */
				esc_html__( 'The shortcode is live on %s.', 'accessfix' ),
				'<a href="' . esc_url( get_permalink( $page ) ) . '">' . esc_html( get_the_title( $page ) ) . '</a>'
			) . '</p></div>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="af-form">';
		wp_nonce_field( 'af_save_statement' );
		echo '<input type="hidden" name="action" value="af_save_statement" />';
		echo '<table class="form-table" role="presentation">';
		self::row_text( 'org', __( 'Organisation name', 'accessfix' ), $d );
		self::row_text( 'site_url', __( 'Website address', 'accessfix' ), $d, 'url' );
		self::row_text( 'email', __( 'Contact email', 'accessfix' ), $d, 'email' );
		self::row_text( 'phone', __( 'Contact phone (optional)', 'accessfix' ), $d );
		self::row_area( 'address', __( 'Postal address (optional)', 'accessfix' ), $d, 2 );
		echo '<tr><th scope="row"><label for="st_standard">' . esc_html__( 'Standard targeted', 'accessfix' ) . '</label></th><td><select id="st_standard" name="st[standard]">';
		foreach ( self::standards() as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $d['standard'], $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select></td></tr>';
		echo '<tr><th scope="row"><label for="st_status">' . esc_html__( 'Compliance status', 'accessfix' ) . '</label></th><td><select id="st_status" name="st[status]">';
		foreach ( array( 'full' => __( 'Fully compliant', 'accessfix' ), 'partial' => __( 'Partially compliant', 'accessfix' ), 'none' => __( 'Not compliant', 'accessfix' ) ) as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $d['status'], $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select><p class="description">' . esc_html__( 'Automated scans cannot prove full compliance. Choose "Fully compliant" only after a complete manual evaluation.', 'accessfix' ) . '</p></td></tr>';
		echo '<tr><th scope="row"><label for="st_method">' . esc_html__( 'Assessment method', 'accessfix' ) . '</label></th><td><select id="st_method" name="st[method]">';
		echo '<option value="self"' . selected( $d['method'], 'self', false ) . '>' . esc_html__( 'Self-assessment', 'accessfix' ) . '</option><option value="third"' . selected( $d['method'], 'third', false ) . '>' . esc_html__( 'Third-party assessment', 'accessfix' ) . '</option></select></td></tr>';
		self::row_text( 'assessor', __( 'Third-party assessor (if any)', 'accessfix' ), $d );
		self::row_text( 'date_prepared', __( 'Date prepared', 'accessfix' ), $d, 'date' );
		self::row_text( 'date_reviewed', __( 'Last reviewed (optional)', 'accessfix' ), $d, 'date' );
		self::row_text( 'response_time', __( 'Response time for feedback', 'accessfix' ), $d );
		self::row_text( 'enforcement_name', __( 'Enforcement body name', 'accessfix' ), $d );
		self::row_text( 'enforcement_url', __( 'Enforcement body link', 'accessfix' ), $d, 'url' );
		self::row_area( 'limitations', __( 'Known limitations (non-compliant content)', 'accessfix' ), $d, 8, __( 'One item per line. Use the "Fill from open issues" button to draft this from the latest scan, then edit it.', 'accessfix' ) );
		self::row_area( 'disproportionate', __( 'Disproportionate burden (optional)', 'accessfix' ), $d, 3 );
		self::row_area( 'out_of_scope', __( 'Content outside the scope of the legislation (optional)', 'accessfix' ), $d, 3 );
		echo '</table><p class="submit">';
		echo '<button type="submit" class="button button-primary">' . esc_html__( 'Save statement', 'accessfix' ) . '</button> ';
		echo '<button type="submit" name="af_fill" value="1" class="button">' . esc_html__( 'Save and fill limitations from open issues', 'accessfix' ) . '</button>';
		echo '</p></form>';

		echo '<h2>' . esc_html__( 'Publish', 'accessfix' ) . '</h2><p>' . esc_html__( 'Add this shortcode to any page:', 'accessfix' ) . ' <code>[accessfix_statement]</code></p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'af_create_statement_page' );
		echo '<input type="hidden" name="action" value="af_create_statement_page" /><button type="submit" class="button">' . esc_html__( 'Create a draft page with the shortcode', 'accessfix' ) . '</button></form>';
		echo '<h2>' . esc_html__( 'Preview', 'accessfix' ) . '</h2><div class="af-preview">' . wp_kses_post( self::render( $d ) ) . '</div></div>';
	}

	/**
	 * Text row.
	 *
	 * @param string $k     Key.
	 * @param string $label Label.
	 * @param array  $d     Data.
	 * @param string $type  Input type.
	 * @return void
	 */
	protected static function row_text( $k, $label, $d, $type = 'text' ) {
		echo '<tr><th scope="row"><label for="st_' . esc_attr( $k ) . '">' . esc_html( $label ) . '</label></th><td><input class="regular-text" type="' . esc_attr( $type ) . '" id="st_' . esc_attr( $k ) . '" name="st[' . esc_attr( $k ) . ']" value="' . esc_attr( $d[ $k ] ) . '" /></td></tr>';
	}

	/**
	 * Textarea row.
	 *
	 * @param string $k     Key.
	 * @param string $label Label.
	 * @param array  $d     Data.
	 * @param int    $rows  Rows.
	 * @param string $help  Help text.
	 * @return void
	 */
	protected static function row_area( $k, $label, $d, $rows, $help = '' ) {
		echo '<tr><th scope="row"><label for="st_' . esc_attr( $k ) . '">' . esc_html( $label ) . '</label></th><td><textarea class="large-text" rows="' . (int) $rows . '" id="st_' . esc_attr( $k ) . '" name="st[' . esc_attr( $k ) . ']"' . ( $help ? ' aria-describedby="st_' . esc_attr( $k ) . '_h"' : '' ) . '>' . esc_textarea( $d[ $k ] ) . '</textarea>';
		if ( $help ) {
			echo '<p class="description" id="st_' . esc_attr( $k ) . '_h">' . esc_html( $help ) . '</p>';
		}
		echo '</td></tr>';
	}
}
