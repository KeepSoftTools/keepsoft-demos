<?php
/**
 * Colour maths and a small CSS cascade used by the contrast check.
 *
 * This is deliberately a *partial* implementation: simple selectors, no media
 * queries, no pseudo-classes, no gradients or background images. Elements whose
 * colours cannot be determined are skipped rather than guessed.
 *
 * @package AccessFix
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Colour helpers.
 */
class AccessFix_Color {

	/**
	 * Named colours (CSS Color Level 3 basic + common extras).
	 *
	 * @return array
	 */
	protected static function names() {
		return array(
			'black' => '000000', 'white' => 'ffffff', 'red' => 'ff0000', 'green' => '008000', 'blue' => '0000ff', 'yellow' => 'ffff00',
			'gray' => '808080', 'grey' => '808080', 'silver' => 'c0c0c0', 'maroon' => '800000', 'purple' => '800080', 'fuchsia' => 'ff00ff',
			'lime' => '00ff00', 'olive' => '808000', 'navy' => '000080', 'teal' => '008080', 'aqua' => '00ffff', 'orange' => 'ffa500',
			'pink' => 'ffc0cb', 'brown' => 'a52a2a', 'gold' => 'ffd700', 'lightgray' => 'd3d3d3', 'lightgrey' => 'd3d3d3', 'darkgray' => 'a9a9a9',
			'darkgrey' => 'a9a9a9', 'dimgray' => '696969', 'dimgrey' => '696969', 'whitesmoke' => 'f5f5f5', 'lightblue' => 'add8e6', 'darkblue' => '00008b',
			'darkred' => '8b0000', 'darkgreen' => '006400', 'crimson' => 'dc143c', 'coral' => 'ff7f50', 'tomato' => 'ff6347', 'salmon' => 'fa8072',
			'khaki' => 'f0e68c', 'ivory' => 'fffff0', 'beige' => 'f5f5dc', 'lavender' => 'e6e6fa', 'turquoise' => '40e0d0', 'cyan' => '00ffff',
			'magenta' => 'ff00ff', 'indigo' => '4b0082', 'violet' => 'ee82ee', 'tan' => 'd2b48c', 'slategray' => '708090', 'slategrey' => '708090',
		);
	}

	/**
	 * Parse a CSS colour into [r,g,b,a]. Returns null when unknown.
	 *
	 * @param string $v CSS value.
	 * @return array|null
	 */
	public static function parse( $v ) {
		$v = strtolower( trim( (string) $v ) );
		$v = trim( preg_replace( '/\s*!important\s*$/', '', $v ) );
		if ( '' === $v ) {
			return null;
		}
		if ( 'transparent' === $v ) {
			return array( 0, 0, 0, 0 );
		}
		$names = self::names();
		if ( isset( $names[ $v ] ) ) {
			$v = '#' . $names[ $v ];
		}
		if ( preg_match( '/^#([0-9a-f]{3,8})$/', $v, $m ) ) {
			$h = $m[1];
			if ( 3 === strlen( $h ) || 4 === strlen( $h ) ) {
				$h = preg_replace( '/(.)/', '$1$1', $h );
			}
			if ( 6 === strlen( $h ) ) {
				$h .= 'ff';
			}
			if ( 8 !== strlen( $h ) ) {
				return null;
			}
			return array( hexdec( substr( $h, 0, 2 ) ), hexdec( substr( $h, 2, 2 ) ), hexdec( substr( $h, 4, 2 ) ), hexdec( substr( $h, 6, 2 ) ) / 255 );
		}
		if ( preg_match( '/^rgba?\(\s*([0-9.]+)(%?)[\s,]+([0-9.]+)(%?)[\s,]+([0-9.]+)(%?)(?:\s*[,\/]\s*([0-9.]+)(%?))?\s*\)$/', $v, $m ) ) {
			$ch = array();
			foreach ( array( 1, 3, 5 ) as $i ) {
				$n    = (float) $m[ $i ];
				$ch[] = '%' === $m[ $i + 1 ] ? $n * 2.55 : $n;
			}
			$a = 1;
			if ( isset( $m[7] ) && '' !== $m[7] ) {
				$a = (float) $m[7];
				if ( isset( $m[8] ) && '%' === $m[8] ) {
					$a /= 100;
				}
			}
			return array( min( 255, $ch[0] ), min( 255, $ch[1] ), min( 255, $ch[2] ), min( 1, $a ) );
		}
		if ( preg_match( '/^hsla?\(\s*([0-9.]+)(?:deg)?[\s,]+([0-9.]+)%[\s,]+([0-9.]+)%(?:\s*[,\/]\s*([0-9.]+)(%?))?\s*\)$/', $v, $m ) ) {
			$rgb = self::hsl_to_rgb( (float) $m[1], (float) $m[2] / 100, (float) $m[3] / 100 );
			$a   = 1;
			if ( isset( $m[4] ) && '' !== $m[4] ) {
				$a = (float) $m[4];
				if ( ! empty( $m[5] ) ) {
					$a /= 100;
				}
			}
			return array( $rgb[0], $rgb[1], $rgb[2], min( 1, $a ) );
		}
		return null;
	}

	/**
	 * HSL to RGB.
	 *
	 * @param float $h Hue.
	 * @param float $s Saturation 0-1.
	 * @param float $l Lightness 0-1.
	 * @return array
	 */
	protected static function hsl_to_rgb( $h, $s, $l ) {
		$h = fmod( fmod( $h, 360 ) + 360, 360 ) / 360;
		if ( 0.0 === $s ) {
			return array( $l * 255, $l * 255, $l * 255 );
		}
		$q  = $l < 0.5 ? $l * ( 1 + $s ) : $l + $s - $l * $s;
		$p  = 2 * $l - $q;
		$f  = function ( $t ) use ( $p, $q ) {
			if ( $t < 0 ) {
				$t += 1;
			}
			if ( $t > 1 ) {
				$t -= 1;
			}
			if ( $t < 1 / 6 ) {
				return $p + ( $q - $p ) * 6 * $t;
			}
			if ( $t < 1 / 2 ) {
				return $q;
			}
			if ( $t < 2 / 3 ) {
				return $p + ( $q - $p ) * ( 2 / 3 - $t ) * 6;
			}
			return $p;
		};
		return array( $f( $h + 1 / 3 ) * 255, $f( $h ) * 255, $f( $h - 1 / 3 ) * 255 );
	}

	/**
	 * Composite a colour with alpha over an opaque background.
	 *
	 * @param array $fg [r,g,b,a].
	 * @param array $bg [r,g,b,a].
	 * @return array
	 */
	public static function over( $fg, $bg ) {
		$a = $fg[3];
		return array(
			$fg[0] * $a + $bg[0] * ( 1 - $a ),
			$fg[1] * $a + $bg[1] * ( 1 - $a ),
			$fg[2] * $a + $bg[2] * ( 1 - $a ),
			1,
		);
	}

	/**
	 * Relative luminance (WCAG definition).
	 *
	 * @param array $c [r,g,b].
	 * @return float
	 */
	public static function luminance( $c ) {
		$l = array();
		for ( $i = 0; $i < 3; $i++ ) {
			$v   = $c[ $i ] / 255;
			$l[] = $v <= 0.03928 ? $v / 12.92 : pow( ( $v + 0.055 ) / 1.055, 2.4 );
		}
		return 0.2126 * $l[0] + 0.7152 * $l[1] + 0.0722 * $l[2];
	}

	/**
	 * Contrast ratio between two opaque colours.
	 *
	 * @param array $a Colour.
	 * @param array $b Colour.
	 * @return float
	 */
	public static function ratio( $a, $b ) {
		$la = self::luminance( $a );
		$lb = self::luminance( $b );
		if ( $la < $lb ) {
			$t  = $la;
			$la = $lb;
			$lb = $t;
		}
		return ( $la + 0.05 ) / ( $lb + 0.05 );
	}

	/**
	 * Hex string for display.
	 *
	 * @param array $c Colour.
	 * @return string
	 */
	public static function hex( $c ) {
		return sprintf( '#%02x%02x%02x', round( $c[0] ), round( $c[1] ), round( $c[2] ) );
	}
}

/**
 * Minimal stylesheet model: rules indexed for fast lookup.
 */
class AccessFix_CSS {

	/** @var array Parsed rules: each [selectors(parsed), decls(array prop=>[value,important]), order]. */
	public $rules = array();
	/** @var array Custom properties from :root / html / body. */
	public $vars = array();
	/** @var array Indexes by key. */
	protected $by_id = array();
	protected $by_class = array();
	protected $by_tag = array();
	protected $universal = array();
	protected $order = 0;
	/** @var bool Whether any unsupported construct could have affected colours. */
	public $partial = false;

	/**
	 * Add CSS text.
	 *
	 * @param string $css CSS source.
	 * @return void
	 */
	public function add( $css ) {
		$css = preg_replace( '!/\*.*?\*/!s', '', (string) $css );
		$len = strlen( $css );
		$pos = 0;
		while ( $pos < $len ) {
			$open = strpos( $css, '{', $pos );
			if ( false === $open ) {
				break;
			}
			$prelude = trim( substr( $css, $pos, $open - $pos ) );
			// Find the matching close brace.
			$depth = 1;
			$i     = $open + 1;
			while ( $i < $len && $depth > 0 ) {
				$ch = $css[ $i ];
				if ( '{' === $ch ) {
					$depth++;
				} elseif ( '}' === $ch ) {
					$depth--;
				}
				$i++;
			}
			$body = substr( $css, $open + 1, $i - $open - 2 );
			$pos  = $i;
			if ( '' === $prelude ) {
				continue;
			}
			// Drop trailing statements (e.g. @import ...;) that precede the rule.
			if ( false !== strpos( $prelude, ';' ) ) {
				$prelude = trim( substr( $prelude, strrpos( $prelude, ';' ) + 1 ) );
			}
			if ( '@' === ( $prelude[0] ?? '' ) ) {
				if ( preg_match( '/^@media\s+(all|screen)\b(?!\s+and)/i', $prelude ) || preg_match( '/^@layer\b/i', $prelude ) ) {
					$this->add( $body );
				} elseif ( preg_match( '/^@(media|supports|container)\b/i', $prelude ) ) {
					$this->partial = true;
				}
				continue;
			}
			$this->add_rule( $prelude, $body );
		}
	}

	/**
	 * Add one rule.
	 *
	 * @param string $prelude Selector list.
	 * @param string $body    Declarations.
	 * @return void
	 */
	protected function add_rule( $prelude, $body ) {
		$decls = self::parse_decls( $body );
		if ( ! $decls ) {
			return;
		}
		$sels = array();
		foreach ( explode( ',', $prelude ) as $sel ) {
			$sel = trim( $sel );
			if ( preg_match( '/^(:root|html|body)$/i', $sel ) ) {
				foreach ( $decls as $p => $d ) {
					if ( 0 === strpos( $p, '--' ) ) {
						$this->vars[ $p ] = $d[0];
					}
				}
			}
			$parsed = $this->parse_selector( $sel );
			if ( null === $parsed ) {
				if ( preg_match( '/color|background|font/i', $body ) ) {
					$this->partial = true;
				}
				continue;
			}
			$sels[] = $parsed;
		}
		if ( ! $sels ) {
			return;
		}
		$idx = count( $this->rules );
		$this->rules[ $idx ] = array( $sels, $decls, $this->order++ );
		foreach ( $sels as $s ) {
			$last = end( $s['parts'] );
			if ( $last['id'] ) {
				$this->by_id[ $last['id'] ][ $idx ] = true;
			} elseif ( $last['classes'] ) {
				$this->by_class[ $last['classes'][0] ][ $idx ] = true;
			} elseif ( $last['tag'] && '*' !== $last['tag'] ) {
				$this->by_tag[ $last['tag'] ][ $idx ] = true;
			} else {
				$this->universal[ $idx ] = true;
			}
		}
	}

	/**
	 * Parse declarations.
	 *
	 * @param string $body Declaration block.
	 * @return array prop => [value, important].
	 */
	public static function parse_decls( $body ) {
		$out = array();
		// Split on ; but not inside parentheses/quotes (data: URIs).
		$parts = preg_split( '/;(?![^(]*\))/', $body );
		foreach ( $parts as $d ) {
			$p = strpos( $d, ':' );
			if ( false === $p ) {
				continue;
			}
			$prop = strtolower( trim( substr( $d, 0, $p ) ) );
			$val  = trim( substr( $d, $p + 1 ) );
			if ( '' === $prop || '' === $val ) {
				continue;
			}
			$imp = false;
			if ( preg_match( '/\s*!important\s*$/i', $val ) ) {
				$imp = true;
				$val = trim( preg_replace( '/\s*!important\s*$/i', '', $val ) );
			}
			$out[ $prop ] = array( $val, $imp );
		}
		return $out;
	}

	/**
	 * Parse a selector made of compounds joined by descendant/child combinators.
	 *
	 * @param string $sel Selector.
	 * @return array|null Null when unsupported.
	 */
	protected function parse_selector( $sel ) {
		if ( ! preg_match( '/^[\w\s.#>-]+$/', $sel ) ) {
			return null;
		}
		$tokens = preg_split( '/\s*(>)\s*|\s+/', trim( $sel ), -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
		$parts  = array();
		$comb   = ' ';
		$spec   = 0;
		foreach ( $tokens as $t ) {
			if ( '>' === $t ) {
				$comb = '>';
				continue;
			}
			if ( ! preg_match( '/^([a-z][a-z0-9-]*)?((?:[.#][\w-]+)*)$/i', $t, $m ) ) {
				return null;
			}
			$tag     = isset( $m[1] ) && '' !== $m[1] ? strtolower( $m[1] ) : '';
			$id      = '';
			$classes = array();
			if ( ! empty( $m[2] ) ) {
				preg_match_all( '/([.#])([\w-]+)/', $m[2], $mm, PREG_SET_ORDER );
				foreach ( $mm as $x ) {
					if ( '#' === $x[1] ) {
						$id = $x[2];
						$spec += 10000;
					} else {
						$classes[] = $x[2];
						$spec     += 100;
					}
				}
			}
			if ( $tag ) {
				$spec += 1;
			}
			$parts[] = array( 'tag' => $tag, 'id' => $id, 'classes' => $classes, 'comb' => $comb );
			$comb    = ' ';
		}
		if ( ! $parts ) {
			return null;
		}
		return array( 'parts' => $parts, 'spec' => $spec );
	}

	/**
	 * Does a compound match an element?
	 *
	 * @param array      $c  Compound.
	 * @param DOMElement $el Element.
	 * @return bool
	 */
	protected function match_compound( $c, $el ) {
		if ( $c['tag'] && $c['tag'] !== strtolower( $el->nodeName ) ) {
			return false;
		}
		if ( $c['id'] && $el->getAttribute( 'id' ) !== $c['id'] ) {
			return false;
		}
		if ( $c['classes'] ) {
			$have = preg_split( '/\s+/', trim( $el->getAttribute( 'class' ) ) );
			foreach ( $c['classes'] as $cl ) {
				if ( ! in_array( $cl, $have, true ) ) {
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * Does a parsed selector match an element?
	 *
	 * @param array      $sel Parsed selector.
	 * @param DOMElement $el  Element.
	 * @return bool
	 */
	protected function matches( $sel, $el ) {
		$parts = $sel['parts'];
		$i     = count( $parts ) - 1;
		if ( ! $this->match_compound( $parts[ $i ], $el ) ) {
			return false;
		}
		return $this->match_up( $parts, $i, $el );
	}

	/**
	 * Match remaining parts walking up the tree.
	 *
	 * @param array      $parts Parts.
	 * @param int        $i     Index of the part already matched on $el.
	 * @param DOMElement $el    Matched element.
	 * @return bool
	 */
	protected function match_up( $parts, $i, $el ) {
		if ( 0 === $i ) {
			return true;
		}
		$comb = $parts[ $i ]['comb'];
		$p    = $el->parentNode;
		if ( '>' === $comb ) {
			return $p instanceof DOMElement && $this->match_compound( $parts[ $i - 1 ], $p ) && $this->match_up( $parts, $i - 1, $p );
		}
		while ( $p instanceof DOMElement ) {
			if ( $this->match_compound( $parts[ $i - 1 ], $p ) && $this->match_up( $parts, $i - 1, $p ) ) {
				return true;
			}
			$p = $p->parentNode;
		}
		return false;
	}

	/**
	 * Winning declarations for an element (own rules + inline style only).
	 *
	 * @param DOMElement $el Element.
	 * @return array prop => value.
	 */
	public function declared( $el ) {
		$cand = $this->universal;
		$id   = $el->getAttribute( 'id' );
		if ( $id && isset( $this->by_id[ $id ] ) ) {
			$cand += $this->by_id[ $id ];
		}
		$cls = trim( $el->getAttribute( 'class' ) );
		if ( '' !== $cls ) {
			foreach ( preg_split( '/\s+/', $cls ) as $c ) {
				if ( isset( $this->by_class[ $c ] ) ) {
					$cand += $this->by_class[ $c ];
				}
			}
		}
		$tag = strtolower( $el->nodeName );
		if ( isset( $this->by_tag[ $tag ] ) ) {
			$cand += $this->by_tag[ $tag ];
		}
		$best = array(); // prop => [rank, value].
		foreach ( array_keys( $cand ) as $idx ) {
			$rule = $this->rules[ $idx ];
			$spec = -1;
			foreach ( $rule[0] as $s ) {
				if ( $s['spec'] > $spec && $this->matches( $s, $el ) ) {
					$spec = $s['spec'];
				}
			}
			if ( $spec < 0 ) {
				continue;
			}
			foreach ( $rule[1] as $p => $d ) {
				$rank = array( $d[1] ? 1 : 0, 0, $spec, $rule[2] );
				if ( ! isset( $best[ $p ] ) || self::cmp( $rank, $best[ $p ][0] ) >= 0 ) {
					$best[ $p ] = array( $rank, $d[0] );
				}
			}
		}
		$style = $el->getAttribute( 'style' );
		if ( '' !== $style ) {
			foreach ( self::parse_decls( $style ) as $p => $d ) {
				$rank = array( $d[1] ? 1 : 0, 1, 0, 0 );
				if ( ! isset( $best[ $p ] ) || self::cmp( $rank, $best[ $p ][0] ) >= 0 ) {
					$best[ $p ] = array( $rank, $d[0] );
				}
			}
		}
		$out = array();
		foreach ( $best as $p => $b ) {
			$out[ $p ] = $this->resolve_vars( $b[1] );
		}
		return $out;
	}

	/**
	 * Compare ranks.
	 *
	 * @param array $a Rank.
	 * @param array $b Rank.
	 * @return int
	 */
	protected static function cmp( $a, $b ) {
		for ( $i = 0; $i < 4; $i++ ) {
			if ( $a[ $i ] !== $b[ $i ] ) {
				return $a[ $i ] < $b[ $i ] ? -1 : 1;
			}
		}
		return 0;
	}

	/**
	 * Resolve var(--x, fallback).
	 *
	 * @param string $v     Value.
	 * @param int    $depth Recursion guard.
	 * @return string
	 */
	public function resolve_vars( $v, $depth = 0 ) {
		if ( $depth > 5 || false === strpos( $v, 'var(' ) ) {
			return $v;
		}
		$vars = $this->vars;
		$self = $this;
		$v    = preg_replace_callback(
			'/var\(\s*(--[\w-]+)\s*(?:,\s*([^()]*(?:\([^()]*\)[^()]*)*))?\)/',
			function ( $m ) use ( $vars, $self, $depth ) {
				if ( isset( $vars[ $m[1] ] ) ) {
					return $self->resolve_vars( $vars[ $m[1] ], $depth + 1 );
				}
				return isset( $m[2] ) ? $m[2] : 'var(unresolved)';
			},
			$v
		);
		return $v;
	}
}
