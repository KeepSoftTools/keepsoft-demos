<?php
/**
 * Scan runner: builds the page list, fetches pages, stores results, cron and email.
 *
 * @package AccessFix
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Runner.
 */
class AccessFix_Runner {

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'af_cron_scan', array( __CLASS__, 'cron_start' ) );
		add_action( 'af_cron_batch', array( __CLASS__, 'cron_batch' ) );
		add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) ); // phpcs:ignore WordPress.WP.CronInterval.ChangeDetected
	}

	/**
	 * Ensure a weekly schedule exists on old WordPress versions.
	 *
	 * @param array $s Schedules.
	 * @return array
	 */
	public static function schedules( $s ) {
		if ( ! isset( $s['weekly'] ) ) {
			$s['weekly'] = array( 'interval' => WEEK_IN_SECONDS, 'display' => __( 'Once weekly', 'accessfix' ) );
		}
		return $s;
	}

	/**
	 * (Re)schedule the recurring scan from settings.
	 *
	 * @return void
	 */
	public static function reschedule() {
		wp_clear_scheduled_hook( 'af_cron_scan' );
		$freq = AccessFix_Settings::get( 'cron_freq', 'off' );
		if ( 'daily' === $freq || 'weekly' === $freq ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, $freq, 'af_cron_scan' );
		}
	}

	/**
	 * Token that authorises a scanner request to the front end.
	 *
	 * @param int $offset Hours back (0 current, 1 previous).
	 * @return string
	 */
	public static function token( $offset = 0 ) {
		$secret = (string) get_option( 'af_scan_secret', '' );
		return hash_hmac( 'sha256', 'af-scan|' . ( floor( time() / HOUR_IN_SECONDS ) - $offset ), $secret );
	}

	/**
	 * Verify a token.
	 *
	 * @param string $given Token.
	 * @return bool
	 */
	public static function token_valid( $given ) {
		if ( ! is_string( $given ) || '' === $given || '' === (string) get_option( 'af_scan_secret', '' ) ) {
			return false;
		}
		return hash_equals( self::token( 0 ), $given ) || hash_equals( self::token( 1 ), $given );
	}

	/**
	 * Pages to scan.
	 *
	 * @return array List of [post_id, url, title].
	 */
	public static function targets() {
		$types = array_filter( (array) AccessFix_Settings::get( 'post_types', array( 'post', 'page' ) ), 'post_type_exists' );
		$max   = (int) AccessFix_Settings::get( 'max_pages', 300 );
		$out   = array();
		if ( 'posts' === get_option( 'show_on_front' ) || ! (int) get_option( 'page_on_front' ) ) {
			$out[] = array( 'post_id' => 0, 'url' => home_url( '/' ), 'title' => __( 'Home page', 'accessfix' ) );
		}
		if ( $types ) {
			$ids = get_posts(
				array(
					'post_type'        => array_values( $types ),
					'post_status'      => 'publish',
					'posts_per_page'   => $max,
					'orderby'          => 'ID',
					'order'            => 'ASC',
					'has_password'     => false,
					'fields'           => 'ids',
					'no_found_rows'    => true,
					'suppress_filters' => true,
				)
			);
			foreach ( $ids as $id ) {
				$out[] = array( 'post_id' => (int) $id, 'url' => get_permalink( $id ), 'title' => get_the_title( $id ) );
			}
		}
		return apply_filters( 'accessfix_scan_targets', $out );
	}

	/**
	 * Begin a scan.
	 *
	 * @param string $source manual|cron.
	 * @return int Scan id.
	 */
	public static function start( $source = 'manual' ) {
		global $wpdb;
		$scans = AccessFix_Install::table( 'scans' );
		$wpdb->query( "UPDATE $scans SET status = 'aborted' WHERE status = 'running'" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$targets = self::targets();
		$wpdb->insert(
			$scans,
			array(
				'started_at'  => current_time( 'mysql', true ),
				'status'      => 'running',
				'source'      => $source,
				'pages_total' => count( $targets ),
				'targets'     => wp_json_encode( $targets ),
			)
		);
		return (int) $wpdb->insert_id;
	}

	/**
	 * Process the next batch of a scan.
	 *
	 * @param int $scan_id Scan id.
	 * @param int $size    Pages per batch.
	 * @return array|WP_Error Progress.
	 */
	public static function run_batch( $scan_id, $size = 3 ) {
		global $wpdb;
		$scans = AccessFix_Install::table( 'scans' );
		$scan  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $scans WHERE id = %d", $scan_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( ! $scan ) {
			return new WP_Error( 'af_no_scan', __( 'Scan not found.', 'accessfix' ), array( 'status' => 404 ) );
		}
		if ( 'running' !== $scan->status ) {
			return self::progress( $scan );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 120 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}
		$targets = json_decode( (string) $scan->targets, true );
		$targets = is_array( $targets ) ? $targets : array();
		$done    = (int) $scan->pages_done;
		$errors  = (int) $scan->errors;
		$slice   = array_slice( $targets, $done, max( 1, (int) $size ) );
		$current = '';
		foreach ( $slice as $t ) {
			$r = self::scan_url( (int) $t['post_id'], $t['url'], $t['title'], $scan_id );
			if ( is_wp_error( $r ) ) {
				$errors++;
			}
			$done++;
			$current = $t['url'];
		}
		$wpdb->update( $scans, array( 'pages_done' => $done, 'errors' => $errors ), array( 'id' => $scan_id ) );
		if ( $done >= count( $targets ) ) {
			self::finalize( $scan_id );
		}
		$scan = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $scans WHERE id = %d", $scan_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$p    = self::progress( $scan );
		$p['current'] = $current;
		return $p;
	}

	/**
	 * Progress array.
	 *
	 * @param object $scan Scan row.
	 * @return array
	 */
	public static function progress( $scan ) {
		return array(
			'scan_id' => (int) $scan->id,
			'status'  => $scan->status,
			'total'   => (int) $scan->pages_total,
			'done'    => (int) $scan->pages_done,
			'errors'  => (int) $scan->errors,
			'open'    => (int) $scan->open_issues,
			'score'   => (int) $scan->score,
		);
	}

	/**
	 * Close a scan and compute totals.
	 *
	 * @param int $scan_id Scan id.
	 * @return void
	 */
	public static function finalize( $scan_id ) {
		global $wpdb;
		$scans  = AccessFix_Install::table( 'scans' );
		$issues = AccessFix_Install::table( 'issues' );
		$pages  = AccessFix_Install::table( 'pages' );
		// Site-wide CSS fixes that no page reported during this scan are no longer active.
		$wpdb->query( $wpdb->prepare( "DELETE FROM $issues WHERE status = 'fixed' AND check_id IN ('focus-visible','reduced-motion') AND scan_id < %d", $scan_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$open   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $issues WHERE status = 'open'" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$fixed  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $issues WHERE status = 'fixed'" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$score  = $wpdb->get_var( $wpdb->prepare( "SELECT AVG(score) FROM $pages WHERE last_scan_id = %d AND (error IS NULL OR error = '')", $scan_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$prev   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $scans WHERE status = 'done' AND id < %d ORDER BY id DESC LIMIT 1", $scan_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->update(
			$scans,
			array(
				'status'       => 'done',
				'finished_at'  => current_time( 'mysql', true ),
				'open_issues'  => $open,
				'fixed_issues' => $fixed,
				'score'        => (int) round( (float) $score ),
			),
			array( 'id' => $scan_id )
		);
		$scan = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $scans WHERE id = %d", $scan_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		do_action( 'accessfix_scan_finished', $scan, $prev );
		if ( 'cron' === $scan->source && AccessFix_Settings::get( 'email_enabled' ) ) {
			self::send_summary( $scan, $prev );
		}
	}

	/**
	 * Cron: start a scan and queue batches.
	 *
	 * @return void
	 */
	public static function cron_start() {
		$id = self::start( 'cron' );
		wp_schedule_single_event( time() + 5, 'af_cron_batch', array( $id ) );
	}

	/**
	 * Cron: process a batch then re-queue.
	 *
	 * @param int $scan_id Scan id.
	 * @return void
	 */
	public static function cron_batch( $scan_id ) {
		$p = self::run_batch( (int) $scan_id, 5 );
		if ( ! is_wp_error( $p ) && 'running' === $p['status'] ) {
			wp_schedule_single_event( time() + 10, 'af_cron_batch', array( (int) $scan_id ) );
		}
	}

	/**
	 * Email the summary.
	 *
	 * @param object      $scan Scan.
	 * @param object|null $prev Previous scan.
	 * @return bool
	 */
	public static function send_summary( $scan, $prev ) {
		global $wpdb;
		$to = AccessFix_Settings::get( 'email_to' );
		if ( '' === trim( (string) $to ) ) {
			$to = get_option( 'admin_email' );
		}
		$issues = AccessFix_Install::table( 'issues' );
		$top    = $wpdb->get_results( "SELECT check_id, criterion, COUNT(*) AS n FROM $issues WHERE status = 'open' GROUP BY check_id, criterion ORDER BY n DESC LIMIT 5" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$delta  = $prev ? (int) $scan->score - (int) $prev->score : null;
		$lines  = array();
		/* translators: %s: site name */
		$lines[] = sprintf( __( 'Accessibility scan summary for %s', 'accessfix' ), get_bloginfo( 'name' ) );
		$lines[] = str_repeat( '-', 40 );
		/* translators: 1: score, 2: change text */
		$lines[] = sprintf( __( 'Site score: %1$d / 100 %2$s', 'accessfix' ), $scan->score, null === $delta ? '' : sprintf( '(%+d %s)', $delta, __( 'since the previous scan', 'accessfix' ) ) );
		/* translators: 1: pages, 2: errors */
		$lines[] = sprintf( __( 'Pages scanned: %1$d (errors: %2$d)', 'accessfix' ), $scan->pages_done, $scan->errors );
		/* translators: 1: open issues, 2: fixed issues */
		$lines[] = sprintf( __( 'Open issues: %1$d. Fixed automatically: %2$d.', 'accessfix' ), $scan->open_issues, $scan->fixed_issues );
		if ( $top ) {
			$lines[] = '';
			$lines[] = __( 'Most common open problems:', 'accessfix' );
			foreach ( $top as $t ) {
				$c       = AccessFix_Checks::get( $t->check_id );
				$lines[] = sprintf( ' - %s (WCAG %s): %d', $c ? $c['title'] : $t->check_id, $t->criterion, $t->n );
			}
		}
		$lines[] = '';
		$lines[] = admin_url( 'admin.php?page=accessfix' );
		$lines[] = '';
		$lines[] = __( 'Automated scans cannot prove legal compliance. Manual testing is still required.', 'accessfix' );
		/* translators: %s: site name */
		$subject = sprintf( __( '[%s] Accessibility scan summary', 'accessfix' ), wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) );
		return wp_mail( $to, $subject, implode( "\n", $lines ) );
	}

	/**
	 * Fetch stylesheet text for the contrast check (same host only, cached).
	 *
	 * @param array  $links Stylesheet URLs.
	 * @param string $base  Page URL.
	 * @return string[]
	 */
	protected static function fetch_css( $links, $base ) {
		$out  = array();
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		$n    = 0;
		foreach ( $links as $href ) {
			if ( $n >= 12 ) {
				break;
			}
			if ( 0 === strpos( $href, '//' ) ) {
				$href = ( is_ssl() ? 'https:' : 'http:' ) . $href;
			} elseif ( 0 === strpos( $href, '/' ) ) {
				$p    = wp_parse_url( home_url() );
				$href = $p['scheme'] . '://' . $p['host'] . ( isset( $p['port'] ) ? ':' . $p['port'] : '' ) . $href;
			} elseif ( ! preg_match( '#^https?://#i', $href ) ) {
				$href = trailingslashit( $base ) . $href;
			}
			$h = wp_parse_url( $href, PHP_URL_HOST );
			if ( ! $h || strtolower( $h ) !== strtolower( (string) $host ) ) {
				continue;
			}
			$key = 'af_css_' . md5( $href );
			$css = get_transient( $key );
			if ( false === $css ) {
				$r   = wp_remote_get( $href, array( 'timeout' => 10, 'limit_response_size' => 600000, 'sslverify' => (bool) AccessFix_Settings::get( 'sslverify', 1 ), 'headers' => self::auth_headers() ) );
				$css = ( ! is_wp_error( $r ) && 200 === (int) wp_remote_retrieve_response_code( $r ) ) ? wp_remote_retrieve_body( $r ) : '';
				set_transient( $key, $css, 6 * HOUR_IN_SECONDS );
			}
			if ( '' !== $css ) {
				$out[] = $css;
				$n++;
			}
		}
		return $out;
	}

	/**
	 * Optional HTTP basic auth for staging sites.
	 *
	 * @return array
	 */
	protected static function auth_headers() {
		$auth = trim( (string) AccessFix_Settings::get( 'scan_auth', '' ) );
		return '' !== $auth && false !== strpos( $auth, ':' ) ? array( 'Authorization' => 'Basic ' . base64_encode( $auth ) ) : array(); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}

	/**
	 * Fetch one URL as the scanner and return HTML (with fix records removed).
	 *
	 * @param string $url URL.
	 * @return array|WP_Error html, fixes.
	 */
	public static function fetch( $url ) {
		$req = add_query_arg( array( 'accessfix_scan' => self::token(), 'af_ts' => time() ), $url );
		$r   = wp_remote_get(
			$req,
			array(
				'timeout'     => 30,
				'redirection' => 3,
				'sslverify'   => (bool) AccessFix_Settings::get( 'sslverify', 1 ),
				'user-agent'  => 'AccessFix/' . AF_VERSION . '; ' . home_url(),
				'headers'     => self::auth_headers(),
			)
		);
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$code = (int) wp_remote_retrieve_response_code( $r );
		if ( $code < 200 || $code >= 400 ) {
			/* translators: %d: HTTP status code */
			return new WP_Error( 'af_http', sprintf( __( 'The page returned HTTP %d. If the site is behind a password or maintenance mode, enter credentials under Settings > Scanner access.', 'accessfix' ), $code ) );
		}
		$body  = wp_remote_retrieve_body( $r );
		$fixes = array();
		if ( preg_match( '/<!--af-fixes:([A-Za-z0-9+\/=]*)-->/', $body, $m ) ) {
			$j = json_decode( base64_decode( $m[1] ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
			if ( is_array( $j ) ) {
				$fixes = $j;
			}
			$body = str_replace( $m[0], '', $body );
		}
		return array( 'html' => $body, 'fixes' => $fixes );
	}

	/**
	 * Scan one URL and store the results.
	 *
	 * @param int    $post_id Post id (0 = home).
	 * @param string $url     URL.
	 * @param string $title   Title.
	 * @param int    $scan_id Scan id.
	 * @return array|WP_Error
	 */
	public static function scan_url( $post_id, $url, $title, $scan_id ) {
		global $wpdb;
		$pages = AccessFix_Install::table( 'pages' );
		$res   = self::fetch( $url );
		if ( is_wp_error( $res ) ) {
			$wpdb->query( $wpdb->prepare( "DELETE FROM $pages WHERE post_id = %d", $post_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->insert(
				$pages,
				array(
					'post_id'      => $post_id,
					'url'          => $url,
					'title'        => mb_substr( (string) $title, 0, 255 ),
					'score'        => 0,
					'last_scan_id' => $scan_id,
					'last_scanned' => current_time( 'mysql', true ),
					'error'        => $res->get_error_message(),
				)
			);
			return $res;
		}
		$src    = AccessFix_Scanner::style_sources( $res['html'] );
		$css    = self::fetch_css( $src['links'], $url );
		$found  = AccessFix_Scanner::scan( $res['html'], array( 'css' => $css ) );
		$stored = self::store( $post_id, $url, $title, $found, $res['fixes'], $scan_id );
		return $stored;
	}

	/**
	 * Site-wide CSS fixes are stored once (not once per page).
	 *
	 * @param array  $f       Fix record.
	 * @param array  $def     Check definition.
	 * @param string $after   After text.
	 * @param int    $scan_id Scan id.
	 * @param string $now     Timestamp.
	 * @return void
	 */
	protected static function store_sitewide_fix( $f, $def, $after, $scan_id, $now ) {
		global $wpdb;
		$t    = AccessFix_Install::table( 'issues' );
		$hash = md5( 'sitewide|' . $f['check'] );
		$id   = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $t WHERE issue_hash = %s", $hash ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( $id ) {
			$wpdb->update( $t, array( 'scan_id' => $scan_id, 'last_seen' => $now, 'status' => 'fixed' ), array( 'id' => $id ) );
			return;
		}
		$msg = isset( $f['note'] ) && '' !== $f['note'] ? $f['note'] : $def['title'];
		$wpdb->insert(
			$t,
			array(
				'issue_hash'  => $hash,
				'scan_id'     => $scan_id,
				'post_id'     => 0,
				'url'         => home_url( '/' ),
				'check_id'    => $f['check'],
				'criterion'   => $def['sc'],
				'severity'    => $def['severity'],
				'message'     => $msg,
				'snippet'     => '(site-wide stylesheet)',
				'status'      => 'fixed',
				'before_html' => '',
				'after_html'  => $after,
				'first_seen'  => $now,
				'last_seen'   => $now,
				'resolved_at' => $now,
			)
		);
		AccessFix_Audit::log( array( 'post_id' => 0, 'url' => home_url( '/' ), 'check_id' => $f['check'], 'criterion' => $def['sc'], 'action' => 'auto-fixed', 'reason' => $msg . ' ' . __( '(applies to all pages)', 'accessfix' ), 'after' => $after, 'user_id' => 0 ) );
	}

	/**
	 * Reconcile scan results with the database and write audit rows.
	 *
	 * @param int    $post_id Post id.
	 * @param string $url     URL.
	 * @param string $title   Title.
	 * @param array  $found   Issues found.
	 * @param array  $fixes   Fix records.
	 * @param int    $scan_id Scan id.
	 * @return array Summary.
	 */
	public static function store( $post_id, $url, $title, $found, $fixes, $scan_id ) {
		global $wpdb;
		$t     = AccessFix_Install::table( 'issues' );
		$pages = AccessFix_Install::table( 'pages' );
		$now   = current_time( 'mysql', true );
		$existing = array();
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $t WHERE url = %s", $url ) ) as $row ) { // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			if ( in_array( $row->check_id, array( 'focus-visible', 'reduced-motion' ), true ) ) {
				continue; // Site-wide rows are handled separately.
			}
			$existing[ $row->issue_hash ] = $row;
		}
		$seen      = array();
		$ordinals  = array();
		$new_open  = 0;
		$auto_checks = array();
		$open_rows = array();

		foreach ( $found as $i ) {
			$k = $i['check'] . '|' . $i['snippet'];
			$ordinals[ $k ] = isset( $ordinals[ $k ] ) ? $ordinals[ $k ] + 1 : 1;
			$hash = md5( $url . '|' . $k . '|' . $ordinals[ $k ] );
			$seen[ $hash ] = true;
			$msg = $i['message'];
			if ( ! empty( $i['extra_count'] ) ) {
				/* translators: %d: number of further elements */
				$msg .= ' ' . sprintf( _n( '(+%d more element with the same colours)', '(+%d more elements with the same colours)', $i['extra_count'], 'accessfix' ), $i['extra_count'] );
			}
			$sc = ! empty( $i['sc'] ) ? $i['sc'] : '';
			if ( isset( $existing[ $hash ] ) ) {
				$row = $existing[ $hash ];
				$upd = array( 'scan_id' => $scan_id, 'last_seen' => $now, 'message' => $msg, 'selector' => $i['selector'] );
				if ( in_array( $row->status, array( 'fixed-manually', 'fixed' ), true ) ) {
					$upd['status']      = 'open';
					$upd['resolved_at'] = null;
					AccessFix_Audit::log( array( 'post_id' => $post_id, 'url' => $url, 'check_id' => $i['check'], 'criterion' => $row->criterion, 'action' => 'reopened', 'reason' => __( 'Problem detected again by a scan.', 'accessfix' ), 'before' => $i['snippet'], 'user_id' => 0 ) );
				}
				$wpdb->update( $t, $upd, array( 'id' => $row->id ) );
				if ( 'ignored' !== $row->status ) {
					$open_rows[] = array( 'check_id' => $i['check'], 'severity' => $row->severity );
				}
			} else {
				$wpdb->insert(
					$t,
					array(
						'issue_hash' => $hash,
						'scan_id'    => $scan_id,
						'post_id'    => $post_id,
						'url'        => substr( $url, 0, 500 ),
						'check_id'   => $i['check'],
						'criterion'  => $sc,
						'severity'   => $i['severity'],
						'selector'   => $i['selector'],
						'snippet'    => $i['snippet'],
						'message'    => $msg,
						'needle'     => $i['needle'],
						'status'     => 'open',
						'first_seen' => $now,
						'last_seen'  => $now,
					)
				);
				AccessFix_Audit::log( array( 'post_id' => $post_id, 'url' => $url, 'check_id' => $i['check'], 'criterion' => $sc, 'action' => 'detected', 'reason' => $msg, 'before' => $i['snippet'], 'user_id' => 0 ) );
				$new_open++;
				$open_rows[] = array( 'check_id' => $i['check'], 'severity' => $i['severity'] );
			}
		}

		// Fix records produced by the render-time fixers.
		$fix_n = 0;
		$ford  = array();
		foreach ( (array) $fixes as $f ) {
			if ( empty( $f['check'] ) ) {
				continue;
			}
			$def = AccessFix_Checks::get( $f['check'] );
			if ( ! $def ) {
				continue;
			}
			$before = isset( $f['before'] ) ? (string) $f['before'] : '';
			$after  = isset( $f['after'] ) ? (string) $f['after'] : '';
			if ( in_array( $f['check'], array( 'focus-visible', 'reduced-motion' ), true ) ) {
				self::store_sitewide_fix( $f, $def, $after, $scan_id, $now );
				continue;
			}
			$auto_checks[ $f['check'] ][] = $before;
			$k      = 'fix|' . $f['check'] . '|' . $before;
			$ford[ $k ] = isset( $ford[ $k ] ) ? $ford[ $k ] + 1 : 1;
			$hash   = md5( $url . '|' . $k . '|' . $ford[ $k ] );
			$seen[ $hash ] = true;
			$fix_n++;
			if ( isset( $existing[ $hash ] ) ) {
				$wpdb->update( $t, array( 'scan_id' => $scan_id, 'last_seen' => $now, 'after_html' => $after ), array( 'id' => $existing[ $hash ]->id ) );
				if ( 'fixed' !== $existing[ $hash ]->status ) {
					$wpdb->update( $t, array( 'status' => 'fixed' ), array( 'id' => $existing[ $hash ]->id ) );
				}
				continue;
			}
			$msg = isset( $f['note'] ) && '' !== $f['note'] ? $f['note'] : $def['title'];
			$wpdb->insert(
				$t,
				array(
					'issue_hash'  => $hash,
					'scan_id'     => $scan_id,
					'post_id'     => $post_id,
					'url'         => substr( $url, 0, 500 ),
					'check_id'    => $f['check'],
					'criterion'   => $def['sc'],
					'severity'    => $def['severity'],
					'selector'    => isset( $f['selector'] ) ? $f['selector'] : '',
					'snippet'     => $before,
					'message'     => $msg,
					'needle'      => isset( $f['needle'] ) ? $f['needle'] : '',
					'status'      => 'fixed',
					'before_html' => $before,
					'after_html'  => $after,
					'first_seen'  => $now,
					'last_seen'   => $now,
					'resolved_at' => $now,
				)
			);
			AccessFix_Audit::log( array( 'post_id' => $post_id, 'url' => $url, 'check_id' => $f['check'], 'criterion' => $def['sc'], 'action' => 'auto-fixed', 'reason' => $msg, 'before' => $before, 'after' => $after, 'user_id' => 0 ) );
		}

		// Things that were open and are gone now.
		foreach ( $existing as $hash => $row ) {
			if ( isset( $seen[ $hash ] ) ) {
				continue;
			}
			if ( 'open' === $row->status ) {
				$by_fixer = false;
				if ( isset( $auto_checks[ $row->check_id ] ) ) {
					foreach ( $auto_checks[ $row->check_id ] as $b ) {
						if ( '' === (string) $row->needle || false !== stripos( $b, (string) $row->needle ) ) {
							$by_fixer = true;
							break;
						}
					}
				}
				if ( $by_fixer ) {
					// Resolved by an automatic fixer: the fix record carries the evidence.
					$wpdb->delete( $t, array( 'id' => $row->id ) );
				} else {
					$wpdb->update( $t, array( 'status' => 'fixed-manually', 'resolved_at' => $now, 'scan_id' => $scan_id ), array( 'id' => $row->id ) );
					AccessFix_Audit::log( array( 'post_id' => $post_id, 'url' => $url, 'check_id' => $row->check_id, 'criterion' => $row->criterion, 'action' => 'manually-fixed', 'reason' => __( 'No longer detected by the latest scan.', 'accessfix' ), 'before' => $row->snippet, 'user_id' => 0 ) );
				}
			} elseif ( 'fixed' === $row->status ) {
				$wpdb->delete( $t, array( 'id' => $row->id ) );
			}
		}

		$score = AccessFix_Checks::score( $open_rows );
		$wpdb->query( $wpdb->prepare( "DELETE FROM $pages WHERE post_id = %d", $post_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->insert(
			$pages,
			array(
				'post_id'      => $post_id,
				'url'          => substr( $url, 0, 500 ),
				'title'        => mb_substr( (string) $title, 0, 255 ),
				'score'        => $score,
				'open_count'   => count( $open_rows ),
				'fixed_count'  => $fix_n,
				'last_scan_id' => $scan_id,
				'last_scanned' => $now,
				'error'        => '',
			)
		);
		return array( 'score' => $score, 'open' => count( $open_rows ), 'fixed' => $fix_n, 'new' => $new_open );
	}
}
