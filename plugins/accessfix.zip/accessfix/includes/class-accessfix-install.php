<?php
/**
 * Activation, tables and upgrades.
 *
 * @package AccessFix
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Installer.
 */
class AccessFix_Install {

	/**
	 * Table name helper.
	 *
	 * @param string $name issues|audit|scans|pages.
	 * @return string
	 */
	public static function table( $name ) {
		global $wpdb;
		return $wpdb->prefix . 'af_' . $name;
	}

	/**
	 * Activation.
	 *
	 * @return void
	 */
	public static function activate() {
		self::create_tables();
		if ( false === get_option( AccessFix_Settings::OPTION ) ) {
			add_option( AccessFix_Settings::OPTION, AccessFix_Settings::defaults(), '', false );
		}
		self::ensure_secret();
		AccessFix_Runner::reschedule();
	}

	/**
	 * Deactivation: stop the scheduled scans (data is kept).
	 *
	 * @return void
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( 'af_cron_scan' );
		wp_clear_scheduled_hook( 'af_cron_batch' );
	}

	/**
	 * Secret used to sign scanner requests.
	 *
	 * @return void
	 */
	public static function ensure_secret() {
		if ( ! get_option( 'af_scan_secret' ) ) {
			add_option( 'af_scan_secret', wp_generate_password( 40, false ), '', false );
		}
	}

	/**
	 * Run an upgrade when the stored DB version is old.
	 *
	 * @return void
	 */
	public static function maybe_upgrade() {
		if ( get_option( 'af_db_version' ) !== AF_DB_VERSION ) {
			self::create_tables();
			self::ensure_secret();
		}
	}

	/**
	 * Create or update tables.
	 *
	 * @return void
	 */
	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		$issues  = self::table( 'issues' );
		$audit   = self::table( 'audit' );
		$scans   = self::table( 'scans' );
		$pages   = self::table( 'pages' );

		dbDelta(
			"CREATE TABLE $issues (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			issue_hash char(32) NOT NULL,
			scan_id bigint(20) unsigned NOT NULL DEFAULT 0,
			post_id bigint(20) unsigned NOT NULL DEFAULT 0,
			url varchar(500) NOT NULL DEFAULT '',
			check_id varchar(40) NOT NULL DEFAULT '',
			criterion varchar(10) NOT NULL DEFAULT '',
			severity varchar(10) NOT NULL DEFAULT 'moderate',
			selector text NULL,
			snippet text NULL,
			message text NULL,
			needle text NULL,
			status varchar(20) NOT NULL DEFAULT 'open',
			ignore_reason text NULL,
			before_html text NULL,
			after_html text NULL,
			first_seen datetime NOT NULL,
			last_seen datetime NOT NULL,
			resolved_at datetime NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY issue_hash (issue_hash),
			KEY post_id (post_id),
			KEY status (status),
			KEY check_id (check_id)
		) $charset;"
		);

		dbDelta(
			"CREATE TABLE $audit (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			logged_at datetime NOT NULL,
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			user_login varchar(60) NOT NULL DEFAULT '',
			post_id bigint(20) unsigned NOT NULL DEFAULT 0,
			url varchar(500) NOT NULL DEFAULT '',
			check_id varchar(40) NOT NULL DEFAULT '',
			criterion varchar(10) NOT NULL DEFAULT '',
			action varchar(20) NOT NULL DEFAULT '',
			reason text NULL,
			before_html text NULL,
			after_html text NULL,
			PRIMARY KEY  (id),
			KEY action (action),
			KEY post_id (post_id),
			KEY logged_at (logged_at)
		) $charset;"
		);

		dbDelta(
			"CREATE TABLE $scans (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			started_at datetime NOT NULL,
			finished_at datetime NULL,
			status varchar(12) NOT NULL DEFAULT 'running',
			source varchar(12) NOT NULL DEFAULT 'manual',
			pages_total int(11) NOT NULL DEFAULT 0,
			pages_done int(11) NOT NULL DEFAULT 0,
			errors int(11) NOT NULL DEFAULT 0,
			open_issues int(11) NOT NULL DEFAULT 0,
			fixed_issues int(11) NOT NULL DEFAULT 0,
			score int(11) NOT NULL DEFAULT 0,
			targets longtext NULL,
			PRIMARY KEY  (id),
			KEY status (status)
		) $charset;"
		);

		dbDelta(
			"CREATE TABLE $pages (
			post_id bigint(20) unsigned NOT NULL,
			url varchar(500) NOT NULL DEFAULT '',
			title varchar(255) NOT NULL DEFAULT '',
			score int(11) NOT NULL DEFAULT 100,
			open_count int(11) NOT NULL DEFAULT 0,
			fixed_count int(11) NOT NULL DEFAULT 0,
			last_scan_id bigint(20) unsigned NOT NULL DEFAULT 0,
			last_scanned datetime NULL,
			error text NULL,
			PRIMARY KEY  (post_id)
		) $charset;"
		);
		update_option( 'af_db_version', AF_DB_VERSION, false );
	}
}
