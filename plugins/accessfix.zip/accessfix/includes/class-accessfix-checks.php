<?php
/**
 * Registry of checks and the WCAG 2.2 criteria they map to.
 *
 * @package AccessFix
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Check registry.
 */
class AccessFix_Checks {

	/**
	 * Severity weights used for the score.
	 *
	 * @return array
	 */
	public static function weights() {
		return array(
			'critical' => 12,
			'serious'  => 8,
			'moderate' => 4,
			'minor'    => 1.5,
		);
	}

	/**
	 * Names and levels of the success criteria we reference.
	 *
	 * @return array sc => [name, level].
	 */
	public static function criteria() {
		return array(
			'1.1.1' => array( __( 'Non-text Content', 'accessfix' ), 'A' ),
			'1.3.1' => array( __( 'Info and Relationships', 'accessfix' ), 'A' ),
			'1.4.2' => array( __( 'Audio Control', 'accessfix' ), 'A' ),
			'1.4.3' => array( __( 'Contrast (Minimum)', 'accessfix' ), 'AA' ),
			'1.4.4' => array( __( 'Resize Text', 'accessfix' ), 'AA' ),
			'2.2.2' => array( __( 'Pause, Stop, Hide', 'accessfix' ), 'A' ),
			'2.4.1' => array( __( 'Bypass Blocks', 'accessfix' ), 'A' ),
			'2.4.2' => array( __( 'Page Titled', 'accessfix' ), 'A' ),
			'2.4.3' => array( __( 'Focus Order', 'accessfix' ), 'A' ),
			'2.4.4' => array( __( 'Link Purpose (In Context)', 'accessfix' ), 'A' ),
			'2.4.6' => array( __( 'Headings and Labels', 'accessfix' ), 'AA' ),
			'2.4.7' => array( __( 'Focus Visible', 'accessfix' ), 'AA' ),
			'2.5.8' => array( __( 'Target Size (Minimum)', 'accessfix' ), 'AA' ),
			'3.1.1' => array( __( 'Language of Page', 'accessfix' ), 'A' ),
			'3.2.5' => array( __( 'Change on Request', 'accessfix' ), 'AAA' ),
			'3.3.2' => array( __( 'Labels or Instructions', 'accessfix' ), 'A' ),
			'4.1.2' => array( __( 'Name, Role, Value', 'accessfix' ), 'A' ),
		);
	}

	/**
	 * Full check definitions.
	 *
	 * @return array id => definition.
	 */
	public static function all() {
		$c = array(
			'img-alt-missing'   => array( __( 'Image has no alt attribute', 'accessfix' ), '1.1.1', 'critical', __( 'Add alt text describing the image, or alt="" if it is purely decorative. Use the Alt Text screen to do this in bulk.', 'accessfix' ), true ),
			'img-alt-decorative' => array( __( 'Decorative image is exposed to assistive technology', 'accessfix' ), '1.1.1', 'moderate', __( 'Images marked role="presentation"/aria-hidden, or tiny spacer images, should have alt="".', 'accessfix' ), true ),
			'img-alt-filename'  => array( __( 'Alt text looks like a file name', 'accessfix' ), '1.1.1', 'moderate', __( 'Replace the file name with a short description of what the image shows.', 'accessfix' ), false ),
			'link-empty'        => array( __( 'Link has no content', 'accessfix' ), '2.4.4', 'serious', __( 'Remove the empty link or give it visible text.', 'accessfix' ), false ),
			'link-name'         => array( __( 'Link has no accessible name', 'accessfix' ), '4.1.2', 'serious', __( 'Add visible text, an aria-label, or alt text on the icon image. Icon-only links can be labelled automatically with the map in Settings.', 'accessfix' ), true ),
			'link-vague'        => array( __( 'Link text is not descriptive ("click here", "read more")', 'accessfix' ), '2.4.4', 'moderate', __( 'Make the link text describe its destination, or add an aria-label that does.', 'accessfix' ), false ),
			'button-name'       => array( __( 'Button has no accessible name', 'accessfix' ), '4.1.2', 'critical', __( 'Add visible text or an aria-label to the button.', 'accessfix' ), false ),
			'input-label'       => array( __( 'Form field has no label', 'accessfix' ), '3.3.2', 'critical', __( 'Associate a <label for="..."> with the field, or add aria-label. A placeholder is not a label.', 'accessfix' ), false ),
			'duplicate-id'      => array( __( 'Duplicate id attribute', 'accessfix' ), '4.1.2', 'moderate', __( 'IDs must be unique. (WCAG 2.2 removed 4.1.1 Parsing, but duplicate IDs still break label and ARIA references under 4.1.2.)', 'accessfix' ), true ),
			'heading-skip'      => array( __( 'Heading level skipped', 'accessfix' ), '1.3.1', 'moderate', __( 'Do not skip heading levels (for example H2 to H4). Change the heading level in the editor.', 'accessfix' ), false ),
			'h1-missing'        => array( __( 'Page has no H1', 'accessfix' ), '2.4.6', 'moderate', __( 'Add one H1 describing the page.', 'accessfix' ), false ),
			'h1-multiple'       => array( __( 'Page has more than one H1', 'accessfix' ), '1.3.1', 'minor', __( 'Use a single H1 per page.', 'accessfix' ), false ),
			'heading-empty'     => array( __( 'Heading is empty', 'accessfix' ), '2.4.6', 'moderate', __( 'Remove the empty heading or add text to it.', 'accessfix' ), false ),
			'html-lang'         => array( __( 'Page language is not set', 'accessfix' ), '3.1.1', 'serious', __( 'The <html> element needs a lang attribute.', 'accessfix' ), true ),
			'page-title'        => array( __( 'Page has no title', 'accessfix' ), '2.4.2', 'serious', __( 'Add a <title> element (add_theme_support("title-tag") in the theme).', 'accessfix' ), true ),
			'iframe-title'      => array( __( 'iframe has no title', 'accessfix' ), '4.1.2', 'serious', __( 'Add a title attribute describing the embedded content.', 'accessfix' ), true ),
			'table-headers'     => array( __( 'Data table has no header cells', 'accessfix' ), '1.3.1', 'serious', __( 'Use <th> for header cells (the table block has a "Header section" option).', 'accessfix' ), true ),
			'new-window'        => array( __( 'Link opens in a new tab without warning', 'accessfix' ), '3.2.5', 'minor', __( 'Tell users the link opens in a new tab. (Advisory: WCAG technique G201; the criterion itself is Level AAA.)', 'accessfix' ), true ),
			'contrast'          => array( __( 'Text contrast is too low', 'accessfix' ), '1.4.3', 'serious', __( 'Use colours with at least 4.5:1 contrast (3:1 for large text).', 'accessfix' ), false ),
			'skip-link'         => array( __( 'No skip link', 'accessfix' ), '2.4.1', 'serious', __( 'Add a link near the top of the page that jumps to the main content.', 'accessfix' ), true ),
			'main-landmark'     => array( __( 'No main landmark', 'accessfix' ), '1.3.1', 'moderate', __( 'Wrap the page content in a <main> element.', 'accessfix' ), true ),
			'autoplay'          => array( __( 'Media plays automatically', 'accessfix' ), '1.4.2', 'serious', __( 'Remove autoplay, or make sure sound is off and a pause control exists.', 'accessfix' ), true ),
			'tap-target'        => array( __( 'Target smaller than 24x24 CSS pixels', 'accessfix' ), '2.5.8', 'moderate', __( 'Make the clickable area at least 24x24 px, or leave 24 px of spacing. (Only inline sizes are detected.)', 'accessfix' ), false ),
			'meta-viewport'     => array( __( 'Zooming is disabled', 'accessfix' ), '1.4.4', 'serious', __( 'Remove user-scalable=no and maximum-scale below 2 from the viewport meta tag.', 'accessfix' ), true ),
			'focus-outline'     => array( __( 'Focus outline removed with inline style', 'accessfix' ), '2.4.7', 'serious', __( 'Do not set outline:none on focusable elements without an alternative focus style.', 'accessfix' ), false ),
			'tabindex-positive' => array( __( 'Positive tabindex', 'accessfix' ), '2.4.3', 'moderate', __( 'Use tabindex="0" or "-1" only; positive values scramble the focus order.', 'accessfix' ), false ),
			// Fix-only entries (no detection, recorded when the CSS fixers are applied).
			'focus-visible'     => array( __( 'Visible keyboard focus style added', 'accessfix' ), '2.4.7', 'minor', __( 'A site-wide :focus-visible outline was added.', 'accessfix' ), true ),
			'reduced-motion'    => array( __( 'Reduced-motion preference respected', 'accessfix' ), '2.2.2', 'minor', __( 'Animations are shortened for visitors who ask for reduced motion.', 'accessfix' ), true ),
		);
		$out = array();
		foreach ( $c as $id => $d ) {
			$out[ $id ] = array(
				'id'       => $id,
				'title'    => $d[0],
				'sc'       => $d[1],
				'severity' => $d[2],
				'help'     => $d[3],
				'fixable'  => $d[4],
			);
		}
		return apply_filters( 'accessfix_checks', $out );
	}

	/**
	 * One check.
	 *
	 * @param string $id Check id.
	 * @return array|null
	 */
	public static function get( $id ) {
		$all = self::all();
		return isset( $all[ $id ] ) ? $all[ $id ] : null;
	}

	/**
	 * "1.1.1 Non-text Content (A)".
	 *
	 * @param string $sc Criterion number.
	 * @return string
	 */
	public static function sc_label( $sc ) {
		$c = self::criteria();
		if ( isset( $c[ $sc ] ) ) {
			return sprintf( '%s %s (%s)', $sc, $c[ $sc ][0], $c[ $sc ][1] );
		}
		return $sc;
	}

	/**
	 * Link to the W3C "Understanding" page.
	 *
	 * @param string $sc Criterion.
	 * @return string
	 */
	public static function sc_url( $sc ) {
		$map = array(
			'1.1.1' => 'non-text-content', '1.3.1' => 'info-and-relationships', '1.4.2' => 'audio-control', '1.4.3' => 'contrast-minimum',
			'1.4.4' => 'resize-text', '2.2.2' => 'pause-stop-hide', '2.4.1' => 'bypass-blocks', '2.4.2' => 'page-titled',
			'2.4.3' => 'focus-order', '2.4.4' => 'link-purpose-in-context', '2.4.6' => 'headings-and-labels', '2.4.7' => 'focus-visible',
			'2.5.8' => 'target-size-minimum', '3.1.1' => 'language-of-page', '3.2.5' => 'change-on-request', '3.3.2' => 'labels-or-instructions',
			'4.1.2' => 'name-role-value',
		);
		return isset( $map[ $sc ] ) ? 'https://www.w3.org/WAI/WCAG22/Understanding/' . $map[ $sc ] . '.html' : 'https://www.w3.org/TR/WCAG22/';
	}

	/**
	 * Score for a set of open issues.
	 *
	 * @param array $issues Rows with check_id and severity.
	 * @return int 0-100.
	 */
	public static function score( $issues ) {
		$w      = self::weights();
		$groups = array();
		foreach ( $issues as $i ) {
			$k = is_object( $i ) ? $i->check_id : $i['check_id'];
			$s = is_object( $i ) ? $i->severity : $i['severity'];
			if ( ! isset( $groups[ $k ] ) ) {
				$groups[ $k ] = array( 's' => $s, 'n' => 0 );
			}
			$groups[ $k ]['n']++;
		}
		$pen = 0;
		foreach ( $groups as $g ) {
			$weight = isset( $w[ $g['s'] ] ) ? $w[ $g['s'] ] : 1;
			$pen   += $weight * ( 1 + 0.5 * log( $g['n'] ) );
		}
		return (int) max( 0, round( 100 - $pen ) );
	}
}
