<?php
/**
 * Plugin Name:       AccessFix – WCAG 2.2 & EAA Accessibility Fixes with Audit Log
 * Plugin URI:        https://keepsofttools.github.io/keepsoft-demos/
 * Description:       Scans your published content for WCAG 2.2 problems, fixes what can be fixed safely at the source, and keeps an append-only audit log you can export as CSV or a PDF evidence report. Not an overlay.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Keepsoft
 * Author URI:        https://keepsofttools.github.io/keepsoft-demos/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       accessfix
 * Domain Path:       /languages
 *
 * @package AccessFix
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AF_VERSION', '1.0.0' );
define( 'AF_FILE', __FILE__ );
define( 'AF_PATH', plugin_dir_path( __FILE__ ) );
define( 'AF_URL', plugin_dir_url( __FILE__ ) );
define( 'AF_DB_VERSION', '1.0' );

$af_includes = array(
	'settings', 'checks', 'color', 'scanner', 'audit', 'pdf', 'runner', 'fixers',
	'media', 'statement', 'dashboard', 'rest', 'admin', 'install',
);
foreach ( $af_includes as $af_inc ) {
	require_once AF_PATH . 'includes/class-accessfix-' . $af_inc . '.php';
}
unset( $af_includes, $af_inc );

register_activation_hook( __FILE__, array( 'AccessFix_Install', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'AccessFix_Install', 'deactivate' ) );

/**
 * Boot the plugin.
 *
 * @return void
 */
function af_init() {
	AccessFix_Install::maybe_upgrade();
	AccessFix_Fixers::init();
	AccessFix_Runner::init();
	AccessFix_Media::init();
	AccessFix_Statement::init();
	AccessFix_REST::init();
	AccessFix_Admin::init();
}
add_action( 'plugins_loaded', 'af_init' );

/**
 * Settings link on the plugins screen.
 *
 * @param array $links Existing links.
 * @return array
 */
function af_action_links( $links ) {
	array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=accessfix' ) ) . '">' . esc_html__( 'Dashboard', 'accessfix' ) . '</a>' );
	return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'af_action_links' );
