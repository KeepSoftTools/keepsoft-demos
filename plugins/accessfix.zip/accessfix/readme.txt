=== AccessFix – WCAG 2.2 & EAA Accessibility Fixes with Audit Log ===
Contributors: keepsoft
Tags: accessibility, wcag, eaa, a11y, audit
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Scan your site for WCAG 2.2 problems, fix what can be fixed safely at the source, and keep an append-only audit log with CSV and PDF evidence. Not an overlay.

== Description ==

AccessFix is not an overlay widget. It does not inject a toolbar or JavaScript into your visitors' browsers. It finds problems in the HTML your site really outputs, corrects the safe ones on the server, and writes down everything it did.

**What it does**

* Scans published pages, posts and products (batched, with a progress bar) and checks 25+ WCAG 2.2 problems: missing and filename alt text, decorative images, empty and vague links, buttons and form fields without names, duplicate IDs, heading order, H1, language, page title, iframe titles, data tables without headers, new-window links, colour contrast (inline styles plus simple CSS), skip link, main landmark, autoplay, small inline tap targets, zoom blocking, removed focus outlines and positive tabindex.
* Maps every problem to a WCAG success criterion and a severity, and gives a score per page and for the site, with a trend over scans.
* Fixes at render time (server side): lang, title, viewport zoom, main landmark, skip link, image alt from the Media Library, icon-only link labels, iframe titles, new-window warnings, table headers, duplicate IDs, autoplay, focus-visible and prefers-reduced-motion CSS. Each fix is verified by re-reading the served HTML and recorded.
* Bulk alt-text editor with "used in" context, a decorative flag, and optional AI suggestions through any OpenAI-compatible vision API (reviewed by a person, never saved automatically).
* "Fix in editor" links that open the post and select the offending block.
* Append-only audit log with before/after snippets, exportable as CSV and as a PDF Accessibility Evidence Report.
* Accessibility statement generator following the EU model statement structure, with known limitations drafted from your open issues, published with [accessfix_statement].
* Dashboard with an EAA readiness checklist, scheduled rescans with WP-Cron and an email summary.

**Honest limits**

Automated testing finds only a portion of accessibility problems. AccessFix does not guarantee, certify or prove compliance with WCAG, EN 301 549, the European Accessibility Act, the ADA or any other law. Colour contrast is only evaluated where colours can be derived from inline styles and simple stylesheet rules (no gradients, images, pseudo-classes, media queries or JavaScript-applied styles).

== Installation ==

1. Upload the `accessfix` folder to `/wp-content/plugins/` or install the zip via Plugins > Add New > Upload.
2. Activate the plugin.
3. Open AccessFix > Dashboard and click "Scan now".

== Frequently Asked Questions ==

= Is this an accessibility overlay? =
No. Nothing is added to the page for visitors to interact with. HTML is corrected on the server and your stored content is not changed.

= Will it make my site legally compliant? =
No tool can. AccessFix gives you detection, fixes and evidence. You still need manual testing and, where required, legal advice.

= Does it work with caching plugins? =
Yes. The fixes are part of the generated HTML so cached pages contain them. Scanner requests carry a signed token and a unique query string to bypass page caches; if your cache ignores query strings, exclude URLs containing `accessfix_scan`.

= The scan fails with an HTTP error =
The scanner requests your own public URLs. If the site is behind a password or maintenance mode, enter HTTP basic-auth credentials under AccessFix > Settings. Hosts that block loopback requests need that fixed first.

= Where is my data stored? =
In four custom tables (af_issues, af_audit, af_scans, af_pages) and a few options. Data is kept when you delete the plugin unless you tick "Delete all AccessFix data" in Settings first.

= Which external services are contacted? =
None, unless you enable AI suggestions, in which case the image you click "Suggest" on is sent to the API endpoint you configure.

== Changelog ==

= 1.0.0 =
* Initial release.
