<?php
/**
 * Uninstall QuoteSign. Data is removed only if the store owner opted in
 * (WooCommerce > Settings > Quotes > Remove all data on uninstall).
 *
 * @package QuoteSign
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

wp_clear_scheduled_hook( 'quotesign_daily' );

$qs_opts = get_option( 'quotesign_settings', array() );
if ( empty( $qs_opts['remove_data'] ) || 'yes' !== $qs_opts['remove_data'] ) {
	return;
}

global $wpdb;

$qs_ids = get_posts(
	array(
		'post_type'      => 'qs_quote',
		'post_status'    => 'any',
		'numberposts'    => -1,
		'fields'         => 'ids',
		'no_found_rows'  => true,
	)
);
foreach ( $qs_ids as $qs_id ) {
	wp_delete_post( $qs_id, true );
}

// Orphaned order meta that points back at quotes (works for posts and HPOS storage).
$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->postmeta} WHERE meta_key = %s", '_qs_quote_id' ) );
$qs_hpos_meta = $wpdb->prefix . 'wc_orders_meta';
if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $qs_hpos_meta ) ) === $qs_hpos_meta ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$qs_hpos_meta} WHERE meta_key = %s", '_qs_quote_id' ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}
$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->postmeta} WHERE meta_key = %s", '_qs_enable_quote' ) );

delete_option( 'quotesign_settings' );
delete_option( 'quotesign_version' );
delete_option( 'woocommerce_qs_new_request_settings' );
delete_option( 'woocommerce_qs_request_received_settings' );
delete_option( 'woocommerce_qs_quote_sent_settings' );
delete_option( 'woocommerce_qs_quote_accepted_settings' );
delete_option( 'woocommerce_qs_quote_accepted_admin_settings' );
delete_option( 'woocommerce_qs_quote_reminder_settings' );
delete_option( 'woocommerce_qs_quote_declined_settings' );

$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_qs\_%' OR option_name LIKE '\_transient\_timeout\_qs\_%'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
