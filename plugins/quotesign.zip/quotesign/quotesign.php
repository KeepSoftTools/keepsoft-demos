<?php
/**
 * Plugin Name:       QuoteSign – Request a Quote, E-Signature & Deposits for WooCommerce
 * Plugin URI:        https://keepsofttools.github.io/keepsoft-demos/
 * Description:       Let customers request quotes, send tokenised quote links, collect legally-minded e-signatures, and take deposits through WooCommerce checkout.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Keepsoft
 * Author URI:        https://keepsofttools.github.io/keepsoft-demos/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       quotesign
 * Domain Path:       /languages
 * WC requires at least: 6.0
 * WC tested up to:   11.2
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

define( 'QUOTESIGN_VERSION', '1.0.0' );
define( 'QUOTESIGN_FILE', __FILE__ );
define( 'QUOTESIGN_PATH', plugin_dir_path( __FILE__ ) );
define( 'QUOTESIGN_URL', plugin_dir_url( __FILE__ ) );

require_once QUOTESIGN_PATH . 'includes/class-quotesign-plugin.php';

register_activation_hook( __FILE__, array( 'QuoteSign_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'QuoteSign_Plugin', 'deactivate' ) );

add_action( 'before_woocommerce_init', 'quotesign_declare_compat' );
/**
 * Declare compatibility with WooCommerce HPOS and checkout blocks.
 */
function quotesign_declare_compat() {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', QUOTESIGN_FILE, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', QUOTESIGN_FILE, true );
	}
}

add_action( 'plugins_loaded', array( 'QuoteSign_Plugin', 'instance' ), 20 );
