<?php
/**
 * REST API endpoints (basket + accept/decline).
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

/**
 * Routes under /wp-json/quotesign/v1/.
 */
class QuoteSign_REST {

	const NS = 'quotesign/v1';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	/**
	 * Register routes.
	 *
	 * The basket routes are public by design (guests request quotes). The
	 * accept/decline routes are authorised by the unguessable per-quote token
	 * in the URL, which is verified in the handler.
	 */
	public static function routes() {
		$public = '__return_true';
		register_rest_route( self::NS, '/basket/add', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'basket_add' ),
			'permission_callback' => $public,
		) );
		register_rest_route( self::NS, '/basket/update', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'basket_update' ),
			'permission_callback' => $public,
		) );
		register_rest_route( self::NS, '/basket/remove', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'basket_remove' ),
			'permission_callback' => $public,
		) );
		register_rest_route( self::NS, '/basket/submit', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'basket_submit' ),
			'permission_callback' => $public,
		) );
		register_rest_route( self::NS, '/quote/(?P<token>[A-Za-z0-9]{24,64})/accept', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'accept' ),
			'permission_callback' => $public,
		) );
		register_rest_route( self::NS, '/quote/(?P<token>[A-Za-z0-9]{24,64})/decline', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'decline' ),
			'permission_callback' => $public,
		) );
	}

	/**
	 * Simple per-IP rate limit.
	 *
	 * @param string $bucket Bucket name.
	 * @param int    $max    Max hits.
	 * @param int    $window Seconds.
	 * @return bool True when allowed.
	 */
	private static function rate_ok( $bucket, $max, $window ) {
		$key  = 'qs_rl_' . md5( $bucket . '|' . QuoteSign_Quote::client_ip() );
		$hits = (int) get_transient( $key );
		if ( $hits >= $max ) {
			return false;
		}
		set_transient( $key, $hits + 1, $window );
		return true;
	}

	/**
	 * Basket payload response.
	 *
	 * @param string $notice Notice.
	 * @return WP_REST_Response
	 */
	private static function basket_response( $notice = '' ) {
		return rest_ensure_response(
			array(
				'ok'    => true,
				'count' => QuoteSign_Basket::count(),
				'html'  => QuoteSign_Basket::render( $notice ),
			)
		);
	}

	/**
	 * Add to basket.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function basket_add( $request ) {
		if ( ! QuoteSign_Rules::enabled() ) {
			return new WP_Error( 'qs_disabled', __( 'Quotes are disabled.', 'quotesign' ), array( 'status' => 403 ) );
		}
		if ( ! self::rate_ok( 'add', 120, HOUR_IN_SECONDS ) ) {
			return new WP_Error( 'qs_rate', __( 'Too many requests. Please try again later.', 'quotesign' ), array( 'status' => 429 ) );
		}
		$r = QuoteSign_Basket::add(
			absint( $request->get_param( 'product_id' ) ),
			absint( $request->get_param( 'variation_id' ) ),
			absint( $request->get_param( 'qty' ) )
		);
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return rest_ensure_response(
			array(
				'ok'    => true,
				'count' => QuoteSign_Basket::count(),
			)
		);
	}

	/**
	 * Update quantities.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function basket_update( $request ) {
		$qtys = $request->get_param( 'qty' );
		QuoteSign_Basket::update( is_array( $qtys ) ? array_map( 'intval', $qtys ) : array() );
		return self::basket_response();
	}

	/**
	 * Remove a line.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function basket_remove( $request ) {
		QuoteSign_Basket::remove( preg_replace( '/[^0-9\-]/', '', (string) $request->get_param( 'key' ) ) );
		return self::basket_response();
	}

	/**
	 * Submit the basket as a quote request.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function basket_submit( $request ) {
		if ( ! QuoteSign_Rules::enabled() ) {
			return new WP_Error( 'qs_disabled', __( 'Quotes are disabled.', 'quotesign' ), array( 'status' => 403 ) );
		}
		// Honeypot: silently succeed.
		if ( '' !== trim( (string) $request->get_param( 'website' ) ) ) {
			QuoteSign_Basket::clear();
			return self::basket_response( __( 'Thank you! Your quote request has been received.', 'quotesign' ) );
		}
		if ( ! self::rate_ok( 'submit', 5, 10 * MINUTE_IN_SECONDS ) ) {
			return new WP_Error( 'qs_rate', __( 'Too many requests. Please try again later.', 'quotesign' ), array( 'status' => 429 ) );
		}

		$name    = sanitize_text_field( (string) $request->get_param( 'name' ) );
		$email   = sanitize_email( (string) $request->get_param( 'email' ) );
		$phone   = sanitize_text_field( (string) $request->get_param( 'phone' ) );
		$company = sanitize_text_field( (string) $request->get_param( 'company' ) );
		$note    = sanitize_textarea_field( (string) $request->get_param( 'note' ) );

		if ( '' === $name ) {
			return new WP_Error( 'qs_name', __( 'Please enter your name.', 'quotesign' ), array( 'status' => 400 ) );
		}
		if ( ! is_email( $email ) ) {
			return new WP_Error( 'qs_email', __( 'Please enter a valid email address.', 'quotesign' ), array( 'status' => 400 ) );
		}
		if ( 'yes' === QuoteSign_Settings::get( 'phone_required' ) && '' === $phone ) {
			return new WP_Error( 'qs_phone', __( 'Please enter your phone number.', 'quotesign' ), array( 'status' => 400 ) );
		}
		$items = QuoteSign_Basket::items();
		if ( empty( $items ) ) {
			return new WP_Error( 'qs_empty', __( 'Your quote basket is empty.', 'quotesign' ), array( 'status' => 400 ) );
		}

		$lines = array();
		foreach ( $items as $item ) {
			$lines[] = array(
				'product_id'   => $item['product_id'],
				'variation_id' => $item['variation_id'],
				'name'         => $item['name'],
				'sku'          => $item['sku'],
				'qty'          => $item['qty'],
				'price'        => $item['price'],
			);
		}

		$customer_id = 0;
		if ( is_user_logged_in() ) {
			$customer_id = get_current_user_id();
		} else {
			$user = get_user_by( 'email', $email );
			if ( $user ) {
				$customer_id = (int) $user->ID;
			}
		}

		$quote = QuoteSign_Quote::create(
			array(
				'name'        => $name,
				'email'       => $email,
				'phone'       => $phone,
				'company'     => $company,
				'note'        => $note,
				'items'       => $lines,
				'customer_id' => $customer_id,
				'source'      => __( 'Submitted from quote basket', 'quotesign' ),
			)
		);
		if ( is_wp_error( $quote ) ) {
			return new WP_Error( 'qs_create', __( 'Could not save your request. Please try again.', 'quotesign' ), array( 'status' => 500 ) );
		}
		QuoteSign_Basket::clear();
		do_action( 'quotesign_quote_created', $quote );

		return self::basket_response( __( 'Thank you! Your quote request has been received. We will email you a quote shortly.', 'quotesign' ) );
	}

	/**
	 * Validate and normalise a PNG data URL.
	 *
	 * @param string $data Data URL.
	 * @return string|WP_Error
	 */
	private static function clean_signature_png( $data ) {
		$prefix = 'data:image/png;base64,';
		if ( 0 !== strpos( $data, $prefix ) || strlen( $data ) > 700000 ) {
			return new WP_Error( 'qs_sig', __( 'Invalid signature image.', 'quotesign' ), array( 'status' => 400 ) );
		}
		$raw = base64_decode( substr( $data, strlen( $prefix ) ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
		if ( false === $raw || '' === $raw ) {
			return new WP_Error( 'qs_sig', __( 'Invalid signature image.', 'quotesign' ), array( 'status' => 400 ) );
		}
		$info = @getimagesizefromstring( $raw ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		if ( ! $info || 'image/png' !== $info['mime'] || $info[0] > 2000 || $info[1] > 1000 || $info[0] < 20 || $info[1] < 10 ) {
			return new WP_Error( 'qs_sig', __( 'Invalid signature image.', 'quotesign' ), array( 'status' => 400 ) );
		}
		// Re-encode to strip anything that is not pixel data.
		if ( function_exists( 'imagecreatefromstring' ) && function_exists( 'imagepng' ) ) {
			$im = @imagecreatefromstring( $raw ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			if ( ! $im ) {
				return new WP_Error( 'qs_sig', __( 'Invalid signature image.', 'quotesign' ), array( 'status' => 400 ) );
			}
			imagealphablending( $im, false );
			imagesavealpha( $im, true );
			ob_start();
			imagepng( $im, null, 9 );
			$raw = ob_get_clean();
			imagedestroy( $im );
		}
		return $prefix . base64_encode( $raw ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
	}

	/**
	 * Accept (sign) a quote.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function accept( $request ) {
		if ( ! self::rate_ok( 'accept', 20, HOUR_IN_SECONDS ) ) {
			return new WP_Error( 'qs_rate', __( 'Too many requests. Please try again later.', 'quotesign' ), array( 'status' => 429 ) );
		}
		$quote = QuoteSign_Quote::find_by_token( $request['token'] );
		if ( ! $quote ) {
			return new WP_Error( 'qs_404', __( 'Quote not found.', 'quotesign' ), array( 'status' => 404 ) );
		}
		if ( $quote->is_past_expiry() && in_array( $quote->status(), array( 'sent', 'viewed' ), true ) ) {
			$quote->set_status( 'expired', __( 'Expiry date passed', 'quotesign' ) );
		}
		if ( ! $quote->is_open() ) {
			return new WP_Error( 'qs_closed', __( 'This quote can no longer be accepted.', 'quotesign' ), array( 'status' => 409 ) );
		}

		$name  = trim( sanitize_text_field( (string) $request->get_param( 'name' ) ) );
		$mode  = 'drawn' === $request->get_param( 'mode' ) ? 'drawn' : 'typed';
		$agree = filter_var( $request->get_param( 'agree' ), FILTER_VALIDATE_BOOLEAN );

		if ( strlen( $name ) < 2 || strlen( $name ) > 120 ) {
			return new WP_Error( 'qs_name', __( 'Please type your full name.', 'quotesign' ), array( 'status' => 400 ) );
		}
		if ( ! $agree ) {
			return new WP_Error( 'qs_agree', __( 'You must agree to the terms to accept this quote.', 'quotesign' ), array( 'status' => 400 ) );
		}
		$image = '';
		if ( 'drawn' === $mode ) {
			$image = self::clean_signature_png( (string) $request->get_param( 'signature' ) );
			if ( is_wp_error( $image ) ) {
				return $image;
			}
		}

		// Single-use lock so a double click cannot create two orders.
		if ( ! add_post_meta( $quote->id, '_qs_accept_lock', time(), true ) ) {
			return new WP_Error( 'qs_closed', __( 'This quote is already being processed.', 'quotesign' ), array( 'status' => 409 ) );
		}

		update_post_meta(
			$quote->id,
			'_qs_signature',
			array(
				'name' => $name,
				'mode' => $mode,
				'data' => $image,
				'time' => time(),
				'ip'   => QuoteSign_Quote::client_ip(),
				'ua'   => QuoteSign_Quote::client_ua(),
			)
		);
		update_post_meta( $quote->id, '_qs_accepted_at', time() );
		$quote->log( 'terms_agreed', '', true );
		$quote->log(
			'signed',
			sprintf(
				/* translators: 1: signer name, 2: typed or drawn */
				__( 'Signed by %1$s (%2$s signature)', 'quotesign' ),
				$name,
				'drawn' === $mode ? __( 'drawn', 'quotesign' ) : __( 'typed', 'quotesign' )
			),
			true
		);

		$redirect = '';
		if ( 'yes' === QuoteSign_Settings::get( 'create_order' ) ) {
			$order = QuoteSign_Orders::create_for_quote( $quote, 'deposit' );
			if ( is_wp_error( $order ) ) {
				$quote->log( 'order_error', $order->get_error_message() );
			} else {
				$redirect = $order->get_checkout_payment_url();
			}
		}

		$quote->set_status( 'accepted', __( 'Quote accepted by customer', 'quotesign' ), true );
		delete_post_meta( $quote->id, '_qs_accept_lock' );

		return rest_ensure_response(
			array(
				'ok'       => true,
				'message'  => __( 'Thank you. Your signed quote has been emailed to you.', 'quotesign' ),
				'redirect' => $redirect,
			)
		);
	}

	/**
	 * Decline a quote.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function decline( $request ) {
		if ( ! self::rate_ok( 'decline', 20, HOUR_IN_SECONDS ) ) {
			return new WP_Error( 'qs_rate', __( 'Too many requests. Please try again later.', 'quotesign' ), array( 'status' => 429 ) );
		}
		$quote = QuoteSign_Quote::find_by_token( $request['token'] );
		if ( ! $quote ) {
			return new WP_Error( 'qs_404', __( 'Quote not found.', 'quotesign' ), array( 'status' => 404 ) );
		}
		if ( ! $quote->is_open() ) {
			return new WP_Error( 'qs_closed', __( 'This quote can no longer be changed.', 'quotesign' ), array( 'status' => 409 ) );
		}
		$reason = sanitize_text_field( (string) $request->get_param( 'reason' ) );
		if ( '' !== $reason ) {
			update_post_meta( $quote->id, '_qs_decline_reason', $reason );
		}
		$quote->set_status( 'declined', __( 'Quote declined by customer', 'quotesign' ), true );
		return rest_ensure_response( array( 'ok' => true ) );
	}
}
