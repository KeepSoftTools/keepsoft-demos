<?php
/**
 * Quote basket (cookie + transient storage, no PHP sessions).
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

/**
 * Basket handling and shortcode.
 */
class QuoteSign_Basket {

	const COOKIE = 'qs_basket';

	/**
	 * Cached id.
	 *
	 * @var string
	 */
	private static $id = '';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_shortcode( 'quotesign_basket', array( __CLASS__, 'shortcode' ) );
	}

	/**
	 * Basket identifier from cookie. Optionally create it.
	 *
	 * @param bool $create Create if missing.
	 * @return string
	 */
	public static function get_id( $create = false ) {
		if ( '' !== self::$id ) {
			return self::$id;
		}
		if ( isset( $_COOKIE[ self::COOKIE ] ) ) {
			$id = preg_replace( '/[^a-zA-Z0-9]/', '', sanitize_text_field( wp_unslash( $_COOKIE[ self::COOKIE ] ) ) );
			if ( 32 === strlen( $id ) ) {
				self::$id = $id;
				return $id;
			}
		}
		if ( $create ) {
			self::$id = wp_generate_password( 32, false, false );
			if ( ! headers_sent() ) {
				setcookie(
					self::COOKIE,
					self::$id,
					array(
						'expires'  => time() + 7 * DAY_IN_SECONDS,
						'path'     => COOKIEPATH ? COOKIEPATH : '/',
						'domain'   => COOKIE_DOMAIN,
						'secure'   => is_ssl(),
						'httponly' => true,
						'samesite' => 'Lax',
					)
				);
			}
			$_COOKIE[ self::COOKIE ] = self::$id;
		}
		return self::$id;
	}

	/**
	 * Raw items array key => [product_id, variation_id, qty].
	 *
	 * @return array
	 */
	public static function raw() {
		$id = self::get_id();
		if ( '' === $id ) {
			return array();
		}
		$data = get_transient( 'qs_basket_' . $id );
		return is_array( $data ) ? $data : array();
	}

	/**
	 * Save raw.
	 *
	 * @param array $data Data.
	 */
	private static function save( $data ) {
		$id = self::get_id( true );
		set_transient( 'qs_basket_' . $id, $data, 7 * DAY_IN_SECONDS );
	}

	/**
	 * Item count (number of lines).
	 *
	 * @return int
	 */
	public static function count() {
		return count( self::raw() );
	}

	/**
	 * Add a product.
	 *
	 * @param int $product_id   Product.
	 * @param int $variation_id Variation.
	 * @param int $qty          Quantity.
	 * @return true|WP_Error
	 */
	public static function add( $product_id, $variation_id, $qty ) {
		$product = wc_get_product( $product_id );
		if ( ! $product || 'publish' !== get_post_status( $product_id ) || $product->is_type( 'variation' ) ) {
			return new WP_Error( 'qs_invalid_product', __( 'This product is not available.', 'quotesign' ), array( 'status' => 400 ) );
		}
		if ( ! QuoteSign_Rules::show_button( $product ) ) {
			return new WP_Error( 'qs_not_allowed', __( 'Quotes are not available for this product.', 'quotesign' ), array( 'status' => 403 ) );
		}
		if ( $product->is_type( 'variable' ) ) {
			$variation = $variation_id ? wc_get_product( $variation_id ) : null;
			if ( ! $variation || (int) $variation->get_parent_id() !== (int) $product_id ) {
				return new WP_Error( 'qs_choose_options', __( 'Please choose the product options first.', 'quotesign' ), array( 'status' => 400 ) );
			}
		} else {
			$variation_id = 0;
		}
		$qty = max( 1, min( 9999, (int) $qty ) );
		$key = $product_id . '-' . $variation_id;

		$data = self::raw();
		if ( isset( $data[ $key ] ) ) {
			$data[ $key ]['qty'] = min( 9999, $data[ $key ]['qty'] + $qty );
		} else {
			if ( count( $data ) >= 100 ) {
				return new WP_Error( 'qs_full', __( 'Your quote basket is full.', 'quotesign' ), array( 'status' => 400 ) );
			}
			$data[ $key ] = array(
				'product_id'   => (int) $product_id,
				'variation_id' => (int) $variation_id,
				'qty'          => $qty,
			);
		}
		self::save( $data );
		return true;
	}

	/**
	 * Update quantities.
	 *
	 * @param array $qtys key => qty.
	 */
	public static function update( $qtys ) {
		$data = self::raw();
		foreach ( (array) $qtys as $key => $qty ) {
			$key = (string) $key;
			if ( ! isset( $data[ $key ] ) ) {
				continue;
			}
			$qty = (int) $qty;
			if ( $qty <= 0 ) {
				unset( $data[ $key ] );
			} else {
				$data[ $key ]['qty'] = min( 9999, $qty );
			}
		}
		self::save( $data );
	}

	/**
	 * Remove a line.
	 *
	 * @param string $key Key.
	 */
	public static function remove( $key ) {
		$data = self::raw();
		unset( $data[ (string) $key ] );
		self::save( $data );
	}

	/**
	 * Empty basket.
	 */
	public static function clear() {
		$id = self::get_id();
		if ( $id ) {
			delete_transient( 'qs_basket_' . $id );
		}
	}

	/**
	 * Resolved items with product objects.
	 *
	 * @return array
	 */
	public static function items() {
		$out = array();
		foreach ( self::raw() as $key => $row ) {
			$product = wc_get_product( $row['variation_id'] ? $row['variation_id'] : $row['product_id'] );
			if ( ! $product ) {
				continue;
			}
			$name = $product->get_name();
			if ( $product->is_type( 'variation' ) ) {
				$attrs = wc_get_formatted_variation( $product, true, false );
				$parent = wc_get_product( $row['product_id'] );
				$name   = ( $parent ? $parent->get_name() : $name ) . ( $attrs ? ' (' . $attrs . ')' : '' );
			}
			$out[ $key ] = array(
				'key'          => $key,
				'product'      => $product,
				'product_id'   => (int) $row['product_id'],
				'variation_id' => (int) $row['variation_id'],
				'qty'          => (int) $row['qty'],
				'name'         => $name,
				'sku'          => $product->get_sku(),
				'price'        => (float) $product->get_price(),
				'url'          => get_permalink( $row['product_id'] ),
			);
		}
		return $out;
	}

	/**
	 * Render the basket HTML.
	 *
	 * @param string $notice Optional success notice.
	 * @return string
	 */
	public static function render( $notice = '' ) {
		$user = wp_get_current_user();
		$prefill = array(
			'name'    => '',
			'email'   => '',
			'phone'   => '',
			'company' => '',
		);
		if ( $user && $user->exists() ) {
			$prefill['name']    = trim( $user->first_name . ' ' . $user->last_name );
			$prefill['name']    = '' !== $prefill['name'] ? $prefill['name'] : $user->display_name;
			$prefill['email']   = $user->user_email;
			$prefill['phone']   = (string) get_user_meta( $user->ID, 'billing_phone', true );
			$prefill['company'] = (string) get_user_meta( $user->ID, 'billing_company', true );
		}
		ob_start();
		wc_get_template(
			'basket.php',
			array(
				'items'    => self::items(),
				'prefill'  => $prefill,
				'notice'   => $notice,
				'phone_required' => 'yes' === QuoteSign_Settings::get( 'phone_required' ),
				'shop_url' => wc_get_page_permalink( 'shop' ),
			),
			'quotesign/',
			QUOTESIGN_PATH . 'templates/'
		);
		return ob_get_clean();
	}

	/**
	 * Shortcode.
	 *
	 * @return string
	 */
	public static function shortcode() {
		if ( ! QuoteSign_Rules::enabled() ) {
			return '';
		}
		QuoteSign_Frontend::enqueue( true );
		return '<div class="qs-basket-wrap" data-qs-basket>' . self::render() . '</div>';
	}

	/**
	 * Basket page URL.
	 *
	 * @return string
	 */
	public static function page_url() {
		$id = (int) QuoteSign_Settings::get( 'basket_page' );
		return $id && get_post( $id ) ? get_permalink( $id ) : home_url( '/' );
	}
}
