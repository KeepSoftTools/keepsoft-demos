<?php
/**
 * Dashboard widget.
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

/**
 * Quotes by status and value accepted this month.
 */
class QuoteSign_Dashboard {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'register' ) );
	}

	/**
	 * Register widget.
	 */
	public static function register() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		wp_add_dashboard_widget( 'quotesign_dashboard', __( 'Quotes', 'quotesign' ), array( __CLASS__, 'render' ) );
		wp_enqueue_style( 'quotesign-admin', QUOTESIGN_URL . 'assets/css/admin.css', array(), QUOTESIGN_VERSION );
	}

	/**
	 * Accepted value this month, grouped by currency.
	 *
	 * @return array currency => amount.
	 */
	public static function accepted_this_month() {
		$start = new DateTime( 'first day of this month 00:00:00', wp_timezone() );
		$ids   = get_posts(
			array(
				'post_type'      => 'qs_quote',
				'post_status'    => 'publish',
				'posts_per_page' => 1000,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery
					'relation' => 'AND',
					array(
						'key'   => '_qs_status',
						'value' => 'accepted',
					),
					array(
						'key'     => '_qs_accepted_at',
						'value'   => $start->getTimestamp(),
						'compare' => '>=',
						'type'    => 'NUMERIC',
					),
				),
			)
		);
		$sum = array();
		foreach ( $ids as $id ) {
			$q = QuoteSign_Quote::get( $id );
			if ( ! $q ) {
				continue;
			}
			$t   = $q->totals();
			$cur = $q->currency();
			$sum[ $cur ] = ( isset( $sum[ $cur ] ) ? $sum[ $cur ] : 0 ) + $t['total'];
		}
		return $sum;
	}

	/**
	 * Status counts.
	 *
	 * @return array slug => count.
	 */
	public static function counts() {
		global $wpdb;
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT m.meta_value AS s, COUNT(*) AS c FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_qs_status' WHERE p.post_type = %s AND p.post_status = 'publish' GROUP BY m.meta_value",
				'qs_quote'
			)
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$out = array_fill_keys( array_keys( QuoteSign_Quote::statuses() ), 0 );
		foreach ( (array) $rows as $r ) {
			if ( isset( $out[ $r->s ] ) ) {
				$out[ $r->s ] = (int) $r->c;
			}
		}
		return $out;
	}

	/**
	 * Render.
	 */
	public static function render() {
		$counts = self::counts();
		$max    = max( 1, max( $counts ) );
		$sum    = self::accepted_this_month();

		echo '<div class="qs-dash">';
		echo '<div class="qs-dash-value"><span>' . esc_html__( 'Accepted this month', 'quotesign' ) . '</span><strong>';
		if ( empty( $sum ) ) {
			echo wp_kses_post( wc_price( 0 ) );
		} else {
			$parts = array();
			foreach ( $sum as $cur => $amt ) {
				$parts[] = wc_price( $amt, array( 'currency' => $cur ) );
			}
			echo wp_kses_post( implode( ' + ', $parts ) );
		}
		echo '</strong></div><ul class="qs-dash-bars">';
		foreach ( QuoteSign_Quote::statuses() as $slug => $label ) {
			$url = add_query_arg(
				array(
					'post_type' => 'qs_quote',
					'qs_status' => $slug,
				),
				admin_url( 'edit.php' )
			);
			printf(
				'<li><a href="%1$s"><span class="qs-dash-label">%2$s</span><span class="qs-dash-track"><span class="qs-dash-fill qs-status-%3$s" style="width:%4$d%%"></span></span><span class="qs-dash-count">%5$d</span></a></li>',
				esc_url( $url ),
				esc_html( $label ),
				esc_attr( $slug ),
				(int) round( $counts[ $slug ] / $max * 100 ),
				(int) $counts[ $slug ]
			);
		}
		echo '</ul></div>';
	}
}
