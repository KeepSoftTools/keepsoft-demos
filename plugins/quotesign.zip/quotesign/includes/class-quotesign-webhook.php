<?php
/**
 * Outgoing webhook.
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

/**
 * Sends signed JSON to the configured URL.
 */
class QuoteSign_Webhook {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'quotesign_quote_created', array( __CLASS__, 'on_created' ) );
		add_action( 'quotesign_status_changed', array( __CLASS__, 'on_status' ), 10, 3 );
	}

	/**
	 * Quote created.
	 *
	 * @param QuoteSign_Quote $quote Quote.
	 */
	public static function on_created( $quote ) {
		self::send( 'quote.created', $quote );
	}

	/**
	 * Status changed.
	 *
	 * @param QuoteSign_Quote $quote Quote.
	 * @param string          $new   New status.
	 */
	public static function on_status( $quote, $new ) {
		if ( in_array( $new, array( 'sent', 'viewed', 'accepted', 'declined', 'expired' ), true ) ) {
			self::send( 'quote.' . $new, $quote );
		}
	}

	/**
	 * Build payload (never includes the signature image).
	 *
	 * @param string          $event Event.
	 * @param QuoteSign_Quote $quote Quote.
	 * @return array
	 */
	public static function payload( $event, $quote ) {
		$t   = $quote->totals();
		$sig = $quote->signature();
		$data = array(
			'event'     => $event,
			'timestamp' => gmdate( 'c' ),
			'site'      => home_url(),
			'quote'     => array(
				'id'        => $quote->id,
				'number'    => $quote->number(),
				'status'    => $quote->status(),
				'currency'  => $quote->currency(),
				'expiry'    => $quote->expiry(),
				'url'       => $quote->url(),
				'customer'  => array(
					'name'    => $quote->customer_name(),
					'email'   => $quote->customer_email(),
					'phone'   => (string) $quote->meta( 'phone' ),
					'company' => (string) $quote->meta( 'company' ),
				),
				'items'     => array_values( $quote->items() ),
				'totals'    => $t,
				'orders'    => array(
					'deposit' => (int) $quote->meta( 'deposit_order_id', 0 ),
					'balance' => (int) $quote->meta( 'balance_order_id', 0 ),
				),
			),
		);
		if ( $sig ) {
			$data['quote']['signature'] = array(
				'name' => $sig['name'],
				'mode' => $sig['mode'],
				'time' => gmdate( 'c', (int) $sig['time'] ),
				'ip'   => $sig['ip'],
			);
		}
		return apply_filters( 'quotesign_webhook_payload', $data, $event, $quote );
	}

	/**
	 * Send a webhook.
	 *
	 * @param string          $event Event name.
	 * @param QuoteSign_Quote $quote Quote.
	 */
	public static function send( $event, $quote ) {
		$url = (string) QuoteSign_Settings::get( 'webhook_url' );
		if ( '' === $url || ! wp_http_validate_url( $url ) ) {
			return;
		}
		$body   = wp_json_encode( self::payload( $event, $quote ) );
		$secret = (string) QuoteSign_Settings::get( 'webhook_secret' );
		$args   = array(
			'timeout'  => 5,
			'blocking' => (bool) apply_filters( 'quotesign_webhook_blocking', false ),
			'headers'  => array(
				'Content-Type'          => 'application/json',
				'X-QuoteSign-Event'     => $event,
				'X-QuoteSign-Signature' => 'sha256=' . hash_hmac( 'sha256', $body, $secret ),
			),
			'body'     => $body,
		);
		$res = wp_safe_remote_post( $url, $args );
		if ( is_wp_error( $res ) ) {
			$quote->log( 'webhook_error', $res->get_error_message() );
		}
	}
}
