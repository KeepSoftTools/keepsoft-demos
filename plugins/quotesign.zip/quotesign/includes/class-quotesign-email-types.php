<?php
/**
 * WC_Email subclasses. Loaded lazily once WooCommerce's email API exists.
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WC_Email' ) ) {
	return;
}

/**
 * Shared behaviour.
 */
abstract class QuoteSign_Email_Base extends WC_Email {

	/** @var QuoteSign_Quote|null */
	public $quote = null;
	/** @var string Temp PDF path. */
	protected $pdf_path = '';
	/** @var bool Attach the PDF. */
	protected $attach_pdf = false;
	/** @var bool Email is for the shop admin. */
	protected $to_admin = false;
	/** @var string Order pay URL for the template. */
	public $pay_url = '';

	/**
	 * Common construction.
	 */
	protected function qs_setup() {
		$this->template_base  = QUOTESIGN_PATH . 'templates/';
		$this->template_html  = 'emails/qs-email.php';
		$this->template_plain = 'emails/plain/qs-email.php';
		$this->placeholders   = array(
			'{quote_number}'  => '',
			'{customer_name}' => '',
		);
	}

	/**
	 * Intro paragraph.
	 *
	 * @param QuoteSign_Quote $quote Quote.
	 * @return string
	 */
	abstract public function intro( $quote );

	/**
	 * Button label and URL.
	 *
	 * @param QuoteSign_Quote $quote Quote.
	 * @return array [label, url] or empty.
	 */
	public function button( $quote ) {
		return array();
	}

	/**
	 * Whether the email should list the items.
	 *
	 * @return bool
	 */
	public function show_items() {
		return true;
	}

	/**
	 * Trigger.
	 *
	 * @param int $quote_id Quote ID.
	 * @param int $order_id Optional order ID (balance emails).
	 */
	public function trigger( $quote_id, $order_id = 0 ) {
		$quote = QuoteSign_Quote::get( $quote_id );
		if ( ! $quote ) {
			return;
		}
		$this->quote  = $quote;
		$this->object = $quote;
		$this->placeholders['{quote_number}']  = $quote->number();
		$this->placeholders['{customer_name}'] = $quote->customer_name();
		$this->pay_url = '';
		if ( $order_id ) {
			$order = wc_get_order( $order_id );
			if ( $order ) {
				$this->pay_url = $order->get_checkout_payment_url();
			}
		}
		$this->recipient = $this->to_admin ? $this->get_option( 'recipient', QuoteSign_Settings::admin_email() ) : $quote->customer_email();

		if ( ! $this->is_enabled() || ! $this->get_recipient() ) {
			return;
		}
		$this->pdf_path = '';
		if ( $this->attach_pdf ) {
			$this->pdf_path = (string) QuoteSign_PDF::to_temp_file( $quote );
		}
		$this->setup_locale();
		$ok = $this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
		$this->restore_locale();
		if ( $this->pdf_path && file_exists( $this->pdf_path ) ) {
			wp_delete_file( $this->pdf_path );
		}
		$this->pdf_path = '';
		if ( $ok ) {
			$quote->log( 'email_sent', $this->get_title() . ' - ' . $this->get_recipient() );
		}
	}

	/**
	 * Attachments (adds PDF).
	 *
	 * @return array
	 */
	public function get_attachments() {
		$a = parent::get_attachments();
		if ( $this->pdf_path ) {
			$a[] = $this->pdf_path;
		}
		return $a;
	}

	/**
	 * Template args.
	 *
	 * @param bool $plain Plain text.
	 * @return array
	 */
	protected function template_args( $plain ) {
		$btn = $this->button( $this->quote );
		return array(
			'email_heading'      => $this->get_heading(),
			'quote'              => $this->quote,
			'intro'              => $this->intro( $this->quote ),
			'button_label'       => isset( $btn[0] ) ? $btn[0] : '',
			'button_url'         => isset( $btn[1] ) ? $btn[1] : '',
			'show_items'         => $this->show_items(),
			'additional_content' => $this->get_additional_content(),
			'sent_to_admin'      => $this->to_admin,
			'plain_text'         => $plain,
			'email'              => $this,
		);
	}

	/**
	 * HTML body.
	 *
	 * @return string
	 */
	public function get_content_html() {
		return wc_get_template_html( $this->template_html, $this->template_args( false ), '', $this->template_base );
	}

	/**
	 * Plain body.
	 *
	 * @return string
	 */
	public function get_content_plain() {
		return wc_get_template_html( $this->template_plain, $this->template_args( true ), '', $this->template_base );
	}

	/**
	 * Default additional content.
	 *
	 * @return string
	 */
	public function get_default_additional_content() {
		return '';
	}

	/**
	 * Add a recipient field for admin emails.
	 */
	public function init_form_fields() {
		parent::init_form_fields();
		if ( $this->to_admin ) {
			$fields = array();
			foreach ( $this->form_fields as $key => $field ) {
				if ( 'subject' === $key ) {
					$fields['recipient'] = array(
						'title'       => __( 'Recipient(s)', 'quotesign' ),
						'type'        => 'text',
						/* translators: %s: admin email */
						'description' => sprintf( __( 'Enter recipients (comma separated) for this email. Defaults to %s.', 'quotesign' ), '<code>' . esc_html( QuoteSign_Settings::admin_email() ) . '</code>' ),
						'placeholder' => '',
						'default'     => '',
						'desc_tip'    => true,
					);
				}
				$fields[ $key ] = $field;
			}
			$this->form_fields = $fields;
		}
	}

	/**
	 * Recipient with fallback to the QuoteSign admin email.
	 *
	 * @param string $key Option key.
	 * @param mixed  $empty_value Value when empty.
	 * @return mixed
	 */
	public function get_option( $key, $empty_value = null ) {
		$v = parent::get_option( $key, $empty_value );
		if ( 'recipient' === $key && ( '' === $v || null === $v ) ) {
			return QuoteSign_Settings::admin_email();
		}
		return $v;
	}
}

/** Admin: new quote request. */
class QuoteSign_Email_New_Request extends QuoteSign_Email_Base {
	/** Constructor. */
	public function __construct() {
		$this->id             = 'qs_new_request';
		$this->title          = __( 'Quote: new request (admin)', 'quotesign' );
		$this->description    = __( 'Sent to the shop when a customer submits a quote request.', 'quotesign' );
		$this->to_admin       = true;
		$this->customer_email = false;
		$this->qs_setup();
		$this->subject = __( '[{site_title}] New quote request {quote_number}', 'quotesign' );
		$this->heading = __( 'New quote request', 'quotesign' );
		parent::__construct();
	}
	/** @inheritDoc */
	public function get_default_subject() {
		return __( '[{site_title}] New quote request {quote_number}', 'quotesign' );
	}
	/** @inheritDoc */
	public function get_default_heading() {
		return __( 'New quote request', 'quotesign' );
	}
	/** @inheritDoc */
	public function intro( $quote ) {
		/* translators: %s: customer name */
		return sprintf( __( '%s has requested a quote. Open it in the dashboard to set prices and send it.', 'quotesign' ), $quote->customer_name() );
	}
	/** @inheritDoc */
	public function button( $quote ) {
		return array( __( 'Open quote', 'quotesign' ), admin_url( 'post.php?post=' . $quote->id . '&action=edit' ) );
	}
}

/** Customer: request received. */
class QuoteSign_Email_Request_Received extends QuoteSign_Email_Base {
	/** Constructor. */
	public function __construct() {
		$this->id             = 'qs_request_received';
		$this->title          = __( 'Quote: request received (customer)', 'quotesign' );
		$this->description    = __( 'Confirmation sent to the customer after they submit a quote request.', 'quotesign' );
		$this->customer_email = true;
		$this->qs_setup();
		parent::__construct();
	}
	/** @inheritDoc */
	public function get_default_subject() {
		return __( 'We received your quote request {quote_number}', 'quotesign' );
	}
	/** @inheritDoc */
	public function get_default_heading() {
		return __( 'Thanks, we have your request', 'quotesign' );
	}
	/** @inheritDoc */
	public function intro( $quote ) {
		/* translators: %s: customer name */
		return sprintf( __( 'Hi %s, thanks for your request. We will review it and email you a quote shortly. Here is what you asked for:', 'quotesign' ), $quote->customer_name() );
	}
}

/** Customer: quote sent. */
class QuoteSign_Email_Quote_Sent extends QuoteSign_Email_Base {
	/** Constructor. */
	public function __construct() {
		$this->id             = 'qs_quote_sent';
		$this->title          = __( 'Quote: sent (customer)', 'quotesign' );
		$this->description    = __( 'Sent to the customer with the secure link to review and sign their quote.', 'quotesign' );
		$this->customer_email = true;
		$this->attach_pdf     = true;
		$this->qs_setup();
		parent::__construct();
	}
	/** @inheritDoc */
	public function get_default_subject() {
		return __( 'Your quote {quote_number} from {site_title}', 'quotesign' );
	}
	/** @inheritDoc */
	public function get_default_heading() {
		return __( 'Your quote is ready', 'quotesign' );
	}
	/** @inheritDoc */
	public function intro( $quote ) {
		$text = sprintf( /* translators: %s: customer name */ __( 'Hi %s, your quote is ready. Please review it and, if you are happy, accept and sign online.', 'quotesign' ), $quote->customer_name() );
		if ( $quote->expiry() ) {
			$text .= ' ' . sprintf( /* translators: %s: date */ __( 'This quote is valid until %s.', 'quotesign' ), mysql2date( get_option( 'date_format' ), $quote->expiry() ) );
		}
		return $text;
	}
	/** @inheritDoc */
	public function button( $quote ) {
		return array( __( 'View & accept quote', 'quotesign' ), $quote->url() );
	}
}

/** Customer: signed copy. */
class QuoteSign_Email_Quote_Accepted extends QuoteSign_Email_Base {
	/** Constructor. */
	public function __construct() {
		$this->id             = 'qs_quote_accepted';
		$this->title          = __( 'Quote: signed copy (customer)', 'quotesign' );
		$this->description    = __( 'Sent to the customer after they sign, with the signed PDF attached.', 'quotesign' );
		$this->customer_email = true;
		$this->attach_pdf     = true;
		$this->qs_setup();
		parent::__construct();
	}
	/** @inheritDoc */
	public function get_default_subject() {
		return __( 'Signed quote {quote_number}', 'quotesign' );
	}
	/** @inheritDoc */
	public function get_default_heading() {
		return __( 'Thank you, your quote is signed', 'quotesign' );
	}
	/** @inheritDoc */
	public function intro( $quote ) {
		/* translators: %s: customer name */
		return sprintf( __( 'Hi %s, thank you for accepting your quote. A signed copy with the full audit trail is attached for your records.', 'quotesign' ), $quote->customer_name() );
	}
	/** @inheritDoc */
	public function button( $quote ) {
		$id = (int) $quote->meta( 'deposit_order_id', 0 );
		if ( $id ) {
			$order = wc_get_order( $id );
			if ( $order && $order->needs_payment() ) {
				return array( __( 'Pay now', 'quotesign' ), $order->get_checkout_payment_url() );
			}
		}
		return array();
	}
}

/** Admin: signed copy. */
class QuoteSign_Email_Accepted_Admin extends QuoteSign_Email_Base {
	/** Constructor. */
	public function __construct() {
		$this->id             = 'qs_quote_accepted_admin';
		$this->title          = __( 'Quote: signed copy (admin)', 'quotesign' );
		$this->description    = __( 'Sent to the shop when a customer signs, with the signed PDF attached.', 'quotesign' );
		$this->to_admin       = true;
		$this->customer_email = false;
		$this->attach_pdf     = true;
		$this->qs_setup();
		parent::__construct();
	}
	/** @inheritDoc */
	public function get_default_subject() {
		return __( '[{site_title}] Quote {quote_number} was accepted', 'quotesign' );
	}
	/** @inheritDoc */
	public function get_default_heading() {
		return __( 'Quote accepted', 'quotesign' );
	}
	/** @inheritDoc */
	public function intro( $quote ) {
		/* translators: %s: customer name */
		return sprintf( __( '%s accepted and signed the quote. The signed PDF is attached.', 'quotesign' ), $quote->customer_name() );
	}
	/** @inheritDoc */
	public function button( $quote ) {
		return array( __( 'Open quote', 'quotesign' ), admin_url( 'post.php?post=' . $quote->id . '&action=edit' ) );
	}
}

/** Admin: declined. */
class QuoteSign_Email_Quote_Declined extends QuoteSign_Email_Base {
	/** Constructor. */
	public function __construct() {
		$this->id             = 'qs_quote_declined';
		$this->title          = __( 'Quote: declined (admin)', 'quotesign' );
		$this->description    = __( 'Sent to the shop when a customer declines a quote.', 'quotesign' );
		$this->to_admin       = true;
		$this->customer_email = false;
		$this->qs_setup();
		parent::__construct();
	}
	/** @inheritDoc */
	public function get_default_subject() {
		return __( '[{site_title}] Quote {quote_number} was declined', 'quotesign' );
	}
	/** @inheritDoc */
	public function get_default_heading() {
		return __( 'Quote declined', 'quotesign' );
	}
	/** @inheritDoc */
	public function intro( $quote ) {
		$text = sprintf( /* translators: %s: customer name */ __( '%s declined the quote.', 'quotesign' ), $quote->customer_name() );
		$reason = (string) $quote->meta( 'decline_reason' );
		if ( '' !== $reason ) {
			$text .= ' ' . sprintf( /* translators: %s: reason */ __( 'Reason given: %s', 'quotesign' ), $reason );
		}
		return $text;
	}
	/** @inheritDoc */
	public function button( $quote ) {
		return array( __( 'Open quote', 'quotesign' ), admin_url( 'post.php?post=' . $quote->id . '&action=edit' ) );
	}
}

/** Customer: expiry reminder. */
class QuoteSign_Email_Quote_Reminder extends QuoteSign_Email_Base {
	/** Constructor. */
	public function __construct() {
		$this->id             = 'qs_quote_reminder';
		$this->title          = __( 'Quote: expiry reminder (customer)', 'quotesign' );
		$this->description    = __( 'Sent to the customer a few days before an open quote expires.', 'quotesign' );
		$this->customer_email = true;
		$this->qs_setup();
		parent::__construct();
	}
	/** @inheritDoc */
	public function get_default_subject() {
		return __( 'Your quote {quote_number} expires soon', 'quotesign' );
	}
	/** @inheritDoc */
	public function get_default_heading() {
		return __( 'Your quote expires soon', 'quotesign' );
	}
	/** @inheritDoc */
	public function intro( $quote ) {
		/* translators: 1: name, 2: date */
		return sprintf( __( 'Hi %1$s, a quick reminder that your quote expires on %2$s. Accept it online before then to lock in the price.', 'quotesign' ), $quote->customer_name(), mysql2date( get_option( 'date_format' ), $quote->expiry() ) );
	}
	/** @inheritDoc */
	public function button( $quote ) {
		return array( __( 'View & accept quote', 'quotesign' ), $quote->url() );
	}
}

/** Customer: balance payment request. */
class QuoteSign_Email_Balance_Request extends QuoteSign_Email_Base {
	/** Constructor. */
	public function __construct() {
		$this->id             = 'qs_balance_request';
		$this->title          = __( 'Quote: balance payment request (customer)', 'quotesign' );
		$this->description    = __( 'Sent to the customer when you click "Request balance" on an accepted quote.', 'quotesign' );
		$this->customer_email = true;
		$this->qs_setup();
		parent::__construct();
	}
	/** @inheritDoc */
	public function get_default_subject() {
		return __( 'Balance payment for quote {quote_number}', 'quotesign' );
	}
	/** @inheritDoc */
	public function get_default_heading() {
		return __( 'Balance payment requested', 'quotesign' );
	}
	/** @inheritDoc */
	public function intro( $quote ) {
		$t = $quote->totals();
		/* translators: 1: name, 2: amount */
		return sprintf( __( 'Hi %1$s, the remaining balance of %2$s for your accepted quote is now due. You can pay securely online.', 'quotesign' ), $quote->customer_name(), wp_strip_all_tags( wc_price( $t['balance'], array( 'currency' => $quote->currency() ) ) ) );
	}
	/** @inheritDoc */
	public function button( $quote ) {
		return $this->pay_url ? array( __( 'Pay balance', 'quotesign' ), $this->pay_url ) : array();
	}
}
