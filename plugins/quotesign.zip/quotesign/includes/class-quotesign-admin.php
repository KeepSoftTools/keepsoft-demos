<?php
/**
 * Admin: quote editor, saving and actions.
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

/**
 * Admin screens.
 */
class QuoteSign_Admin {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'add_meta_boxes_qs_quote', array( __CLASS__, 'meta_boxes' ) );
		add_action( 'save_post_qs_quote', array( __CLASS__, 'save' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notices' ) );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_head-post.php', array( __CLASS__, 'hide_publish_box' ) );
		add_action( 'admin_head-post-new.php', array( __CLASS__, 'hide_publish_box' ) );
	}

	/**
	 * Settings submenu.
	 */
	public static function menu() {
		add_submenu_page(
			'edit.php?post_type=qs_quote',
			__( 'Quote settings', 'quotesign' ),
			__( 'Settings', 'quotesign' ),
			'manage_woocommerce',
			'admin.php?page=wc-settings&tab=quotesign'
		);
	}

	/**
	 * Assets.
	 *
	 * @param string $hook Hook suffix.
	 */
	public static function assets( $hook ) {
		$screen = get_current_screen();
		if ( ! $screen || 'qs_quote' !== $screen->post_type ) {
			return;
		}
		wp_enqueue_style( 'quotesign-admin', QUOTESIGN_URL . 'assets/css/admin.css', array(), QUOTESIGN_VERSION );
		if ( in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			wp_enqueue_script( 'quotesign-admin', QUOTESIGN_URL . 'assets/js/admin.js', array(), QUOTESIGN_VERSION, true );
			wp_localize_script(
				'quotesign-admin',
				'qsAdmin',
				array(
					'restNonce'  => wp_create_nonce( 'wp_rest' ),
					'searchUrl'  => rest_url( 'wc/v3/products' ),
					'decimals'   => wc_get_price_decimals(),
					'currency'   => html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8' ),
					'i18n'       => array(
						'noResults' => __( 'No products found.', 'quotesign' ),
						'copied'    => __( 'Copied!', 'quotesign' ),
						'confirmSend' => __( 'Save and email this quote to the customer?', 'quotesign' ),
						'confirmBalance' => __( 'Create the balance order and email the payment link to the customer?', 'quotesign' ),
					),
				)
			);
		}
	}

	/**
	 * The default publish box is not used.
	 */
	public static function hide_publish_box() {
		$screen = get_current_screen();
		if ( $screen && 'qs_quote' === $screen->post_type ) {
			echo '<style>#submitdiv .misc-pub-section.misc-pub-post-status,#submitdiv .misc-pub-visibility,#submitdiv .misc-pub-curtime{display:none}</style>';
		}
	}

	/**
	 * Meta boxes.
	 */
	public static function meta_boxes() {
		remove_meta_box( 'slugdiv', 'qs_quote', 'normal' );
		add_meta_box( 'qs_actions', __( 'Quote actions', 'quotesign' ), array( __CLASS__, 'box_actions' ), 'qs_quote', 'side', 'high' );
		add_meta_box( 'qs_customer', __( 'Customer', 'quotesign' ), array( __CLASS__, 'box_customer' ), 'qs_quote', 'normal', 'high' );
		add_meta_box( 'qs_items', __( 'Line items & pricing', 'quotesign' ), array( __CLASS__, 'box_items' ), 'qs_quote', 'normal', 'high' );
		add_meta_box( 'qs_terms', __( 'Terms & expiry', 'quotesign' ), array( __CLASS__, 'box_terms' ), 'qs_quote', 'normal', 'default' );
		add_meta_box( 'qs_audit', __( 'Signature & audit trail', 'quotesign' ), array( __CLASS__, 'box_audit' ), 'qs_quote', 'normal', 'low' );
	}

	/**
	 * Get quote for a post (works on auto-drafts).
	 *
	 * @param WP_Post $post Post.
	 * @return QuoteSign_Quote
	 */
	private static function q( $post ) {
		return QuoteSign_Quote::get( $post->ID );
	}

	/**
	 * Side box.
	 *
	 * @param WP_Post $post Post.
	 */
	public static function box_actions( $post ) {
		$q = self::q( $post );
		wp_nonce_field( 'qs_save_quote', 'qs_nonce' );
		$status    = $q->status();
		$is_saved  = (bool) $q->token();
		?>
		<p>
			<label for="qs_status"><strong><?php esc_html_e( 'Status', 'quotesign' ); ?></strong></label><br>
			<select name="qs_status" id="qs_status" class="widefat">
				<?php foreach ( QuoteSign_Quote::statuses() as $slug => $label ) : ?>
					<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $status, $slug ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
		</p>
		<?php if ( 'accepted' !== $status ) : ?>
			<p>
				<button type="submit" name="qs_action" value="send" class="button button-primary button-large widefat" data-qs-confirm="send">
					<?php echo in_array( $status, array( 'sent', 'viewed' ), true ) ? esc_html__( 'Save & re-send quote', 'quotesign' ) : esc_html__( 'Save & send quote', 'quotesign' ); ?>
				</button>
			</p>
		<?php endif; ?>
		<p>
			<button type="submit" class="button widefat"><?php esc_html_e( 'Save changes', 'quotesign' ); ?></button>
		</p>
		<?php if ( $is_saved ) : ?>
			<hr>
			<p>
				<label for="qs_link"><strong><?php esc_html_e( 'Customer link', 'quotesign' ); ?></strong></label>
				<input type="text" readonly id="qs_link" class="widefat" value="<?php echo esc_url( $q->url() ); ?>" onfocus="this.select()">
				<button type="button" class="button button-small" data-qs-copy="#qs_link"><?php esc_html_e( 'Copy link', 'quotesign' ); ?></button>
				<a class="button button-small" href="<?php echo esc_url( $q->url() ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Open', 'quotesign' ); ?></a>
				<a class="button button-small" href="<?php echo esc_url( $q->pdf_url() ); ?>"><?php esc_html_e( 'PDF', 'quotesign' ); ?></a>
			</p>
			<?php
			$dep = (int) $q->meta( 'deposit_order_id', 0 );
			$bal = (int) $q->meta( 'balance_order_id', 0 );
			if ( $dep || $bal ) :
				?>
				<hr>
				<p><strong><?php esc_html_e( 'Orders', 'quotesign' ); ?></strong></p>
				<ul class="qs-orders">
					<?php
					foreach ( array(
						__( 'Deposit / payment', 'quotesign' ) => $dep,
						__( 'Balance', 'quotesign' )           => $bal,
					) as $label => $oid ) {
						$o = $oid ? wc_get_order( $oid ) : null;
						if ( $o ) {
							printf(
								'<li>%s: <a href="%s">#%s</a> (%s)</li>',
								esc_html( $label ),
								esc_url( $o->get_edit_order_url() ),
								esc_html( $o->get_order_number() ),
								esc_html( wc_get_order_status_name( $o->get_status() ) )
							);
						}
					}
					?>
				</ul>
			<?php endif; ?>
			<?php if ( 'accepted' === $status && $dep && ! $bal && $q->has_deposit() ) : ?>
				<p>
					<button type="submit" name="qs_action" value="balance" class="button widefat" data-qs-confirm="balance"><?php esc_html_e( 'Request balance', 'quotesign' ); ?></button>
				</p>
			<?php endif; ?>
		<?php endif; ?>
		<?php
	}

	/**
	 * Customer box.
	 *
	 * @param WP_Post $post Post.
	 */
	public static function box_customer( $post ) {
		$q = self::q( $post );
		?>
		<div class="qs-grid">
			<p><label for="qs_name"><?php esc_html_e( 'Name', 'quotesign' ); ?></label>
				<input type="text" class="widefat" id="qs_name" name="qs_name" value="<?php echo esc_attr( $q->customer_name() ); ?>"></p>
			<p><label for="qs_email"><?php esc_html_e( 'Email', 'quotesign' ); ?></label>
				<input type="email" class="widefat" id="qs_email" name="qs_email" value="<?php echo esc_attr( $q->customer_email() ); ?>"></p>
			<p><label for="qs_phone"><?php esc_html_e( 'Phone', 'quotesign' ); ?></label>
				<input type="text" class="widefat" id="qs_phone" name="qs_phone" value="<?php echo esc_attr( $q->meta( 'phone' ) ); ?>"></p>
			<p><label for="qs_company"><?php esc_html_e( 'Company', 'quotesign' ); ?></label>
				<input type="text" class="widefat" id="qs_company" name="qs_company" value="<?php echo esc_attr( $q->meta( 'company' ) ); ?>"></p>
		</div>
		<?php if ( $q->meta( 'customer_note' ) ) : ?>
			<p><strong><?php esc_html_e( 'Customer note', 'quotesign' ); ?></strong><br><?php echo nl2br( esc_html( $q->meta( 'customer_note' ) ) ); ?></p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Items box.
	 *
	 * @param WP_Post $post Post.
	 */
	public static function box_items( $post ) {
		$q     = self::q( $post );
		$items = $q->items();
		$tax   = $q->meta( 'tax_rate', QuoteSign_Settings::get( 'tax_rate' ) );
		$dtype = $q->meta( 'discount_type', 'percent' );
		$dval  = $q->meta( 'discount_value', '0' );
		$deptype = $q->meta( 'deposit_type', QuoteSign_Settings::get( 'deposit_type' ) );
		$depval  = $q->meta( 'deposit_value', QuoteSign_Settings::get( 'deposit_value' ) );
		?>
		<div class="qs-search">
			<label for="qs-product-search" class="screen-reader-text"><?php esc_html_e( 'Search products', 'quotesign' ); ?></label>
			<input type="search" id="qs-product-search" class="widefat" placeholder="<?php esc_attr_e( 'Search products to add…', 'quotesign' ); ?>" autocomplete="off">
			<ul class="qs-search-results" hidden></ul>
		</div>
		<table class="widefat qs-items" id="qs-items">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Description', 'quotesign' ); ?></th>
					<th class="qs-w-sku"><?php esc_html_e( 'SKU', 'quotesign' ); ?></th>
					<th class="qs-w-num"><?php esc_html_e( 'Qty', 'quotesign' ); ?></th>
					<th class="qs-w-num"><?php esc_html_e( 'Unit price', 'quotesign' ); ?></th>
					<th class="qs-w-num"><?php esc_html_e( 'Line total', 'quotesign' ); ?></th>
					<th class="qs-w-x"></th>
				</tr>
			</thead>
			<tbody>
			<?php
			foreach ( $items as $i => $it ) {
				self::item_row( $i, $it );
			}
			?>
			</tbody>
		</table>
		<template id="qs-row-template"><?php self::item_row( '__i__', array() ); ?></template>
		<p><button type="button" class="button" id="qs-add-line"><?php esc_html_e( 'Add line', 'quotesign' ); ?></button></p>

		<div class="qs-pricing">
			<div class="qs-grid">
				<p><label for="qs_discount_value"><?php esc_html_e( 'Discount', 'quotesign' ); ?></label>
					<span class="qs-inline">
						<input type="text" id="qs_discount_value" name="qs_discount_value" class="wc_input_decimal" value="<?php echo esc_attr( $dval ); ?>" data-qs-calc>
						<select name="qs_discount_type" data-qs-calc>
							<option value="percent" <?php selected( $dtype, 'percent' ); ?>>%</option>
							<option value="fixed" <?php selected( $dtype, 'fixed' ); ?>><?php esc_html_e( 'Amount', 'quotesign' ); ?></option>
						</select>
					</span></p>
				<p><label for="qs_tax_rate"><?php echo esc_html( QuoteSign_Settings::tax_label() ); ?> (%)</label>
					<input type="text" id="qs_tax_rate" name="qs_tax_rate" class="wc_input_decimal" value="<?php echo esc_attr( $tax ); ?>" data-qs-calc></p>
				<p><label for="qs_deposit_value"><?php esc_html_e( 'Deposit', 'quotesign' ); ?></label>
					<span class="qs-inline">
						<input type="text" id="qs_deposit_value" name="qs_deposit_value" class="wc_input_decimal" value="<?php echo esc_attr( $depval ); ?>" data-qs-calc>
						<select name="qs_deposit_type" data-qs-calc>
							<option value="none" <?php selected( $deptype, 'none' ); ?>><?php esc_html_e( 'None', 'quotesign' ); ?></option>
							<option value="percent" <?php selected( $deptype, 'percent' ); ?>>%</option>
							<option value="fixed" <?php selected( $deptype, 'fixed' ); ?>><?php esc_html_e( 'Amount', 'quotesign' ); ?></option>
						</select>
					</span></p>
			</div>
			<table class="qs-sum">
				<tr><th><?php esc_html_e( 'Subtotal', 'quotesign' ); ?></th><td data-qs-sum="subtotal">&ndash;</td></tr>
				<tr><th><?php esc_html_e( 'Discount', 'quotesign' ); ?></th><td data-qs-sum="discount">&ndash;</td></tr>
				<tr><th><?php echo esc_html( QuoteSign_Settings::tax_label() ); ?></th><td data-qs-sum="tax">&ndash;</td></tr>
				<tr class="qs-sum-total"><th><?php esc_html_e( 'Total', 'quotesign' ); ?></th><td data-qs-sum="total">&ndash;</td></tr>
				<tr><th><?php esc_html_e( 'Due on acceptance', 'quotesign' ); ?></th><td data-qs-sum="deposit">&ndash;</td></tr>
				<tr><th><?php esc_html_e( 'Balance', 'quotesign' ); ?></th><td data-qs-sum="balance">&ndash;</td></tr>
			</table>
		</div>
		<?php
	}

	/**
	 * One item row.
	 *
	 * @param int|string $i  Index.
	 * @param array      $it Item.
	 */
	private static function item_row( $i, $it ) {
		$it = wp_parse_args(
			$it,
			array(
				'product_id'   => 0,
				'variation_id' => 0,
				'name'         => '',
				'sku'          => '',
				'desc'         => '',
				'qty'          => 1,
				'price'        => '',
			)
		);
		$n = 'qs_items[' . $i . ']';
		?>
		<tr class="qs-row">
			<td>
				<input type="hidden" name="<?php echo esc_attr( $n ); ?>[product_id]" value="<?php echo esc_attr( $it['product_id'] ); ?>">
				<input type="hidden" name="<?php echo esc_attr( $n ); ?>[variation_id]" value="<?php echo esc_attr( $it['variation_id'] ); ?>">
				<input type="text" class="widefat" name="<?php echo esc_attr( $n ); ?>[name]" value="<?php echo esc_attr( $it['name'] ); ?>" placeholder="<?php esc_attr_e( 'Item name', 'quotesign' ); ?>" aria-label="<?php esc_attr_e( 'Item name', 'quotesign' ); ?>">
				<input type="text" class="widefat qs-desc" name="<?php echo esc_attr( $n ); ?>[desc]" value="<?php echo esc_attr( $it['desc'] ); ?>" placeholder="<?php esc_attr_e( 'Optional description', 'quotesign' ); ?>" aria-label="<?php esc_attr_e( 'Description', 'quotesign' ); ?>">
			</td>
			<td><input type="text" class="widefat" name="<?php echo esc_attr( $n ); ?>[sku]" value="<?php echo esc_attr( $it['sku'] ); ?>" aria-label="<?php esc_attr_e( 'SKU', 'quotesign' ); ?>"></td>
			<td><input type="number" step="any" min="0" class="widefat" data-qs-calc data-qs-field="qty" name="<?php echo esc_attr( $n ); ?>[qty]" value="<?php echo esc_attr( $it['qty'] ); ?>" aria-label="<?php esc_attr_e( 'Quantity', 'quotesign' ); ?>"></td>
			<td><input type="text" class="widefat wc_input_price" data-qs-calc data-qs-field="price" name="<?php echo esc_attr( $n ); ?>[price]" value="<?php echo esc_attr( $it['price'] ); ?>" aria-label="<?php esc_attr_e( 'Unit price', 'quotesign' ); ?>"></td>
			<td class="qs-line-total">&ndash;</td>
			<td><button type="button" class="button-link qs-remove" aria-label="<?php esc_attr_e( 'Remove line', 'quotesign' ); ?>">&times;</button></td>
		</tr>
		<?php
	}

	/**
	 * Terms & expiry box.
	 *
	 * @param WP_Post $post Post.
	 */
	public static function box_terms( $post ) {
		$q     = self::q( $post );
		$has   = metadata_exists( 'post', $post->ID, '_qs_terms' );
		$terms = $has ? (string) $q->meta( 'terms' ) : (string) QuoteSign_Settings::get( 'default_terms' );
		?>
		<p>
			<label for="qs_expiry"><strong><?php esc_html_e( 'Expiry date', 'quotesign' ); ?></strong></label>
			<input type="date" id="qs_expiry" name="qs_expiry" value="<?php echo esc_attr( $q->expiry() ); ?>">
			<span class="description"><?php echo esc_html( sprintf( /* translators: %d: days */ __( 'Leave empty to use the default of %d days when sending.', 'quotesign' ), (int) QuoteSign_Settings::get( 'validity_days' ) ) ); ?></span>
		</p>
		<p>
			<label for="qs_terms"><strong><?php esc_html_e( 'Terms & conditions', 'quotesign' ); ?></strong></label>
			<textarea id="qs_terms" name="qs_terms" rows="8" class="widefat"><?php echo esc_textarea( $terms ); ?></textarea>
		</p>
		<?php
	}

	/**
	 * Signature + audit box.
	 *
	 * @param WP_Post $post Post.
	 */
	public static function box_audit( $post ) {
		$q   = self::q( $post );
		$sig = $q->signature();
		if ( $sig ) {
			echo '<div class="qs-sig">';
			printf(
				'<p><strong>%s</strong> &mdash; %s<br>%s: %s<br>%s: %s</p>',
				esc_html( $sig['name'] ),
				esc_html( 'drawn' === $sig['mode'] ? __( 'drawn signature', 'quotesign' ) : __( 'typed signature', 'quotesign' ) ),
				esc_html__( 'IP', 'quotesign' ),
				esc_html( $sig['ip'] ),
				esc_html__( 'Browser', 'quotesign' ),
				esc_html( $sig['ua'] )
			);
			if ( 'drawn' === $sig['mode'] && ! empty( $sig['data'] ) && 0 === strpos( $sig['data'], 'data:image/png;base64,' ) ) {
				echo '<img class="qs-sig-img" alt="' . esc_attr__( 'Signature', 'quotesign' ) . '" src="' . esc_attr( $sig['data'] ) . '">';
			}
			echo '</div>';
		}
		$audit = array_reverse( $q->audit() );
		if ( empty( $audit ) ) {
			echo '<p>' . esc_html__( 'No activity yet.', 'quotesign' ) . '</p>';
			return;
		}
		echo '<table class="widefat striped qs-audit"><thead><tr><th>' . esc_html__( 'Time (UTC)', 'quotesign' ) . '</th><th>' . esc_html__( 'Event', 'quotesign' ) . '</th><th>' . esc_html__( 'Details', 'quotesign' ) . '</th></tr></thead><tbody>';
		foreach ( $audit as $e ) {
			$detail = $e['detail'];
			if ( ! empty( $e['ip'] ) ) {
				$detail .= ( $detail ? ' · ' : '' ) . 'IP ' . $e['ip'];
			}
			if ( ! empty( $e['user'] ) ) {
				$u = get_userdata( $e['user'] );
				if ( $u ) {
					$detail .= ( $detail ? ' · ' : '' ) . $u->display_name;
				}
			}
			printf(
				'<tr><td>%s</td><td>%s</td><td>%s</td></tr>',
				esc_html( gmdate( 'Y-m-d H:i:s', (int) $e['time'] ) ),
				esc_html( QuoteSign_PDF::event_label( $e['event'] ) ),
				esc_html( $detail )
			);
		}
		echo '</tbody></table>';
	}

	/**
	 * Save.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post.
	 */
	public static function save( $post_id, $post ) {
		if ( ! isset( $_POST['qs_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['qs_nonce'] ) ), 'qs_save_quote' ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_woocommerce' ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// Raw items are sanitised in QuoteSign_Quote::sanitize_items().
		$raw_items = isset( $_POST['qs_items'] ) && is_array( $_POST['qs_items'] ) ? wp_unslash( $_POST['qs_items'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$quote     = QuoteSign_Quote::get( $post_id );
		if ( ! $quote ) {
			return;
		}
		if ( ! $quote->token() ) {
			update_post_meta( $post_id, '_qs_token', wp_generate_password( 32, false, false ) );
			update_post_meta( $post_id, '_qs_status', 'new' );
			update_post_meta( $post_id, '_qs_currency', get_woocommerce_currency() );
			$quote->log( 'created', __( 'Created in dashboard', 'quotesign' ) );
		}

		$post_text = function ( $key ) {
			return isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		};
		$email = sanitize_email( $post_text( 'qs_email' ) );
		update_post_meta( $post_id, '_qs_name', $post_text( 'qs_name' ) );
		update_post_meta( $post_id, '_qs_email', $email );
		update_post_meta( $post_id, '_qs_phone', $post_text( 'qs_phone' ) );
		update_post_meta( $post_id, '_qs_company', $post_text( 'qs_company' ) );
		if ( $email && ! (int) get_post_meta( $post_id, '_qs_customer_id', true ) ) {
			$user = get_user_by( 'email', $email );
			update_post_meta( $post_id, '_qs_customer_id', $user ? (int) $user->ID : 0 );
		}

		update_post_meta( $post_id, '_qs_items', QuoteSign_Quote::sanitize_items( array_values( $raw_items ) ) );

		$dtype = in_array( $post_text( 'qs_discount_type' ), array( 'percent', 'fixed' ), true ) ? $post_text( 'qs_discount_type' ) : 'percent';
		update_post_meta( $post_id, '_qs_discount_type', $dtype );
		update_post_meta( $post_id, '_qs_discount_value', (string) max( 0, (float) wc_format_decimal( $post_text( 'qs_discount_value' ) ) ) );
		update_post_meta( $post_id, '_qs_tax_rate', (string) max( 0, (float) wc_format_decimal( $post_text( 'qs_tax_rate' ) ) ) );
		$deptype = in_array( $post_text( 'qs_deposit_type' ), array( 'none', 'percent', 'fixed' ), true ) ? $post_text( 'qs_deposit_type' ) : 'none';
		update_post_meta( $post_id, '_qs_deposit_type', $deptype );
		update_post_meta( $post_id, '_qs_deposit_value', (string) max( 0, (float) wc_format_decimal( $post_text( 'qs_deposit_value' ) ) ) );

		$expiry = $post_text( 'qs_expiry' );
		update_post_meta( $post_id, '_qs_expiry', preg_match( '/^\d{4}-\d{2}-\d{2}$/', $expiry ) ? $expiry : '' );
		$terms = isset( $_POST['qs_terms'] ) ? wp_kses_post( wp_unslash( $_POST['qs_terms'] ) ) : '';
		update_post_meta( $post_id, '_qs_terms', $terms );

		// Title.
		remove_action( 'save_post_qs_quote', array( __CLASS__, 'save' ), 10 );
		wp_update_post(
			array(
				'ID'          => $post_id,
				'post_title'  => sprintf( '%s — %s', $quote->number(), $post_text( 'qs_name' ) ),
				'post_name'   => 'qs-' . $post_id,
				'post_status' => 'publish' === $post->post_status || 'auto-draft' === $post->post_status || 'draft' === $post->post_status ? 'publish' : $post->post_status,
			)
		);
		add_action( 'save_post_qs_quote', array( __CLASS__, 'save' ), 10, 2 );

		$quote = QuoteSign_Quote::get( $post_id );

		// Manual status change.
		$new_status = $post_text( 'qs_status' );
		if ( $new_status && $new_status !== $quote->status() && isset( QuoteSign_Quote::statuses()[ $new_status ] ) ) {
			$quote->set_status( $new_status, __( 'Changed in dashboard', 'quotesign' ) );
		}

		// Action buttons.
		$action = $post_text( 'qs_action' );
		if ( 'send' === $action ) {
			self::do_send( $quote );
		} elseif ( 'balance' === $action ) {
			self::do_balance( $quote );
		}
	}

	/**
	 * Send the quote link to the customer.
	 *
	 * @param QuoteSign_Quote $quote Quote.
	 */
	private static function do_send( $quote ) {
		if ( 'accepted' === $quote->status() ) {
			self::flash( 'error', __( 'This quote has already been accepted.', 'quotesign' ) );
			return;
		}
		if ( ! is_email( $quote->customer_email() ) ) {
			self::flash( 'error', __( 'Add a valid customer email before sending.', 'quotesign' ) );
			return;
		}
		if ( ! $quote->items() ) {
			self::flash( 'error', __( 'Add at least one line item before sending.', 'quotesign' ) );
			return;
		}
		if ( '' === $quote->expiry() || $quote->is_past_expiry() ) {
			$days = max( 1, (int) QuoteSign_Settings::get( 'validity_days' ) );
			update_post_meta( $quote->id, '_qs_expiry', wp_date( 'Y-m-d', time() + $days * DAY_IN_SECONDS ) );
		}
		delete_post_meta( $quote->id, '_qs_reminder_sent' );
		if ( 'sent' === $quote->status() || 'viewed' === $quote->status() ) {
			$quote->log( 'resent', __( 'Quote re-sent', 'quotesign' ) );
		} else {
			$quote->set_status( 'sent', __( 'Quote sent by email', 'quotesign' ) );
		}
		do_action( 'quotesign_send_quote', $quote->id );
		/* translators: %s: email */
		self::flash( 'success', sprintf( __( 'Quote sent to %s.', 'quotesign' ), $quote->customer_email() ) );
	}

	/**
	 * Create and request the balance order.
	 *
	 * @param QuoteSign_Quote $quote Quote.
	 */
	private static function do_balance( $quote ) {
		$order = QuoteSign_Orders::create_for_quote( $quote, 'balance' );
		if ( is_wp_error( $order ) ) {
			self::flash( 'error', $order->get_error_message() );
			return;
		}
		do_action( 'quotesign_balance_requested', $quote->id, $order->get_id() );
		/* translators: %s: order number */
		self::flash( 'success', sprintf( __( 'Balance order #%s created and emailed to the customer.', 'quotesign' ), $order->get_order_number() ) );
	}

	/**
	 * Store a one-off notice.
	 *
	 * @param string $type    success|error.
	 * @param string $message Message.
	 */
	private static function flash( $type, $message ) {
		set_transient( 'qs_notice_' . get_current_user_id(), array( $type, $message ), 60 );
	}

	/**
	 * Show notices.
	 */
	public static function notices() {
		$n = get_transient( 'qs_notice_' . get_current_user_id() );
		if ( ! $n ) {
			return;
		}
		delete_transient( 'qs_notice_' . get_current_user_id() );
		printf(
			'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
			'error' === $n[0] ? 'error' : 'success',
			esc_html( $n[1] )
		);
	}
}
