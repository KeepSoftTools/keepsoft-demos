<?php
/**
 * Quote post type and list table.
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registers the qs_quote post type.
 */
class QuoteSign_CPT {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		if ( is_admin() ) {
			add_filter( 'manage_qs_quote_posts_columns', array( __CLASS__, 'columns' ) );
			add_action( 'manage_qs_quote_posts_custom_column', array( __CLASS__, 'column_content' ), 10, 2 );
			add_filter( 'views_edit-qs_quote', array( __CLASS__, 'views' ) );
			add_action( 'pre_get_posts', array( __CLASS__, 'filter_list' ) );
			add_filter( 'post_row_actions', array( __CLASS__, 'row_actions' ), 10, 2 );
			add_filter( 'bulk_actions-edit-qs_quote', array( __CLASS__, 'bulk_actions' ) );
		}
	}

	/**
	 * Register post type.
	 */
	public static function register() {
		$cap = 'manage_woocommerce';
		register_post_type(
			'qs_quote',
			array(
				'labels'              => array(
					'name'               => __( 'Quotes', 'quotesign' ),
					'singular_name'      => __( 'Quote', 'quotesign' ),
					'add_new'            => __( 'Add quote', 'quotesign' ),
					'add_new_item'       => __( 'Add new quote', 'quotesign' ),
					'edit_item'          => __( 'Edit quote', 'quotesign' ),
					'new_item'           => __( 'New quote', 'quotesign' ),
					'view_item'          => __( 'View quote', 'quotesign' ),
					'search_items'       => __( 'Search quotes', 'quotesign' ),
					'not_found'          => __( 'No quotes found', 'quotesign' ),
					'not_found_in_trash' => __( 'No quotes found in trash', 'quotesign' ),
					'menu_name'          => __( 'Quotes', 'quotesign' ),
					'all_items'          => __( 'All quotes', 'quotesign' ),
				),
				'public'              => false,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'show_in_nav_menus'   => false,
				'show_in_rest'        => false,
				'menu_position'       => 56,
				'menu_icon'           => 'dashicons-media-text',
				'supports'            => array( 'title' ),
				'has_archive'         => false,
				'rewrite'             => false,
				'query_var'           => false,
				'map_meta_cap'        => true,
				'capability_type'     => 'qs_quote',
				'capabilities'        => array(
					'edit_posts'             => $cap,
					'edit_others_posts'      => $cap,
					'delete_posts'           => $cap,
					'publish_posts'          => $cap,
					'read_private_posts'     => $cap,
					'delete_private_posts'   => $cap,
					'delete_published_posts' => $cap,
					'delete_others_posts'    => $cap,
					'edit_private_posts'     => $cap,
					'edit_published_posts'   => $cap,
					'create_posts'           => $cap,
				),
			)
		);
	}

	/**
	 * Columns.
	 *
	 * @param array $cols Columns.
	 * @return array
	 */
	public static function columns( $cols ) {
		return array(
			'cb'        => isset( $cols['cb'] ) ? $cols['cb'] : '',
			'qs_number' => __( 'Quote', 'quotesign' ),
			'qs_cust'   => __( 'Customer', 'quotesign' ),
			'qs_total'  => __( 'Total', 'quotesign' ),
			'qs_status' => __( 'Status', 'quotesign' ),
			'qs_expiry' => __( 'Expires', 'quotesign' ),
			'date'      => __( 'Date', 'quotesign' ),
		);
	}

	/**
	 * Column output.
	 *
	 * @param string $col     Column.
	 * @param int    $post_id Post ID.
	 */
	public static function column_content( $col, $post_id ) {
		$q = QuoteSign_Quote::get( $post_id );
		if ( ! $q ) {
			return;
		}
		switch ( $col ) {
			case 'qs_number':
				printf(
					'<a href="%s"><strong>%s</strong></a>',
					esc_url( get_edit_post_link( $post_id ) ),
					esc_html( $q->number() )
				);
				break;
			case 'qs_cust':
				echo esc_html( $q->customer_name() );
				if ( $q->meta( 'company' ) ) {
					echo '<br><small>' . esc_html( $q->meta( 'company' ) ) . '</small>';
				}
				if ( $q->customer_email() ) {
					echo '<br><small><a href="mailto:' . esc_attr( $q->customer_email() ) . '">' . esc_html( $q->customer_email() ) . '</a></small>';
				}
				break;
			case 'qs_total':
				$t = $q->totals();
				echo wp_kses_post( wc_price( $t['total'], array( 'currency' => $q->currency() ) ) );
				break;
			case 'qs_status':
				printf(
					'<mark class="qs-status qs-status-%1$s"><span>%2$s</span></mark>',
					esc_attr( $q->status() ),
					esc_html( $q->status_label() )
				);
				break;
			case 'qs_expiry':
				echo $q->expiry() ? esc_html( $q->expiry() ) : '&ndash;';
				break;
		}
	}

	/**
	 * Status filter links.
	 *
	 * @param array $views Views.
	 * @return array
	 */
	public static function views( $views ) {
		global $wpdb;
		$current = isset( $_GET['qs_status'] ) ? sanitize_key( wp_unslash( $_GET['qs_status'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$counts  = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT m.meta_value AS s, COUNT(*) AS c FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_qs_status' WHERE p.post_type = %s AND p.post_status <> 'trash' AND p.post_status <> 'auto-draft' GROUP BY m.meta_value",
				'qs_quote'
			),
			OBJECT_K
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$new_views = array();
		if ( isset( $views['all'] ) ) {
			$new_views['all'] = $views['all'];
		}
		foreach ( QuoteSign_Quote::statuses() as $slug => $label ) {
			$n   = isset( $counts[ $slug ] ) ? (int) $counts[ $slug ]->c : 0;
			$url = add_query_arg(
				array(
					'post_type' => 'qs_quote',
					'qs_status' => $slug,
				),
				admin_url( 'edit.php' )
			);
			$new_views[ 'qs_' . $slug ] = sprintf(
				'<a href="%s"%s>%s <span class="count">(%d)</span></a>',
				esc_url( $url ),
				$current === $slug ? ' class="current"' : '',
				esc_html( $label ),
				$n
			);
		}
		if ( isset( $views['trash'] ) ) {
			$new_views['trash'] = $views['trash'];
		}
		return $new_views;
	}

	/**
	 * Apply status filter.
	 *
	 * @param WP_Query $query Query.
	 */
	public static function filter_list( $query ) {
		if ( ! is_admin() || ! $query->is_main_query() || 'qs_quote' !== $query->get( 'post_type' ) ) {
			return;
		}
		if ( ! empty( $_GET['qs_status'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$status = sanitize_key( wp_unslash( $_GET['qs_status'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
			if ( isset( QuoteSign_Quote::statuses()[ $status ] ) ) {
				$query->set(
					'meta_query',
					array(
						array(
							'key'   => '_qs_status',
							'value' => $status,
						),
					)
				);
			}
		}
	}

	/**
	 * Row actions: remove quick edit.
	 *
	 * @param array   $actions Actions.
	 * @param WP_Post $post    Post.
	 * @return array
	 */
	public static function row_actions( $actions, $post ) {
		if ( 'qs_quote' === $post->post_type ) {
			unset( $actions['inline hide-if-no-js'], $actions['view'] );
		}
		return $actions;
	}

	/**
	 * Bulk actions: remove edit.
	 *
	 * @param array $actions Actions.
	 * @return array
	 */
	public static function bulk_actions( $actions ) {
		unset( $actions['edit'] );
		return $actions;
	}
}
