<?php
/**
 * Minimal pure-PHP PDF 1.4 writer (original code, GPL-2.0-or-later).
 *
 * Supports: A4 pages, the three standard Helvetica fonts (not embedded),
 * text, rectangles, lines and flate-compressed RGB images. Strings are
 * converted from UTF-8 to Windows-1252.
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

/**
 * PDF writer.
 */
class QuoteSign_PDF_Writer {

	/** @var float Page width (pt). */
	public $w = 595.28;
	/** @var float Page height (pt). */
	public $h = 841.89;

	/** @var string[] Page content streams. */
	private $pages = array();
	/** @var int Current page index. */
	private $cur = -1;
	/** @var array Images: id => [w,h,data]. */
	private $images = array();
	/** @var array Page => image ids used. */
	private $page_images = array();
	/** @var string Font key. */
	private $font = 'F1';
	/** @var float Font size. */
	private $size = 10;
	/** @var array Document info. */
	private $info = array();

	/** @var array Helvetica widths for chars 32..126. */
	private static $w_reg = array(
		278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278,
		556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556,
		1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778,
		667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556,
		333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556,
		556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584,
	);
	/** @var array Helvetica-Bold widths for chars 32..126. */
	private static $w_bold = array(
		278, 333, 474, 556, 556, 889, 722, 238, 333, 333, 389, 584, 278, 333, 278, 278,
		556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 333, 333, 584, 584, 584, 611,
		975, 722, 722, 722, 722, 667, 611, 778, 722, 278, 556, 722, 611, 833, 722, 778,
		667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 333, 278, 333, 584, 556,
		333, 556, 611, 556, 611, 556, 333, 611, 611, 278, 278, 556, 278, 889, 611, 611,
		611, 611, 389, 556, 333, 611, 556, 778, 556, 556, 500, 389, 280, 389, 584,
	);

	/**
	 * Set document info.
	 *
	 * @param string $title  Title.
	 * @param string $author Author.
	 */
	public function set_info( $title, $author ) {
		$this->info = array(
			'Title'  => $this->to_win( $title ),
			'Author' => $this->to_win( $author ),
		);
	}

	/**
	 * Convert UTF-8 to Windows-1252.
	 *
	 * @param string $s String.
	 * @return string
	 */
	public function to_win( $s ) {
		$s = (string) $s;
		if ( function_exists( 'mb_convert_encoding' ) ) {
			$out = @mb_convert_encoding( $s, 'Windows-1252', 'UTF-8' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			if ( is_string( $out ) ) {
				return $out;
			}
		}
		if ( function_exists( 'iconv' ) ) {
			$out = @iconv( 'UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $s ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			if ( is_string( $out ) ) {
				return $out;
			}
		}
		return preg_replace( '/[^\x20-\x7E]/', '?', $s );
	}

	/**
	 * Add a page.
	 */
	public function add_page() {
		$this->pages[]     = '';
		$this->cur         = count( $this->pages ) - 1;
		$this->page_images[ $this->cur ] = array();
	}

	/**
	 * Page count.
	 *
	 * @return int
	 */
	public function page_count() {
		return count( $this->pages );
	}

	/**
	 * Switch to a page index.
	 *
	 * @param int $i Index.
	 */
	public function go_to_page( $i ) {
		$this->cur = (int) $i;
	}

	/**
	 * Set font.
	 *
	 * @param string $style R, B or I.
	 * @param float  $size  Size in pt.
	 */
	public function set_font( $style = 'R', $size = 10 ) {
		$map        = array(
			'R' => 'F1',
			'B' => 'F2',
			'I' => 'F3',
		);
		$this->font = isset( $map[ $style ] ) ? $map[ $style ] : 'F1';
		$this->size = (float) $size;
		$this->out( sprintf( 'BT /%s %.2F Tf ET', $this->font, $this->size ) );
	}

	/**
	 * Width of a string with the current font (pt).
	 *
	 * @param string $utf8 UTF-8 text.
	 * @return float
	 */
	public function width( $utf8 ) {
		$s     = $this->to_win( $utf8 );
		$table = 'F2' === $this->font ? self::$w_bold : self::$w_reg;
		$def   = 'F2' === $this->font ? 611 : 556;
		$total = 0;
		$len   = strlen( $s );
		for ( $i = 0; $i < $len; $i++ ) {
			$c = ord( $s[ $i ] );
			if ( $c >= 32 && $c <= 126 ) {
				$total += $table[ $c - 32 ];
			} else {
				$total += $def;
			}
		}
		return $total * $this->size / 1000;
	}

	/**
	 * Escape a Windows-1252 string for a PDF literal.
	 *
	 * @param string $s String.
	 * @return string
	 */
	private function esc( $s ) {
		return str_replace( array( '\\', '(', ')', "\r" ), array( '\\\\', '\\(', '\\)', '' ), $s );
	}

	/**
	 * Append to the current page stream.
	 *
	 * @param string $s PDF operators.
	 */
	private function out( $s ) {
		$this->pages[ $this->cur ] .= $s . "\n";
	}

	/**
	 * Set text/fill colour from hex.
	 *
	 * @param string $hex RRGGBB.
	 */
	public function color( $hex ) {
		list( $r, $g, $b ) = $this->rgb( $hex );
		$this->out( sprintf( '%.3F %.3F %.3F rg %.3F %.3F %.3F RG', $r, $g, $b, $r, $g, $b ) );
	}

	/**
	 * Hex to 0..1 floats.
	 *
	 * @param string $hex Hex.
	 * @return array
	 */
	private function rgb( $hex ) {
		$hex = ltrim( $hex, '#' );
		return array(
			hexdec( substr( $hex, 0, 2 ) ) / 255,
			hexdec( substr( $hex, 2, 2 ) ) / 255,
			hexdec( substr( $hex, 4, 2 ) ) / 255,
		);
	}

	/**
	 * Draw text with its baseline at y (from top).
	 *
	 * @param float  $x     X.
	 * @param float  $y     Baseline Y from top.
	 * @param string $utf8  Text.
	 * @param string $align L, R or C (x is then the right edge / centre).
	 */
	public function text( $x, $y, $utf8, $align = 'L' ) {
		if ( '' === (string) $utf8 ) {
			return;
		}
		$wd = $this->width( $utf8 );
		if ( 'R' === $align ) {
			$x -= $wd;
		} elseif ( 'C' === $align ) {
			$x -= $wd / 2;
		}
		$this->out(
			sprintf(
				'BT /%s %.2F Tf %.2F %.2F Td (%s) Tj ET',
				$this->font,
				$this->size,
				$x,
				$this->h - $y,
				$this->esc( $this->to_win( $utf8 ) )
			)
		);
	}

	/**
	 * Rectangle.
	 *
	 * @param float  $x     X.
	 * @param float  $y     Top Y.
	 * @param float  $w     Width.
	 * @param float  $h     Height.
	 * @param string $style F fill, S stroke, FD both.
	 */
	public function rect( $x, $y, $w, $h, $style = 'S' ) {
		$op = 'F' === $style ? 'f' : ( 'FD' === $style ? 'B' : 'S' );
		$this->out( sprintf( '%.2F %.2F %.2F %.2F re %s', $x, $this->h - $y - $h, $w, $h, $op ) );
	}

	/**
	 * Line.
	 *
	 * @param float $x1 X1.
	 * @param float $y1 Y1 (from top).
	 * @param float $x2 X2.
	 * @param float $y2 Y2.
	 * @param float $lw Line width.
	 */
	public function line( $x1, $y1, $x2, $y2, $lw = 0.5 ) {
		$this->out( sprintf( '%.2F w %.2F %.2F m %.2F %.2F l S', $lw, $x1, $this->h - $y1, $x2, $this->h - $y2 ) );
	}

	/**
	 * Place an RGB image.
	 *
	 * @param string $rgb  Raw 8-bit RGB bytes (w*h*3).
	 * @param int    $pw   Pixel width.
	 * @param int    $ph   Pixel height.
	 * @param float  $x    X.
	 * @param float  $y    Top Y.
	 * @param float  $w    Draw width.
	 * @param float  $h    Draw height.
	 */
	public function image_rgb( $rgb, $pw, $ph, $x, $y, $w, $h ) {
		$id                              = count( $this->images ) + 1;
		$this->images[ $id ]             = array( $pw, $ph, gzcompress( $rgb, 6 ) );
		$this->page_images[ $this->cur ][] = $id;
		$this->out( sprintf( 'q %.2F 0 0 %.2F %.2F %.2F cm /Im%d Do Q', $w, $h, $x, $this->h - $y - $h, $id ) );
	}

	/**
	 * Build the PDF file.
	 *
	 * @return string
	 */
	public function output() {
		$objs = array(); // Object bodies, index = object number - 1.
		$add  = function ( $body ) use ( &$objs ) {
			$objs[] = $body;
			return count( $objs );
		};

		$add( '' ); // 1: catalog (filled later).
		$add( '' ); // 2: pages (filled later).
		$f1 = $add( '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>' );
		$f2 = $add( '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>' );
		$f3 = $add( '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Oblique /Encoding /WinAnsiEncoding >>' );

		$img_obj = array();
		foreach ( $this->images as $id => $im ) {
			$img_obj[ $id ] = $add(
				sprintf(
					"<< /Type /XObject /Subtype /Image /Width %d /Height %d /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /FlateDecode /Length %d >>\nstream\n%s\nendstream",
					$im[0],
					$im[1],
					strlen( $im[2] ),
					$im[2]
				)
			);
		}

		$kids = array();
		foreach ( $this->pages as $i => $content ) {
			$stream   = gzcompress( $content, 6 );
			$c_obj    = $add( sprintf( "<< /Filter /FlateDecode /Length %d >>\nstream\n%s\nendstream", strlen( $stream ), $stream ) );
			$xobj     = '';
			foreach ( array_unique( $this->page_images[ $i ] ) as $id ) {
				$xobj .= sprintf( '/Im%d %d 0 R ', $id, $img_obj[ $id ] );
			}
			$p_obj  = $add(
				sprintf(
					'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %.2F %.2F] /Resources << /Font << /F1 %d 0 R /F2 %d 0 R /F3 %d 0 R >> /XObject << %s>> >> /Contents %d 0 R >>',
					$this->w,
					$this->h,
					$f1,
					$f2,
					$f3,
					$xobj,
					$c_obj
				)
			);
			$kids[] = $p_obj . ' 0 R';
		}

		$objs[0] = '<< /Type /Catalog /Pages 2 0 R >>';
		$objs[1] = sprintf( '<< /Type /Pages /Kids [%s] /Count %d >>', implode( ' ', $kids ), count( $kids ) );

		$info = '';
		foreach ( $this->info as $k => $v ) {
			$info .= sprintf( '/%s (%s) ', $k, $this->esc( $v ) );
		}
		$info .= '/Producer (QuoteSign) /CreationDate (D:' . gmdate( 'YmdHis' ) . 'Z)';
		$info_obj = $add( '<< ' . $info . ' >>' );

		$pdf     = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
		$offsets = array();
		foreach ( $objs as $i => $body ) {
			$offsets[ $i ] = strlen( $pdf );
			$pdf          .= ( $i + 1 ) . " 0 obj\n" . $body . "\nendobj\n";
		}
		$xref = strlen( $pdf );
		$pdf .= "xref\n0 " . ( count( $objs ) + 1 ) . "\n0000000000 65535 f \n";
		foreach ( $offsets as $off ) {
			$pdf .= sprintf( "%010d 00000 n \n", $off );
		}
		$pdf .= sprintf( "trailer\n<< /Size %d /Root 1 0 R /Info %d 0 R >>\nstartxref\n%d\n%%%%EOF", count( $objs ) + 1, $info_obj, $xref );
		return $pdf;
	}
}
