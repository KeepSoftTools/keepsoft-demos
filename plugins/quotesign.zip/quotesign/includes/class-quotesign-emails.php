<?php
/**
 * Email manager: registers WC_Email classes and wires triggers.
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registers QuoteSign emails with WooCommerce.
 */
class QuoteSign_Emails {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_filter( 'woocommerce_email_classes', array( __CLASS__, 'register' ) );
		add_action( 'quotesign_quote_created', array( __CLASS__, 'on_created' ) );
		add_action( 'quotesign_quote_accepted', array( __CLASS__, 'on_accepted' ) );
		add_action( 'quotesign_quote_declined', array( __CLASS__, 'on_declined' ) );
		add_action( 'quotesign_send_quote', array( __CLASS__, 'on_send_quote' ) );
		add_action( 'quotesign_send_reminder', array( __CLASS__, 'on_reminder' ) );
		add_action( 'quotesign_balance_requested', array( __CLASS__, 'on_balance' ), 10, 2 );
	}

	/**
	 * Register classes.
	 *
	 * @param array $emails Emails.
	 * @return array
	 */
	public static function register( $emails ) {
		require_once QUOTESIGN_PATH . 'includes/class-quotesign-email-types.php';
		$emails['QuoteSign_Email_New_Request']     = new QuoteSign_Email_New_Request();
		$emails['QuoteSign_Email_Request_Received'] = new QuoteSign_Email_Request_Received();
		$emails['QuoteSign_Email_Quote_Sent']       = new QuoteSign_Email_Quote_Sent();
		$emails['QuoteSign_Email_Quote_Accepted']   = new QuoteSign_Email_Quote_Accepted();
		$emails['QuoteSign_Email_Accepted_Admin']   = new QuoteSign_Email_Accepted_Admin();
		$emails['QuoteSign_Email_Quote_Declined']   = new QuoteSign_Email_Quote_Declined();
		$emails['QuoteSign_Email_Quote_Reminder']   = new QuoteSign_Email_Quote_Reminder();
		$emails['QuoteSign_Email_Balance_Request']  = new QuoteSign_Email_Balance_Request();
		return $emails;
	}

	/**
	 * Fire one of our emails.
	 *
	 * @param string $id   Email ID.
	 * @param mixed  ...$args Trigger args.
	 * @return bool Whether an email object handled it.
	 */
	public static function fire( $id, ...$args ) {
		$mailer = WC()->mailer();
		foreach ( $mailer->get_emails() as $email ) {
			if ( $email instanceof QuoteSign_Email_Base && $email->id === $id ) {
				$email->trigger( ...$args );
				return true;
			}
		}
		return false;
	}

	/**
	 * New request.
	 *
	 * @param QuoteSign_Quote $quote Quote.
	 */
	public static function on_created( $quote ) {
		self::fire( 'qs_new_request', $quote->id );
		self::fire( 'qs_request_received', $quote->id );
	}

	/**
	 * Accepted.
	 *
	 * @param QuoteSign_Quote $quote Quote.
	 */
	public static function on_accepted( $quote ) {
		self::fire( 'qs_quote_accepted', $quote->id );
		self::fire( 'qs_quote_accepted_admin', $quote->id );
	}

	/**
	 * Declined.
	 *
	 * @param QuoteSign_Quote $quote Quote.
	 */
	public static function on_declined( $quote ) {
		self::fire( 'qs_quote_declined', $quote->id );
	}

	/**
	 * Send the quote link.
	 *
	 * @param int $quote_id Quote ID.
	 */
	public static function on_send_quote( $quote_id ) {
		self::fire( 'qs_quote_sent', $quote_id );
	}

	/**
	 * Expiry reminder.
	 *
	 * @param int $quote_id Quote ID.
	 */
	public static function on_reminder( $quote_id ) {
		self::fire( 'qs_quote_reminder', $quote_id );
	}

	/**
	 * Balance requested.
	 *
	 * @param int $quote_id Quote ID.
	 * @param int $order_id Order ID.
	 */
	public static function on_balance( $quote_id, $order_id ) {
		self::fire( 'qs_balance_request', $quote_id, $order_id );
	}
}
