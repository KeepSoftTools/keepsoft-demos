<?php
/**
 * Plugin bootstrap.
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

/**
 * Main plugin class.
 */
final class QuoteSign_Plugin {

	/**
	 * Singleton.
	 *
	 * @var QuoteSign_Plugin|null
	 */
	private static $instance = null;

	/**
	 * Get instance.
	 *
	 * @return QuoteSign_Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'init', array( $this, 'load_textdomain' ), 1 );

		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action( 'admin_notices', array( $this, 'missing_woocommerce_notice' ) );
			return;
		}

		$this->includes();

		QuoteSign_CPT::init();
		QuoteSign_Rules::init();
		QuoteSign_Basket::init();
		QuoteSign_Frontend::init();
		QuoteSign_Public_Page::init();
		QuoteSign_REST::init();
		QuoteSign_Orders::init();
		QuoteSign_Emails::init();
		QuoteSign_Cron::init();
		QuoteSign_Webhook::init();
		if ( is_admin() ) {
			QuoteSign_Admin::init();
			QuoteSign_Export::init();
			QuoteSign_Dashboard::init();
		}
		QuoteSign_Privacy::init();
		add_action( 'init', array( $this, 'maybe_setup' ), 20 );
		add_filter( 'woocommerce_get_settings_pages', array( $this, 'register_settings_page' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( QUOTESIGN_FILE ), array( $this, 'action_links' ) );
	}

	/**
	 * Load classes.
	 */
	private function includes() {
		$files = array(
			'class-quotesign-settings.php',
			'class-quotesign-quote.php',
			'class-quotesign-cpt.php',
			'class-quotesign-rules.php',
			'class-quotesign-basket.php',
			'class-quotesign-frontend.php',
			'class-quotesign-public-page.php',
			'class-quotesign-rest.php',
			'class-quotesign-orders.php',
			'class-quotesign-emails.php',
			'class-quotesign-pdf.php',
			'class-quotesign-cron.php',
			'class-quotesign-webhook.php',
			'class-quotesign-export.php',
			'class-quotesign-dashboard.php',
			'class-quotesign-admin.php',
			'class-quotesign-privacy.php',
		);
		foreach ( $files as $file ) {
			require_once QUOTESIGN_PATH . 'includes/' . $file;
		}
	}

	/**
	 * Run first-time setup if the plugin was activated before WooCommerce existed.
	 */
	public function maybe_setup() {
		if ( ! get_option( 'quotesign_version' ) && current_user_can( 'activate_plugins' ) ) {
			self::activate();
		}
	}

	/**
	 * Load translations.
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 'quotesign', false, dirname( plugin_basename( QUOTESIGN_FILE ) ) . '/languages' );
	}

	/**
	 * Admin notice when WooCommerce is missing.
	 */
	public function missing_woocommerce_notice() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		echo '<div class="notice notice-error"><p>' . esc_html__( 'QuoteSign requires WooCommerce to be installed and active.', 'quotesign' ) . '</p></div>';
	}

	/**
	 * Register WooCommerce settings tab.
	 *
	 * @param array $pages Settings pages.
	 * @return array
	 */
	public function register_settings_page( $pages ) {
		require_once QUOTESIGN_PATH . 'includes/class-quotesign-settings-page.php';
		$pages[] = new QuoteSign_Settings_Page();
		return $pages;
	}

	/**
	 * Plugin action links.
	 *
	 * @param array $links Links.
	 * @return array
	 */
	public function action_links( $links ) {
		$url = admin_url( 'admin.php?page=wc-settings&tab=quotesign' );
		array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'quotesign' ) . '</a>' );
		return $links;
	}

	/**
	 * Activation.
	 */
	public static function activate() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}
		require_once QUOTESIGN_PATH . 'includes/class-quotesign-settings.php';
		require_once QUOTESIGN_PATH . 'includes/class-quotesign-cpt.php';
		require_once QUOTESIGN_PATH . 'includes/class-quotesign-public-page.php';
		require_once QUOTESIGN_PATH . 'includes/class-quotesign-frontend.php';

		QuoteSign_CPT::register();
		QuoteSign_Public_Page::add_rewrite();
		QuoteSign_Frontend::add_endpoint();

		// Basket page.
		$page_id = (int) QuoteSign_Settings::get( 'basket_page' );
		if ( ! $page_id || ! get_post( $page_id ) ) {
			$page_id = wp_insert_post(
				array(
					'post_type'    => 'page',
					'post_status'  => 'publish',
					'post_title'   => __( 'Quote basket', 'quotesign' ),
					'post_content' => '[quotesign_basket]',
				)
			);
			if ( $page_id && ! is_wp_error( $page_id ) ) {
				QuoteSign_Settings::update( 'basket_page', (int) $page_id );
			}
		}

		if ( ! wp_next_scheduled( 'quotesign_daily' ) ) {
			wp_schedule_event( time() + 300, 'daily', 'quotesign_daily' );
		}
		update_option( 'quotesign_version', QUOTESIGN_VERSION );
		flush_rewrite_rules();
	}

	/**
	 * Deactivation.
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( 'quotesign_daily' );
		flush_rewrite_rules();
	}
}
