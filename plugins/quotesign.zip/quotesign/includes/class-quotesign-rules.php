<?php
/**
 * Rules: which products / users get the quote button and hidden prices.
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

/**
 * Eligibility logic and price hiding.
 */
class QuoteSign_Rules {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_filter( 'woocommerce_get_price_html', array( __CLASS__, 'filter_price_html' ), 99, 2 );
		add_filter( 'woocommerce_is_purchasable', array( __CLASS__, 'filter_purchasable' ), 99, 2 );
		add_filter( 'woocommerce_add_to_cart_validation', array( __CLASS__, 'validate_add_to_cart' ), 99, 2 );
		add_action( 'woocommerce_before_single_variation', array( __CLASS__, 'maybe_remove_variation_button' ) );
		add_filter( 'woocommerce_show_variation_price', array( __CLASS__, 'filter_show_variation_price' ), 99, 3 );
		add_action( 'woocommerce_product_options_general_product_data', array( __CLASS__, 'product_field' ) );
		add_action( 'woocommerce_process_product_meta', array( __CLASS__, 'save_product_field' ) );
	}

	/**
	 * Is the feature on?
	 *
	 * @return bool
	 */
	public static function enabled() {
		return 'yes' === QuoteSign_Settings::get( 'enabled' );
	}

	/**
	 * Current user's role slugs (or guest).
	 *
	 * @return array
	 */
	public static function current_roles() {
		if ( ! is_user_logged_in() ) {
			return array( 'guest' );
		}
		$user = wp_get_current_user();
		return empty( $user->roles ) ? array( 'guest' ) : array_values( (array) $user->roles );
	}

	/**
	 * Is the current visitor allowed to use quotes?
	 *
	 * @return bool
	 */
	public static function user_allowed() {
		$roles = (array) QuoteSign_Settings::get( 'roles' );
		if ( empty( $roles ) ) {
			return true;
		}
		return (bool) array_intersect( $roles, self::current_roles() );
	}

	/**
	 * Does a product participate in quotes (ignoring the visitor)?
	 *
	 * @param WC_Product|int $product Product.
	 * @return bool
	 */
	public static function product_enabled( $product ) {
		if ( is_numeric( $product ) ) {
			$product = wc_get_product( $product );
		}
		if ( ! $product || ! self::enabled() ) {
			return false;
		}
		$parent_id = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();
		$mode      = QuoteSign_Settings::get( 'apply_to' );
		if ( 'categories' === $mode ) {
			$cats = array_map( 'intval', (array) QuoteSign_Settings::get( 'categories' ) );
			if ( empty( $cats ) ) {
				return false;
			}
			$terms = wp_get_post_terms( $parent_id, 'product_cat', array( 'fields' => 'ids' ) );
			if ( is_wp_error( $terms ) ) {
				return false;
			}
			// Include ancestors so child categories inherit.
			$all = array();
			foreach ( $terms as $tid ) {
				$all[] = (int) $tid;
				$all   = array_merge( $all, array_map( 'intval', get_ancestors( $tid, 'product_cat', 'taxonomy' ) ) );
			}
			return (bool) array_intersect( $cats, $all );
		}
		if ( 'products' === $mode ) {
			return 'yes' === get_post_meta( $parent_id, '_qs_enable_quote', true );
		}
		return true;
	}

	/**
	 * Should the current visitor see a quote button for this product?
	 *
	 * @param WC_Product|int $product Product.
	 * @return bool
	 */
	public static function show_button( $product ) {
		return self::product_enabled( $product ) && ( self::user_allowed() || self::hide_price( $product ) );
	}

	/**
	 * Replace add-to-cart for this visitor on this product?
	 *
	 * @param WC_Product $product Product.
	 * @return bool
	 */
	public static function replace_cart( $product ) {
		if ( ! self::show_button( $product ) ) {
			return false;
		}
		return 'replace' === QuoteSign_Settings::get( 'button_mode' ) || self::hide_price( $product );
	}

	/**
	 * Hide the price of this product from the current visitor?
	 *
	 * @param WC_Product|null $product Product.
	 * @return bool
	 */
	public static function hide_price( $product = null ) {
		if ( ! self::enabled() ) {
			return false;
		}
		$mode = QuoteSign_Settings::get( 'hide_price' );
		if ( 'never' === $mode ) {
			return false;
		}
		if ( $product && ! self::product_enabled( $product ) ) {
			return false;
		}
		if ( 'all' === $mode ) {
			return true;
		}
		if ( 'guests' === $mode ) {
			return ! is_user_logged_in();
		}
		if ( 'roles' === $mode ) {
			return (bool) array_intersect( (array) QuoteSign_Settings::get( 'hide_price_roles' ), self::current_roles() );
		}
		return false;
	}

	/**
	 * Price HTML filter.
	 *
	 * @param string     $html    Price HTML.
	 * @param WC_Product $product Product.
	 * @return string
	 */
	public static function filter_price_html( $html, $product ) {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return $html;
		}
		if ( self::hide_price( $product ) ) {
			$text = (string) QuoteSign_Settings::get( 'hide_price_text' );
			return '' !== $text ? '<span class="qs-hidden-price">' . esc_html( $text ) . '</span>' : '';
		}
		return $html;
	}

	/**
	 * Purchasable filter.
	 *
	 * @param bool       $purchasable Purchasable.
	 * @param WC_Product $product     Product.
	 * @return bool
	 */
	public static function filter_purchasable( $purchasable, $product ) {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return $purchasable;
		}
		// Never interfere with orders created by the plugin or the REST API.
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST && current_user_can( 'manage_woocommerce' ) ) {
			return $purchasable;
		}
		if ( $product->is_type( array( 'variable', 'variation' ) ) ) {
			return $purchasable; // Handled by removing the button and by add-to-cart validation.
		}
		if ( $purchasable && self::replace_cart( $product ) ) {
			return false;
		}
		return $purchasable;
	}

	/**
	 * Block add-to-cart (e.g. via URL tampering) when the quote button replaces it.
	 *
	 * @param bool $passed     Passed.
	 * @param int  $product_id Product.
	 * @return bool
	 */
	public static function validate_add_to_cart( $passed, $product_id ) {
		$product = wc_get_product( $product_id );
		if ( $product && self::replace_cart( $product ) ) {
			wc_add_notice( __( 'This product is available by quote only.', 'quotesign' ), 'error' );
			return false;
		}
		return $passed;
	}

	/**
	 * Remove the variable add-to-cart button when it is replaced by the quote button.
	 */
	public static function maybe_remove_variation_button() {
		global $product;
		if ( $product && self::replace_cart( $product ) ) {
			remove_action( 'woocommerce_single_variation', 'woocommerce_single_variation_add_to_cart_button', 20 );
			add_action( 'woocommerce_single_variation', array( __CLASS__, 'variation_hidden_inputs' ), 20 );
		}
	}

	/**
	 * Keep the hidden inputs WooCommerce's variation script updates (the quote button reads variation_id).
	 */
	public static function variation_hidden_inputs() {
		global $product;
		echo '<input type="hidden" name="variation_id" class="variation_id" value="0" />';
		if ( $product ) {
			echo '<input type="hidden" name="product_id" value="' . esc_attr( $product->get_id() ) . '" />';
		}
	}

	/**
	 * Hide variation price block.
	 *
	 * @param bool                 $show      Show.
	 * @param WC_Product           $product   Parent.
	 * @param WC_Product_Variation $variation Variation.
	 * @return bool
	 */
	public static function filter_show_variation_price( $show, $product, $variation ) {
		return self::hide_price( $product ) ? false : $show;
	}

	/**
	 * Product edit field.
	 */
	public static function product_field() {
		woocommerce_wp_checkbox(
			array(
				'id'          => '_qs_enable_quote',
				'label'       => __( 'Request a quote', 'quotesign' ),
				'description' => __( 'Enable "Add to quote" for this product (used when QuoteSign is set to apply to selected products).', 'quotesign' ),
			)
		);
		wp_nonce_field( 'qs_product_field', 'qs_product_nonce' );
	}

	/**
	 * Save product field.
	 *
	 * @param int $post_id Product ID.
	 */
	public static function save_product_field( $post_id ) {
		if ( ! isset( $_POST['qs_product_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['qs_product_nonce'] ) ), 'qs_product_field' ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		update_post_meta( $post_id, '_qs_enable_quote', isset( $_POST['_qs_enable_quote'] ) ? 'yes' : 'no' );
	}
}
