<?php
/**
 * Quote PDF layout.
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

require_once QUOTESIGN_PATH . 'includes/lib/class-quotesign-pdf-writer.php';

/**
 * Renders a quote (with signature and audit trail when signed) to PDF.
 */
class QuoteSign_PDF {

	const MARGIN = 42;

	/** @var QuoteSign_PDF_Writer */
	private $pdf;
	/** @var float */
	private $y = 0;
	/** @var QuoteSign_Quote */
	private $quote;

	/**
	 * Render a quote to a PDF string.
	 *
	 * @param QuoteSign_Quote $quote Quote.
	 * @return string|WP_Error
	 */
	public static function render( $quote ) {
		if ( ! function_exists( 'gzcompress' ) ) {
			return new WP_Error( 'qs_zlib', __( 'The PHP zlib extension is required to create PDFs.', 'quotesign' ) );
		}
		$doc = new self();
		return $doc->build( $quote );
	}

	/**
	 * Save a PDF to a temporary file (for email attachments).
	 *
	 * @param QuoteSign_Quote $quote Quote.
	 * @return string|false Path.
	 */
	public static function to_temp_file( $quote ) {
		$pdf = self::render( $quote );
		if ( is_wp_error( $pdf ) ) {
			return false;
		}
		$dir = trailingslashit( get_temp_dir() );
		$tmp = $dir . 'quotesign-' . $quote->number() . '-' . wp_generate_password( 8, false, false ) . '.pdf';
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		if ( false === file_put_contents( $tmp, $pdf ) ) {
			return false;
		}
		return $tmp;
	}

	/**
	 * Money string for PDF (no HTML; falls back to currency code for symbols Helvetica lacks).
	 *
	 * @param float  $n        Amount.
	 * @param string $currency Currency code.
	 * @return string
	 */
	private function money( $n, $currency ) {
		$sym = html_entity_decode( get_woocommerce_currency_symbol( $currency ), ENT_QUOTES, 'UTF-8' );
		$win = $this->pdf->to_win( $sym );
		if ( '' === $sym || false !== strpos( $win, '?' ) ) {
			$sym = $currency . ' ';
		}
		$num = number_format( (float) $n, wc_get_price_decimals(), wc_get_price_decimal_separator(), wc_get_price_thousand_separator() );
		switch ( get_option( 'woocommerce_currency_pos', 'left' ) ) {
			case 'right':
				return $num . $sym;
			case 'left_space':
				return $sym . ' ' . $num;
			case 'right_space':
				return $num . ' ' . $sym;
			default:
				return $sym . $num;
		}
	}

	/**
	 * Wrap text to a width.
	 *
	 * @param string $text  Text.
	 * @param float  $width Width in pt.
	 * @return string[]
	 */
	private function wrap( $text, $width ) {
		$lines = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $para ) {
			$words = preg_split( '/\s+/', trim( $para ), -1, PREG_SPLIT_NO_EMPTY );
			if ( empty( $words ) ) {
				$lines[] = '';
				continue;
			}
			$line = '';
			foreach ( $words as $word ) {
				// Break very long words.
				while ( $this->pdf->width( $word ) > $width && function_exists( 'mb_strlen' ) && mb_strlen( $word ) > 1 ) {
					$cut = mb_strlen( $word );
					while ( $cut > 1 && $this->pdf->width( mb_substr( $word, 0, $cut ) ) > $width ) {
						--$cut;
					}
					if ( '' !== $line ) {
						$lines[] = $line;
						$line    = '';
					}
					$lines[] = mb_substr( $word, 0, $cut );
					$word    = mb_substr( $word, $cut );
				}
				$try = '' === $line ? $word : $line . ' ' . $word;
				if ( $this->pdf->width( $try ) <= $width ) {
					$line = $try;
				} else {
					$lines[] = $line;
					$line    = $word;
				}
			}
			$lines[] = $line;
		}
		return $lines;
	}

	/**
	 * Start a new page if fewer than $need points remain.
	 *
	 * @param float $need Points needed.
	 */
	private function ensure( $need ) {
		if ( $this->y + $need > $this->pdf->h - 60 ) {
			$this->pdf->add_page();
			$this->y = self::MARGIN + 10;
		}
	}

	/**
	 * Write wrapped paragraph(s).
	 *
	 * @param string $text   Text.
	 * @param float  $x      X.
	 * @param float  $width  Width.
	 * @param float  $lead   Line height.
	 */
	private function paragraph( $text, $x, $width, $lead ) {
		foreach ( $this->wrap( $text, $width ) as $line ) {
			$this->ensure( $lead );
			$this->pdf->text( $x, $this->y, $line );
			$this->y += $lead;
		}
	}

	/**
	 * Build.
	 *
	 * @param QuoteSign_Quote $quote Quote.
	 * @return string
	 */
	private function build( $quote ) {
		$this->quote = $quote;
		$this->pdf   = new QuoteSign_PDF_Writer();
		$pdf         = $this->pdf;
		$cur         = $quote->currency();
		$totals      = $quote->totals();
		$m           = self::MARGIN;
		$right       = $pdf->w - $m;
		$cw          = $pdf->w - 2 * $m;

		$pdf->set_info( sprintf( 'Quote %s', $quote->number() ), QuoteSign_Settings::company_name() );
		$pdf->add_page();

		// Header.
		$this->y = $m + 12;
		$pdf->color( '1F2937' );
		$pdf->set_font( 'B', 18 );
		$pdf->text( $m, $this->y, QuoteSign_Settings::company_name() );
		$pdf->set_font( 'B', 22 );
		$pdf->color( '2563EB' );
		$pdf->text( $right, $this->y, __( 'QUOTE', 'quotesign' ), 'R' );

		$this->y += 18;
		$pdf->set_font( 'R', 9 );
		$pdf->color( '6B7280' );
		$details_y = $this->y;
		foreach ( $this->wrap( (string) QuoteSign_Settings::get( 'company_details' ), 280 ) as $line ) {
			$pdf->text( $m, $details_y, $line );
			$details_y += 12;
		}
		$meta_y = $this->y;
		$pdf->set_font( 'B', 10 );
		$pdf->color( '1F2937' );
		$pdf->text( $right, $meta_y, $quote->number(), 'R' );
		$pdf->set_font( 'R', 9 );
		$pdf->color( '6B7280' );
		$meta_y += 13;
		$pdf->text( $right, $meta_y, __( 'Date:', 'quotesign' ) . ' ' . get_the_date( '', $quote->id ), 'R' );
		if ( $quote->expiry() ) {
			$meta_y += 12;
			$pdf->text( $right, $meta_y, __( 'Valid until:', 'quotesign' ) . ' ' . mysql2date( get_option( 'date_format' ), $quote->expiry() ), 'R' );
		}
		$meta_y += 12;
		$pdf->text( $right, $meta_y, __( 'Status:', 'quotesign' ) . ' ' . $quote->status_label(), 'R' );
		$this->y = max( $details_y, $meta_y ) + 10;
		$pdf->line( $m, $this->y, $right, $this->y, 1 );
		$this->y += 20;

		// Customer.
		$pdf->set_font( 'B', 9 );
		$pdf->color( '6B7280' );
		$pdf->text( $m, $this->y, strtoupper( __( 'Prepared for', 'quotesign' ) ) );
		$this->y += 14;
		$pdf->set_font( 'B', 11 );
		$pdf->color( '1F2937' );
		$pdf->text( $m, $this->y, $quote->customer_name() );
		$pdf->set_font( 'R', 10 );
		foreach ( array( $quote->meta( 'company' ), $quote->customer_email(), $quote->meta( 'phone' ) ) as $l ) {
			if ( $l ) {
				$this->y += 13;
				$pdf->text( $m, $this->y, $l );
			}
		}
		$this->y += 28;

		// Items table.
		$col_qty   = $m + $cw - 200;
		$col_unit  = $m + $cw - 90;
		$col_total = $right;
		$name_w    = $col_qty - $m - 40;

		$header = function () use ( $pdf, $m, $cw, $col_qty, $col_unit, $col_total ) {
			$pdf->color( 'F3F4F6' );
			$pdf->rect( $m, $this->y - 12, $cw, 20, 'F' );
			$pdf->set_font( 'B', 9 );
			$pdf->color( '374151' );
			$pdf->text( $m + 8, $this->y + 1, __( 'Item', 'quotesign' ) );
			$pdf->text( $col_qty, $this->y + 1, __( 'Qty', 'quotesign' ), 'R' );
			$pdf->text( $col_unit, $this->y + 1, __( 'Unit price', 'quotesign' ), 'R' );
			$pdf->text( $col_total - 8, $this->y + 1, __( 'Total', 'quotesign' ), 'R' );
			$this->y += 22;
		};
		$header();

		foreach ( $quote->items() as $item ) {
			$pdf->set_font( 'B', 10 );
			$name_lines = $this->wrap( $item['name'], $name_w );
			$extra      = array();
			$pdf->set_font( 'R', 8 );
			if ( ! empty( $item['sku'] ) ) {
				$extra[] = sprintf( /* translators: %s: SKU */ __( 'SKU: %s', 'quotesign' ), $item['sku'] );
			}
			if ( ! empty( $item['desc'] ) ) {
				$extra = array_merge( $extra, $this->wrap( $item['desc'], $name_w ) );
			}
			$content = ( count( $name_lines ) - 1 ) * 13 + count( $extra ) * 11;
			$h       = $content + 26;
			if ( $this->y + $h > $pdf->h - 60 ) {
				$pdf->add_page();
				$this->y = $m + 20;
				$header();
			}
			$row_top = $this->y;
			$pdf->set_font( 'B', 10 );
			$pdf->color( '1F2937' );
			$yy = $this->y;
			foreach ( $name_lines as $nl ) {
				$pdf->text( $m + 8, $yy, $nl );
				$yy += 13;
			}
			$pdf->set_font( 'R', 8 );
			$pdf->color( '6B7280' );
			foreach ( $extra as $el ) {
				$pdf->text( $m + 8, $yy, $el );
				$yy += 11;
			}
			$pdf->set_font( 'R', 10 );
			$pdf->color( '1F2937' );
			$pdf->text( $col_qty, $row_top, wc_format_localized_decimal( $item['qty'] ), 'R' );
			$pdf->text( $col_unit, $row_top, $this->money( $item['price'], $cur ), 'R' );
			$pdf->text( $col_total - 8, $row_top, $this->money( round( $item['qty'] * $item['price'], wc_get_price_decimals() ), $cur ), 'R' );
			$pdf->line( $m, $row_top + $content + 8, $right, $row_top + $content + 8, 0.3 );
			$this->y = $row_top + $h;
		}

		// Totals.
		$this->ensure( 120 );
		$this->y += 6;
		$lab_x = $right - 210;
		$row   = function ( $label, $value, $bold = false, $colour = '1F2937' ) use ( $pdf, $lab_x, $right ) {
			$this->ensure( 16 );
			$pdf->set_font( $bold ? 'B' : 'R', $bold ? 11 : 10 );
			$pdf->color( $colour );
			$pdf->text( $lab_x, $this->y, $label );
			$pdf->text( $right - 8, $this->y, $value, 'R' );
			$this->y += $bold ? 18 : 15;
		};
		$row( __( 'Subtotal', 'quotesign' ), $this->money( $totals['subtotal'], $cur ) );
		if ( $totals['discount'] > 0 ) {
			$row( __( 'Discount', 'quotesign' ), '-' . $this->money( $totals['discount'], $cur ) );
		}
		if ( $totals['tax'] > 0 ) {
			$row( sprintf( '%s (%s%%)', QuoteSign_Settings::tax_label(), wc_format_localized_decimal( $totals['tax_rate'] ) ), $this->money( $totals['tax'], $cur ) );
		}
		$pdf->line( $lab_x, $this->y - 11, $right, $this->y - 11, 0.8 );
		$this->y += 2;
		$row( __( 'Total', 'quotesign' ), $this->money( $totals['total'], $cur ), true, '2563EB' );
		if ( $quote->has_deposit() ) {
			$row( __( 'Deposit due on acceptance', 'quotesign' ), $this->money( $totals['deposit_due'], $cur ) );
			$row( __( 'Balance', 'quotesign' ), $this->money( $totals['balance'], $cur ) );
		}
		$this->y += 10;

		// Terms.
		$terms = trim( wp_strip_all_tags( (string) $quote->meta( 'terms' ) ) );
		if ( '' !== $terms ) {
			$this->ensure( 40 );
			$pdf->set_font( 'B', 11 );
			$pdf->color( '1F2937' );
			$pdf->text( $m, $this->y, __( 'Terms & conditions', 'quotesign' ) );
			$this->y += 15;
			$pdf->set_font( 'R', 9 );
			$pdf->color( '374151' );
			$this->paragraph( $terms, $m, $cw, 12 );
			$this->y += 8;
		}

		// Signature.
		$sig = $quote->signature();
		if ( $sig && 'accepted' === $quote->status() ) {
			$this->signature_block( $sig );
			$this->audit_block();
		}

		// Footers.
		$total_pages = $pdf->page_count();
		for ( $i = 0; $i < $total_pages; $i++ ) {
			$pdf->go_to_page( $i );
			$pdf->set_font( 'R', 8 );
			$pdf->color( '9CA3AF' );
			$pdf->line( $m, $pdf->h - 40, $right, $pdf->h - 40, 0.3 );
			$pdf->text( $m, $pdf->h - 28, $quote->number() . ' – ' . QuoteSign_Settings::company_name() );
			/* translators: 1: page number, 2: total pages */
			$pdf->text( $right, $pdf->h - 28, sprintf( __( 'Page %1$d of %2$d', 'quotesign' ), $i + 1, $total_pages ), 'R' );
		}

		return $pdf->output();
	}

	/**
	 * Signature block.
	 *
	 * @param array $sig Signature record.
	 */
	private function signature_block( $sig ) {
		$pdf = $this->pdf;
		$m   = self::MARGIN;
		$this->ensure( 190 );
		$this->y += 14;
		$pdf->color( 'F9FAFB' );
		$pdf->rect( $m, $this->y - 14, $pdf->w - 2 * $m, 150, 'F' );
		$pdf->set_font( 'B', 11 );
		$pdf->color( '1F2937' );
		$pdf->text( $m + 12, $this->y, __( 'Accepted & electronically signed', 'quotesign' ) );
		$this->y += 10;

		$drawn = false;
		if ( 'drawn' === $sig['mode'] && ! empty( $sig['data'] ) ) {
			$drawn = $this->draw_signature_image( $sig['data'], $m + 12, $this->y, 200, 62 );
		}
		if ( ! $drawn ) {
			$pdf->set_font( 'I', 24 );
			$pdf->color( '111827' );
			$pdf->text( $m + 12, $this->y + 42, $sig['name'] );
		}
		$pdf->line( $m + 12, $this->y + 66, $m + 232, $this->y + 66, 0.6 );
		$this->y += 80;

		$pdf->set_font( 'R', 9 );
		$pdf->color( '374151' );
		$lines = array(
			sprintf( /* translators: %s: name */ __( 'Signed by: %s', 'quotesign' ), $sig['name'] ),
			sprintf( /* translators: %s: date */ __( 'Date: %s', 'quotesign' ), wp_date( 'Y-m-d H:i:s T', (int) $sig['time'] ) . ' (' . gmdate( 'Y-m-d H:i:s', (int) $sig['time'] ) . ' UTC)' ),
			sprintf( /* translators: %s: IP */ __( 'IP address: %s', 'quotesign' ), $sig['ip'] ),
		);
		foreach ( $lines as $l ) {
			$pdf->text( $m + 12, $this->y, $l );
			$this->y += 12;
		}
		$this->y += 20;
	}

	/**
	 * Draw a PNG data URL onto the PDF (flattened on white).
	 *
	 * @param string $data_url Data URL.
	 * @param float  $x        X.
	 * @param float  $y        Y.
	 * @param float  $max_w    Max width.
	 * @param float  $max_h    Max height.
	 * @return bool
	 */
	private function draw_signature_image( $data_url, $x, $y, $max_w, $max_h ) {
		if ( ! function_exists( 'imagecreatefromstring' ) ) {
			return false;
		}
		$raw = base64_decode( substr( $data_url, strpos( $data_url, ',' ) + 1 ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
		if ( ! $raw ) {
			return false;
		}
		$src = @imagecreatefromstring( $raw ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		if ( ! $src ) {
			return false;
		}
		$w = imagesx( $src );
		$h = imagesy( $src );
		// Down-scale large canvases to keep the PDF small.
		$scale = min( 1, 800 / max( 1, $w ) );
		$tw    = max( 1, (int) round( $w * $scale ) );
		$th    = max( 1, (int) round( $h * $scale ) );
		$dst   = imagecreatetruecolor( $tw, $th );
		imagefill( $dst, 0, 0, imagecolorallocate( $dst, 255, 255, 255 ) );
		imagealphablending( $dst, true );
		imagecopyresampled( $dst, $src, 0, 0, 0, 0, $tw, $th, $w, $h );
		$rgb = '';
		for ( $yy = 0; $yy < $th; $yy++ ) {
			for ( $xx = 0; $xx < $tw; $xx++ ) {
				$c    = imagecolorat( $dst, $xx, $yy );
				$rgb .= chr( ( $c >> 16 ) & 255 ) . chr( ( $c >> 8 ) & 255 ) . chr( $c & 255 );
			}
		}
		imagedestroy( $src );
		imagedestroy( $dst );
		$ratio = min( $max_w / $tw, $max_h / $th );
		$this->pdf->image_rgb( $rgb, $tw, $th, $x, $y, $tw * $ratio, $th * $ratio );
		return true;
	}

	/**
	 * Audit trail table.
	 */
	private function audit_block() {
		$pdf = $this->pdf;
		$m   = self::MARGIN;
		$cw  = $pdf->w - 2 * $m;
		$this->ensure( 60 );
		$pdf->set_font( 'B', 11 );
		$pdf->color( '1F2937' );
		$pdf->text( $m, $this->y, __( 'Audit trail', 'quotesign' ) );
		$this->y += 16;

		foreach ( $this->quote->audit() as $e ) {
			$when   = gmdate( 'Y-m-d H:i:s', (int) $e['time'] ) . ' UTC';
			$label  = self::event_label( $e['event'] );
			$detail = $e['detail'];
			if ( ! empty( $e['ip'] ) ) {
				$detail .= ( $detail ? ' | ' : '' ) . 'IP ' . $e['ip'];
			}
			$lines = $this->wrap( $label . ( $detail ? ' – ' . $detail : '' ), $cw - 120 );
			$need  = max( 1, count( $lines ) ) * 11 + 4;
			$this->ensure( $need );
			$pdf->set_font( 'R', 8 );
			$pdf->color( '6B7280' );
			$pdf->text( $m, $this->y, $when );
			$pdf->color( '1F2937' );
			$yy = $this->y;
			foreach ( $lines as $l ) {
				$pdf->text( $m + 120, $yy, $l );
				$yy += 11;
			}
			$this->y = $yy + 3;
		}

		$sig = $this->quote->signature();
		if ( $sig && ! empty( $sig['ua'] ) ) {
			$this->y += 4;
			$pdf->set_font( 'R', 8 );
			$pdf->color( '6B7280' );
			$this->paragraph( __( 'Device:', 'quotesign' ) . ' ' . $sig['ua'], $m, $cw, 11 );
		}
	}

	/**
	 * Human readable event.
	 *
	 * @param string $event Code.
	 * @return string
	 */
	public static function event_label( $event ) {
		$labels = array(
			'created'          => __( 'Quote created', 'quotesign' ),
			'status_sent'      => __( 'Quote sent', 'quotesign' ),
			'status_viewed'    => __( 'Quote viewed', 'quotesign' ),
			'status_accepted'  => __( 'Quote accepted', 'quotesign' ),
			'status_declined'  => __( 'Quote declined', 'quotesign' ),
			'status_expired'   => __( 'Quote expired', 'quotesign' ),
			'status_new'       => __( 'Set to new', 'quotesign' ),
			'terms_agreed'     => __( 'Terms agreed', 'quotesign' ),
			'signed'           => __( 'Signature captured', 'quotesign' ),
			'deposit_order'    => __( 'Order created', 'quotesign' ),
			'balance_order'    => __( 'Balance order created', 'quotesign' ),
			'deposit_paid'     => __( 'Payment received', 'quotesign' ),
			'balance_paid'     => __( 'Balance payment received', 'quotesign' ),
			'email_sent'       => __( 'Email sent', 'quotesign' ),
			'reminder_sent'    => __( 'Expiry reminder sent', 'quotesign' ),
		);
		return isset( $labels[ $event ] ) ? $labels[ $event ] : $event;
	}
}
