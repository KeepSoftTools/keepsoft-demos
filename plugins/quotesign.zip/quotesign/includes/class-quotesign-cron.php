<?php
/**
 * WP-Cron: expiry and reminders.
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

/**
 * Daily housekeeping.
 */
class QuoteSign_Cron {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'quotesign_daily', array( __CLASS__, 'run' ) );
		add_action( 'init', array( __CLASS__, 'ensure_scheduled' ) );
	}

	/**
	 * Re-schedule if something cleared the event.
	 */
	public static function ensure_scheduled() {
		if ( ! wp_next_scheduled( 'quotesign_daily' ) ) {
			wp_schedule_event( time() + 300, 'daily', 'quotesign_daily' );
		}
	}

	/**
	 * Run expiry + reminders.
	 *
	 * @return array Counts [expired, reminded].
	 */
	public static function run() {
		$today   = wp_date( 'Y-m-d' );
		$expired = 0;
		$reminded = 0;

		// 1. Expire.
		$ids = get_posts(
			array(
				'post_type'      => 'qs_quote',
				'post_status'    => 'publish',
				'posts_per_page' => 200,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery
					'relation' => 'AND',
					array(
						'key'     => '_qs_status',
						'value'   => array( 'sent', 'viewed' ),
						'compare' => 'IN',
					),
					array(
						'key'     => '_qs_expiry',
						'value'   => $today,
						'compare' => '<',
						'type'    => 'CHAR',
					),
					array(
						'key'     => '_qs_expiry',
						'value'   => '',
						'compare' => '!=',
					),
				),
			)
		);
		foreach ( $ids as $id ) {
			$q = QuoteSign_Quote::get( $id );
			if ( $q && $q->set_status( 'expired', __( 'Expiry date passed', 'quotesign' ) ) ) {
				++$expired;
			}
		}

		// 2. Reminders.
		if ( 'yes' === QuoteSign_Settings::get( 'reminder_enabled' ) ) {
			$days   = max( 1, (int) QuoteSign_Settings::get( 'reminder_days' ) );
			$target = wp_date( 'Y-m-d', time() + $days * DAY_IN_SECONDS );
			$ids    = get_posts(
				array(
					'post_type'      => 'qs_quote',
					'post_status'    => 'publish',
					'posts_per_page' => 200,
					'fields'         => 'ids',
					'no_found_rows'  => true,
					'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery
						'relation' => 'AND',
						array(
							'key'     => '_qs_status',
							'value'   => array( 'sent', 'viewed' ),
							'compare' => 'IN',
						),
						array(
							'key'     => '_qs_expiry',
							'value'   => array( $today, $target ),
							'compare' => 'BETWEEN',
							'type'    => 'CHAR',
						),
						array(
							'key'     => '_qs_reminder_sent',
							'compare' => 'NOT EXISTS',
						),
					),
				)
			);
			foreach ( $ids as $id ) {
				$q = QuoteSign_Quote::get( $id );
				if ( ! $q || ! $q->is_open() ) {
					continue;
				}
				update_post_meta( $id, '_qs_reminder_sent', time() );
				do_action( 'quotesign_send_reminder', $id );
				$q->log( 'reminder_sent', $q->expiry() );
				++$reminded;
			}
		}

		return array( $expired, $reminded );
	}
}
