<?php
/**
 * WooCommerce settings tab.
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WC_Settings_Page' ) ) {
	return;
}

/**
 * WooCommerce > Settings > Quotes.
 */
class QuoteSign_Settings_Page extends WC_Settings_Page {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->id    = 'quotesign';
		$this->label = __( 'Quotes', 'quotesign' );
		parent::__construct();
	}

	/**
	 * Sections.
	 *
	 * @return array
	 */
	protected function get_own_sections() {
		return array(
			''         => __( 'Request a quote', 'quotesign' ),
			'quotes'   => __( 'Quote defaults', 'quotesign' ),
			'deposits' => __( 'Deposits & orders', 'quotesign' ),
			'notify'   => __( 'Notifications & expiry', 'quotesign' ),
			'webhook'  => __( 'Webhook', 'quotesign' ),
			'data'     => __( 'Data', 'quotesign' ),
		);
	}

	/**
	 * Get settings for a section.
	 *
	 * @param string $section Section ID.
	 * @return array
	 */
	protected function get_settings_for_section_core( $section ) {
		return $this->get_settings( $section );
	}

	/**
	 * Back-compat for older WooCommerce: get_sections.
	 *
	 * @return array
	 */
	public function get_sections() {
		return apply_filters( 'woocommerce_get_sections_' . $this->id, $this->get_own_sections() );
	}

	/**
	 * Build settings array.
	 *
	 * @param string $section Section.
	 * @return array
	 */
	public function get_settings( $section = '' ) {
		$d = QuoteSign_Settings::defaults();
		$o = QuoteSign_Settings::OPTION;

		$roles = array( 'guest' => __( 'Guests (not logged in)', 'quotesign' ) );
		foreach ( wp_roles()->get_names() as $slug => $name ) {
			$roles[ $slug ] = translate_user_role( $name );
		}

		$cats = array();
		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
			)
		);
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$cats[ $term->term_id ] = $term->name;
			}
		}

		switch ( $section ) {
			case 'quotes':
				$settings = array(
					array(
						'title' => __( 'Quote defaults', 'quotesign' ),
						'type'  => 'title',
						'id'    => 'qs_quotes_title',
					),
					array(
						'title'   => __( 'Company name', 'quotesign' ),
						'desc'    => __( 'Shown on quotes and PDFs. Defaults to the site title.', 'quotesign' ),
						'id'      => $o . '[company_name]',
						'type'    => 'text',
						'default' => $d['company_name'],
					),
					array(
						'title'   => __( 'Company details', 'quotesign' ),
						'desc'    => __( 'Address, tax number, phone. Shown under the company name.', 'quotesign' ),
						'id'      => $o . '[company_details]',
						'type'    => 'textarea',
						'css'     => 'width:400px;height:90px;',
						'default' => $d['company_details'],
					),
					array(
						'title'             => __( 'Validity (days)', 'quotesign' ),
						'desc'              => __( 'How long a quote stays open after you send it.', 'quotesign' ),
						'id'                => $o . '[validity_days]',
						'type'              => 'number',
						'custom_attributes' => array( 'min' => 1, 'step' => 1 ),
						'default'           => $d['validity_days'],
					),
					array(
						'title'   => __( 'Tax label', 'quotesign' ),
						'id'      => $o . '[tax_label]',
						'type'    => 'text',
						'desc'    => __( 'For example GST, VAT or Sales tax.', 'quotesign' ),
						'default' => $d['tax_label'],
					),
					array(
						'title'             => __( 'Default tax rate (%)', 'quotesign' ),
						'id'                => $o . '[tax_rate]',
						'type'              => 'text',
						'class'             => 'wc_input_decimal',
						'default'           => $d['tax_rate'],
					),
					array(
						'title'   => __( 'Default terms & conditions', 'quotesign' ),
						'desc'    => __( 'Pre-filled on every new quote. The customer must agree to these before signing.', 'quotesign' ),
						'id'      => $o . '[default_terms]',
						'type'    => 'textarea',
						'css'     => 'width:400px;height:150px;',
						'default' => $d['default_terms'],
					),
					array(
						'type' => 'sectionend',
						'id'   => 'qs_quotes_title',
					),
				);
				break;

			case 'deposits':
				$settings = array(
					array(
						'title' => __( 'Deposits & orders', 'quotesign' ),
						'type'  => 'title',
						'id'    => 'qs_dep_title',
					),
					array(
						'title'   => __( 'Create order on acceptance', 'quotesign' ),
						'desc'    => __( 'When a customer signs, create a WooCommerce order and send them to checkout to pay.', 'quotesign' ),
						'id'      => $o . '[create_order]',
						'type'    => 'checkbox',
						'default' => $d['create_order'],
					),
					array(
						'title'   => __( 'Default deposit type', 'quotesign' ),
						'desc'    => __( 'Can be overridden on each quote.', 'quotesign' ),
						'id'      => $o . '[deposit_type]',
						'type'    => 'select',
						'class'   => 'wc-enhanced-select',
						'options' => array(
							'none'    => __( 'No deposit (full payment)', 'quotesign' ),
							'percent' => __( 'Percentage of total', 'quotesign' ),
							'fixed'   => __( 'Fixed amount', 'quotesign' ),
						),
						'default' => $d['deposit_type'],
					),
					array(
						'title'   => __( 'Default deposit value', 'quotesign' ),
						'desc'    => __( 'A percentage (e.g. 30) or an amount in your store currency.', 'quotesign' ),
						'id'      => $o . '[deposit_value]',
						'type'    => 'text',
						'class'   => 'wc_input_decimal',
						'default' => $d['deposit_value'],
					),
					array(
						'type' => 'sectionend',
						'id'   => 'qs_dep_title',
					),
				);
				break;

			case 'notify':
				$settings = array(
					array(
						'title' => __( 'Notifications & expiry', 'quotesign' ),
						'type'  => 'title',
						'desc'  => __( 'Email subjects and headings can be edited under WooCommerce > Settings > Emails.', 'quotesign' ),
						'id'    => 'qs_notify_title',
					),
					array(
						'title'   => __( 'Admin notification email', 'quotesign' ),
						'desc'    => __( 'Receives new request, signed and declined notices. Defaults to the site admin email.', 'quotesign' ),
						'id'      => $o . '[admin_email]',
						'type'    => 'email',
						'default' => $d['admin_email'],
					),
					array(
						'title'   => __( 'Expiry reminder', 'quotesign' ),
						'desc'    => __( 'Email the customer shortly before their quote expires.', 'quotesign' ),
						'id'      => $o . '[reminder_enabled]',
						'type'    => 'checkbox',
						'default' => $d['reminder_enabled'],
					),
					array(
						'title'             => __( 'Reminder days before expiry', 'quotesign' ),
						'id'                => $o . '[reminder_days]',
						'type'              => 'number',
						'custom_attributes' => array( 'min' => 1, 'step' => 1 ),
						'default'           => $d['reminder_days'],
					),
					array(
						'type' => 'sectionend',
						'id'   => 'qs_notify_title',
					),
				);
				break;

			case 'webhook':
				$settings = array(
					array(
						'title' => __( 'Webhook', 'quotesign' ),
						'type'  => 'title',
						'desc'  => __( 'QuoteSign sends a JSON POST to this URL when a quote is created, sent, viewed, accepted, declined or expired. Requests are signed with HMAC-SHA256 in the X-QuoteSign-Signature header.', 'quotesign' ),
						'id'    => 'qs_hook_title',
					),
					array(
						'title'   => __( 'Webhook URL', 'quotesign' ),
						'id'      => $o . '[webhook_url]',
						'type'    => 'url',
						'default' => $d['webhook_url'],
					),
					array(
						'title'   => __( 'Secret', 'quotesign' ),
						'desc'    => __( 'Used to sign the payload so your receiver can verify it.', 'quotesign' ),
						'id'      => $o . '[webhook_secret]',
						'type'    => 'text',
						'default' => $d['webhook_secret'],
					),
					array(
						'type' => 'sectionend',
						'id'   => 'qs_hook_title',
					),
				);
				break;

			case 'data':
				$settings = array(
					array(
						'title' => __( 'Data', 'quotesign' ),
						'type'  => 'title',
						'id'    => 'qs_data_title',
					),
					array(
						'title'   => __( 'Remove all data on uninstall', 'quotesign' ),
						'desc'    => __( 'Delete every quote, signature, audit trail and setting when the plugin is deleted. This cannot be undone.', 'quotesign' ),
						'id'      => $o . '[remove_data]',
						'type'    => 'checkbox',
						'default' => $d['remove_data'],
					),
					array(
						'type' => 'sectionend',
						'id'   => 'qs_data_title',
					),
				);
				break;

			default:
				$settings = array(
					array(
						'title' => __( 'Request a quote', 'quotesign' ),
						'type'  => 'title',
						'id'    => 'qs_general_title',
					),
					array(
						'title'   => __( 'Enable request a quote', 'quotesign' ),
						'id'      => $o . '[enabled]',
						'type'    => 'checkbox',
						'desc'    => __( 'Show the quote button and basket.', 'quotesign' ),
						'default' => $d['enabled'],
					),
					array(
						'title'   => __( 'Quote button', 'quotesign' ),
						'id'      => $o . '[button_mode]',
						'type'    => 'select',
						'class'   => 'wc-enhanced-select',
						'options' => array(
							'replace'   => __( 'Replace Add to cart', 'quotesign' ),
							'alongside' => __( 'Show alongside Add to cart', 'quotesign' ),
						),
						'default' => $d['button_mode'],
					),
					array(
						'title'   => __( 'Button text', 'quotesign' ),
						'id'      => $o . '[button_text]',
						'type'    => 'text',
						'desc'    => __( 'Leave empty for "Add to quote".', 'quotesign' ),
						'default' => $d['button_text'],
					),
					array(
						'title'   => __( 'Apply to', 'quotesign' ),
						'id'      => $o . '[apply_to]',
						'type'    => 'select',
						'class'   => 'wc-enhanced-select',
						'options' => array(
							'all'        => __( 'All products', 'quotesign' ),
							'categories' => __( 'Selected categories', 'quotesign' ),
							'products'   => __( 'Products I tick "Enable request a quote" on', 'quotesign' ),
						),
						'default' => $d['apply_to'],
					),
					array(
						'title'   => __( 'Categories', 'quotesign' ),
						'id'      => $o . '[categories]',
						'type'    => 'multiselect',
						'class'   => 'wc-enhanced-select',
						'options' => $cats,
						'desc'    => __( 'Used when "Selected categories" is chosen above.', 'quotesign' ),
						'default' => array(),
					),
					array(
						'title'   => __( 'Who sees the quote button', 'quotesign' ),
						'id'      => $o . '[roles]',
						'type'    => 'multiselect',
						'class'   => 'wc-enhanced-select',
						'options' => $roles,
						'desc'    => __( 'Leave empty for everyone. Other visitors keep the normal Add to cart.', 'quotesign' ),
						'default' => array(),
					),
					array(
						'title'   => __( 'Hide prices', 'quotesign' ),
						'id'      => $o . '[hide_price]',
						'type'    => 'select',
						'class'   => 'wc-enhanced-select',
						'options' => array(
							'never'  => __( 'Never', 'quotesign' ),
							'guests' => __( 'For guests (not logged in)', 'quotesign' ),
							'roles'  => __( 'For selected roles', 'quotesign' ),
							'all'    => __( 'For everyone on quote-enabled products', 'quotesign' ),
						),
						'desc'    => __( 'Visitors who cannot see a price also cannot add the product to the cart.', 'quotesign' ),
						'default' => $d['hide_price'],
					),
					array(
						'title'   => __( 'Roles that cannot see prices', 'quotesign' ),
						'id'      => $o . '[hide_price_roles]',
						'type'    => 'multiselect',
						'class'   => 'wc-enhanced-select',
						'options' => $roles,
						'default' => array(),
					),
					array(
						'title'   => __( 'Hidden-price text', 'quotesign' ),
						'id'      => $o . '[hide_price_text]',
						'type'    => 'text',
						'desc'    => __( 'Shown instead of the price. Leave empty to show nothing.', 'quotesign' ),
						'default' => $d['hide_price_text'],
					),
					array(
						'title'   => __( 'Basket page', 'quotesign' ),
						'id'      => $o . '[basket_page]',
						'type'    => 'single_select_page',
						'class'   => 'wc-enhanced-select-nostd',
						'css'     => 'min-width:300px;',
						'desc'    => __( 'Page containing the [quotesign_basket] shortcode. Created automatically on activation.', 'quotesign' ),
						'default' => '',
					),
					array(
						'title'   => __( 'Phone number required', 'quotesign' ),
						'id'      => $o . '[phone_required]',
						'type'    => 'checkbox',
						'default' => $d['phone_required'],
					),
					array(
						'type' => 'sectionend',
						'id'   => 'qs_general_title',
					),
				);
				break;
		}

		return apply_filters( 'quotesign_settings_fields', $settings, $section );
	}

	/**
	 * Output settings.
	 */
	public function output() {
		global $current_section;
		WC_Admin_Settings::output_fields( $this->get_settings( $current_section ) );
	}

	/**
	 * Save settings.
	 */
	public function save() {
		global $current_section;
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		WC_Admin_Settings::save_fields( $this->get_settings( $current_section ) );
		// Numeric clean-up.
		$opts = get_option( QuoteSign_Settings::OPTION, array() );
		if ( isset( $opts['tax_rate'] ) ) {
			$opts['tax_rate'] = (string) max( 0, (float) wc_format_decimal( $opts['tax_rate'] ) );
		}
		if ( isset( $opts['deposit_value'] ) ) {
			$opts['deposit_value'] = (string) max( 0, (float) wc_format_decimal( $opts['deposit_value'] ) );
		}
		update_option( QuoteSign_Settings::OPTION, $opts );
	}
}
