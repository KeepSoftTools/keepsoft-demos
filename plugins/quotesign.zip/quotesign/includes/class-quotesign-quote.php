<?php
/**
 * Quote data model.
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

/**
 * A quote, stored as a "qs_quote" post with post meta.
 */
class QuoteSign_Quote {

	/**
	 * Post ID.
	 *
	 * @var int
	 */
	public $id = 0;

	/**
	 * Post object.
	 *
	 * @var WP_Post
	 */
	public $post;

	/**
	 * Valid statuses.
	 *
	 * @return array slug => label.
	 */
	public static function statuses() {
		return array(
			'new'      => __( 'New', 'quotesign' ),
			'sent'     => __( 'Sent', 'quotesign' ),
			'viewed'   => __( 'Viewed', 'quotesign' ),
			'accepted' => __( 'Accepted', 'quotesign' ),
			'declined' => __( 'Declined', 'quotesign' ),
			'expired'  => __( 'Expired', 'quotesign' ),
		);
	}

	/**
	 * Constructor.
	 *
	 * @param WP_Post $post Post.
	 */
	private function __construct( $post ) {
		$this->post = $post;
		$this->id   = (int) $post->ID;
	}

	/**
	 * Load a quote by ID.
	 *
	 * @param int $id Post ID.
	 * @return QuoteSign_Quote|null
	 */
	public static function get( $id ) {
		$post = get_post( (int) $id );
		if ( ! $post || 'qs_quote' !== $post->post_type ) {
			return null;
		}
		return new self( $post );
	}

	/**
	 * Find a quote by its secret token.
	 *
	 * @param string $token Token.
	 * @return QuoteSign_Quote|null
	 */
	public static function find_by_token( $token ) {
		$token = preg_replace( '/[^A-Za-z0-9]/', '', (string) $token );
		if ( strlen( $token ) < 24 ) {
			return null;
		}
		$ids = get_posts(
			array(
				'post_type'      => 'qs_quote',
				'post_status'    => 'any',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_key'       => '_qs_token', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'     => $token, // phpcs:ignore WordPress.DB.SlowDBQuery
			)
		);
		if ( empty( $ids ) ) {
			return null;
		}
		$quote = self::get( $ids[0] );
		// Constant-time confirmation.
		if ( $quote && hash_equals( $quote->token(), $token ) ) {
			return $quote;
		}
		return null;
	}

	/**
	 * Create a quote.
	 *
	 * @param array $data Keys: name,email,phone,company,note,items,customer_id,source.
	 * @return QuoteSign_Quote|WP_Error
	 */
	public static function create( $data ) {
		$id = wp_insert_post(
			array(
				'post_type'   => 'qs_quote',
				'post_status' => 'publish',
				'post_title'  => __( 'Quote', 'quotesign' ),
			),
			true
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		$quote = self::get( $id );

		update_post_meta( $id, '_qs_token', wp_generate_password( 32, false, false ) );
		update_post_meta( $id, '_qs_status', 'new' );
		update_post_meta( $id, '_qs_name', sanitize_text_field( isset( $data['name'] ) ? $data['name'] : '' ) );
		update_post_meta( $id, '_qs_email', sanitize_email( isset( $data['email'] ) ? $data['email'] : '' ) );
		update_post_meta( $id, '_qs_phone', sanitize_text_field( isset( $data['phone'] ) ? $data['phone'] : '' ) );
		update_post_meta( $id, '_qs_company', sanitize_text_field( isset( $data['company'] ) ? $data['company'] : '' ) );
		update_post_meta( $id, '_qs_customer_note', sanitize_textarea_field( isset( $data['note'] ) ? $data['note'] : '' ) );
		update_post_meta( $id, '_qs_customer_id', isset( $data['customer_id'] ) ? absint( $data['customer_id'] ) : 0 );
		update_post_meta( $id, '_qs_items', self::sanitize_items( isset( $data['items'] ) ? $data['items'] : array() ) );
		update_post_meta( $id, '_qs_currency', get_woocommerce_currency() );
		update_post_meta( $id, '_qs_tax_rate', QuoteSign_Settings::get( 'tax_rate' ) );
		update_post_meta( $id, '_qs_discount_type', 'percent' );
		update_post_meta( $id, '_qs_discount_value', '0' );
		update_post_meta( $id, '_qs_terms', QuoteSign_Settings::get( 'default_terms' ) );
		update_post_meta( $id, '_qs_deposit_type', QuoteSign_Settings::get( 'deposit_type' ) );
		update_post_meta( $id, '_qs_deposit_value', QuoteSign_Settings::get( 'deposit_value' ) );

		wp_update_post(
			array(
				'ID'         => $id,
				'post_title' => sprintf( '%s — %s', $quote->number(), $quote->customer_name() ),
			)
		);
		$quote->post = get_post( $id );
		$quote->log( 'created', isset( $data['source'] ) ? $data['source'] : '' );
		return $quote;
	}

	/**
	 * Sanitise a list of line items.
	 *
	 * @param array $items Raw items.
	 * @return array
	 */
	public static function sanitize_items( $items ) {
		$clean = array();
		if ( ! is_array( $items ) ) {
			return $clean;
		}
		foreach ( $items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$name = isset( $item['name'] ) ? sanitize_text_field( $item['name'] ) : '';
			if ( '' === $name ) {
				continue;
			}
			$qty = isset( $item['qty'] ) ? (float) wc_format_decimal( $item['qty'] ) : 1;
			if ( $qty <= 0 ) {
				continue;
			}
			$clean[] = array(
				'product_id'   => isset( $item['product_id'] ) ? absint( $item['product_id'] ) : 0,
				'variation_id' => isset( $item['variation_id'] ) ? absint( $item['variation_id'] ) : 0,
				'name'         => $name,
				'sku'          => isset( $item['sku'] ) ? sanitize_text_field( $item['sku'] ) : '',
				'desc'         => isset( $item['desc'] ) ? sanitize_textarea_field( $item['desc'] ) : '',
				'qty'          => $qty,
				'price'        => isset( $item['price'] ) && '' !== $item['price'] ? (string) wc_format_decimal( $item['price'] ) : '0',
			);
		}
		return $clean;
	}

	/* ---------------------------------------------------------------- Getters */

	/**
	 * Quote number.
	 *
	 * @return string
	 */
	public function number() {
		return 'QS-' . $this->id;
	}

	/**
	 * Secret token.
	 *
	 * @return string
	 */
	public function token() {
		return (string) get_post_meta( $this->id, '_qs_token', true );
	}

	/**
	 * Status slug.
	 *
	 * @return string
	 */
	public function status() {
		$s = (string) get_post_meta( $this->id, '_qs_status', true );
		return isset( self::statuses()[ $s ] ) ? $s : 'new';
	}

	/**
	 * Status label.
	 *
	 * @return string
	 */
	public function status_label() {
		$all = self::statuses();
		return $all[ $this->status() ];
	}

	/**
	 * Generic meta getter.
	 *
	 * @param string $key     Key without prefix.
	 * @param mixed  $default Default.
	 * @return mixed
	 */
	public function meta( $key, $default = '' ) {
		$v = get_post_meta( $this->id, '_qs_' . $key, true );
		return ( '' === $v || false === $v ) ? $default : $v;
	}

	/**
	 * Customer name.
	 *
	 * @return string
	 */
	public function customer_name() {
		return (string) $this->meta( 'name' );
	}

	/**
	 * Customer email.
	 *
	 * @return string
	 */
	public function customer_email() {
		return (string) $this->meta( 'email' );
	}

	/**
	 * Currency code.
	 *
	 * @return string
	 */
	public function currency() {
		return (string) $this->meta( 'currency', get_woocommerce_currency() );
	}

	/**
	 * Line items.
	 *
	 * @return array
	 */
	public function items() {
		$items = get_post_meta( $this->id, '_qs_items', true );
		return is_array( $items ) ? $items : array();
	}

	/**
	 * Expiry as Y-m-d or ''.
	 *
	 * @return string
	 */
	public function expiry() {
		$e = (string) $this->meta( 'expiry' );
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $e ) ? $e : '';
	}

	/**
	 * Has the expiry date passed (site timezone)?
	 *
	 * @return bool
	 */
	public function is_past_expiry() {
		$e = $this->expiry();
		return '' !== $e && $e < wp_date( 'Y-m-d' );
	}

	/**
	 * Can the customer still act on this quote?
	 *
	 * @return bool
	 */
	public function is_open() {
		return in_array( $this->status(), array( 'sent', 'viewed' ), true ) && ! $this->is_past_expiry();
	}

	/**
	 * Signature record.
	 *
	 * @return array|null
	 */
	public function signature() {
		$s = get_post_meta( $this->id, '_qs_signature', true );
		return ( is_array( $s ) && ! empty( $s['name'] ) ) ? $s : null;
	}

	/**
	 * Audit trail.
	 *
	 * @return array
	 */
	public function audit() {
		$a = get_post_meta( $this->id, '_qs_audit', true );
		return is_array( $a ) ? $a : array();
	}

	/**
	 * Totals.
	 *
	 * @return array subtotal, discount, taxable, tax_rate, tax, total, deposit_due, balance.
	 */
	public function totals() {
		$dp       = wc_get_price_decimals();
		$subtotal = 0.0;
		foreach ( $this->items() as $it ) {
			$subtotal += round( (float) $it['qty'] * (float) $it['price'], $dp );
		}
		$dtype = $this->meta( 'discount_type', 'percent' );
		$dval  = (float) $this->meta( 'discount_value', 0 );
		$disc  = 'fixed' === $dtype ? $dval : $subtotal * ( $dval / 100 );
		$disc  = round( min( max( 0, $disc ), $subtotal ), $dp );

		$taxable  = $subtotal - $disc;
		$tax_rate = max( 0, (float) $this->meta( 'tax_rate', 0 ) );
		$tax      = round( $taxable * $tax_rate / 100, $dp );
		$total    = round( $taxable + $tax, $dp );

		$deposit = $this->deposit_amount( $total );

		return array(
			'subtotal'    => round( $subtotal, $dp ),
			'discount'    => $disc,
			'taxable'     => round( $taxable, $dp ),
			'tax_rate'    => $tax_rate,
			'tax'         => $tax,
			'total'       => $total,
			'deposit_due' => $deposit,
			'balance'     => round( $total - $deposit, $dp ),
		);
	}

	/**
	 * Deposit amount due on acceptance.
	 *
	 * @param float|null $total Grand total.
	 * @return float Equals total when no deposit applies.
	 */
	public function deposit_amount( $total = null ) {
		$dp = wc_get_price_decimals();
		if ( null === $total ) {
			$t     = $this->totals();
			$total = $t['total'];
		}
		$type = $this->meta( 'deposit_type', 'none' );
		$val  = (float) $this->meta( 'deposit_value', 0 );
		if ( 'percent' === $type && $val > 0 && $val < 100 ) {
			return round( $total * $val / 100, $dp );
		}
		if ( 'fixed' === $type && $val > 0 && $val < $total ) {
			return round( $val, $dp );
		}
		return round( $total, $dp );
	}

	/**
	 * Does this quote use a deposit?
	 *
	 * @return bool
	 */
	public function has_deposit() {
		$t = $this->totals();
		return $t['deposit_due'] < $t['total'];
	}

	/* ---------------------------------------------------------------- URLs */

	/**
	 * Public tokenised URL.
	 *
	 * @param array $args Extra query args.
	 * @return string
	 */
	public function url( $args = array() ) {
		return QuoteSign_Public_Page::url( $this->token(), $args );
	}

	/**
	 * PDF URL.
	 *
	 * @return string
	 */
	public function pdf_url() {
		return $this->url( array( 'qs_pdf' => 1 ) );
	}

	/* ---------------------------------------------------------------- Mutators */

	/**
	 * Client IP.
	 *
	 * @return string
	 */
	public static function client_ip() {
		$ip = '';
		if ( class_exists( 'WC_Geolocation' ) ) {
			$ip = WC_Geolocation::get_ip_address();
		}
		if ( ! $ip && isset( $_SERVER['REMOTE_ADDR'] ) ) {
			$ip = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
		}
		return (string) apply_filters( 'quotesign_client_ip', $ip );
	}

	/**
	 * Client user agent.
	 *
	 * @return string
	 */
	public static function client_ua() {
		return isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ), 0, 255 ) : '';
	}

	/**
	 * Append an audit trail entry.
	 *
	 * @param string $event  Event code.
	 * @param string $detail Detail text.
	 * @param bool   $client Record client IP / UA.
	 */
	public function log( $event, $detail = '', $client = false ) {
		$audit   = $this->audit();
		$entry   = array(
			'time'   => time(),
			'event'  => sanitize_key( $event ),
			'detail' => sanitize_text_field( $detail ),
			'user'   => is_user_logged_in() ? get_current_user_id() : 0,
		);
		if ( $client ) {
			$entry['ip'] = self::client_ip();
			$entry['ua'] = self::client_ua();
		}
		$audit[] = $entry;
		update_post_meta( $this->id, '_qs_audit', $audit );
	}

	/**
	 * Change status, log and fire hooks.
	 *
	 * @param string $new    New status.
	 * @param string $detail Audit detail.
	 * @param bool   $client Log client details.
	 * @return bool
	 */
	public function set_status( $new, $detail = '', $client = false ) {
		if ( ! isset( self::statuses()[ $new ] ) ) {
			return false;
		}
		$old = $this->status();
		if ( $old === $new ) {
			return false;
		}
		update_post_meta( $this->id, '_qs_status', $new );
		$this->log( 'status_' . $new, $detail, $client );
		do_action( 'quotesign_status_changed', $this, $new, $old );
		do_action( 'quotesign_quote_' . $new, $this, $old );
		return true;
	}
}
