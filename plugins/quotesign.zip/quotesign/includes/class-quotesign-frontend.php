<?php
/**
 * Front-end: buttons, assets and My Account endpoint.
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

/**
 * Front-end integration.
 */
class QuoteSign_Frontend {

	const ENDPOINT = 'quotes';

	/**
	 * Enqueued flag.
	 *
	 * @var bool
	 */
	private static $enqueued = false;

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'add_endpoint' ) );
		add_filter( 'woocommerce_get_query_vars', array( __CLASS__, 'query_vars' ) );
		add_filter( 'woocommerce_account_menu_items', array( __CLASS__, 'menu_items' ) );
		add_action( 'woocommerce_account_' . self::ENDPOINT . '_endpoint', array( __CLASS__, 'endpoint_content' ) );
		add_filter( 'woocommerce_endpoint_' . self::ENDPOINT . '_title', array( __CLASS__, 'endpoint_title' ) );

		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'maybe_enqueue' ) );
		add_action( 'woocommerce_single_product_summary', array( __CLASS__, 'single_button' ), 31 );
		add_action( 'woocommerce_after_shop_loop_item', array( __CLASS__, 'loop_button' ), 11 );
	}

	/**
	 * Register the My Account endpoint.
	 */
	public static function add_endpoint() {
		add_rewrite_endpoint( self::ENDPOINT, EP_ROOT | EP_PAGES );
	}

	/**
	 * Add the endpoint to WooCommerce query vars.
	 *
	 * @param array $vars Vars.
	 * @return array
	 */
	public static function query_vars( $vars ) {
		$vars[ self::ENDPOINT ] = self::ENDPOINT;
		return $vars;
	}

	/**
	 * Add to account menu.
	 *
	 * @param array $items Items.
	 * @return array
	 */
	public static function menu_items( $items ) {
		$new = array();
		foreach ( $items as $key => $label ) {
			if ( 'customer-logout' === $key ) {
				$new[ self::ENDPOINT ] = __( 'Quotes', 'quotesign' );
			}
			$new[ $key ] = $label;
		}
		if ( ! isset( $new[ self::ENDPOINT ] ) ) {
			$new[ self::ENDPOINT ] = __( 'Quotes', 'quotesign' );
		}
		return $new;
	}

	/**
	 * Endpoint title.
	 *
	 * @return string
	 */
	public static function endpoint_title() {
		return __( 'Quotes', 'quotesign' );
	}

	/**
	 * Endpoint content.
	 */
	public static function endpoint_content() {
		$quotes = array();
		if ( is_user_logged_in() ) {
			$ids = get_posts(
				array(
					'post_type'      => 'qs_quote',
					'post_status'    => 'publish',
					'posts_per_page' => 100,
					'fields'         => 'ids',
					'no_found_rows'  => true,
					'meta_key'       => '_qs_customer_id', // phpcs:ignore WordPress.DB.SlowDBQuery
					'meta_value'     => get_current_user_id(), // phpcs:ignore WordPress.DB.SlowDBQuery
				)
			);
			foreach ( $ids as $id ) {
				$q = QuoteSign_Quote::get( $id );
				if ( $q ) {
					$quotes[] = $q;
				}
			}
		}
		wc_get_template(
			'myaccount-quotes.php',
			array( 'quotes' => $quotes ),
			'quotesign/',
			QUOTESIGN_PATH . 'templates/'
		);
	}

	/**
	 * Enqueue on relevant pages.
	 */
	public static function maybe_enqueue() {
		if ( ! QuoteSign_Rules::enabled() ) {
			return;
		}
		if ( is_woocommerce() || is_cart() || is_checkout() || is_shop() ) {
			self::enqueue();
		}
	}

	/**
	 * Enqueue assets.
	 *
	 * @param bool $basket Load basket strings.
	 */
	public static function enqueue( $basket = false ) {
		if ( self::$enqueued ) {
			return;
		}
		self::$enqueued = true;
		wp_enqueue_style( 'quotesign-frontend', QUOTESIGN_URL . 'assets/css/frontend.css', array(), QUOTESIGN_VERSION );
		wp_enqueue_script( 'quotesign-frontend', QUOTESIGN_URL . 'assets/js/frontend.js', array(), QUOTESIGN_VERSION, true );
		wp_localize_script(
			'quotesign-frontend',
			'qsFront',
			array(
				'nonce'     => wp_create_nonce( 'wp_rest' ),
				'basketUrl' => QuoteSign_Basket::page_url(),
				'routes'    => array(
					'add'    => rest_url( 'quotesign/v1/basket/add' ),
					'update' => rest_url( 'quotesign/v1/basket/update' ),
					'remove' => rest_url( 'quotesign/v1/basket/remove' ),
					'submit' => rest_url( 'quotesign/v1/basket/submit' ),
				),
				'i18n'      => array(
					'added'      => __( 'Added to your quote.', 'quotesign' ),
					'view'       => __( 'View quote basket', 'quotesign' ),
					'error'      => __( 'Something went wrong. Please try again.', 'quotesign' ),
					'chooseOpts' => __( 'Please choose the product options first.', 'quotesign' ),
					'sending'    => __( 'Sending…', 'quotesign' ),
				),
			)
		);
	}

	/**
	 * Render the quote button.
	 *
	 * @param WC_Product $product Product.
	 * @param string     $context single|loop.
	 */
	private static function button( $product, $context ) {
		if ( ! $product || ! QuoteSign_Rules::show_button( $product ) || ! $product->is_type( array( 'simple', 'variable' ) ) ) {
			return;
		}
		self::enqueue();
		$replace = QuoteSign_Rules::replace_cart( $product );
		echo '<div class="qs-add-wrap qs-context-' . esc_attr( $context ) . '" data-qs-product="' . esc_attr( $product->get_id() ) . '" data-qs-type="' . esc_attr( $product->get_type() ) . '">';
		if ( 'single' === $context && $replace ) {
			echo '<label class="screen-reader-text" for="qs-add-qty-' . esc_attr( $product->get_id() ) . '">' . esc_html__( 'Quantity', 'quotesign' ) . '</label>';
			echo '<input type="number" class="qs-add-qty" id="qs-add-qty-' . esc_attr( $product->get_id() ) . '" value="1" min="1" max="9999" step="1">';
		}
		echo '<button type="button" class="button alt qs-add-btn" data-qs-add>' . esc_html( QuoteSign_Settings::button_text() ) . '</button>';
		echo '<div class="qs-add-msg" role="status" aria-live="polite"></div>';
		echo '</div>';
	}

	/**
	 * Single product button.
	 */
	public static function single_button() {
		global $product;
		self::button( $product, 'single' );
	}

	/**
	 * Loop button (simple products only; variable products link to their page).
	 */
	public static function loop_button() {
		global $product;
		if ( $product && $product->is_type( 'simple' ) ) {
			self::button( $product, 'loop' );
		}
	}
}
