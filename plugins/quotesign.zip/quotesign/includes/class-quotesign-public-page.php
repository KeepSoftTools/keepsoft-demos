<?php
/**
 * Tokenised public quote page and PDF download.
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

/**
 * Handles /qs-quote/{token}/ requests.
 */
class QuoteSign_Public_Page {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'add_rewrite' ) );
		add_filter( 'query_vars', array( __CLASS__, 'query_vars' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_render' ), 1 );
		add_filter( 'redirect_canonical', array( __CLASS__, 'no_canonical' ) );
	}

	/**
	 * Rewrite rule.
	 */
	public static function add_rewrite() {
		add_rewrite_rule( '^qs-quote/([A-Za-z0-9]{24,64})/?$', 'index.php?qs_quote=$matches[1]', 'top' );
	}

	/**
	 * Query vars.
	 *
	 * @param array $vars Vars.
	 * @return array
	 */
	public static function query_vars( $vars ) {
		$vars[] = 'qs_quote';
		$vars[] = 'qs_pdf';
		return $vars;
	}

	/**
	 * Avoid canonical redirects for token URLs.
	 *
	 * @param string $url URL.
	 * @return string|false
	 */
	public static function no_canonical( $url ) {
		return get_query_var( 'qs_quote' ) ? false : $url;
	}

	/**
	 * Build the public URL.
	 *
	 * @param string $token Token.
	 * @param array  $args  Query args.
	 * @return string
	 */
	public static function url( $token, $args = array() ) {
		if ( get_option( 'permalink_structure' ) ) {
			$url = home_url( '/qs-quote/' . rawurlencode( $token ) . '/' );
		} else {
			$url = add_query_arg( 'qs_quote', rawurlencode( $token ), home_url( '/' ) );
		}
		return $args ? add_query_arg( $args, $url ) : $url;
	}

	/**
	 * Send headers that stop caching and indexing.
	 */
	private static function private_headers() {
		nocache_headers();
		header( 'X-Robots-Tag: noindex, nofollow, noarchive' );
		header( 'Referrer-Policy: no-referrer' );
	}

	/**
	 * Entry point.
	 */
	public static function maybe_render() {
		$token = get_query_var( 'qs_quote' );
		if ( ! $token ) {
			return;
		}
		self::private_headers();
		define( 'DONOTCACHEPAGE', true );

		$quote = QuoteSign_Quote::find_by_token( $token );
		if ( ! $quote || 'new' === $quote->status() || 'publish' !== $quote->post->post_status ) {
			status_header( 404 );
			self::message_page( __( 'Quote not found', 'quotesign' ), __( 'This quote link is invalid or the quote is no longer available.', 'quotesign' ) );
			exit;
		}

		// Lazy expiry (in case WP-Cron has not run yet).
		if ( in_array( $quote->status(), array( 'sent', 'viewed' ), true ) && $quote->is_past_expiry() ) {
			$quote->set_status( 'expired', __( 'Expiry date passed', 'quotesign' ) );
		}

		if ( get_query_var( 'qs_pdf' ) ) {
			$pdf = QuoteSign_PDF::render( $quote );
			if ( is_wp_error( $pdf ) ) {
				wp_die( esc_html( $pdf->get_error_message() ), '', array( 'response' => 500 ) );
			}
			header( 'Content-Type: application/pdf' );
			header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $quote->number() ) . '.pdf"' );
			header( 'Content-Length: ' . strlen( $pdf ) );
			echo $pdf; // phpcs:ignore WordPress.Security.EscapeOutput
			exit;
		}

		if ( 'sent' === $quote->status() ) {
			$quote->set_status( 'viewed', __( 'Customer opened the quote link', 'quotesign' ), true );
		}

		self::render( $quote );
		exit;
	}

	/**
	 * Simple message page.
	 *
	 * @param string $title Title.
	 * @param string $text  Message.
	 */
	private static function message_page( $title, $text ) {
		?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?php echo esc_html( $title ); ?></title>
<link rel="stylesheet" href="<?php echo esc_url( QUOTESIGN_URL . 'assets/css/quote-page.css?ver=' . QUOTESIGN_VERSION ); ?>">
</head>
<body class="qs-page qs-message">
<main class="qs-wrap qs-narrow"><div class="qs-card"><h1><?php echo esc_html( $title ); ?></h1><p><?php echo esc_html( $text ); ?></p></div></main>
</body>
</html>
		<?php
	}

	/**
	 * Render the quote page.
	 *
	 * @param QuoteSign_Quote $quote Quote.
	 */
	private static function render( $quote ) {
		$orders = array(
			'deposit' => (int) $quote->meta( 'deposit_order_id', 0 ),
			'balance' => (int) $quote->meta( 'balance_order_id', 0 ),
		);
		$pay_url = '';
		foreach ( array( 'deposit', 'balance' ) as $kind ) {
			if ( $orders[ $kind ] ) {
				$order = wc_get_order( $orders[ $kind ] );
				if ( $order && $order->needs_payment() ) {
					$pay_url = $order->get_checkout_payment_url();
					break;
				}
			}
		}

		$logo = '';
		$logo_id = (int) get_theme_mod( 'custom_logo' );
		if ( $logo_id ) {
			$logo = wp_get_attachment_image_url( $logo_id, 'medium' );
		}

		$config = array(
			'acceptUrl'  => rest_url( 'quotesign/v1/quote/' . $quote->token() . '/accept' ),
			'declineUrl' => rest_url( 'quotesign/v1/quote/' . $quote->token() . '/decline' ),
			'i18n'       => array(
				'needName'   => __( 'Please type your full name.', 'quotesign' ),
				'needDraw'   => __( 'Please draw your signature in the box.', 'quotesign' ),
				'needAgree'  => __( 'Please tick the box to agree to the terms.', 'quotesign' ),
				'error'      => __( 'Something went wrong. Please try again.', 'quotesign' ),
				'working'    => __( 'Saving…', 'quotesign' ),
				'confirmDecline' => __( 'Are you sure you want to decline this quote?', 'quotesign' ),
				'accept'     => __( 'Accept & sign', 'quotesign' ),
			),
		);

		$quote_obj = $quote;
		$totals    = $quote->totals();
		$logo_url  = $logo;

		// Theme-overridable template.
		$template = locate_template( 'quotesign/quote-page.php' );
		if ( ! $template ) {
			$template = QUOTESIGN_PATH . 'templates/quote-page.php';
		}
		self::include_template( $template, $quote_obj, $totals, $pay_url, $logo_url, $config );
	}

	/**
	 * Include the template with a clean variable scope.
	 *
	 * @param string          $template Template path.
	 * @param QuoteSign_Quote $quote    Quote.
	 * @param array           $totals   Totals.
	 * @param string          $pay_url  Pay URL.
	 * @param string          $logo     Logo URL.
	 * @param array           $config   JS config.
	 */
	private static function include_template( $template, $quote, $totals, $pay_url, $logo, $config ) {
		include $template;
	}
}
