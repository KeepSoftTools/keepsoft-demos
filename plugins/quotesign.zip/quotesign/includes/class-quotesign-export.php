<?php
/**
 * CSV export.
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

/**
 * Streams all quotes as CSV.
 */
class QuoteSign_Export {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_post_qs_export', array( __CLASS__, 'handle' ) );
		add_action( 'manage_posts_extra_tablenav', array( __CLASS__, 'button' ) );
	}

	/**
	 * Export button on the Quotes list.
	 *
	 * @param string $which Position.
	 */
	public static function button( $which ) {
		global $typenow;
		if ( 'top' !== $which || 'qs_quote' !== $typenow || ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		$args = array(
			'action'   => 'qs_export',
			'_wpnonce' => wp_create_nonce( 'qs_export' ),
		);
		if ( ! empty( $_GET['qs_status'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$args['status'] = sanitize_key( wp_unslash( $_GET['qs_status'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		}
		printf(
			'<div class="alignleft actions"><a class="button" href="%s">%s</a></div>',
			esc_url( add_query_arg( $args, admin_url( 'admin-post.php' ) ) ),
			esc_html__( 'Export CSV', 'quotesign' )
		);
	}

	/**
	 * Guard against spreadsheet formula injection.
	 *
	 * @param mixed $v Value.
	 * @return string
	 */
	public static function safe( $v ) {
		$v = (string) $v;
		if ( '' !== $v && in_array( $v[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) ) {
			return "'" . $v;
		}
		return $v;
	}

	/**
	 * Output the file.
	 */
	public static function handle() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'quotesign' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'qs_export' );

		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		$args   = array(
			'post_type'      => 'qs_quote',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
			'orderby'        => 'ID',
			'order'          => 'ASC',
		);
		if ( isset( QuoteSign_Quote::statuses()[ $status ] ) ) {
			$args['meta_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery
				array(
					'key'   => '_qs_status',
					'value' => $status,
				),
			);
		}
		$ids = get_posts( $args );

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="quotes-' . gmdate( 'Y-m-d' ) . '.csv"' );

		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fputcsv(
			$out,
			array( 'Quote', 'Created', 'Status', 'Name', 'Email', 'Phone', 'Company', 'Currency', 'Subtotal', 'Discount', 'Tax', 'Total', 'Deposit due', 'Expiry', 'Accepted at (UTC)', 'Signed by', 'Items', 'Deposit order', 'Balance order' )
		);
		foreach ( $ids as $id ) {
			$q = QuoteSign_Quote::get( $id );
			if ( ! $q ) {
				continue;
			}
			$t     = $q->totals();
			$sig   = $q->signature();
			$items = array();
			foreach ( $q->items() as $it ) {
				$items[] = $it['qty'] . ' x ' . $it['name'];
			}
			$accepted = (int) $q->meta( 'accepted_at', 0 );
			fputcsv(
				$out,
				array_map(
					array( __CLASS__, 'safe' ),
					array(
						$q->number(),
						get_post_time( 'Y-m-d H:i:s', true, $id ),
						$q->status(),
						$q->customer_name(),
						$q->customer_email(),
						$q->meta( 'phone' ),
						$q->meta( 'company' ),
						$q->currency(),
						$t['subtotal'],
						$t['discount'],
						$t['tax'],
						$t['total'],
						$t['deposit_due'],
						$q->expiry(),
						$accepted ? gmdate( 'Y-m-d H:i:s', $accepted ) : '',
						$sig ? $sig['name'] : '',
						implode( '; ', $items ),
						$q->meta( 'deposit_order_id', '' ),
						$q->meta( 'balance_order_id', '' ),
					)
				)
			);
		}
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		exit;
	}
}
