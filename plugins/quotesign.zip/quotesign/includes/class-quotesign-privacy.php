<?php
/**
 * Privacy: policy text, personal data exporter and eraser.
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

/**
 * GDPR tools integration.
 */
class QuoteSign_Privacy {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'policy_text' ) );
		add_filter( 'wp_privacy_personal_data_exporters', array( __CLASS__, 'register_exporter' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( __CLASS__, 'register_eraser' ) );
	}

	/**
	 * Suggested privacy policy text.
	 */
	public static function policy_text() {
		if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}
		$text = '<h3>' . esc_html__( 'Quotes and e-signatures', 'quotesign' ) . '</h3>'
			. '<p>' . esc_html__( 'When you request a quote we store your name, email address, phone number, company and the products you asked about. If you accept a quote, we also store your typed or drawn signature, the date and time, your IP address and browser details as evidence of your agreement. This information is kept for as long as needed for our contract and legal obligations.', 'quotesign' ) . '</p>';
		wp_add_privacy_policy_content( 'QuoteSign', wp_kses_post( wpautop( $text, false ) ) );
	}

	/**
	 * Register exporter.
	 *
	 * @param array $exporters Exporters.
	 * @return array
	 */
	public static function register_exporter( $exporters ) {
		$exporters['quotesign'] = array(
			'exporter_friendly_name' => __( 'Quotes', 'quotesign' ),
			'callback'               => array( __CLASS__, 'export' ),
		);
		return $exporters;
	}

	/**
	 * Register eraser.
	 *
	 * @param array $erasers Erasers.
	 * @return array
	 */
	public static function register_eraser( $erasers ) {
		$erasers['quotesign'] = array(
			'eraser_friendly_name' => __( 'Quotes', 'quotesign' ),
			'callback'             => array( __CLASS__, 'erase' ),
		);
		return $erasers;
	}

	/**
	 * Quote IDs for an email.
	 *
	 * @param string $email Email.
	 * @return int[]
	 */
	private static function ids_for( $email ) {
		return get_posts(
			array(
				'post_type'      => 'qs_quote',
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_key'       => '_qs_email', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'     => $email, // phpcs:ignore WordPress.DB.SlowDBQuery
			)
		);
	}

	/**
	 * Export.
	 *
	 * @param string $email Email.
	 * @return array
	 */
	public static function export( $email ) {
		$data = array();
		foreach ( self::ids_for( sanitize_email( $email ) ) as $id ) {
			$q = QuoteSign_Quote::get( $id );
			if ( ! $q ) {
				continue;
			}
			$t     = $q->totals();
			$items = array();
			foreach ( $q->items() as $it ) {
				$items[] = $it['qty'] . ' x ' . $it['name'];
			}
			$rows = array(
				array( 'name' => __( 'Quote', 'quotesign' ), 'value' => $q->number() ),
				array( 'name' => __( 'Status', 'quotesign' ), 'value' => $q->status_label() ),
				array( 'name' => __( 'Name', 'quotesign' ), 'value' => $q->customer_name() ),
				array( 'name' => __( 'Phone', 'quotesign' ), 'value' => (string) $q->meta( 'phone' ) ),
				array( 'name' => __( 'Company', 'quotesign' ), 'value' => (string) $q->meta( 'company' ) ),
				array( 'name' => __( 'Items', 'quotesign' ), 'value' => implode( '; ', $items ) ),
				array( 'name' => __( 'Total', 'quotesign' ), 'value' => (string) $t['total'] ),
			);
			$sig = $q->signature();
			if ( $sig ) {
				$rows[] = array( 'name' => __( 'Signed by', 'quotesign' ), 'value' => $sig['name'] );
				$rows[] = array( 'name' => __( 'Signed at (UTC)', 'quotesign' ), 'value' => gmdate( 'Y-m-d H:i:s', (int) $sig['time'] ) );
				$rows[] = array( 'name' => __( 'Signing IP address', 'quotesign' ), 'value' => $sig['ip'] );
				$rows[] = array( 'name' => __( 'Signing browser', 'quotesign' ), 'value' => $sig['ua'] );
			}
			$data[] = array(
				'group_id'    => 'quotesign_quotes',
				'group_label' => __( 'Quotes', 'quotesign' ),
				'item_id'     => 'quote-' . $id,
				'data'        => $rows,
			);
		}
		return array(
			'data' => $data,
			'done' => true,
		);
	}

	/**
	 * Erase: anonymise personal data but keep the commercial record.
	 *
	 * @param string $email Email.
	 * @return array
	 */
	public static function erase( $email ) {
		$removed = false;
		foreach ( self::ids_for( sanitize_email( $email ) ) as $id ) {
			update_post_meta( $id, '_qs_name', __( 'Anonymised', 'quotesign' ) );
			update_post_meta( $id, '_qs_email', 'deleted@invalid.invalid' );
			update_post_meta( $id, '_qs_phone', '' );
			update_post_meta( $id, '_qs_company', '' );
			update_post_meta( $id, '_qs_customer_note', '' );
			update_post_meta( $id, '_qs_customer_id', 0 );
			delete_post_meta( $id, '_qs_signature' );
			$audit = get_post_meta( $id, '_qs_audit', true );
			if ( is_array( $audit ) ) {
				foreach ( $audit as $k => $e ) {
					unset( $audit[ $k ]['ip'], $audit[ $k ]['ua'] );
					$audit[ $k ]['detail'] = '';
				}
				update_post_meta( $id, '_qs_audit', $audit );
			}
			wp_update_post(
				array(
					'ID'         => $id,
					'post_title' => 'QS-' . $id,
				)
			);
			$removed = true;
		}
		return array(
			'items_removed'  => $removed,
			'items_retained' => false,
			'messages'       => array(),
			'done'           => true,
		);
	}
}
