<?php
/**
 * Settings accessor.
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

/**
 * Reads and writes the single "quotesign_settings" option.
 */
class QuoteSign_Settings {

	const OPTION = 'quotesign_settings';

	/**
	 * Defaults.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'enabled'            => 'yes',
			'button_mode'        => 'replace', // replace|alongside.
			'apply_to'           => 'all',     // all|categories|products.
			'categories'         => array(),
			'roles'              => array(),   // Empty = everyone (including guests).
			'hide_price'         => 'never',   // never|guests|roles|all.
			'hide_price_roles'   => array(),
			'hide_price_text'    => '',
			'button_text'        => '',
			'basket_page'        => 0,
			'phone_required'     => 'no',
			'company_name'       => '',
			'company_details'    => '',
			'validity_days'      => 30,
			'default_terms'      => '',
			'tax_label'          => '',
			'tax_rate'           => '0',
			'deposit_type'       => 'none',    // none|percent|fixed.
			'deposit_value'      => '0',
			'create_order'       => 'yes',
			'admin_email'        => '',
			'reminder_enabled'   => 'yes',
			'reminder_days'      => 2,
			'webhook_url'        => '',
			'webhook_secret'     => '',
			'remove_data'        => 'no',
		);
	}

	/**
	 * Get all settings merged with defaults.
	 *
	 * @return array
	 */
	public static function all() {
		$saved = get_option( self::OPTION, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		return array_merge( self::defaults(), $saved );
	}

	/**
	 * Get one setting.
	 *
	 * @param string $key     Key.
	 * @param mixed  $default Fallback.
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		$all = self::all();
		if ( isset( $all[ $key ] ) ) {
			return $all[ $key ];
		}
		return $default;
	}

	/**
	 * Update one setting.
	 *
	 * @param string $key   Key.
	 * @param mixed  $value Value.
	 */
	public static function update( $key, $value ) {
		$saved         = get_option( self::OPTION, array() );
		$saved         = is_array( $saved ) ? $saved : array();
		$saved[ $key ] = $value;
		update_option( self::OPTION, $saved );
	}

	/**
	 * Button label.
	 *
	 * @return string
	 */
	public static function button_text() {
		$t = (string) self::get( 'button_text' );
		return '' !== $t ? $t : __( 'Add to quote', 'quotesign' );
	}

	/**
	 * Tax label.
	 *
	 * @return string
	 */
	public static function tax_label() {
		$t = (string) self::get( 'tax_label' );
		return '' !== $t ? $t : __( 'Tax', 'quotesign' );
	}

	/**
	 * Company name.
	 *
	 * @return string
	 */
	public static function company_name() {
		$t = (string) self::get( 'company_name' );
		return '' !== $t ? $t : wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	}

	/**
	 * Admin notification email.
	 *
	 * @return string
	 */
	public static function admin_email() {
		$e = (string) self::get( 'admin_email' );
		return is_email( $e ) ? $e : get_option( 'admin_email' );
	}
}
