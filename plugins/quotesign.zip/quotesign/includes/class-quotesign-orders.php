<?php
/**
 * WooCommerce order creation for deposits and balances.
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

/**
 * Orders generated from quotes.
 */
class QuoteSign_Orders {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'woocommerce_order_status_changed', array( __CLASS__, 'track_payment' ), 10, 4 );
		add_action( 'add_meta_boxes', array( __CLASS__, 'order_metabox' ), 10, 2 );
	}

	/**
	 * Create the deposit (or full) order, or the balance order.
	 *
	 * @param QuoteSign_Quote $quote Quote.
	 * @param string          $kind  deposit|balance.
	 * @return WC_Order|WP_Error
	 */
	public static function create_for_quote( $quote, $kind = 'deposit' ) {
		$kind = 'balance' === $kind ? 'balance' : 'deposit';
		$dp   = wc_get_price_decimals();
		$t    = $quote->totals();

		$existing_id = (int) $quote->meta( $kind . '_order_id', 0 );
		if ( $existing_id ) {
			$existing = wc_get_order( $existing_id );
			if ( $existing && ! $existing->has_status( array( 'cancelled', 'failed' ) ) ) {
				return 'deposit' === $kind ? $existing : new WP_Error( 'qs_exists', __( 'A balance order already exists for this quote.', 'quotesign' ) );
			}
		}

		if ( 'balance' === $kind ) {
			if ( ! $quote->meta( 'deposit_order_id', 0 ) ) {
				return new WP_Error( 'qs_no_deposit', __( 'There is no deposit order for this quote.', 'quotesign' ) );
			}
			$amount = $t['balance'];
		} else {
			$amount = $t['deposit_due'];
		}
		if ( $amount <= 0 || $t['total'] <= 0 ) {
			return new WP_Error( 'qs_zero', __( 'There is no amount to charge for this quote.', 'quotesign' ) );
		}

		$ratio = $amount / $t['total'];
		$dfac  = $t['subtotal'] > 0 ? $t['taxable'] / $t['subtotal'] : 1;

		$customer_id = 0;
		if ( 'deposit' === $kind && is_user_logged_in() && (int) $quote->meta( 'customer_id', 0 ) === get_current_user_id() ) {
			$customer_id = get_current_user_id();
		}

		$order = wc_create_order(
			array(
				'status'      => 'pending',
				'customer_id' => $customer_id,
				'created_via' => 'quotesign',
			)
		);
		if ( is_wp_error( $order ) ) {
			return $order;
		}
		$order->set_currency( $quote->currency() );

		$parts = preg_split( '/\s+/', trim( $quote->customer_name() ), 2 );
		$order->set_billing_first_name( isset( $parts[0] ) ? $parts[0] : '' );
		$order->set_billing_last_name( isset( $parts[1] ) ? $parts[1] : '' );
		$order->set_billing_email( $quote->customer_email() );
		$order->set_billing_phone( (string) $quote->meta( 'phone' ) );
		$order->set_billing_company( (string) $quote->meta( 'company' ) );

		$suffix = '';
		if ( 'balance' === $kind ) {
			$suffix = ' – ' . __( 'balance', 'quotesign' );
		} elseif ( $ratio < 1 ) {
			$suffix = ' – ' . __( 'deposit', 'quotesign' );
		}

		$sum = 0.0;
		foreach ( $quote->items() as $it ) {
			$line     = (float) $it['qty'] * (float) $it['price'];
			$sub      = round( $line * $ratio, $dp );
			$tot      = round( $line * $dfac * $ratio, $dp );
			$sum     += $tot;
			$line_item = new WC_Order_Item_Product();
			$product   = null;
			if ( 'deposit' === $kind && ! empty( $it['product_id'] ) ) {
				$product = wc_get_product( ! empty( $it['variation_id'] ) ? $it['variation_id'] : $it['product_id'] );
			}
			if ( $product ) {
				$line_item->set_product( $product );
			}
			$line_item->set_name( $it['name'] . $suffix );
			$line_item->set_quantity( (float) $it['qty'] );
			$line_item->set_subtotal( $sub );
			$line_item->set_total( $tot );
			$line_item->set_tax_class( '' );
			$line_item->set_taxes( array( 'total' => array(), 'subtotal' => array() ) );
			$order->add_item( $line_item );
		}

		// Whatever remains (tax and rounding) goes in as a non-taxable fee line.
		$remainder = round( $amount - $sum, $dp );
		if ( abs( $remainder ) >= pow( 10, -$dp ) / 2 ) {
			$fee = new WC_Order_Item_Fee();
			if ( $t['tax'] > 0 ) {
				/* translators: 1: tax label, 2: percent */
				$fee->set_name( sprintf( __( '%1$s (%2$s%%)', 'quotesign' ), QuoteSign_Settings::tax_label(), wc_format_localized_decimal( $t['tax_rate'] ) ) );
			} else {
				$fee->set_name( __( 'Adjustment', 'quotesign' ) );
			}
			$fee->set_amount( $remainder );
			$fee->set_total( $remainder );
			$fee->set_tax_status( 'none' );
			$order->add_item( $fee );
		}

		$order->calculate_totals( false );
		if ( abs( (float) $order->get_total() - $amount ) > 0.001 ) {
			$order->set_total( $amount );
		}

		$order->update_meta_data( '_qs_quote_id', $quote->id );
		$order->update_meta_data( '_qs_order_kind', $kind );
		$order->save();

		$edit = admin_url( 'post.php?post=' . $quote->id . '&action=edit' );
		$order->add_order_note(
			sprintf(
				/* translators: 1: kind, 2: quote number, 3: link */
				__( 'Created from quote %2$s (%1$s). <a href="%3$s">Open quote</a>', 'quotesign' ),
				'balance' === $kind ? __( 'balance payment', 'quotesign' ) : ( $ratio < 1 ? __( 'deposit', 'quotesign' ) : __( 'full payment', 'quotesign' ) ),
				esc_html( $quote->number() ),
				esc_url( $edit )
			)
		);

		update_post_meta( $quote->id, '_qs_' . $kind . '_order_id', $order->get_id() );
		$quote->log(
			$kind . '_order',
			sprintf(
				/* translators: 1: order number, 2: amount */
				__( 'Order #%1$s created for %2$s', 'quotesign' ),
				$order->get_order_number(),
				wp_strip_all_tags( html_entity_decode( wc_price( $amount, array( 'currency' => $quote->currency() ) ) ) )
			)
		);

		do_action( 'quotesign_order_created', $order, $quote, $kind );
		return $order;
	}

	/**
	 * Log payment on the quote.
	 *
	 * @param int      $order_id Order ID.
	 * @param string   $from     Old status.
	 * @param string   $to       New status.
	 * @param WC_Order $order    Order.
	 */
	public static function track_payment( $order_id, $from, $to, $order ) {
		$quote_id = (int) $order->get_meta( '_qs_quote_id' );
		if ( ! $quote_id || ! in_array( $to, array( 'processing', 'completed', 'on-hold' ), true ) ) {
			return;
		}
		if ( $order->get_meta( '_qs_paid_logged' ) ) {
			return;
		}
		$quote = QuoteSign_Quote::get( $quote_id );
		if ( ! $quote ) {
			return;
		}
		$kind = $order->get_meta( '_qs_order_kind' );
		$order->update_meta_data( '_qs_paid_logged', time() );
		$order->save();
		update_post_meta( $quote_id, '_qs_' . $kind . '_paid', time() );
		$quote->log(
			$kind . '_paid',
			sprintf(
				/* translators: %s: order number */
				__( 'Payment received on order #%s', 'quotesign' ),
				$order->get_order_number()
			)
		);
	}

	/**
	 * Show a "Quote" box on orders created by the plugin.
	 *
	 * @param string $post_type Screen / post type.
	 * @param mixed  $post      Post or order.
	 */
	public static function order_metabox( $post_type, $post ) {
		$screen_ids = array( 'shop_order' );
		if ( function_exists( 'wc_get_page_screen_id' ) ) {
			$screen_ids[] = wc_get_page_screen_id( 'shop-order' );
		}
		if ( ! in_array( $post_type, $screen_ids, true ) ) {
			return;
		}
		add_meta_box( 'qs_order_quote', __( 'Quote', 'quotesign' ), array( __CLASS__, 'order_metabox_content' ), $post_type, 'side', 'default' );
	}

	/**
	 * Metabox body.
	 *
	 * @param mixed $post_or_order Post or order.
	 */
	public static function order_metabox_content( $post_or_order ) {
		$order = $post_or_order instanceof WC_Order ? $post_or_order : wc_get_order( $post_or_order->ID );
		$qid   = $order ? (int) $order->get_meta( '_qs_quote_id' ) : 0;
		$quote = $qid ? QuoteSign_Quote::get( $qid ) : null;
		if ( ! $quote ) {
			echo '<p>' . esc_html__( 'Not created from a quote.', 'quotesign' ) . '</p>';
			return;
		}
		printf(
			'<p><a href="%s">%s</a><br>%s</p>',
			esc_url( get_edit_post_link( $qid ) ),
			esc_html( $quote->number() ),
			esc_html( ucfirst( (string) $order->get_meta( '_qs_order_kind' ) ) )
		);
	}
}
