/*! QuoteSign front-end (vanilla JS, no dependencies) */
(function () {
	'use strict';

	var cfg = window.qsFront || { routes: {}, i18n: {} };

	function post(url, data) {
		return fetch(url, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': cfg.nonce },
			body: JSON.stringify(data || {})
		}).then(function (r) {
			return r.json().then(function (j) {
				if (!r.ok) {
					throw new Error((j && j.message) || cfg.i18n.error);
				}
				return j;
			});
		});
	}

	function closest(el, sel) {
		while (el && el.nodeType === 1) {
			if (el.matches(sel)) { return el; }
			el = el.parentElement;
		}
		return null;
	}

	/* ---------- Add to quote buttons ---------- */
	document.addEventListener('click', function (e) {
		var btn = closest(e.target, '[data-qs-add]');
		if (!btn) { return; }
		e.preventDefault();

		var wrap = closest(btn, '.qs-add-wrap');
		var msg = wrap.querySelector('.qs-add-msg');
		var productId = parseInt(wrap.getAttribute('data-qs-product'), 10);
		var type = wrap.getAttribute('data-qs-type');
		var qty = 1;
		var variationId = 0;

		var form = document.querySelector('form.cart, form.variations_form');
		var ownQty = wrap.querySelector('.qs-add-qty');
		if (ownQty) {
			qty = parseInt(ownQty.value, 10) || 1;
		} else if (form) {
			var q = form.querySelector('input.qty, input[name="quantity"]');
			if (q) { qty = parseInt(q.value, 10) || 1; }
		}

		if (type === 'variable') {
			var vf = document.querySelector('form.variations_form');
			var vid = vf ? vf.querySelector('input[name="variation_id"]') : null;
			variationId = vid ? parseInt(vid.value, 10) || 0 : 0;
			if (!variationId) {
				msg.className = 'qs-add-msg qs-is-error';
				msg.textContent = cfg.i18n.chooseOpts;
				return;
			}
		}

		btn.disabled = true;
		msg.className = 'qs-add-msg';
		msg.textContent = '';

		post(cfg.routes.add, { product_id: productId, variation_id: variationId, qty: qty })
			.then(function () {
				msg.className = 'qs-add-msg qs-is-ok';
				msg.textContent = cfg.i18n.added + ' ';
				var a = document.createElement('a');
				a.href = cfg.basketUrl;
				a.textContent = cfg.i18n.view;
				msg.appendChild(a);
			})
			.catch(function (err) {
				msg.className = 'qs-add-msg qs-is-error';
				msg.textContent = err.message || cfg.i18n.error;
			})
			.then(function () { btn.disabled = false; });
	});

	/* ---------- Basket ---------- */
	function basketRoot(el) { return closest(el, '[data-qs-basket]'); }

	function showError(root, text) {
		var box = root.querySelector('[data-qs-error]');
		if (!box) { return; }
		box.textContent = text;
		box.hidden = !text;
	}

	function replaceHtml(root, res) {
		if (res && typeof res.html === 'string') {
			root.innerHTML = res.html;
		}
	}

	document.addEventListener('change', function (e) {
		var input = closest(e.target, '[data-qs-qty]');
		if (!input) { return; }
		var root = basketRoot(input);
		var row = closest(input, 'tr[data-key]');
		if (!root || !row) { return; }
		var qty = {};
		qty[row.getAttribute('data-key')] = parseInt(input.value, 10) || 0;
		post(cfg.routes.update, { qty: qty }).then(function (res) {
			replaceHtml(root, res);
		}).catch(function (err) { showError(root, err.message); });
	});

	document.addEventListener('click', function (e) {
		var rm = closest(e.target, '[data-qs-remove]');
		if (!rm) { return; }
		e.preventDefault();
		var root = basketRoot(rm);
		var row = closest(rm, 'tr[data-key]');
		if (!root || !row) { return; }
		post(cfg.routes.remove, { key: row.getAttribute('data-key') }).then(function (res) {
			replaceHtml(root, res);
		}).catch(function (err) { showError(root, err.message); });
	});

	document.addEventListener('submit', function (e) {
		var form = closest(e.target, '[data-qs-submit]');
		if (!form) { return; }
		e.preventDefault();
		var root = basketRoot(form);
		showError(root, '');

		var data = {};
		Array.prototype.forEach.call(form.elements, function (el) {
			if (el.name) { data[el.name] = el.value; }
		});
		if (!data.name || !data.email) {
			showError(root, cfg.i18n.error);
			if (form.reportValidity) { form.reportValidity(); }
			return;
		}
		var submit = form.querySelector('[type="submit"]');
		var label = submit.textContent;
		submit.disabled = true;
		submit.textContent = cfg.i18n.sending;
		post(cfg.routes.submit, data).then(function (res) {
			replaceHtml(root, res);
			root.scrollIntoView({ behavior: 'smooth', block: 'start' });
		}).catch(function (err) {
			showError(root, err.message);
			submit.disabled = false;
			submit.textContent = label;
		});
	});
})();
