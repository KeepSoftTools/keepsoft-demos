/*! QuoteSign public quote page: typed / drawn signature (vanilla JS) */
(function () {
	'use strict';

	var root = document.getElementById('qs-quote');
	if (!root) { return; }
	var cfg = {};
	try { cfg = JSON.parse(root.getAttribute('data-qs-config')); } catch (e) { cfg = { i18n: {} }; }
	var t = cfg.i18n || {};

	var form = root.querySelector('[data-qs-accept]');
	if (!form) { return; }

	var errBox = root.querySelector('[data-qs-error]');
	var nameInput = form.querySelector('input[name="name"]');
	var preview = form.querySelector('[data-qs-typed-preview]');
	var canvas = form.querySelector('[data-qs-canvas]');
	var tabs = form.querySelectorAll('[data-qs-mode]');
	var panes = form.querySelectorAll('[data-qs-pane]');
	var mode = 'typed';
	var hasInk = false;

	function showError(msg, ok) {
		errBox.textContent = msg || '';
		errBox.hidden = !msg;
		errBox.className = 'qs-alert' + (ok ? ' is-ok' : '');
		if (msg) { errBox.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
	}

	function updatePreview() { preview.textContent = nameInput.value; }
	nameInput.addEventListener('input', updatePreview);
	updatePreview();

	Array.prototype.forEach.call(tabs, function (tab) {
		tab.addEventListener('click', function () {
			mode = tab.getAttribute('data-qs-mode');
			Array.prototype.forEach.call(tabs, function (x) {
				var on = x === tab;
				x.classList.toggle('is-active', on);
				x.setAttribute('aria-selected', on ? 'true' : 'false');
			});
			Array.prototype.forEach.call(panes, function (p) {
				p.hidden = p.getAttribute('data-qs-pane') !== mode;
			});
		});
	});

	/* ---------- Drawing ---------- */
	var ctx = canvas.getContext('2d');
	var drawing = false;
	var last = null;

	function setup() {
		// Keep the bitmap crisp on high-density screens without distorting strokes.
		var ratio = Math.max(1, window.devicePixelRatio || 1);
		canvas.width = 640 * ratio;
		canvas.height = 200 * ratio;
		ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
		ctx.lineWidth = 2.4;
		ctx.lineCap = 'round';
		ctx.lineJoin = 'round';
		ctx.strokeStyle = '#111827';
		hasInk = false;
	}
	setup();

	function pos(e) {
		var r = canvas.getBoundingClientRect();
		return { x: (e.clientX - r.left) * (640 / r.width), y: (e.clientY - r.top) * (200 / r.height) };
	}
	canvas.addEventListener('pointerdown', function (e) {
		drawing = true;
		last = pos(e);
		canvas.setPointerCapture(e.pointerId);
		ctx.beginPath();
		ctx.arc(last.x, last.y, 1.2, 0, Math.PI * 2);
		ctx.fillStyle = '#111827';
		ctx.fill();
		hasInk = true;
		e.preventDefault();
	});
	canvas.addEventListener('pointermove', function (e) {
		if (!drawing) { return; }
		var p = pos(e);
		ctx.beginPath();
		ctx.moveTo(last.x, last.y);
		ctx.lineTo(p.x, p.y);
		ctx.stroke();
		last = p;
		e.preventDefault();
	});
	function stop() { drawing = false; }
	canvas.addEventListener('pointerup', stop);
	canvas.addEventListener('pointercancel', stop);
	canvas.addEventListener('pointerleave', stop);

	root.querySelector('[data-qs-clear]').addEventListener('click', function () {
		ctx.setTransform(1, 0, 0, 1, 0, 0);
		ctx.clearRect(0, 0, canvas.width, canvas.height);
		setup();
	});

	/* ---------- Submit ---------- */
	function send(url, body) {
		return fetch(url, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify(body)
		}).then(function (r) {
			return r.json().then(function (j) {
				if (!r.ok) { throw new Error((j && j.message) || t.error); }
				return j;
			});
		});
	}

	form.addEventListener('submit', function (e) {
		e.preventDefault();
		showError('');
		var name = nameInput.value.trim();
		if (name.length < 2) { showError(t.needName); nameInput.focus(); return; }
		if (mode === 'drawn' && !hasInk) { showError(t.needDraw); return; }
		if (!form.elements.agree.checked) { showError(t.needAgree); return; }

		var btn = form.querySelector('[data-qs-submit]');
		btn.disabled = true;
		btn.textContent = t.working;

		var body = { name: name, mode: mode, agree: true };
		if (mode === 'drawn') { body.signature = canvas.toDataURL('image/png'); }

		send(cfg.acceptUrl, body).then(function (res) {
			showError(res.message, true);
			form.querySelectorAll('input,button').forEach(function (el) { el.disabled = true; });
			window.setTimeout(function () {
				window.location.href = res.redirect || window.location.href.split('#')[0];
			}, res.redirect ? 1200 : 1800);
		}).catch(function (err) {
			showError(err.message);
			btn.disabled = false;
			btn.textContent = t.accept;
		});
	});

	var decline = root.querySelector('[data-qs-decline]');
	if (decline) {
		decline.addEventListener('click', function () {
			if (!window.confirm(t.confirmDecline)) { return; }
			send(cfg.declineUrl, {}).then(function () {
				window.location.reload();
			}).catch(function (err) { showError(err.message); });
		});
	}
})();
