/*! QuoteSign admin (vanilla JS) */
(function () {
	'use strict';
	var cfg = window.qsAdmin || { i18n: {} };
	var tbody = document.querySelector('#qs-items tbody');
	if (!tbody) { return; }

	var tpl = document.getElementById('qs-row-template');
	var nextIndex = tbody.querySelectorAll('tr').length;

	function num(v) {
		var n = parseFloat(String(v).replace(',', '.'));
		return isNaN(n) ? 0 : n;
	}
	function money(n) {
		return cfg.currency + n.toFixed(cfg.decimals);
	}
	function round(n) {
		var f = Math.pow(10, cfg.decimals);
		return Math.round((n + Number.EPSILON) * f) / f;
	}
	function field(name) { return document.querySelector('[name="' + name + '"]'); }

	function recalc() {
		var subtotal = 0;
		tbody.querySelectorAll('tr.qs-row').forEach(function (tr) {
			var q = num(tr.querySelector('[data-qs-field="qty"]').value);
			var p = num(tr.querySelector('[data-qs-field="price"]').value);
			var line = round(q * p);
			subtotal += line;
			tr.querySelector('.qs-line-total').textContent = money(line);
		});
		var dtype = field('qs_discount_type').value;
		var dval = num(field('qs_discount_value').value);
		var disc = dtype === 'fixed' ? dval : subtotal * dval / 100;
		disc = round(Math.min(Math.max(0, disc), subtotal));
		var taxable = subtotal - disc;
		var tax = round(taxable * num(field('qs_tax_rate').value) / 100);
		var total = round(taxable + tax);
		var deptype = field('qs_deposit_type').value;
		var depval = num(field('qs_deposit_value').value);
		var due = total;
		if (deptype === 'percent' && depval > 0 && depval < 100) { due = round(total * depval / 100); }
		if (deptype === 'fixed' && depval > 0 && depval < total) { due = round(depval); }

		var out = { subtotal: subtotal, discount: disc, tax: tax, total: total, deposit: due, balance: round(total - due) };
		Object.keys(out).forEach(function (k) {
			var el = document.querySelector('[data-qs-sum="' + k + '"]');
			if (el) { el.textContent = (k === 'discount' && out[k] > 0 ? '-' : '') + money(round(out[k])); }
		});
	}

	function addRow(data) {
		var html = tpl.innerHTML.replace(/__i__/g, String(nextIndex++));
		var holder = document.createElement('tbody');
		holder.innerHTML = html;
		var tr = holder.firstElementChild;
		if (data) {
			Object.keys(data).forEach(function (k) {
				var el = tr.querySelector('[name$="[' + k + ']"]');
				if (el) { el.value = data[k]; }
			});
		}
		tbody.appendChild(tr);
		recalc();
		return tr;
	}

	document.addEventListener('input', function (e) {
		if (e.target.closest && e.target.closest('[data-qs-calc]') || e.target.hasAttribute('data-qs-calc')) { recalc(); }
	});
	document.addEventListener('change', function (e) {
		if (e.target.hasAttribute && e.target.hasAttribute('data-qs-calc')) { recalc(); }
	});

	document.getElementById('qs-add-line').addEventListener('click', function () {
		addRow({ qty: 1 }).querySelector('input[type="text"]:not([type="hidden"])').focus();
	});

	tbody.addEventListener('click', function (e) {
		var rm = e.target.closest('.qs-remove');
		if (rm) {
			rm.closest('tr').remove();
			recalc();
		}
	});

	if (!tbody.querySelector('tr')) { addRow({ qty: 1 }); }
	recalc();

	/* ---------- Product search (WooCommerce REST, cookie + nonce) ---------- */
	var search = document.getElementById('qs-product-search');
	var results = document.querySelector('.qs-search-results');
	var timer;
	search.addEventListener('input', function () {
		clearTimeout(timer);
		var term = search.value.trim();
		if (term.length < 2) { results.hidden = true; return; }
		timer = setTimeout(function () {
			var url = cfg.searchUrl + (cfg.searchUrl.indexOf('?') > -1 ? '&' : '?') + 'per_page=8&status=publish&search=' + encodeURIComponent(term);
			fetch(url, { credentials: 'same-origin', headers: { 'X-WP-Nonce': cfg.restNonce } })
				.then(function (r) { return r.json(); })
				.then(function (list) {
					results.innerHTML = '';
					if (!Array.isArray(list) || !list.length) {
						var li = document.createElement('li');
						li.textContent = cfg.i18n.noResults;
						results.appendChild(li);
					} else {
						list.forEach(function (p) {
							var li = document.createElement('li');
							li.tabIndex = 0;
							li.textContent = p.name + (p.sku ? ' (' + p.sku + ')' : '') + (p.price ? ' – ' + p.price : '');
							function pick() {
								addRow({ product_id: p.id, name: p.name, sku: p.sku || '', qty: 1, price: p.price || '' });
								results.hidden = true;
								search.value = '';
							}
							li.addEventListener('click', pick);
							li.addEventListener('keydown', function (ev) { if (ev.key === 'Enter') { pick(); } });
							results.appendChild(li);
						});
					}
					results.hidden = false;
				})
				.catch(function () { results.hidden = true; });
		}, 250);
	});
	document.addEventListener('click', function (e) {
		if (!e.target.closest('.qs-search')) { results.hidden = true; }
	});

	/* ---------- Misc ---------- */
	document.querySelectorAll('[data-qs-copy]').forEach(function (btn) {
		btn.addEventListener('click', function () {
			var input = document.querySelector(btn.getAttribute('data-qs-copy'));
			input.select();
			if (navigator.clipboard) { navigator.clipboard.writeText(input.value); } else { document.execCommand('copy'); }
			var old = btn.textContent;
			btn.textContent = cfg.i18n.copied;
			setTimeout(function () { btn.textContent = old; }, 1200);
		});
	});
	document.querySelectorAll('[data-qs-confirm]').forEach(function (btn) {
		btn.addEventListener('click', function (e) {
			var msg = btn.getAttribute('data-qs-confirm') === 'send' ? cfg.i18n.confirmSend : cfg.i18n.confirmBalance;
			if (!window.confirm(msg)) { e.preventDefault(); }
		});
	});
})();
