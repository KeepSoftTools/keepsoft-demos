<?php
/**
 * Public quote page. Override at yourtheme/quotesign/quote-page.php
 *
 * @package QuoteSign
 * @var QuoteSign_Quote $quote
 * @var array           $totals
 * @var string          $pay_url
 * @var string          $logo
 * @var array           $config
 */

defined( 'ABSPATH' ) || exit;

$cur       = array( 'currency' => $quote->currency() );
$status    = $quote->status();
$sig       = $quote->signature();
$is_open   = $quote->is_open();
$terms     = (string) $quote->meta( 'terms' );
$has_dep   = $quote->has_deposit();
$tax_label = QuoteSign_Settings::tax_label();
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow,noarchive">
<title><?php echo esc_html( sprintf( /* translators: 1: quote number, 2: company */ __( 'Quote %1$s – %2$s', 'quotesign' ), $quote->number(), QuoteSign_Settings::company_name() ) ); ?></title>
<link rel="stylesheet" href="<?php echo esc_url( QUOTESIGN_URL . 'assets/css/quote-page.css?ver=' . QUOTESIGN_VERSION ); ?>">
</head>
<body class="qs-page">
<main class="qs-wrap" id="qs-quote" data-qs-config="<?php echo esc_attr( wp_json_encode( $config ) ); ?>">

	<header class="qs-head">
		<div class="qs-brand">
			<?php if ( $logo ) : ?>
				<img class="qs-logo" src="<?php echo esc_url( $logo ); ?>" alt="<?php echo esc_attr( QuoteSign_Settings::company_name() ); ?>">
			<?php else : ?>
				<div class="qs-company"><?php echo esc_html( QuoteSign_Settings::company_name() ); ?></div>
			<?php endif; ?>
			<div class="qs-company-details"><?php echo nl2br( esc_html( (string) QuoteSign_Settings::get( 'company_details' ) ) ); ?></div>
		</div>
		<div class="qs-meta">
			<h1 class="qs-title"><?php esc_html_e( 'Quote', 'quotesign' ); ?> <?php echo esc_html( $quote->number() ); ?></h1>
			<span class="qs-badge qs-badge-<?php echo esc_attr( $status ); ?>"><?php echo esc_html( $quote->status_label() ); ?></span>
			<dl>
				<dt><?php esc_html_e( 'Date', 'quotesign' ); ?></dt>
				<dd><?php echo esc_html( get_the_date( '', $quote->id ) ); ?></dd>
				<?php if ( $quote->expiry() ) : ?>
					<dt><?php esc_html_e( 'Valid until', 'quotesign' ); ?></dt>
					<dd><?php echo esc_html( mysql2date( get_option( 'date_format' ), $quote->expiry() ) ); ?></dd>
				<?php endif; ?>
			</dl>
		</div>
	</header>

	<section class="qs-card qs-to">
		<h2><?php esc_html_e( 'Prepared for', 'quotesign' ); ?></h2>
		<p>
			<strong><?php echo esc_html( $quote->customer_name() ); ?></strong>
			<?php if ( $quote->meta( 'company' ) ) : ?><br><?php echo esc_html( $quote->meta( 'company' ) ); ?><?php endif; ?>
			<br><?php echo esc_html( $quote->customer_email() ); ?>
			<?php if ( $quote->meta( 'phone' ) ) : ?><br><?php echo esc_html( $quote->meta( 'phone' ) ); ?><?php endif; ?>
		</p>
	</section>

	<section class="qs-card">
		<div class="qs-table-wrap">
		<table class="qs-items">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Item', 'quotesign' ); ?></th>
					<th class="qs-num"><?php esc_html_e( 'Qty', 'quotesign' ); ?></th>
					<th class="qs-num"><?php esc_html_e( 'Unit price', 'quotesign' ); ?></th>
					<th class="qs-num"><?php esc_html_e( 'Total', 'quotesign' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $quote->items() as $item ) : ?>
				<tr>
					<td>
						<strong><?php echo esc_html( $item['name'] ); ?></strong>
						<?php if ( ! empty( $item['sku'] ) ) : ?><small><?php echo esc_html( sprintf( /* translators: %s: SKU */ __( 'SKU: %s', 'quotesign' ), $item['sku'] ) ); ?></small><?php endif; ?>
						<?php if ( ! empty( $item['desc'] ) ) : ?><small><?php echo nl2br( esc_html( $item['desc'] ) ); ?></small><?php endif; ?>
					</td>
					<td class="qs-num"><?php echo esc_html( wc_format_localized_decimal( $item['qty'] ) ); ?></td>
					<td class="qs-num"><?php echo wp_kses_post( wc_price( $item['price'], $cur ) ); ?></td>
					<td class="qs-num"><?php echo wp_kses_post( wc_price( round( $item['qty'] * $item['price'], wc_get_price_decimals() ), $cur ) ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		</div>
		<table class="qs-totals">
			<tr><th><?php esc_html_e( 'Subtotal', 'quotesign' ); ?></th><td><?php echo wp_kses_post( wc_price( $totals['subtotal'], $cur ) ); ?></td></tr>
			<?php if ( $totals['discount'] > 0 ) : ?>
				<tr><th><?php esc_html_e( 'Discount', 'quotesign' ); ?></th><td>&minus;<?php echo wp_kses_post( wc_price( $totals['discount'], $cur ) ); ?></td></tr>
			<?php endif; ?>
			<?php if ( $totals['tax'] > 0 ) : ?>
				<tr><th><?php echo esc_html( sprintf( '%s (%s%%)', $tax_label, wc_format_localized_decimal( $totals['tax_rate'] ) ) ); ?></th><td><?php echo wp_kses_post( wc_price( $totals['tax'], $cur ) ); ?></td></tr>
			<?php endif; ?>
			<tr class="qs-grand"><th><?php esc_html_e( 'Total', 'quotesign' ); ?></th><td><?php echo wp_kses_post( wc_price( $totals['total'], $cur ) ); ?></td></tr>
			<?php if ( $has_dep ) : ?>
				<tr class="qs-dep"><th><?php esc_html_e( 'Deposit due on acceptance', 'quotesign' ); ?></th><td><?php echo wp_kses_post( wc_price( $totals['deposit_due'], $cur ) ); ?></td></tr>
				<tr><th><?php esc_html_e( 'Balance', 'quotesign' ); ?></th><td><?php echo wp_kses_post( wc_price( $totals['balance'], $cur ) ); ?></td></tr>
			<?php endif; ?>
		</table>
	</section>

	<?php if ( '' !== trim( $terms ) ) : ?>
		<section class="qs-card">
			<h2><?php esc_html_e( 'Terms & conditions', 'quotesign' ); ?></h2>
			<div class="qs-terms"><?php echo wp_kses_post( wpautop( $terms ) ); ?></div>
		</section>
	<?php endif; ?>

	<?php if ( 'accepted' === $status && $sig ) : ?>
		<section class="qs-card qs-signed">
			<h2><?php esc_html_e( 'Accepted & signed', 'quotesign' ); ?></h2>
			<p>
				<?php
				echo esc_html(
					sprintf(
						/* translators: 1: name, 2: date/time */
						__( 'Signed electronically by %1$s on %2$s.', 'quotesign' ),
						$sig['name'],
						wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $sig['time'] )
					)
				);
				?>
			</p>
			<?php if ( ! empty( $sig['data'] ) && 'drawn' === $sig['mode'] ) : ?>
				<img class="qs-sigimg" src="<?php echo esc_attr( $sig['data'] ); ?>" alt="<?php esc_attr_e( 'Signature', 'quotesign' ); ?>">
			<?php else : ?>
				<p class="qs-typed-sig"><?php echo esc_html( $sig['name'] ); ?></p>
			<?php endif; ?>
			<?php if ( $pay_url ) : ?>
				<p><a class="qs-btn qs-btn-primary" href="<?php echo esc_url( $pay_url ); ?>"><?php esc_html_e( 'Pay now', 'quotesign' ); ?></a></p>
			<?php endif; ?>
		</section>
	<?php elseif ( 'declined' === $status ) : ?>
		<section class="qs-card"><p><?php esc_html_e( 'You declined this quote. Please get in touch if you would like a revised version.', 'quotesign' ); ?></p></section>
	<?php elseif ( 'expired' === $status ) : ?>
		<section class="qs-card"><p><?php esc_html_e( 'This quote has expired. Please contact us to request an updated quote.', 'quotesign' ); ?></p></section>
	<?php elseif ( $is_open ) : ?>
		<section class="qs-card qs-accept" id="qs-accept">
			<h2><?php esc_html_e( 'Accept this quote', 'quotesign' ); ?></h2>
			<div class="qs-alert" role="alert" hidden data-qs-error></div>
			<form data-qs-accept novalidate>
				<p class="qs-field">
					<label for="qs-sig-name"><?php esc_html_e( 'Your full name', 'quotesign' ); ?></label>
					<input type="text" id="qs-sig-name" name="name" autocomplete="name" required value="<?php echo esc_attr( $quote->customer_name() ); ?>">
				</p>

				<div class="qs-tabs" role="tablist">
					<button type="button" role="tab" class="qs-tab is-active" aria-selected="true" data-qs-mode="typed"><?php esc_html_e( 'Type signature', 'quotesign' ); ?></button>
					<button type="button" role="tab" class="qs-tab" aria-selected="false" data-qs-mode="drawn"><?php esc_html_e( 'Draw signature', 'quotesign' ); ?></button>
				</div>
				<div class="qs-pane" data-qs-pane="typed">
					<div class="qs-typed-preview" data-qs-typed-preview aria-hidden="true"></div>
					<p class="qs-hint"><?php esc_html_e( 'Your typed name above will be used as your signature.', 'quotesign' ); ?></p>
				</div>
				<div class="qs-pane" data-qs-pane="drawn" hidden>
					<canvas class="qs-canvas" data-qs-canvas width="640" height="200" aria-label="<?php esc_attr_e( 'Signature drawing area', 'quotesign' ); ?>"></canvas>
					<p><button type="button" class="qs-btn qs-btn-link" data-qs-clear><?php esc_html_e( 'Clear', 'quotesign' ); ?></button></p>
				</div>

				<p class="qs-check">
					<label><input type="checkbox" name="agree" value="1" required>
					<span>
					<?php
					if ( '' !== trim( $terms ) ) {
						esc_html_e( 'I have read and agree to the terms & conditions and accept this quote.', 'quotesign' );
					} else {
						esc_html_e( 'I accept this quote and agree that my electronic signature is legally binding.', 'quotesign' );
					}
					?>
					</span></label>
				</p>
				<?php if ( $has_dep && 'yes' === QuoteSign_Settings::get( 'create_order' ) ) : ?>
					<p class="qs-hint"><?php echo wp_kses_post( sprintf( /* translators: %s: deposit amount */ __( 'After signing you will be taken to checkout to pay the deposit of %s.', 'quotesign' ), wc_price( $totals['deposit_due'], $cur ) ) ); ?></p>
				<?php elseif ( 'yes' === QuoteSign_Settings::get( 'create_order' ) ) : ?>
					<p class="qs-hint"><?php esc_html_e( 'After signing you will be taken to checkout to pay.', 'quotesign' ); ?></p>
				<?php endif; ?>
				<p class="qs-actions">
					<button type="submit" class="qs-btn qs-btn-primary" data-qs-submit><?php esc_html_e( 'Accept & sign', 'quotesign' ); ?></button>
					<button type="button" class="qs-btn qs-btn-link" data-qs-decline><?php esc_html_e( 'Decline quote', 'quotesign' ); ?></button>
				</p>
			</form>
		</section>
	<?php endif; ?>

	<footer class="qs-foot">
		<a class="qs-btn" href="<?php echo esc_url( $quote->pdf_url() ); ?>"><?php esc_html_e( 'Download PDF', 'quotesign' ); ?></a>
	</footer>
</main>
<script src="<?php echo esc_url( QUOTESIGN_URL . 'assets/js/quote-page.js?ver=' . QUOTESIGN_VERSION ); ?>" defer></script>
</body>
</html>
