<?php
/**
 * QuoteSign email (HTML). Override at yourtheme/woocommerce/emails/qs-email.php
 *
 * @package QuoteSign
 * @var string          $email_heading
 * @var QuoteSign_Quote $quote
 * @var string          $intro
 * @var string          $button_label
 * @var string          $button_url
 * @var bool            $show_items
 * @var string          $additional_content
 * @var bool            $sent_to_admin
 * @var bool            $plain_text
 * @var WC_Email        $email
 */

defined( 'ABSPATH' ) || exit;

$cur       = array( 'currency' => $quote->currency() );
$totals    = $quote->totals();
$text_align = is_rtl() ? 'right' : 'left';
$has_prices = 'new' !== $quote->status() || $sent_to_admin;

do_action( 'woocommerce_email_header', $email_heading, $email );
?>

<p><?php echo esc_html( $intro ); ?></p>

<?php if ( $button_url ) : ?>
	<p style="margin: 24px 0;">
		<a href="<?php echo esc_url( $button_url ); ?>" style="display:inline-block;background-color:<?php echo esc_attr( get_option( 'woocommerce_email_base_color', '#7f54b3' ) ); ?>;color:#ffffff;padding:12px 24px;text-decoration:none;font-weight:bold;border-radius:3px;"><?php echo esc_html( $button_label ); ?></a>
	</p>
<?php endif; ?>

<?php if ( $show_items ) : ?>
	<h2 style="font-size:18px;margin:24px 0 12px;"><?php echo esc_html( $quote->number() ); ?></h2>
	<div style="margin-bottom:24px;">
		<table cellspacing="0" cellpadding="6" border="1" style="width:100%;border:1px solid #e5e5e5;vertical-align:middle;" width="100%">
			<thead>
				<tr>
					<th style="text-align:<?php echo esc_attr( $text_align ); ?>;border:1px solid #e5e5e5;padding:12px;"><?php esc_html_e( 'Item', 'quotesign' ); ?></th>
					<th style="text-align:<?php echo esc_attr( $text_align ); ?>;border:1px solid #e5e5e5;padding:12px;"><?php esc_html_e( 'Qty', 'quotesign' ); ?></th>
					<?php if ( $has_prices ) : ?>
						<th style="text-align:<?php echo esc_attr( $text_align ); ?>;border:1px solid #e5e5e5;padding:12px;"><?php esc_html_e( 'Total', 'quotesign' ); ?></th>
					<?php endif; ?>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $quote->items() as $item ) : ?>
				<tr>
					<td style="text-align:<?php echo esc_attr( $text_align ); ?>;border:1px solid #e5e5e5;padding:12px;"><?php echo esc_html( $item['name'] ); ?></td>
					<td style="text-align:<?php echo esc_attr( $text_align ); ?>;border:1px solid #e5e5e5;padding:12px;"><?php echo esc_html( wc_format_localized_decimal( $item['qty'] ) ); ?></td>
					<?php if ( $has_prices ) : ?>
						<td style="text-align:<?php echo esc_attr( $text_align ); ?>;border:1px solid #e5e5e5;padding:12px;"><?php echo wp_kses_post( wc_price( round( $item['qty'] * $item['price'], wc_get_price_decimals() ), $cur ) ); ?></td>
					<?php endif; ?>
				</tr>
			<?php endforeach; ?>
			</tbody>
			<?php if ( $has_prices ) : ?>
			<tfoot>
				<?php if ( $totals['discount'] > 0 || $totals['tax'] > 0 ) : ?>
					<tr>
						<th colspan="2" style="text-align:<?php echo esc_attr( $text_align ); ?>;border:1px solid #e5e5e5;padding:12px;"><?php esc_html_e( 'Subtotal', 'quotesign' ); ?></th>
						<td style="text-align:<?php echo esc_attr( $text_align ); ?>;border:1px solid #e5e5e5;padding:12px;"><?php echo wp_kses_post( wc_price( $totals['subtotal'], $cur ) ); ?></td>
					</tr>
				<?php endif; ?>
				<?php if ( $totals['discount'] > 0 ) : ?>
					<tr>
						<th colspan="2" style="text-align:<?php echo esc_attr( $text_align ); ?>;border:1px solid #e5e5e5;padding:12px;"><?php esc_html_e( 'Discount', 'quotesign' ); ?></th>
						<td style="text-align:<?php echo esc_attr( $text_align ); ?>;border:1px solid #e5e5e5;padding:12px;">&minus;<?php echo wp_kses_post( wc_price( $totals['discount'], $cur ) ); ?></td>
					</tr>
				<?php endif; ?>
				<?php if ( $totals['tax'] > 0 ) : ?>
					<tr>
						<th colspan="2" style="text-align:<?php echo esc_attr( $text_align ); ?>;border:1px solid #e5e5e5;padding:12px;"><?php echo esc_html( QuoteSign_Settings::tax_label() ); ?></th>
						<td style="text-align:<?php echo esc_attr( $text_align ); ?>;border:1px solid #e5e5e5;padding:12px;"><?php echo wp_kses_post( wc_price( $totals['tax'], $cur ) ); ?></td>
					</tr>
				<?php endif; ?>
				<tr>
					<th colspan="2" style="text-align:<?php echo esc_attr( $text_align ); ?>;border:1px solid #e5e5e5;padding:12px;"><?php esc_html_e( 'Total', 'quotesign' ); ?></th>
					<td style="text-align:<?php echo esc_attr( $text_align ); ?>;border:1px solid #e5e5e5;padding:12px;"><?php echo wp_kses_post( wc_price( $totals['total'], $cur ) ); ?></td>
				</tr>
				<?php if ( $quote->has_deposit() ) : ?>
					<tr>
						<th colspan="2" style="text-align:<?php echo esc_attr( $text_align ); ?>;border:1px solid #e5e5e5;padding:12px;"><?php esc_html_e( 'Deposit due on acceptance', 'quotesign' ); ?></th>
						<td style="text-align:<?php echo esc_attr( $text_align ); ?>;border:1px solid #e5e5e5;padding:12px;"><?php echo wp_kses_post( wc_price( $totals['deposit_due'], $cur ) ); ?></td>
					</tr>
				<?php endif; ?>
			</tfoot>
			<?php endif; ?>
		</table>
	</div>
<?php endif; ?>

<?php if ( $sent_to_admin ) : ?>
	<p>
		<strong><?php esc_html_e( 'Customer', 'quotesign' ); ?>:</strong>
		<?php echo esc_html( $quote->customer_name() ); ?>,
		<a href="mailto:<?php echo esc_attr( $quote->customer_email() ); ?>"><?php echo esc_html( $quote->customer_email() ); ?></a>
		<?php echo $quote->meta( 'phone' ) ? ', ' . esc_html( $quote->meta( 'phone' ) ) : ''; ?>
	</p>
	<?php if ( $quote->meta( 'customer_note' ) ) : ?>
		<p><strong><?php esc_html_e( 'Customer note', 'quotesign' ); ?>:</strong><br><?php echo nl2br( esc_html( $quote->meta( 'customer_note' ) ) ); ?></p>
	<?php endif; ?>
<?php endif; ?>

<?php
if ( $additional_content ) {
	echo wp_kses_post( wpautop( wptexturize( $additional_content ) ) );
}

do_action( 'woocommerce_email_footer', $email );
