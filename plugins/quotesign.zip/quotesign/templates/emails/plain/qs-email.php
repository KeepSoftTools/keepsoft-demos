<?php
/**
 * QuoteSign email (plain text). Override at yourtheme/woocommerce/emails/plain/qs-email.php
 *
 * @package QuoteSign
 */

defined( 'ABSPATH' ) || exit;

echo '= ' . esc_html( wp_strip_all_tags( $email_heading ) ) . " =\n\n";
echo esc_html( wp_strip_all_tags( $intro ) ) . "\n\n";

if ( $button_url ) {
	echo esc_html( $button_label ) . ': ' . esc_url_raw( $button_url ) . "\n\n";
}

if ( $show_items ) {
	$cur = array( 'currency' => $quote->currency() );
	echo esc_html( $quote->number() ) . "\n----------------------------------------\n";
	foreach ( $quote->items() as $item ) {
		echo esc_html( $item['name'] ) . ' x ' . esc_html( wc_format_localized_decimal( $item['qty'] ) );
		if ( 'new' !== $quote->status() || $sent_to_admin ) {
			echo ' = ' . esc_html( html_entity_decode( wp_strip_all_tags( wc_price( round( $item['qty'] * $item['price'], wc_get_price_decimals() ), $cur ) ) ) );
		}
		echo "\n";
	}
	if ( 'new' !== $quote->status() || $sent_to_admin ) {
		$t = $quote->totals();
		echo "----------------------------------------\n";
		echo esc_html__( 'Total', 'quotesign' ) . ': ' . esc_html( html_entity_decode( wp_strip_all_tags( wc_price( $t['total'], $cur ) ) ) ) . "\n";
	}
	echo "\n";
}

if ( $sent_to_admin ) {
	echo esc_html__( 'Customer', 'quotesign' ) . ': ' . esc_html( $quote->customer_name() ) . ' <' . esc_html( $quote->customer_email() ) . ">\n\n";
}

if ( $additional_content ) {
	echo esc_html( wp_strip_all_tags( wptexturize( $additional_content ) ) ) . "\n\n";
}

echo wp_kses_post( apply_filters( 'woocommerce_email_footer_text', get_option( 'woocommerce_email_footer_text' ) ) );
