<?php
/**
 * Quote basket template. Override in your theme at: yourtheme/quotesign/basket.php
 *
 * @package QuoteSign
 * @var array  $items
 * @var array  $prefill
 * @var string $notice
 * @var bool   $phone_required
 * @var string $shop_url
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="qs-basket" aria-live="polite">
	<?php if ( $notice ) : ?>
		<div class="qs-notice qs-notice-success" role="status"><?php echo esc_html( $notice ); ?></div>
	<?php endif; ?>
	<div class="qs-notice qs-notice-error" role="alert" hidden data-qs-error></div>

	<?php if ( empty( $items ) ) : ?>
		<?php if ( ! $notice ) : ?>
			<p class="qs-empty"><?php esc_html_e( 'Your quote basket is empty.', 'quotesign' ); ?></p>
		<?php endif; ?>
		<p><a class="qs-link" href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'Browse products', 'quotesign' ); ?></a></p>
	<?php else : ?>
		<table class="qs-table">
			<thead>
				<tr>
					<th class="qs-col-product"><?php esc_html_e( 'Product', 'quotesign' ); ?></th>
					<th class="qs-col-qty"><?php esc_html_e( 'Quantity', 'quotesign' ); ?></th>
					<th class="qs-col-remove"><span class="screen-reader-text"><?php esc_html_e( 'Remove', 'quotesign' ); ?></span></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $items as $key => $item ) : ?>
				<tr data-key="<?php echo esc_attr( $key ); ?>">
					<td class="qs-col-product">
						<a href="<?php echo esc_url( $item['url'] ); ?>"><?php echo esc_html( $item['name'] ); ?></a>
						<?php if ( $item['sku'] ) : ?>
							<small class="qs-sku"><?php echo esc_html( sprintf( /* translators: %s: SKU */ __( 'SKU: %s', 'quotesign' ), $item['sku'] ) ); ?></small>
						<?php endif; ?>
					</td>
					<td class="qs-col-qty">
						<label class="screen-reader-text" for="qs-qty-<?php echo esc_attr( $key ); ?>"><?php esc_html_e( 'Quantity', 'quotesign' ); ?></label>
						<input type="number" min="1" max="9999" step="1" class="qs-qty" id="qs-qty-<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $item['qty'] ); ?>" data-qs-qty>
					</td>
					<td class="qs-col-remove">
						<button type="button" class="qs-remove" data-qs-remove aria-label="<?php echo esc_attr( sprintf( /* translators: %s: product name */ __( 'Remove %s', 'quotesign' ), $item['name'] ) ); ?>">&times;</button>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>

		<form class="qs-form" data-qs-submit novalidate>
			<h3 class="qs-heading"><?php esc_html_e( 'Your details', 'quotesign' ); ?></h3>
			<div class="qs-grid">
				<p class="qs-field">
					<label for="qs-name"><?php esc_html_e( 'Full name', 'quotesign' ); ?> <span class="qs-req">*</span></label>
					<input type="text" id="qs-name" name="name" required autocomplete="name" value="<?php echo esc_attr( $prefill['name'] ); ?>">
				</p>
				<p class="qs-field">
					<label for="qs-email"><?php esc_html_e( 'Email', 'quotesign' ); ?> <span class="qs-req">*</span></label>
					<input type="email" id="qs-email" name="email" required autocomplete="email" value="<?php echo esc_attr( $prefill['email'] ); ?>">
				</p>
				<p class="qs-field">
					<label for="qs-phone"><?php esc_html_e( 'Phone', 'quotesign' ); ?><?php echo $phone_required ? ' <span class="qs-req">*</span>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput ?></label>
					<input type="tel" id="qs-phone" name="phone" autocomplete="tel" <?php echo $phone_required ? 'required' : ''; ?> value="<?php echo esc_attr( $prefill['phone'] ); ?>">
				</p>
				<p class="qs-field">
					<label for="qs-company"><?php esc_html_e( 'Company', 'quotesign' ); ?></label>
					<input type="text" id="qs-company" name="company" autocomplete="organization" value="<?php echo esc_attr( $prefill['company'] ); ?>">
				</p>
			</div>
			<p class="qs-field">
				<label for="qs-note"><?php esc_html_e( 'Notes', 'quotesign' ); ?></label>
				<textarea id="qs-note" name="note" rows="4" maxlength="3000"></textarea>
			</p>
			<p class="qs-hp" aria-hidden="true"><label>Website <input type="text" name="website" tabindex="-1" autocomplete="off"></label></p>
			<p><button type="submit" class="qs-btn qs-btn-primary"><?php esc_html_e( 'Submit quote request', 'quotesign' ); ?></button></p>
		</form>
	<?php endif; ?>
</div>
