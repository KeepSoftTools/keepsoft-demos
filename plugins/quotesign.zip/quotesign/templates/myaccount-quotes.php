<?php
/**
 * My Account > Quotes. Override at yourtheme/quotesign/myaccount-quotes.php
 *
 * @package QuoteSign
 * @var QuoteSign_Quote[] $quotes
 */

defined( 'ABSPATH' ) || exit;
?>
<h2><?php esc_html_e( 'Your quotes', 'quotesign' ); ?></h2>
<?php if ( empty( $quotes ) ) : ?>
	<div class="woocommerce-info"><?php esc_html_e( 'You have no quotes yet.', 'quotesign' ); ?></div>
<?php else : ?>
	<table class="woocommerce-orders-table shop_table shop_table_responsive my_account_orders">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Quote', 'quotesign' ); ?></th>
				<th><?php esc_html_e( 'Date', 'quotesign' ); ?></th>
				<th><?php esc_html_e( 'Status', 'quotesign' ); ?></th>
				<th><?php esc_html_e( 'Total', 'quotesign' ); ?></th>
				<th></th>
			</tr>
		</thead>
		<tbody>
		<?php foreach ( $quotes as $quote ) : ?>
			<?php $totals = $quote->totals(); ?>
			<tr>
				<td data-title="<?php esc_attr_e( 'Quote', 'quotesign' ); ?>"><?php echo esc_html( $quote->number() ); ?></td>
				<td data-title="<?php esc_attr_e( 'Date', 'quotesign' ); ?>"><?php echo esc_html( get_the_date( '', $quote->id ) ); ?></td>
				<td data-title="<?php esc_attr_e( 'Status', 'quotesign' ); ?>"><?php echo esc_html( $quote->status_label() ); ?></td>
				<td data-title="<?php esc_attr_e( 'Total', 'quotesign' ); ?>">
					<?php echo 'new' === $quote->status() ? '&ndash;' : wp_kses_post( wc_price( $totals['total'], array( 'currency' => $quote->currency() ) ) ); ?>
				</td>
				<td>
					<?php if ( 'new' !== $quote->status() ) : ?>
						<a class="woocommerce-button button view" href="<?php echo esc_url( $quote->url() ); ?>"><?php esc_html_e( 'View', 'quotesign' ); ?></a>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
<?php endif; ?>
