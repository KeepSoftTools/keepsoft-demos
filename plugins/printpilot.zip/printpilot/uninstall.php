<?php
/**
 * Uninstall PrintPilot.
 *
 * Data is only removed when the "Delete all PrintPilot data" box is ticked in Settings.
 *
 * @package PrintPilot
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$pp_settings = get_option( 'pp_settings', array() );

wp_clear_scheduled_hook( 'pp_process_queue' );
wp_clear_scheduled_hook( 'pp_daily_cleanup' );

if ( is_array( $pp_settings ) && ! empty( $pp_settings['remove_data'] ) ) {
	global $wpdb;

	// Jobs table.
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}pp_jobs" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

	// Options.
	foreach ( array( 'pp_settings', 'pp_printers', 'pp_templates', 'pp_rules', 'pp_stations', 'pp_db_version' ) as $pp_option ) {
		delete_option( $pp_option );
	}

	// Order meta used for duplicate protection (classic posts storage and HPOS).
	$wpdb->delete( $wpdb->postmeta, array( 'meta_key' => '_pp_auto' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	$pp_hpos_meta = $wpdb->prefix . 'wc_orders_meta';
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $pp_hpos_meta ) ) === $pp_hpos_meta ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->delete( $pp_hpos_meta, array( 'meta_key' => '_pp_auto' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	delete_transient( 'pp_flash_' . get_current_user_id() );
}
