=== PrintPilot – Automatic Order Printing for WooCommerce (No Subscription) ===
Contributors: keepsoft
Tags: woocommerce, print orders, thermal printer, receipt printer, kitchen printer
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Automatically print WooCommerce kitchen tickets, receipts and packing slips. No PrintNode, no cloud subscription.

== Description ==

PrintPilot turns every WooCommerce order into a printed ticket without any monthly fee.

* Print Station: a kiosk web page for a tablet or PC that polls for new orders, prints them, plays a sound and lets staff accept orders.
* Direct thermal printing from the browser (Web Serial, WebUSB, Web Bluetooth) with a built-in ESC/POS encoder: bold, sizes, QR codes, paper cut and cash drawer.
* Server-side network printing: WordPress sends ESC/POS to printer IP:9100.
* Print to email and browser/PDF printing as fallbacks.
* Template editor with live preview, placeholders and kitchen, receipt and packing-slip presets.
* Routing rules by order status, product category, shipping method, payment method, order type or custom field.
* Print log with retries, bulk "Print" order action, order screen metabox. HPOS compatible.

See the documentation folder for setup instructions (silent printing, printer connection, troubleshooting).

== Installation ==

1. Upload the plugin and activate it (WooCommerce must be active).
2. Open PrintPilot > Printers, add a printer and press Test print.
3. Open PrintPilot > Overview and launch the Print Station.

== Frequently Asked Questions ==

= Do I need PrintNode or a subscription? =
No. Everything runs on your site and in your browser.

= Which printers work? =
Any printer with a driver via browser printing, and ESC/POS thermal printers (Epson TM series and compatibles) via USB, Serial, Bluetooth or network.

== Changelog ==

= 1.0.0 =
* Initial release.
