<?php
/**
 * Ticket data, template parser and renderers.
 *
 * A template is parsed into a "document": a list of simple operations (text, left/right row,
 * rule, feed, QR, drawer, cut). The same document is rendered to HTML (browser / email / preview)
 * and to ESC/POS bytes (PHP network printing and the JS encoder in the Print Station).
 *
 * @package PrintPilot
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ticket builder.
 */
class PrintPilot_Ticket {

	/**
	 * Placeholders offered in the template editor.
	 *
	 * @return array<string,string>
	 */
	public static function placeholders() {
		return array(
			'items'            => __( 'All order lines (qty x name, options, price)', 'printpilot' ),
			'order_number'     => __( 'Order number', 'printpilot' ),
			'order_id'         => __( 'Order ID', 'printpilot' ),
			'order_date'       => __( 'Order date', 'printpilot' ),
			'order_time'       => __( 'Order time', 'printpilot' ),
			'order_status'     => __( 'Order status', 'printpilot' ),
			'order_type'       => __( 'Pickup / Delivery', 'printpilot' ),
			'customer'         => __( 'Customer name', 'printpilot' ),
			'customer_phone'   => __( 'Customer phone', 'printpilot' ),
			'customer_email'   => __( 'Customer email', 'printpilot' ),
			'billing_address'  => __( 'Billing address', 'printpilot' ),
			'shipping_address' => __( 'Shipping address', 'printpilot' ),
			'shipping_method'  => __( 'Shipping method', 'printpilot' ),
			'delivery_time'    => __( 'Delivery / pickup time', 'printpilot' ),
			'notes'            => __( 'Customer note', 'printpilot' ),
			'payment_method'   => __( 'Payment method', 'printpilot' ),
			'subtotal'         => __( 'Subtotal', 'printpilot' ),
			'discount'         => __( 'Discount total', 'printpilot' ),
			'shipping_total'   => __( 'Shipping cost', 'printpilot' ),
			'fees'             => __( 'Fees total', 'printpilot' ),
			'tax'              => __( 'Tax total', 'printpilot' ),
			'total'            => __( 'Order total', 'printpilot' ),
			'item_count'       => __( 'Number of items', 'printpilot' ),
			'coupons'          => __( 'Coupon codes', 'printpilot' ),
			'order_url'        => __( 'Public order link (good for QR codes)', 'printpilot' ),
			'admin_url'        => __( 'Admin edit link', 'printpilot' ),
			'site_name'        => __( 'Site name', 'printpilot' ),
			'site_url'         => __( 'Site address', 'printpilot' ),
			'printer_name'     => __( 'Printer name', 'printpilot' ),
			'print_time'       => __( 'Time of printing', 'printpilot' ),
			'meta:KEY'         => __( 'Any order custom field, e.g. {meta:_billing_vat}', 'printpilot' ),
		);
	}

	/**
	 * Clean a value for printing: plain text, no control characters.
	 *
	 * @param mixed $v Value.
	 * @return string
	 */
	public static function clean( $v ) {
		if ( is_array( $v ) || is_object( $v ) ) {
			$v = '';
		}
		$v = (string) $v;
		$v = str_replace( array( '<br/>', '<br>', '<br />', '</p>' ), "\n", $v );
		$v = wp_strip_all_tags( $v );
		$v = html_entity_decode( $v, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$v = wp_check_invalid_utf8( $v );
		$v = str_replace( array( "\r\n", "\r" ), "\n", $v );
		$v = preg_replace( '/[\x00-\x09\x0B-\x1F\x7F]/', ' ', $v );
		return trim( $v );
	}

	/**
	 * Price as plain text.
	 *
	 * @param float  $amount   Amount.
	 * @param string $currency Currency code.
	 * @return string
	 */
	public static function money( $amount, $currency = '' ) {
		$args = array();
		if ( $currency ) {
			$args['currency'] = $currency;
		}
		return self::clean( wc_price( (float) $amount, $args ) );
	}

	/**
	 * Which meta keys may hold a delivery/pickup time.
	 *
	 * @return string[]
	 */
	protected static function delivery_keys() {
		$keys = array();
		foreach ( explode( ',', (string) PrintPilot_Settings::get_one( 'delivery_meta_keys', '' ) ) as $k ) {
			$k = trim( $k );
			if ( '' !== $k ) {
				$keys[] = $k;
			}
		}
		return apply_filters( 'printpilot_delivery_time_meta_keys', $keys );
	}

	/**
	 * Order type: pickup, delivery or none.
	 *
	 * @param WC_Order $order Order.
	 * @return string
	 */
	public static function order_type( $order ) {
		$type  = 'none';
		$lines = $order->get_shipping_methods();
		foreach ( $lines as $line ) {
			$mid = $line->get_method_id();
			if ( 0 === strpos( $mid, 'local_pickup' ) || false !== strpos( $mid, 'pickup' ) ) {
				return apply_filters( 'printpilot_order_type', 'pickup', $order );
			}
			$type = 'delivery';
		}
		return apply_filters( 'printpilot_order_type', $type, $order );
	}

	/**
	 * Human label for an order type.
	 *
	 * @param string $type Type.
	 * @return string
	 */
	public static function order_type_label( $type ) {
		$labels = array(
			'pickup'   => __( 'PICKUP', 'printpilot' ),
			'delivery' => __( 'DELIVERY', 'printpilot' ),
			'none'     => '',
		);
		return isset( $labels[ $type ] ) ? $labels[ $type ] : '';
	}

	/**
	 * Delivery / pickup time from order meta.
	 *
	 * @param WC_Order $order Order.
	 * @return string
	 */
	protected static function delivery_time( $order ) {
		$val = '';
		foreach ( self::delivery_keys() as $key ) {
			$m = $order->get_meta( $key, true );
			if ( is_scalar( $m ) && '' !== (string) $m ) {
				$val = (string) $m;
				break;
			}
		}
		if ( '' !== $val && ctype_digit( $val ) && (int) $val > 1000000000 ) {
			$val = wp_date( 'D j M, H:i', (int) $val );
		}
		return self::clean( apply_filters( 'printpilot_delivery_time', $val, $order ) );
	}

	/**
	 * Build the placeholder values and item list for a real order.
	 *
	 * @param WC_Order $order Order.
	 * @return array
	 */
	public static function context_from_order( $order ) {
		$currency = $order->get_currency();
		$created  = $order->get_date_created();
		$first    = $order->get_billing_first_name();
		$name     = trim( $first . ' ' . $order->get_billing_last_name() );
		if ( '' === $name ) {
			$name = $order->get_billing_company();
		}
		if ( '' === $name ) {
			$name = __( 'Guest', 'printpilot' );
		}
		$ship_addr = $order->get_formatted_shipping_address();
		if ( '' === trim( wp_strip_all_tags( $ship_addr ) ) ) {
			$ship_addr = $order->get_formatted_billing_address();
		}
		$ship_methods = array();
		foreach ( $order->get_shipping_methods() as $sm ) {
			$ship_methods[] = $sm->get_name();
		}
		$fees = 0.0;
		foreach ( $order->get_fees() as $fee ) {
			$fees += (float) $fee->get_total();
		}
		$type  = self::order_type( $order );
		$items = array();
		$count = 0;
		foreach ( $order->get_items() as $item ) {
			if ( ! $item instanceof WC_Order_Item_Product ) {
				continue;
			}
			$product = $item->get_product();
			$meta    = array();
			foreach ( $item->get_formatted_meta_data( '_', true ) as $md ) {
				$meta[] = self::clean( $md->display_key ) . ': ' . self::clean( $md->display_value );
			}
			$qty     = (float) $item->get_quantity();
			$count  += $qty;
			$items[] = array(
				'qty'   => $qty == (int) $qty ? (string) (int) $qty : (string) $qty, // phpcs:ignore Universal.Operators.StrictComparisons.LooseEqual
				'name'  => self::clean( $item->get_name() ),
				'sku'   => $product ? self::clean( $product->get_sku() ) : '',
				'total' => self::money( (float) $item->get_total() + (float) $item->get_total_tax(), $currency ),
				'meta'  => $meta,
				'cats'  => array_map( 'intval', wc_get_product_cat_ids( $item->get_product_id() ) ),
			);
		}
		$shipping_total = (float) $order->get_shipping_total() + (float) $order->get_shipping_tax();
		$discount       = (float) $order->get_total_discount();
		$tax            = (float) $order->get_total_tax();

		$vars = array(
			'site_name'        => self::clean( get_bloginfo( 'name' ) ),
			'site_url'         => self::clean( preg_replace( '#^https?://#', '', home_url() ) ),
			'order_number'     => self::clean( $order->get_order_number() ),
			'order_id'         => (string) $order->get_id(),
			'order_date'       => $created ? self::clean( wc_format_datetime( $created, wc_date_format() ) ) : '',
			'order_time'       => $created ? self::clean( wc_format_datetime( $created, wc_time_format() ) ) : '',
			'order_status'     => self::clean( wc_get_order_status_name( $order->get_status() ) ),
			'order_type'       => self::order_type_label( $type ),
			'customer'         => self::clean( $name ),
			'customer_phone'   => self::clean( $order->get_billing_phone() ),
			'customer_email'   => self::clean( $order->get_billing_email() ),
			'billing_address'  => self::clean( $order->get_formatted_billing_address() ),
			'shipping_address' => self::clean( $ship_addr ),
			'shipping_method'  => self::clean( implode( ', ', $ship_methods ) ),
			'delivery_time'    => self::delivery_time( $order ),
			'notes'            => self::clean( $order->get_customer_note() ),
			'payment_method'   => self::clean( $order->get_payment_method_title() ),
			'subtotal'         => self::money( $order->get_subtotal(), $currency ),
			'discount'         => $discount > 0 ? self::money( $discount, $currency ) : '',
			'shipping_total'   => $shipping_total > 0 ? self::money( $shipping_total, $currency ) : '',
			'fees'             => abs( $fees ) > 0 ? self::money( $fees, $currency ) : '',
			'tax'              => $tax > 0 ? self::money( $tax, $currency ) : '',
			'total'            => self::money( $order->get_total(), $currency ),
			'item_count'       => (string) ( $count == (int) $count ? (int) $count : $count ), // phpcs:ignore Universal.Operators.StrictComparisons.LooseEqual
			'coupons'          => self::clean( implode( ', ', $order->get_coupon_codes() ) ),
			'order_url'        => esc_url_raw( $order->get_checkout_order_received_url() ),
			'admin_url'        => esc_url_raw( $order->get_edit_order_url() ),
			'print_time'       => wp_date( 'Y-m-d H:i' ),
		);
		return apply_filters(
			'printpilot_context',
			array(
				'vars'    => $vars,
				'items'   => $items,
				'meta_cb' => function ( $key ) use ( $order ) {
					$v = $order->get_meta( $key, true );
					return is_scalar( $v ) ? self::clean( $v ) : '';
				},
			),
			$order
		);
	}

	/**
	 * Fake order used for previews and test prints.
	 *
	 * @return array
	 */
	public static function sample_context() {
		$cur   = get_woocommerce_currency();
		$items = array(
			array(
				'qty'   => '2',
				'name'  => 'Margherita Pizza',
				'sku'   => 'PZ-001',
				'total' => self::money( 25.0, $cur ),
				'meta'  => array( 'Size: Large', 'Extra: Olives, Basil' ),
				'cats'  => array(),
			),
			array(
				'qty'   => '1',
				'name'  => 'Garlic Bread with Cheese',
				'sku'   => 'SD-014',
				'total' => self::money( 6.5, $cur ),
				'meta'  => array(),
				'cats'  => array(),
			),
			array(
				'qty'   => '3',
				'name'  => 'Cola 330ml',
				'sku'   => 'DR-103',
				'total' => self::money( 9.0, $cur ),
				'meta'  => array(),
				'cats'  => array(),
			),
		);
		$vars  = array(
			'site_name'        => self::clean( get_bloginfo( 'name' ) ),
			'site_url'         => self::clean( preg_replace( '#^https?://#', '', home_url() ) ),
			'order_number'     => '1042',
			'order_id'         => '1042',
			'order_date'       => wp_date( get_option( 'date_format' ) ),
			'order_time'       => wp_date( get_option( 'time_format' ) ),
			'order_status'     => __( 'Processing', 'printpilot' ),
			'order_type'       => __( 'DELIVERY', 'printpilot' ),
			'customer'         => 'Jane Doe',
			'customer_phone'   => '0400 000 000',
			'customer_email'   => 'jane@example.com',
			'billing_address'  => "Jane Doe\n12 Example Street\nSample City 3000",
			'shipping_address' => "Jane Doe\n12 Example Street\nSample City 3000",
			'shipping_method'  => 'Flat rate',
			'delivery_time'    => wp_date( 'D j M, H:i', time() + 3600 ),
			'notes'            => 'Please ring the bell. No onions on the pizza!',
			'payment_method'   => 'Credit card',
			'subtotal'         => self::money( 40.5, $cur ),
			'discount'         => self::money( 4.05, $cur ),
			'shipping_total'   => self::money( 5.0, $cur ),
			'fees'             => '',
			'tax'              => self::money( 3.68, $cur ),
			'total'            => self::money( 41.45, $cur ),
			'item_count'       => '6',
			'coupons'          => 'WELCOME10',
			'order_url'        => home_url( '/?sample-order=1042' ),
			'admin_url'        => admin_url( 'post.php?post=1042&action=edit' ),
			'print_time'       => wp_date( 'Y-m-d H:i' ),
		);
		return array(
			'vars'    => $vars,
			'items'   => $items,
			'meta_cb' => function ( $key ) {
				return 'sample ' . $key;
			},
		);
	}

	/**
	 * Keep only items in the given product categories.
	 *
	 * @param array $ctx  Context.
	 * @param int[] $cats Category IDs.
	 * @return array
	 */
	public static function filter_items( $ctx, $cats ) {
		$cats = array_map( 'intval', (array) $cats );
		if ( ! $cats ) {
			return $ctx;
		}
		$keep = array();
		foreach ( $ctx['items'] as $it ) {
			if ( ! empty( $it['cats'] ) && array_intersect( $cats, $it['cats'] ) ) {
				$keep[] = $it;
			}
		}
		$ctx['items'] = $keep;
		return $ctx;
	}

	/**
	 * Replace {placeholders} in a string.
	 *
	 * @param string $str Template text.
	 * @param array  $ctx Context.
	 * @return string
	 */
	protected static function substitute( $str, $ctx ) {
		return preg_replace_callback(
			'/\{([a-z0-9_]+(?::[A-Za-z0-9_\-\.]+)?)\}/',
			function ( $m ) use ( $ctx ) {
				$k = $m[1];
				if ( 0 === strpos( $k, 'meta:' ) ) {
					return isset( $ctx['meta_cb'] ) && is_callable( $ctx['meta_cb'] ) ? (string) call_user_func( $ctx['meta_cb'], substr( $k, 5 ) ) : '';
				}
				return isset( $ctx['vars'][ $k ] ) ? (string) $ctx['vars'][ $k ] : '';
			},
			$str
		);
	}

	/**
	 * Value of a placeholder (for [?name] conditions).
	 *
	 * @param string $name Name.
	 * @param array  $ctx  Context.
	 * @return string
	 */
	protected static function var_value( $name, $ctx ) {
		return trim( self::substitute( '{' . $name . '}', $ctx ) );
	}

	/**
	 * Columns for a paper width.
	 *
	 * @param string $paper 58, 80 or a4.
	 * @return int
	 */
	public static function columns( $paper ) {
		return '58' === (string) $paper ? 32 : 48;
	}

	/**
	 * Parse a template into a document.
	 *
	 * @param array $ctx      Context.
	 * @param array $template Template record.
	 * @param array $printer  Printer record.
	 * @return array
	 */
	public static function build_doc( $ctx, $template, $printer ) {
		$paper = isset( $printer['paper'] ) ? (string) $printer['paper'] : '80';
		$doc   = array(
			'v'     => 1,
			'paper' => $paper,
			'cols'  => self::columns( $paper ),
			'cp'    => isset( $printer['codepage'] ) ? $printer['codepage'] : 'cp437',
			'cut'   => isset( $printer['cut'] ) ? $printer['cut'] : 'partial',
			'ops'   => array(),
		);
		$body  = isset( $template['body'] ) ? (string) $template['body'] : '';
		$has_cut    = false;
		$has_drawer = false;

		foreach ( explode( "\n", $body ) as $line ) {
			$line  = rtrim( $line );
			$style = array(
				'a' => 'l',
				'b' => 0,
				'u' => 0,
				'w' => 1,
				'h' => 1,
			);
			$explicit_align = false;
			$conds          = array();
			$rest           = $line;
			while ( preg_match( '/^\[(c|l|r|b|u|big|wide|tall|\?[a-z0-9_:\-\.]+)\]/i', $rest, $m ) ) {
				$tag = strtolower( $m[1] );
				switch ( $tag ) {
					case 'c':
					case 'l':
					case 'r':
						$style['a']     = $tag;
						$explicit_align = true;
						break;
					case 'b':
						$style['b'] = 1;
						break;
					case 'u':
						$style['u'] = 1;
						break;
					case 'big':
						$style['w'] = 2;
						$style['h'] = 2;
						break;
					case 'wide':
						$style['w'] = 2;
						break;
					case 'tall':
						$style['h'] = 2;
						break;
					default:
						$conds[] = substr( $m[1], 1 );
						break;
				}
				$rest = substr( $rest, strlen( $m[0] ) );
			}
			foreach ( $conds as $c ) {
				if ( '' === self::var_value( $c, $ctx ) ) {
					continue 2;
				}
			}

			if ( preg_match( '/^\[hr(?:=(.))?\]\s*$/i', $rest, $m ) ) {
				$doc['ops'][] = array(
					'op' => 'hr',
					'ch' => isset( $m[1] ) ? $m[1] : '-',
				);
				continue;
			}
			if ( preg_match( '/^\[feed(?:=(\d+))?\]\s*$/i', $rest, $m ) ) {
				$doc['ops'][] = array(
					'op' => 'feed',
					'n'  => isset( $m[1] ) ? min( 10, (int) $m[1] ) : 1,
				);
				continue;
			}
			if ( preg_match( '/^\[cut\]\s*$/i', $rest ) ) {
				$has_cut      = true;
				$doc['ops'][] = array( 'op' => 'cut' );
				continue;
			}
			if ( preg_match( '/^\[drawer\]\s*$/i', $rest ) ) {
				$has_drawer   = true;
				$doc['ops'][] = array( 'op' => 'drawer' );
				continue;
			}
			if ( preg_match( '/^\[qr(?:=(\d+))?\](.*)$/i', $rest, $m ) ) {
				$data = trim( self::substitute( $m[2], $ctx ) );
				if ( '' !== $data ) {
					$doc['ops'][] = array(
						'op'   => 'qr',
						's'    => $data,
						'size' => isset( $m[1] ) && '' !== $m[1] ? min( 16, max( 1, (int) $m[1] ) ) : 6,
						'a'    => $explicit_align ? $style['a'] : 'c',
					);
				}
				continue;
			}
			if ( preg_match( '/^\[lr\](.*)$/i', $rest, $m ) ) {
				$parts = explode( '||', self::substitute( $m[1], $ctx ), 2 );
				$left  = trim( str_replace( "\n", ' ', $parts[0] ) );
				$right = isset( $parts[1] ) ? trim( str_replace( "\n", ' ', $parts[1] ) ) : '';
				$doc['ops'][] = array(
					'op' => 'lr',
					'l'  => $left,
					'r'  => $right,
					'b'  => $style['b'],
					'u'  => $style['u'],
					'w'  => $style['w'],
					'h'  => $style['h'],
				);
				continue;
			}
			if ( '{items}' === trim( $rest ) ) {
				self::expand_items( $doc, $ctx, $template, $style );
				continue;
			}
			$text = self::substitute( $rest, $ctx );
			foreach ( explode( "\n", $text ) as $sub ) {
				$doc['ops'][] = array(
					'op' => 'text',
					's'  => rtrim( $sub ),
					'a'  => $style['a'],
					'b'  => $style['b'],
					'u'  => $style['u'],
					'w'  => $style['w'],
					'h'  => $style['h'],
				);
			}
		}

		if ( ! empty( $printer['drawer'] ) && ! $has_drawer && 'kitchen' !== ( isset( $template['type'] ) ? $template['type'] : '' ) ) {
			// Kick before the cut so the drawer opens when the receipt comes out.
			$pos = count( $doc['ops'] );
			if ( $has_cut ) {
				$pos = null;
				foreach ( $doc['ops'] as $i => $op ) {
					if ( 'cut' === $op['op'] ) {
						$pos = $i;
					}
				}
			}
			array_splice( $doc['ops'], (int) $pos, 0, array( array( 'op' => 'drawer' ) ) );
		}
		if ( ! $has_cut ) {
			$doc['ops'][] = array( 'op' => 'cut' );
		}
		return apply_filters( 'printpilot_doc', $doc, $ctx, $template, $printer );
	}

	/**
	 * Expand {items} into document operations.
	 *
	 * @param array $doc      Document (by reference).
	 * @param array $ctx      Context.
	 * @param array $template Template.
	 * @param array $style    Line style.
	 * @return void
	 */
	protected static function expand_items( &$doc, $ctx, $template, $style ) {
		$size   = isset( $template['item_size'] ) ? (int) $template['item_size'] : 1;
		$w      = 1;
		$h      = 1;
		if ( 2 === $size ) {
			$h = 2;
		} elseif ( $size >= 3 ) {
			$w = 2;
			$h = 2;
		}
		if ( $style['w'] > 1 || $style['h'] > 1 ) {
			$w = $style['w'];
			$h = $style['h'];
		}
		$prices = ! empty( $template['show_prices'] );
		$sku    = ! empty( $template['show_sku'] );
		$meta   = ! empty( $template['show_meta'] );
		foreach ( $ctx['items'] as $it ) {
			$label = $it['qty'] . ' x ' . $it['name'];
			if ( $sku && '' !== $it['sku'] ) {
				$label .= ' [' . $it['sku'] . ']';
			}
			if ( $prices ) {
				$doc['ops'][] = array(
					'op' => 'lr',
					'l'  => $label,
					'r'  => $it['total'],
					'b'  => $style['b'] ? 1 : ( $size > 1 ? 1 : 0 ),
					'u'  => $style['u'],
					'w'  => $w,
					'h'  => $h,
				);
			} else {
				$doc['ops'][] = array(
					'op' => 'text',
					's'  => $label,
					'a'  => $style['a'],
					'b'  => $style['b'] ? 1 : ( $size > 1 ? 1 : 0 ),
					'u'  => $style['u'],
					'w'  => $w,
					'h'  => $h,
				);
			}
			if ( $meta ) {
				foreach ( $it['meta'] as $m ) {
					$doc['ops'][] = array(
						'op' => 'text',
						's'  => '   ' . $m,
						'a'  => 'l',
						'b'  => 0,
						'u'  => 0,
						'w'  => 1,
						'h'  => 1,
					);
				}
			}
		}
	}

	/**
	 * Build the document for a job (real or test).
	 *
	 * @param object $job Job row.
	 * @return array|WP_Error
	 */
	public static function doc_for_job( $job ) {
		$printer  = PrintPilot_Settings::printer( $job->printer_id );
		$template = PrintPilot_Settings::template( $job->template_id );
		if ( ! $printer ) {
			return new WP_Error( 'pp_no_printer', __( 'Printer no longer exists.', 'printpilot' ) );
		}
		if ( ! $template ) {
			return new WP_Error( 'pp_no_template', __( 'Template no longer exists.', 'printpilot' ) );
		}
		$meta = PrintPilot_Jobs::meta( $job );
		if ( (int) $job->order_id > 0 ) {
			$order = wc_get_order( (int) $job->order_id );
			if ( ! $order ) {
				return new WP_Error( 'pp_no_order', __( 'Order not found.', 'printpilot' ) );
			}
			$ctx = self::context_from_order( $order );
		} else {
			$ctx = self::sample_context();
		}
		if ( ! empty( $meta['cats'] ) ) {
			$ctx = self::filter_items( $ctx, $meta['cats'] );
		}
		$ctx['vars']['printer_name'] = self::clean( $printer['name'] );
		if ( ! empty( $meta['test'] ) ) {
			$ctx['vars']['notes'] = __( 'TEST PRINT – this is sample data.', 'printpilot' );
		}
		return self::build_doc( $ctx, $template, $printer );
	}

	/**
	 * Document to HTML fragment.
	 *
	 * @param array $doc Document.
	 * @return string
	 */
	public static function render_html( $doc ) {
		$paper = isset( $doc['paper'] ) ? (string) $doc['paper'] : '80';
		$cls   = 'pp-w' . ( in_array( $paper, array( '58', '80', 'a4' ), true ) ? $paper : '80' );
		$out   = '<div class="pp-ticket ' . esc_attr( $cls ) . '">';
		$al    = array(
			'l' => '',
			'c' => ' pp-c',
			'r' => ' pp-r',
		);
		foreach ( $doc['ops'] as $op ) {
			switch ( $op['op'] ) {
				case 'text':
					$size = max( (int) $op['w'], (int) $op['h'] );
					$out .= '<div class="pp-l' . ( isset( $al[ $op['a'] ] ) ? $al[ $op['a'] ] : '' ) . ( ! empty( $op['b'] ) ? ' pp-b' : '' ) . ( ! empty( $op['u'] ) ? ' pp-u' : '' ) . '"' . ( $size > 1 ? ' style="font-size:' . (int) $size . 'em"' : '' ) . '>' . ( '' === $op['s'] ? '&nbsp;' : esc_html( $op['s'] ) ) . '</div>';
					break;
				case 'lr':
					$size = max( (int) $op['w'], (int) $op['h'] );
					$out .= '<div class="pp-lr' . ( ! empty( $op['b'] ) ? ' pp-b' : '' ) . ( ! empty( $op['u'] ) ? ' pp-u' : '' ) . '"' . ( $size > 1 ? ' style="font-size:' . (int) $size . 'em"' : '' ) . '><span>' . esc_html( $op['l'] ) . '</span><span>' . esc_html( $op['r'] ) . '</span></div>';
					break;
				case 'hr':
					$out .= '<div class="pp-hr' . ( isset( $op['ch'] ) && '=' === $op['ch'] ? ' pp-hr2' : '' ) . '"></div>';
					break;
				case 'feed':
					$out .= '<div class="pp-feed" style="height:' . (int) $op['n'] . 'em"></div>';
					break;
				case 'qr':
					$out .= '<div class="pp-qr" data-qr="' . esc_attr( $op['s'] ) . '" data-size="' . (int) ( 20 * $op['size'] ) . '"><span class="pp-qrt">' . esc_html( $op['s'] ) . '</span></div>';
					break;
				case 'cut':
					$out .= '<div class="pp-cut"></div>';
					break;
				default:
					break;
			}
		}
		return $out . '</div>';
	}

	/**
	 * Stylesheet for tickets.
	 *
	 * @param string $paper Paper key.
	 * @return string
	 */
	public static function css( $paper = '80' ) {
		$size = 'a4' === $paper ? 'A4' : ( '58' === $paper ? '58mm auto' : '80mm auto' );
		return '@page{size:' . $size . ';margin:0}'
			. '.pp-ticket{font:12px/1.35 "Courier New",Courier,monospace;color:#000;background:#fff;margin:0 auto;padding:2mm 0;box-sizing:border-box;overflow-wrap:anywhere}'
			. '.pp-w80{width:72mm}.pp-w58{width:48mm}.pp-wa4{width:180mm;font-size:14px}'
			. '.pp-l{white-space:pre-wrap}.pp-c{text-align:center}.pp-r{text-align:right}.pp-b{font-weight:700}.pp-u{text-decoration:underline}'
			. '.pp-lr{display:flex;justify-content:space-between;gap:1ch}.pp-lr span:first-child{white-space:pre-wrap;flex:1 1 auto}.pp-lr span:last-child{white-space:nowrap;text-align:right}'
			. '.pp-hr{border-top:1px dashed #000;margin:.45em 0;height:0}.pp-hr2{border-top:3px double #000}'
			. '.pp-qr{text-align:center;margin:.5em 0}.pp-qr svg{display:inline-block;max-width:100%;height:auto}.pp-qrt{font-size:.8em;word-break:break-all}'
			. '.pp-cut{border-top:1px dotted #888;margin:1.2em 0 0;height:0}'
			. '@media print{.pp-cut{display:none}}';
	}

	/**
	 * Complete standalone HTML page for a document.
	 *
	 * @param array  $doc        Document.
	 * @param string $title      Title.
	 * @param bool   $autoprint  Auto-print on load (manual browser print view).
	 * @param bool   $scripts    Include the QR script (false when the caller hydrates QR codes itself).
	 * @return string
	 */
	public static function html_document( $doc, $title = '', $autoprint = false, $scripts = true ) {
		$paper = isset( $doc['paper'] ) ? (string) $doc['paper'] : '80';
		$h     = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
		$h    .= '<title>' . esc_html( $title ) . '</title><style>body{margin:0;background:#fff}' . self::css( $paper ) . '</style></head><body>';
		$h    .= self::render_html( $doc );
		if ( ! $scripts ) {
			return $h . '</body></html>';
		}
		$h    .= '<script src="' . esc_url( PP_URL . 'assets/js/pp-qr.js?ver=' . PP_VERSION ) . '"></script>';
		$h    .= '<script>(function(){if(window.PPQR){PPQR.hydrate(document);}' . ( $autoprint ? 'setTimeout(function(){window.print();},350);' : '' ) . '})();</script>';
		return $h . '</body></html>';
	}

	/**
	 * Plain-text rendering of a document (used for email alternative bodies and debugging).
	 *
	 * @param array $doc Document.
	 * @return string
	 */
	public static function doc_to_text( $doc ) {
		$cols  = isset( $doc['cols'] ) ? (int) $doc['cols'] : 48;
		$cp    = 'ascii';
		$lines = array();
		foreach ( $doc['ops'] as $op ) {
			switch ( $op['op'] ) {
				case 'text':
					$w = max( 1, (int) floor( $cols / max( 1, (int) $op['w'] ) ) );
					foreach ( PrintPilot_ESCPOS::wrap( $op['s'], $w, $cp ) as $l ) {
						if ( 'c' === $op['a'] ) {
							$l = str_repeat( ' ', max( 0, (int) floor( ( $w - strlen( $l ) ) / 2 ) ) ) . $l;
						} elseif ( 'r' === $op['a'] ) {
							$l = str_repeat( ' ', max( 0, $w - strlen( $l ) ) ) . $l;
						}
						$lines[] = $l;
					}
					break;
				case 'lr':
					$lines[] = $op['l'] . ( '' !== $op['r'] ? '  ' . $op['r'] : '' );
					break;
				case 'hr':
					$lines[] = str_repeat( isset( $op['ch'] ) ? $op['ch'] : '-', $cols );
					break;
				case 'qr':
					$lines[] = '[QR] ' . $op['s'];
					break;
				case 'feed':
					$lines[] = '';
					break;
				default:
					break;
			}
		}
		return implode( "\n", $lines ) . "\n";
	}
}
