<?php
/**
 * Activation, database table, defaults and cron.
 *
 * @package PrintPilot
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Installer.
 */
class PrintPilot_Install {

	/**
	 * Jobs table name.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'pp_jobs';
	}

	/**
	 * Activation callback.
	 *
	 * @return void
	 */
	public static function activate() {
		self::create_table();
		self::seed_defaults();
		self::schedule();
		update_option( 'pp_db_version', PP_DB_VERSION );
	}

	/**
	 * Deactivation callback.
	 *
	 * @return void
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( 'pp_process_queue' );
		wp_clear_scheduled_hook( 'pp_daily_cleanup' );
	}

	/**
	 * Run upgrades when the stored DB version is older.
	 *
	 * @return void
	 */
	public static function maybe_upgrade() {
		if ( get_option( 'pp_db_version' ) !== PP_DB_VERSION ) {
			self::create_table();
			update_option( 'pp_db_version', PP_DB_VERSION );
		}
		if ( ! wp_next_scheduled( 'pp_process_queue' ) ) {
			self::schedule();
		}
	}

	/**
	 * Schedule recurring events.
	 *
	 * @return void
	 */
	public static function schedule() {
		if ( ! wp_next_scheduled( 'pp_process_queue' ) ) {
			wp_schedule_event( time() + 60, 'pp_minute', 'pp_process_queue' );
		}
		if ( ! wp_next_scheduled( 'pp_daily_cleanup' ) ) {
			wp_schedule_event( time() + 3600, 'daily', 'pp_daily_cleanup' );
		}
	}

	/**
	 * Create or update the jobs table.
	 *
	 * @return void
	 */
	public static function create_table() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table   = self::table();
		$charset = $wpdb->get_charset_collate();
		$sql     = "CREATE TABLE {$table} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  order_id bigint(20) unsigned NOT NULL DEFAULT 0,
  printer_id varchar(40) NOT NULL DEFAULT '',
  template_id varchar(40) NOT NULL DEFAULT '',
  method varchar(20) NOT NULL DEFAULT '',
  status varchar(20) NOT NULL DEFAULT 'pending',
  copies tinyint(3) unsigned NOT NULL DEFAULT 1,
  attempts smallint(5) unsigned NOT NULL DEFAULT 0,
  source varchar(60) NOT NULL DEFAULT '',
  station varchar(80) NOT NULL DEFAULT '',
  error text NULL,
  meta longtext NULL,
  created_gmt datetime NOT NULL,
  updated_gmt datetime NOT NULL,
  retry_gmt datetime NULL,
  printed_gmt datetime NULL,
  PRIMARY KEY  (id),
  KEY status_method (status,method),
  KEY order_id (order_id)
) {$charset};";
		dbDelta( $sql );
	}

	/**
	 * Default templates.
	 *
	 * @return array
	 */
	public static function default_templates() {
		$kitchen = implode(
			"\n",
			array(
				'[c][big][b]KITCHEN',
				'[c][big][b]#{order_number}',
				'[c][b]{order_type}',
				'[?delivery_time][c][b]Time: {delivery_time}',
				'[hr]',
				'[b]{customer}',
				'[?customer_phone]{customer_phone}',
				'[hr]',
				'{items}',
				'[hr]',
				'[?notes][b]NOTE:',
				'[?notes][b]{notes}',
				'[?notes][hr]',
				'[c]{order_date} {order_time}',
				'[cut]',
			)
		);
		$receipt = implode(
			
			"\n",
			array(
				'[c][big][b]{site_name}',
				'[c]{site_url}',
				'[hr]',
				'[b]Order #{order_number}',
				'{order_date} {order_time}',
				'[?customer]Customer: {customer}',
				'[?delivery_time]Time: {delivery_time}',
				'[hr]',
				'{items}',
				'[hr]',
				'[lr]Subtotal||{subtotal}',
				'[?discount][lr]Discount||-{discount}',
				'[?shipping_total][lr]Shipping||{shipping_total}',
				'[?fees][lr]Fees||{fees}',
				'[?tax][lr]Tax||{tax}',
				'[b][lr]TOTAL||{total}',
				'[hr]',
				'Paid by: {payment_method}',
				'[?notes]Note: {notes}',
				'[feed=1]',
				'[c]Thank you!',
				'[qr=5]{order_url}',
				'[drawer]',
				'[cut]',
			)
		);
		$packing = implode(
			"\n",
			array(
				'[c][big][b]PACKING SLIP',
				'[c][b]Order #{order_number}',
				'[c]{order_date}',
				'[hr]',
				'[b]Ship to:',
				'{shipping_address}',
				'[?customer_phone]Tel: {customer_phone}',
				'[b]Method: {shipping_method}',
				'[hr]',
				'{items}',
				'[hr]',
				'[?notes][b]Customer note:',
				'[?notes]{notes}',
				'[?notes][hr]',
				'[c][qr=5]{order_number}',
				'[cut]',
			)
		);
		return array(
			'tkitchen' => array(
				'id'          => 'tkitchen',
				'name'        => __( 'Kitchen ticket', 'printpilot' ),
				'type'        => 'kitchen',
				'body'        => $kitchen,
				'show_prices' => 0,
				'show_sku'    => 0,
				'show_meta'   => 1,
				'item_size'   => 2,
			),
			'treceipt' => array(
				'id'          => 'treceipt',
				'name'        => __( 'Customer receipt', 'printpilot' ),
				'type'        => 'receipt',
				'body'        => $receipt,
				'show_prices' => 1,
				'show_sku'    => 0,
				'show_meta'   => 1,
				'item_size'   => 1,
			),
			'tpacking' => array(
				'id'          => 'tpacking',
				'name'        => __( 'Packing slip', 'printpilot' ),
				'type'        => 'packing',
				'body'        => $packing,
				'show_prices' => 0,
				'show_sku'    => 1,
				'show_meta'   => 1,
				'item_size'   => 1,
			),
		);
	}

	/**
	 * Create default printers, templates and rule on first run.
	 *
	 * @return void
	 */
	public static function seed_defaults() {
		if ( false === get_option( PrintPilot_Settings::OPT_TEMPLATES, false ) ) {
			update_option( PrintPilot_Settings::OPT_TEMPLATES, self::default_templates(), false );
		}
		if ( false === get_option( PrintPilot_Settings::OPT_PRINTERS, false ) ) {
			$def               = PrintPilot_Settings::printer_defaults();
			$def['id']         = 'pstation';
			$def['name']       = __( 'Print Station (browser)', 'printpilot' );
			$def['method']     = 'station_html';
			update_option( PrintPilot_Settings::OPT_PRINTERS, array( 'pstation' => $def ), false );
		}
		if ( false === get_option( PrintPilot_Settings::OPT_RULES, false ) ) {
			update_option(
				PrintPilot_Settings::OPT_RULES,
				array(
					array(
						'id'               => 'rdefault',
						'name'             => __( 'All new paid orders – kitchen ticket', 'printpilot' ),
						'enabled'          => 1,
						'statuses'         => array( 'processing' ),
						'categories'       => array(),
						'shipping_methods' => array(),
						'payment_methods'  => array(),
						'order_type'       => 'any',
						'meta_key'         => '',
						'meta_value'       => '',
						'printer'          => 'pstation',
						'template'         => 'tkitchen',
						'copies'           => 1,
						'split_items'      => 0,
						'stop'             => 0,
					),
				),
				false
			);
		}
		$s = PrintPilot_Settings::get();
		if ( empty( $s['default_printer'] ) ) {
			PrintPilot_Settings::save(
				array(
					'default_printer'  => 'pstation',
					'default_template' => 'treceipt',
				)
			);
		}
		PrintPilot_Settings::token();
	}
}
