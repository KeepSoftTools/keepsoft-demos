<?php
/**
 * Print Station kiosk page (admin and tokenised frontend URL).
 *
 * @package PrintPilot
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Print Station.
 */
class PrintPilot_Station {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'maybe_render_admin' ), 1 );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_render_frontend' ), 1 );
	}

	/**
	 * Tablet URL containing the secret token.
	 *
	 * @param array $args Optional extra args: printers (array of IDs), name.
	 * @return string
	 */
	public static function token_url( $args = array() ) {
		$q = array( 'printpilot-station' => PrintPilot_Settings::token() );
		if ( ! empty( $args['printers'] ) ) {
			$q['printers'] = implode( ',', array_map( 'sanitize_key', (array) $args['printers'] ) );
		}
		if ( ! empty( $args['name'] ) ) {
			$q['name'] = sanitize_text_field( $args['name'] );
		}
		return add_query_arg( rawurlencode_deep( $q ), home_url( '/' ) );
	}

	/**
	 * Admin URL of the station.
	 *
	 * @return string
	 */
	public static function admin_url() {
		return admin_url( 'admin.php?page=printpilot-station' );
	}

	/**
	 * Standalone station inside wp-admin (no admin chrome).
	 *
	 * @return void
	 */
	public static function maybe_render_admin() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $_GET['page'] ) || 'printpilot-station' !== sanitize_key( wp_unslash( $_GET['page'] ) ) ) {
			return;
		}
		if ( ! current_user_can( PrintPilot_Settings::capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to use the Print Station.', 'printpilot' ), '', array( 'response' => 403 ) );
		}
		self::render( 'admin' );
		exit;
	}

	/**
	 * Station on a front-end URL protected by the token.
	 *
	 * @return void
	 */
	public static function maybe_render_frontend() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $_GET['printpilot-station'] ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$given = sanitize_text_field( wp_unslash( $_GET['printpilot-station'] ) );
		if ( ! hash_equals( PrintPilot_Settings::token(), $given ) ) {
			wp_die( esc_html__( 'Invalid or expired Print Station link.', 'printpilot' ), '', array( 'response' => 403 ) );
		}
		self::render( 'token', $given );
		exit;
	}

	/**
	 * Strings for the JavaScript app.
	 *
	 * @return array
	 */
	protected static function i18n() {
		return array(
			'connected'      => __( 'Connected', 'printpilot' ),
			'offline'        => __( 'Offline – retrying…', 'printpilot' ),
			'connecting'     => __( 'Connecting…', 'printpilot' ),
			'expired'        => __( 'Session expired – reload this page.', 'printpilot' ),
			'lastSeen'       => __( 'Last update', 'printpilot' ),
			'noJobs'         => __( 'No print jobs yet. New orders appear here automatically.', 'printpilot' ),
			'noOrders'       => __( 'No orders waiting for acceptance.', 'printpilot' ),
			'accept'         => __( 'Accept order', 'printpilot' ),
			'accepted'       => __( 'Accepted', 'printpilot' ),
			'reprint'        => __( 'Reprint', 'printpilot' ),
			'order'          => __( 'Order', 'printpilot' ),
			'test'           => __( 'Test', 'printpilot' ),
			'testPrint'      => __( 'Test print', 'printpilot' ),
			'connect'        => __( 'Connect printer', 'printpilot' ),
			'reconnect'      => __( 'Reconnect', 'printpilot' ),
			'forget'         => __( 'Forget', 'printpilot' ),
			'printerReady'   => __( 'Connected', 'printpilot' ),
			'printerNot'     => __( 'Not connected', 'printpilot' ),
			'browserPrint'   => __( 'Browser print (window.print)', 'printpilot' ),
			'unsupported'    => __( 'This browser does not support this connection type. Use Chrome or Edge.', 'printpilot' ),
			'soundOn'        => __( 'Sound on', 'printpilot' ),
			'soundOff'       => __( 'Sound off', 'printpilot' ),
			'paused'         => __( 'Printing paused', 'printpilot' ),
			'autoOn'         => __( 'Auto-print on', 'printpilot' ),
			'fullscreen'     => __( 'Fullscreen', 'printpilot' ),
			'pending'        => __( 'Pending', 'printpilot' ),
			'printing'       => __( 'Printing', 'printpilot' ),
			'printed'        => __( 'Printed', 'printpilot' ),
			'failed'         => __( 'Failed', 'printpilot' ),
			'cancelled'      => __( 'Cancelled', 'printpilot' ),
			'newOrder'       => __( 'New print job', 'printpilot' ),
			'printError'     => __( 'Print error', 'printpilot' ),
			'connectedTo'    => __( 'Printer connected', 'printpilot' ),
			'secsAgo'        => __( 's ago', 'printpilot' ),
			'minsAgo'        => __( 'm ago', 'printpilot' ),
			'hrsAgo'         => __( 'h ago', 'printpilot' ),
			'now'            => __( 'just now', 'printpilot' ),
			'noPrinters'     => __( 'No station printers configured. Add one under PrintPilot > Printers.', 'printpilot' ),
			'serial'         => __( 'USB / Serial', 'printpilot' ),
			'usb'            => __( 'WebUSB', 'printpilot' ),
			'bluetooth'      => __( 'Bluetooth', 'printpilot' ),
			'queuedTest'     => __( 'Test ticket queued.', 'printpilot' ),
			'wakeLock'       => __( 'Screen will stay awake.', 'printpilot' ),
			'hintSilent'     => __( 'Tip: to print without the print dialog, start Chrome with --kiosk-printing (see the documentation).', 'printpilot' ),
			'notConnected'   => __( 'Printer is not connected. Tap "Connect printer" on the Print Station.', 'printpilot' ),
			'noDevice'       => __( 'No device selected.', 'printpilot' ),
		);
	}

	/**
	 * Output the station document.
	 *
	 * @param string $mode  admin|token.
	 * @param string $token Token (token mode).
	 * @return void
	 */
	public static function render( $mode, $token = '' ) {
		status_header( 200 );
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		header( 'X-Robots-Tag: noindex, nofollow' );
		header( 'Referrer-Policy: no-referrer' );

		$s       = PrintPilot_Settings::get();
		$printers = array();
		foreach ( PrintPilot_Settings::printers() as $p ) {
			if ( empty( $p['enabled'] ) || ! in_array( $p['method'], array( 'station_html', 'station_escpos' ), true ) ) {
				continue;
			}
			$printers[] = array(
				'id'         => $p['id'],
				'name'       => $p['name'],
				'method'     => $p['method'],
				'connection' => $p['connection'],
				'baud'       => (int) $p['baud'],
				'paper'      => $p['paper'],
			);
		}
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$only = array();
		if ( ! empty( $_GET['printers'] ) ) {
			$only = array_values( array_filter( array_map( 'sanitize_key', explode( ',', sanitize_text_field( wp_unslash( $_GET['printers'] ) ) ) ) ) );
		}
		$name = ! empty( $_GET['name'] ) ? sanitize_text_field( wp_unslash( $_GET['name'] ) ) : '';
		// phpcs:enable
		if ( '' === $name ) {
			$name = 'admin' === $mode ? __( 'Print Station', 'printpilot' ) : __( 'Tablet', 'printpilot' );
		}
		$cfg = array(
			'rest'        => esc_url_raw( rest_url( PrintPilot_REST::NS . '/' ) ),
			'auth'        => 'admin' === $mode ? 'nonce' : 'token',
			'nonce'       => 'admin' === $mode ? wp_create_nonce( 'wp_rest' ) : '',
			'token'       => 'token' === $mode ? $token : '',
			'interval'    => (int) $s['poll_interval'],
			'sound'       => (bool) $s['sound'],
			'repeatAlarm' => (bool) $s['repeat_alarm'],
			'station'     => $name,
			'only'        => $only,
			'printers'    => $printers,
			'acceptTo'    => $s['accept_to'],
			'i18n'        => self::i18n(),
		);
		$ver = PP_VERSION;
		?>
<!doctype html>
<html lang="<?php echo esc_attr( get_bloginfo( 'language' ) ); ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex,nofollow">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<title><?php echo esc_html( $name . ' – ' . get_bloginfo( 'name' ) ); ?></title>
<link rel="stylesheet" href="<?php echo esc_url( PP_URL . 'assets/css/station.css?ver=' . $ver ); ?>">
</head>
<body class="ps-body">
<header class="ps-top">
	<div class="ps-brand">
		<svg viewBox="0 0 24 24" width="26" height="26" aria-hidden="true"><path fill="currentColor" d="M7 3h10v4H7V3Zm-3 5h16a2 2 0 0 1 2 2v6h-4v-3H6v3H2v-6a2 2 0 0 1 2-2Zm4 6h8v7H8v-7Zm2 2v3h4v-3h-4Z"/></svg>
		<div><strong><?php esc_html_e( 'Print Station', 'printpilot' ); ?></strong><span id="ps-name" class="ps-sub"></span></div>
	</div>
	<div class="ps-conn" role="status" aria-live="polite"><span class="ps-dot" id="ps-dot"></span><span id="ps-conn"><?php esc_html_e( 'Connecting…', 'printpilot' ); ?></span><small id="ps-last"></small></div>
	<div class="ps-stats">
		<span><?php esc_html_e( 'Pending', 'printpilot' ); ?> <b id="ps-pend">0</b></span>
		<span><?php esc_html_e( 'Printed today', 'printpilot' ); ?> <b id="ps-today">0</b></span>
		<span><?php esc_html_e( 'Failed', 'printpilot' ); ?> <b id="ps-failed">0</b></span>
	</div>
	<div class="ps-actions">
		<button type="button" class="ps-btn" id="ps-btn-sound"></button>
		<button type="button" class="ps-btn" id="ps-btn-auto"></button>
		<button type="button" class="ps-btn" id="ps-btn-full"><?php esc_html_e( 'Fullscreen', 'printpilot' ); ?></button>
	</div>
</header>
<main class="ps-main">
	<section class="ps-col" aria-labelledby="ps-h-orders">
		<h2 id="ps-h-orders"><?php esc_html_e( 'Orders to accept', 'printpilot' ); ?> <span class="ps-count" id="ps-orders-count">0</span></h2>
		<div id="ps-orders" class="ps-list"></div>
	</section>
	<section class="ps-col ps-col-wide" aria-labelledby="ps-h-queue">
		<h2 id="ps-h-queue"><?php esc_html_e( 'Print queue', 'printpilot' ); ?></h2>
		<div id="ps-queue" class="ps-list"></div>
	</section>
	<section class="ps-col" aria-labelledby="ps-h-printers">
		<h2 id="ps-h-printers"><?php esc_html_e( 'Printers', 'printpilot' ); ?></h2>
		<div id="ps-printers" class="ps-list"></div>
		<p class="ps-hint" id="ps-hint"></p>
	</section>
</main>
<div id="ps-start" class="ps-start" role="dialog" aria-modal="true" aria-labelledby="ps-start-title">
	<div class="ps-start-box">
		<h1 id="ps-start-title"><?php esc_html_e( 'Print Station', 'printpilot' ); ?></h1>
		<p><?php esc_html_e( 'Tap start to enable sound alerts and keep the screen awake. Leave this page open to print new orders automatically.', 'printpilot' ); ?></p>
		<button type="button" class="ps-btn ps-btn-primary" id="ps-start-btn"><?php esc_html_e( 'Start', 'printpilot' ); ?></button>
	</div>
</div>
<div id="ps-toast" class="ps-toast" role="alert" aria-live="assertive"></div>
<script type="application/json" id="pp-config"><?php echo wp_json_encode( $cfg, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></script>
<script src="<?php echo esc_url( PP_URL . 'assets/js/pp-qr.js?ver=' . $ver ); ?>"></script>
<script src="<?php echo esc_url( PP_URL . 'assets/js/pp-escpos.js?ver=' . $ver ); ?>"></script>
<script src="<?php echo esc_url( PP_URL . 'assets/js/station.js?ver=' . $ver ); ?>"></script>
</body>
</html>
		<?php
	}
}
