<?php
/**
 * Admin screens, order list bulk action and order metabox.
 *
 * @package PrintPilot
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin UI.
 */
class PrintPilot_Admin {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notices' ) );

		$actions = array(
			'pp_save_printers'  => 'save_printers',
			'pp_save_templates' => 'save_templates',
			'pp_save_rules'     => 'save_rules',
			'pp_save_settings'  => 'save_settings',
			'pp_test_print'     => 'test_print',
			'pp_job_action'     => 'job_action',
			'pp_regen_token'    => 'regen_token',
			'pp_view_ticket'    => 'view_ticket',
		);
		foreach ( $actions as $action => $method ) {
			add_action( 'admin_post_' . $action, array( __CLASS__, $method ) );
		}

		// Order list bulk action (legacy posts screen and HPOS screen).
		add_filter( 'bulk_actions-edit-shop_order', array( __CLASS__, 'bulk_actions' ) );
		add_filter( 'bulk_actions-woocommerce_page_wc-orders', array( __CLASS__, 'bulk_actions' ) );
		add_filter( 'handle_bulk_actions-edit-shop_order', array( __CLASS__, 'handle_bulk' ), 10, 3 );
		add_filter( 'handle_bulk_actions-woocommerce_page_wc-orders', array( __CLASS__, 'handle_bulk' ), 10, 3 );

		// Order screen.
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_metabox' ), 20, 2 );
		add_filter( 'woocommerce_order_actions', array( __CLASS__, 'order_actions' ) );
		add_action( 'woocommerce_order_action_pp_print', array( __CLASS__, 'handle_order_action' ) );
	}

	/**
	 * Admin tabs.
	 *
	 * @return array<string,string>
	 */
	protected static function tabs() {
		return array(
			'overview'  => __( 'Overview', 'printpilot' ),
			'printers'  => __( 'Printers', 'printpilot' ),
			'templates' => __( 'Templates', 'printpilot' ),
			'rules'     => __( 'Routing rules', 'printpilot' ),
			'log'       => __( 'Print log', 'printpilot' ),
			'settings'  => __( 'Settings', 'printpilot' ),
		);
	}

	/**
	 * Admin menu.
	 *
	 * @return void
	 */
	public static function menu() {
		$cap = PrintPilot_Settings::capability();
		add_menu_page(
			__( 'PrintPilot', 'printpilot' ),
			__( 'PrintPilot', 'printpilot' ),
			$cap,
			'printpilot',
			array( __CLASS__, 'render_page' ),
			'dashicons-printer',
			56
		);
		add_submenu_page( 'printpilot', __( 'PrintPilot', 'printpilot' ), __( 'Settings', 'printpilot' ), $cap, 'printpilot', array( __CLASS__, 'render_page' ) );
		add_submenu_page( 'printpilot', __( 'Print Station', 'printpilot' ), __( 'Print Station', 'printpilot' ), $cap, 'printpilot-station', '__return_null' );
	}

	/**
	 * Is the current screen an order edit or list screen?
	 *
	 * @return bool
	 */
	protected static function is_order_screen() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen ) {
			return false;
		}
		$ids = array( 'shop_order', 'edit-shop_order', 'woocommerce_page_wc-orders' );
		if ( function_exists( 'wc_get_page_screen_id' ) ) {
			$ids[] = wc_get_page_screen_id( 'shop-order' );
		}
		return in_array( $screen->id, $ids, true );
	}

	/**
	 * Enqueue admin assets.
	 *
	 * @param string $hook Hook suffix.
	 * @return void
	 */
	public static function assets( $hook ) {
		$on_plugin = ( false !== strpos( (string) $hook, 'printpilot' ) );
		if ( ! $on_plugin && ! self::is_order_screen() ) {
			return;
		}
		wp_enqueue_style( 'printpilot-admin', PP_URL . 'assets/css/admin.css', array(), PP_VERSION );
		wp_enqueue_script( 'printpilot-qr', PP_URL . 'assets/js/pp-qr.js', array(), PP_VERSION, true );
		wp_enqueue_script( 'printpilot-admin', PP_URL . 'assets/js/admin.js', array( 'printpilot-qr' ), PP_VERSION, true );
		wp_localize_script(
			'printpilot-admin',
			'PPAdmin',
			array(
				'rest'  => esc_url_raw( rest_url( PrintPilot_REST::NS . '/' ) ),
				'nonce' => wp_create_nonce( 'wp_rest' ),
				'i18n'  => array(
					'printing' => __( 'Sending…', 'printpilot' ),
					'queued'   => __( 'Queued', 'printpilot' ),
					'error'    => __( 'Error', 'printpilot' ),
					'copied'   => __( 'Copied', 'printpilot' ),
					'noJobs'   => __( 'No print jobs for this order yet.', 'printpilot' ),
					'confirm'  => __( 'Are you sure?', 'printpilot' ),
					'order'    => __( 'Order', 'printpilot' ),
					'test'     => __( 'Test', 'printpilot' ),
					'pending'  => __( 'Pending', 'printpilot' ),
					'printing_s' => __( 'Printing', 'printpilot' ),
					'printed'  => __( 'Printed', 'printpilot' ),
					'failed'   => __( 'Failed', 'printpilot' ),
					'cancelled' => __( 'Cancelled', 'printpilot' ),
				),
			)
		);
	}

	/* ------------------------------------------------------------------ *
	 * Notices
	 * ------------------------------------------------------------------ */

	/**
	 * Store a one-time message for the current user.
	 *
	 * @param string $msg  Message.
	 * @param string $type success|error|warning|info.
	 * @return void
	 */
	protected static function flash( $msg, $type = 'success' ) {
		set_transient(
			'pp_flash_' . get_current_user_id(),
			array(
				'm' => $msg,
				't' => $type,
			),
			120
		);
	}

	/**
	 * Print stored message.
	 *
	 * @return void
	 */
	public static function notices() {
		$key = 'pp_flash_' . get_current_user_id();
		$f   = get_transient( $key );
		if ( ! $f ) {
			return;
		}
		delete_transient( $key );
		$type = in_array( $f['t'], array( 'success', 'error', 'warning', 'info' ), true ) ? $f['t'] : 'info';
		echo '<div class="notice notice-' . esc_attr( $type ) . ' is-dismissible"><p>' . esc_html( $f['m'] ) . '</p></div>';
	}

	/**
	 * Redirect back to a tab.
	 *
	 * @param string $tab  Tab.
	 * @param array  $args Extra query args.
	 * @return void
	 */
	protected static function back( $tab, $args = array() ) {
		$args = array_merge(
			array(
				'page' => 'printpilot',
				'tab'  => $tab,
			),
			$args
		);
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Common guard for admin-post handlers.
	 *
	 * @param string $nonce_action Nonce action.
	 * @return void
	 */
	protected static function guard( $nonce_action ) {
		if ( ! current_user_can( PrintPilot_Settings::capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'printpilot' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( $nonce_action );
	}

	/* ------------------------------------------------------------------ *
	 * Save handlers
	 * ------------------------------------------------------------------ */

	/**
	 * Save printers.
	 *
	 * @return void
	 */
	public static function save_printers() {
		self::guard( 'pp_save_printers' );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised in sanitize_printers().
		$rows = isset( $_POST['printers'] ) && is_array( $_POST['printers'] ) ? wp_unslash( $_POST['printers'] ) : array();
		update_option( PrintPilot_Settings::OPT_PRINTERS, PrintPilot_Settings::sanitize_printers( wp_slash( $rows ) ), false );
		self::flash( __( 'Printers saved.', 'printpilot' ) );
		self::back( 'printers' );
	}

	/**
	 * Save templates.
	 *
	 * @return void
	 */
	public static function save_templates() {
		self::guard( 'pp_save_templates' );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised in sanitize_templates().
		$rows = isset( $_POST['templates'] ) && is_array( $_POST['templates'] ) ? wp_unslash( $_POST['templates'] ) : array();
		update_option( PrintPilot_Settings::OPT_TEMPLATES, PrintPilot_Settings::sanitize_templates( wp_slash( $rows ) ), false );
		self::flash( __( 'Templates saved.', 'printpilot' ) );
		self::back( 'templates' );
	}

	/**
	 * Save rules.
	 *
	 * @return void
	 */
	public static function save_rules() {
		self::guard( 'pp_save_rules' );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised in sanitize_rules().
		$rows = isset( $_POST['rules'] ) && is_array( $_POST['rules'] ) ? wp_unslash( $_POST['rules'] ) : array();
		update_option( PrintPilot_Settings::OPT_RULES, PrintPilot_Settings::sanitize_rules( wp_slash( $rows ) ), false );
		self::flash( __( 'Routing rules saved.', 'printpilot' ) );
		self::back( 'rules' );
	}

	/**
	 * Save general settings.
	 *
	 * @return void
	 */
	public static function save_settings() {
		self::guard( 'pp_save_settings' );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised in sanitize_settings().
		$in = isset( $_POST['pp'] ) && is_array( $_POST['pp'] ) ? wp_slash( wp_unslash( $_POST['pp'] ) ) : array();
		PrintPilot_Settings::save( PrintPilot_Settings::sanitize_settings( $in ) );
		self::flash( __( 'Settings saved.', 'printpilot' ) );
		self::back( 'settings' );
	}

	/**
	 * Regenerate the station token.
	 *
	 * @return void
	 */
	public static function regen_token() {
		self::guard( 'pp_regen_token' );
		PrintPilot_Settings::regenerate_token();
		self::flash( __( 'New Print Station link generated. Update the link on your tablets.', 'printpilot' ), 'warning' );
		self::back( 'overview' );
	}

	/**
	 * Queue a test print (network/email are sent immediately).
	 *
	 * @return void
	 */
	public static function test_print() {
		self::guard( 'pp_test_print' );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$pid = isset( $_REQUEST['printer'] ) ? sanitize_key( wp_unslash( $_REQUEST['printer'] ) ) : '';
		$id  = PrintPilot_Router::test_print( $pid );
		if ( is_wp_error( $id ) ) {
			self::flash( $id->get_error_message(), 'error' );
			self::back( 'printers' );
		}
		$job = PrintPilot_Jobs::get( $id );
		if ( $job && in_array( $job->method, array( 'network', 'email' ), true ) ) {
			PrintPilot_Jobs::process_job( $id );
			$job = PrintPilot_Jobs::get( $id );
			if ( 'printed' === $job->status ) {
				self::flash( __( 'Test ticket sent to the printer.', 'printpilot' ) );
			} else {
				/* translators: %s: error message */
				self::flash( sprintf( __( 'Test print failed: %s', 'printpilot' ), $job->error ), 'error' );
			}
		} else {
			self::flash( __( 'Test ticket queued. Open the Print Station to print it.', 'printpilot' ), 'info' );
		}
		self::back( 'printers' );
	}

	/**
	 * Job log actions: retry, reprint, delete, clear.
	 *
	 * @return void
	 */
	public static function job_action() {
		self::guard( 'pp_job_action' );
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$do = isset( $_REQUEST['do'] ) ? sanitize_key( wp_unslash( $_REQUEST['do'] ) ) : '';
		$id = isset( $_REQUEST['job'] ) ? absint( $_REQUEST['job'] ) : 0;
		// phpcs:enable
		switch ( $do ) {
			case 'retry':
				PrintPilot_Jobs::retry( $id );
				PrintPilot_Jobs::process_job( $id );
				self::flash( __( 'Job retried.', 'printpilot' ) );
				break;
			case 'reprint':
				$new = PrintPilot_Jobs::reprint( $id, 'reprint:admin' );
				if ( is_wp_error( $new ) ) {
					self::flash( $new->get_error_message(), 'error' );
				} else {
					PrintPilot_Jobs::process_job( (int) $new );
					self::flash( __( 'New print job created.', 'printpilot' ) );
				}
				break;
			case 'delete':
				PrintPilot_Jobs::delete( $id );
				self::flash( __( 'Job deleted.', 'printpilot' ) );
				break;
			case 'cancel':
				PrintPilot_Jobs::update( $id, array( 'status' => 'cancelled' ) );
				self::flash( __( 'Job cancelled.', 'printpilot' ) );
				break;
			case 'clear':
				PrintPilot_Jobs::clear();
				self::flash( __( 'Print log cleared.', 'printpilot' ) );
				break;
			default:
				break;
		}
		self::back( 'log' );
	}

	/**
	 * Show a ticket in the browser for printing / saving as PDF.
	 *
	 * @return void
	 */
	public static function view_ticket() {
		self::guard( 'pp_view_ticket' );
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$job_id   = isset( $_GET['job'] ) ? absint( $_GET['job'] ) : 0;
		$order_id = isset( $_GET['order_id'] ) ? absint( $_GET['order_id'] ) : 0;
		$printer  = isset( $_GET['printer'] ) ? sanitize_key( wp_unslash( $_GET['printer'] ) ) : '';
		$tpl      = isset( $_GET['template'] ) ? sanitize_key( wp_unslash( $_GET['template'] ) ) : '';
		// phpcs:enable
		if ( $job_id ) {
			$job = PrintPilot_Jobs::get( $job_id );
		} else {
			if ( '' === $printer || ! PrintPilot_Settings::printer( $printer ) ) {
				$printer = PrintPilot_Settings::get_one( 'default_printer' );
			}
			if ( '' === $tpl || ! PrintPilot_Settings::template( $tpl ) ) {
				$tpl = PrintPilot_Settings::get_one( 'default_template' );
			}
			$job = (object) array(
				'id'          => 0,
				'order_id'    => $order_id,
				'printer_id'  => $printer,
				'template_id' => $tpl,
				'meta'        => '',
				'copies'      => 1,
			);
		}
		if ( ! $job ) {
			wp_die( esc_html__( 'Job not found.', 'printpilot' ) );
		}
		$doc = PrintPilot_Ticket::doc_for_job( $job );
		if ( is_wp_error( $doc ) ) {
			wp_die( esc_html( $doc->get_error_message() ) );
		}
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		echo PrintPilot_Ticket::html_document( $doc, __( 'Ticket', 'printpilot' ), true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped while building.
		exit;
	}

	/* ------------------------------------------------------------------ *
	 * Order list + order screen
	 * ------------------------------------------------------------------ */

	/**
	 * Add bulk action.
	 *
	 * @param array $actions Actions.
	 * @return array
	 */
	public static function bulk_actions( $actions ) {
		if ( current_user_can( PrintPilot_Settings::capability() ) ) {
			$actions['pp_print'] = __( 'Print (PrintPilot)', 'printpilot' );
		}
		return $actions;
	}

	/**
	 * Handle bulk action.
	 *
	 * @param string $redirect Redirect URL.
	 * @param string $action   Action.
	 * @param array  $ids      Order IDs.
	 * @return string
	 */
	public static function handle_bulk( $redirect, $action, $ids ) {
		if ( 'pp_print' !== $action || ! current_user_can( PrintPilot_Settings::capability() ) ) {
			return $redirect;
		}
		$n = 0;
		foreach ( (array) $ids as $oid ) {
			$order = wc_get_order( absint( $oid ) );
			if ( ! $order ) {
				continue;
			}
			$res = PrintPilot_Router::print_with_rules( $order, 'bulk:' . get_current_user_id() );
			if ( ! is_wp_error( $res ) ) {
				$n += count( $res );
			}
		}
		/* translators: %d: number of jobs */
		self::flash( sprintf( _n( '%d print job created.', '%d print jobs created.', $n, 'printpilot' ), $n ), $n ? 'success' : 'warning' );
		return $redirect;
	}

	/**
	 * Order actions dropdown.
	 *
	 * @param array $actions Actions.
	 * @return array
	 */
	public static function order_actions( $actions ) {
		if ( current_user_can( PrintPilot_Settings::capability() ) ) {
			$actions['pp_print'] = __( 'Print with PrintPilot', 'printpilot' );
		}
		return $actions;
	}

	/**
	 * Handle the order action.
	 *
	 * @param WC_Order $order Order.
	 * @return void
	 */
	public static function handle_order_action( $order ) {
		if ( ! current_user_can( PrintPilot_Settings::capability() ) ) {
			return;
		}
		PrintPilot_Router::print_with_rules( $order, 'order-action:' . get_current_user_id() );
	}

	/**
	 * Register the metabox on the order screen.
	 *
	 * @param string $screen_id Screen ID or post type.
	 * @param mixed  $obj       Post or order.
	 * @return void
	 */
	public static function add_metabox( $screen_id, $obj = null ) {
		$ids = array( 'shop_order' );
		if ( function_exists( 'wc_get_page_screen_id' ) ) {
			$ids[] = wc_get_page_screen_id( 'shop-order' );
		}
		if ( ! in_array( $screen_id, $ids, true ) || ! current_user_can( PrintPilot_Settings::capability() ) ) {
			return;
		}
		add_meta_box( 'printpilot-order', __( 'PrintPilot', 'printpilot' ), array( __CLASS__, 'render_metabox' ), $screen_id, 'side', 'high' );
	}

	/**
	 * Metabox content.
	 *
	 * @param WP_Post|WC_Order $obj Post or order.
	 * @return void
	 */
	public static function render_metabox( $obj ) {
		$order_id = $obj instanceof WC_Order ? $obj->get_id() : ( isset( $obj->ID ) ? (int) $obj->ID : 0 );
		if ( ! $order_id ) {
			echo '<p>' . esc_html__( 'Save the order first to print it.', 'printpilot' ) . '</p>';
			return;
		}
		$printers  = PrintPilot_Settings::printers();
		$templates = PrintPilot_Settings::templates();
		?>
		<div class="pp-metabox" data-order="<?php echo esc_attr( $order_id ); ?>">
			<p>
				<label for="pp-mb-printer"><?php esc_html_e( 'Printer', 'printpilot' ); ?></label>
				<select id="pp-mb-printer" class="pp-mb-printer widefat">
					<option value=""><?php esc_html_e( 'Automatic (use routing rules)', 'printpilot' ); ?></option>
					<?php foreach ( $printers as $p ) : ?>
						<option value="<?php echo esc_attr( $p['id'] ); ?>"><?php echo esc_html( $p['name'] ); ?></option>
					<?php endforeach; ?>
				</select>
			</p>
			<p>
				<label for="pp-mb-template"><?php esc_html_e( 'Ticket template', 'printpilot' ); ?></label>
				<select id="pp-mb-template" class="pp-mb-template widefat">
					<?php foreach ( $templates as $t ) : ?>
						<option value="<?php echo esc_attr( $t['id'] ); ?>" <?php selected( PrintPilot_Settings::get_one( 'default_template' ), $t['id'] ); ?>><?php echo esc_html( $t['name'] ); ?></option>
					<?php endforeach; ?>
				</select>
			</p>
			<p>
				<label for="pp-mb-copies"><?php esc_html_e( 'Copies', 'printpilot' ); ?></label>
				<input type="number" id="pp-mb-copies" class="pp-mb-copies small-text" min="1" max="10" value="1">
			</p>
			<p class="pp-mb-actions">
				<button type="button" class="button button-primary pp-mb-print"><?php esc_html_e( 'Print', 'printpilot' ); ?></button>
				<a class="button pp-mb-browser" target="_blank" rel="noopener" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=pp_view_ticket&order_id=' . $order_id ), 'pp_view_ticket' ) ); ?>" data-base="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=pp_view_ticket&order_id=' . $order_id ), 'pp_view_ticket' ) ); ?>"><?php esc_html_e( 'Open in browser', 'printpilot' ); ?></a>
			</p>
			<p class="pp-mb-msg" role="status" aria-live="polite"></p>
			<h4><?php esc_html_e( 'Print history', 'printpilot' ); ?></h4>
			<ul class="pp-mb-history"></ul>
		</div>
		<?php
	}

	/* ------------------------------------------------------------------ *
	 * Rendering helpers
	 * ------------------------------------------------------------------ */

	/**
	 * Echo a select element.
	 *
	 * @param string $name     Name attribute.
	 * @param array  $options  value => label.
	 * @param string $selected Selected value.
	 * @param string $class    CSS class.
	 * @param string $id       Optional id.
	 * @return void
	 */
	protected static function select( $name, $options, $selected, $class = '', $id = '' ) {
		echo '<select name="' . esc_attr( $name ) . '"' . ( $class ? ' class="' . esc_attr( $class ) . '"' : '' ) . ( $id ? ' id="' . esc_attr( $id ) . '"' : '' ) . '>';
		foreach ( $options as $v => $label ) {
			echo '<option value="' . esc_attr( $v ) . '"' . selected( (string) $selected, (string) $v, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';
	}

	/**
	 * Order statuses without the wc- prefix.
	 *
	 * @return array<string,string>
	 */
	protected static function statuses() {
		$out = array();
		foreach ( wc_get_order_statuses() as $k => $label ) {
			$out[ PrintPilot_Settings::strip_wc( $k ) ] = $label;
		}
		return $out;
	}

	/**
	 * Printer options for selects.
	 *
	 * @param bool $blank Add a blank option.
	 * @return array<string,string>
	 */
	protected static function printer_options( $blank = false ) {
		$out = $blank ? array( '' => __( '— select —', 'printpilot' ) ) : array();
		foreach ( PrintPilot_Settings::printers() as $p ) {
			$out[ $p['id'] ] = $p['name'];
		}
		return $out;
	}

	/**
	 * Template options for selects.
	 *
	 * @return array<string,string>
	 */
	protected static function template_options() {
		$out = array();
		foreach ( PrintPilot_Settings::templates() as $t ) {
			$out[ $t['id'] ] = $t['name'];
		}
		return $out;
	}

	/**
	 * Page wrapper with tabs.
	 *
	 * @return void
	 */
	public static function render_page() {
		if ( ! current_user_can( PrintPilot_Settings::capability() ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'overview';
		$tabs = self::tabs();
		if ( ! isset( $tabs[ $tab ] ) ) {
			$tab = 'overview';
		}
		echo '<div class="wrap pp-wrap"><h1 class="wp-heading-inline">' . esc_html__( 'PrintPilot', 'printpilot' ) . '</h1>';
		echo '<span class="pp-version">v' . esc_html( PP_VERSION ) . '</span><hr class="wp-header-end">';
		echo '<nav class="nav-tab-wrapper pp-tabs">';
		foreach ( $tabs as $slug => $label ) {
			echo '<a class="nav-tab' . ( $slug === $tab ? ' nav-tab-active' : '' ) . '" href="' . esc_url( add_query_arg( array( 'page' => 'printpilot', 'tab' => $slug ), admin_url( 'admin.php' ) ) ) . '">' . esc_html( $label ) . '</a>';
		}
		echo '</nav>';
		call_user_func( array( __CLASS__, 'tab_' . $tab ) );
		echo '</div>';
	}

	/* ------------------------------------------------------------------ *
	 * Tab: overview
	 * ------------------------------------------------------------------ */

	/**
	 * Overview.
	 *
	 * @return void
	 */
	protected static function tab_overview() {
		$url      = PrintPilot_Station::token_url();
		$stations = PrintPilot_Settings::stations();
		$doc_url  = PP_URL . 'documentation/index.html';
		?>
		<div class="pp-grid">
			<div class="pp-card">
				<h2><?php esc_html_e( 'Print Station', 'printpilot' ); ?></h2>
				<p><?php esc_html_e( 'Open the Print Station on the computer or tablet that is connected to your printer. It checks for new orders every few seconds and prints them automatically.', 'printpilot' ); ?></p>
				<p><a class="button button-primary button-hero" target="_blank" rel="noopener" href="<?php echo esc_url( PrintPilot_Station::admin_url() ); ?>"><?php esc_html_e( 'Open Print Station', 'printpilot' ); ?></a></p>
				<h3><?php esc_html_e( 'Tablet / kiosk link (no login needed)', 'printpilot' ); ?></h3>
				<p class="description"><?php esc_html_e( 'Anyone with this secret link can use the Print Station, so keep it private. Add &name=Kitchen to name a station and &printers=ID1,ID2 to limit which printers it serves.', 'printpilot' ); ?></p>
				<p><input type="text" readonly class="large-text code pp-copy-src" id="pp-station-url" value="<?php echo esc_attr( $url ); ?>">
				<button type="button" class="button pp-copy" data-target="pp-station-url"><?php esc_html_e( 'Copy', 'printpilot' ); ?></button>
				<a class="button" target="_blank" rel="noopener" href="<?php echo esc_url( $url ); ?>"><?php esc_html_e( 'Open', 'printpilot' ); ?></a></p>
				<p><a class="button-link-delete" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=pp_regen_token' ), 'pp_regen_token' ) ); ?>" data-confirm="1"><?php esc_html_e( 'Generate a new link (invalidates the old one)', 'printpilot' ); ?></a></p>
			</div>
			<div class="pp-card">
				<h2><?php esc_html_e( 'Status', 'printpilot' ); ?></h2>
				<ul class="pp-kv">
					<li><span><?php esc_html_e( 'Pending jobs', 'printpilot' ); ?></span><strong><?php echo (int) PrintPilot_Jobs::count( 'pending' ); ?></strong></li>
					<li><span><?php esc_html_e( 'Failed jobs', 'printpilot' ); ?></span><strong><?php echo (int) PrintPilot_Jobs::count( 'failed' ); ?></strong></li>
					<li><span><?php esc_html_e( 'Printed today', 'printpilot' ); ?></span><strong><?php echo (int) PrintPilot_Jobs::count_printed_since( strtotime( 'today midnight' ) ); ?></strong></li>
					<li><span><?php esc_html_e( 'Printers', 'printpilot' ); ?></span><strong><?php echo (int) count( PrintPilot_Settings::printers() ); ?></strong></li>
					<li><span><?php esc_html_e( 'Routing rules', 'printpilot' ); ?></span><strong><?php echo (int) count( PrintPilot_Settings::rules() ); ?></strong></li>
				</ul>
				<h3><?php esc_html_e( 'Stations seen recently', 'printpilot' ); ?></h3>
				<?php if ( ! $stations ) : ?>
					<p class="description"><?php esc_html_e( 'No station has connected yet.', 'printpilot' ); ?></p>
				<?php else : ?>
					<table class="widefat striped"><thead><tr><th><?php esc_html_e( 'Station', 'printpilot' ); ?></th><th><?php esc_html_e( 'Last seen', 'printpilot' ); ?></th><th><?php esc_html_e( 'State', 'printpilot' ); ?></th></tr></thead><tbody>
					<?php foreach ( $stations as $st ) : ?>
						<tr>
							<td><?php echo esc_html( $st['name'] ); ?></td>
							<td><?php echo esc_html( human_time_diff( $st['seen'], time() ) ); ?> <?php esc_html_e( 'ago', 'printpilot' ); ?></td>
							<td><?php echo ( time() - $st['seen'] ) < 30 ? '<span class="pp-pill pp-pill-printed">' . esc_html__( 'Online', 'printpilot' ) . '</span>' : '<span class="pp-pill pp-pill-failed">' . esc_html__( 'Offline', 'printpilot' ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody></table>
				<?php endif; ?>
			</div>
			<div class="pp-card pp-card-wide">
				<h2><?php esc_html_e( 'Quick start', 'printpilot' ); ?></h2>
				<ol class="pp-steps">
					<li><?php esc_html_e( 'Printers: add the printers you own (Print Station browser print, direct USB/Bluetooth thermal, or a network printer).', 'printpilot' ); ?></li>
					<li><?php esc_html_e( 'Templates: adjust the kitchen ticket, receipt or packing slip and check the live preview.', 'printpilot' ); ?></li>
					<li><?php esc_html_e( 'Routing rules: choose which order status triggers a print and which printer gets it, by category, shipping method or order type.', 'printpilot' ); ?></li>
					<li><?php esc_html_e( 'Open the Print Station on the device next to the printer and tap Start. Use "Test print" on the Printers tab to check everything.', 'printpilot' ); ?></li>
				</ol>
				<p><a class="button" target="_blank" rel="noopener" href="<?php echo esc_url( $doc_url ); ?>"><?php esc_html_e( 'Read the documentation', 'printpilot' ); ?></a></p>
			</div>
		</div>
		<?php
	}

	/* ------------------------------------------------------------------ *
	 * Tab: printers
	 * ------------------------------------------------------------------ */

	/**
	 * Output one printer row.
	 *
	 * @param string $key Array key.
	 * @param array  $p   Printer.
	 * @param bool   $saved Whether the printer exists in storage.
	 * @return void
	 */
	protected static function printer_row( $key, $p, $saved ) {
		$n = 'printers[' . $key . ']';
		?>
		<fieldset class="pp-card pp-row" data-row>
			<input type="hidden" name="<?php echo esc_attr( $n ); ?>[id]" value="<?php echo esc_attr( $p['id'] ); ?>">
			<div class="pp-row-head">
				<label class="pp-grow"><span><?php esc_html_e( 'Name', 'printpilot' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $n ); ?>[name]" value="<?php echo esc_attr( $p['name'] ); ?>" class="regular-text" placeholder="<?php esc_attr_e( 'e.g. Kitchen printer', 'printpilot' ); ?>"></label>
				<label class="pp-check"><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[enabled]" value="1" <?php checked( ! empty( $p['enabled'] ) ); ?>> <?php esc_html_e( 'Enabled', 'printpilot' ); ?></label>
				<button type="button" class="button-link button-link-delete pp-remove"><?php esc_html_e( 'Remove', 'printpilot' ); ?></button>
			</div>
			<div class="pp-fields" data-method-switch>
				<label class="pp-field"><span><?php esc_html_e( 'Connection', 'printpilot' ); ?></span>
					<?php self::select( $n . '[method]', PrintPilot_Settings::methods(), $p['method'], 'pp-method' ); ?></label>
				<label class="pp-field"><span><?php esc_html_e( 'Paper width', 'printpilot' ); ?></span>
					<?php self::select( $n . '[paper]', array( '58' => '58 mm', '80' => '80 mm', 'a4' => 'A4 / Letter (HTML only)' ), $p['paper'] ); ?></label>
				<label class="pp-field" data-show-for="station_escpos network"><span><?php esc_html_e( 'Code page', 'printpilot' ); ?></span>
					<?php self::select( $n . '[codepage]', PrintPilot_Settings::codepages(), $p['codepage'] ); ?></label>
				<label class="pp-field" data-show-for="station_escpos network"><span><?php esc_html_e( 'Paper cut', 'printpilot' ); ?></span>
					<?php self::select( $n . '[cut]', array( 'partial' => __( 'Partial cut', 'printpilot' ), 'full' => __( 'Full cut', 'printpilot' ), 'none' => __( 'No cut (feed only)', 'printpilot' ) ), $p['cut'] ); ?></label>
				<label class="pp-field" data-show-for="station_escpos network"><span><?php esc_html_e( 'Cash drawer', 'printpilot' ); ?></span>
					<span class="pp-check"><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[drawer]" value="1" <?php checked( ! empty( $p['drawer'] ) ); ?>> <?php esc_html_e( 'Open on receipts', 'printpilot' ); ?></span></label>
				<label class="pp-field"><span><?php esc_html_e( 'Default copies', 'printpilot' ); ?></span>
					<input type="number" min="1" max="10" name="<?php echo esc_attr( $n ); ?>[copies]" value="<?php echo esc_attr( $p['copies'] ); ?>" class="small-text"></label>
				<label class="pp-field" data-show-for="station_escpos"><span><?php esc_html_e( 'Browser connection', 'printpilot' ); ?></span>
					<?php self::select( $n . '[connection]', array( 'serial' => __( 'USB / Serial (Web Serial)', 'printpilot' ), 'usb' => __( 'USB (WebUSB)', 'printpilot' ), 'bluetooth' => __( 'Bluetooth (Web Bluetooth)', 'printpilot' ) ), $p['connection'] ); ?></label>
				<label class="pp-field" data-show-for="station_escpos"><span><?php esc_html_e( 'Serial baud rate', 'printpilot' ); ?></span>
					<input type="number" min="1200" max="921600" name="<?php echo esc_attr( $n ); ?>[baud]" value="<?php echo esc_attr( $p['baud'] ); ?>" class="small-text"></label>
				<label class="pp-field" data-show-for="network"><span><?php esc_html_e( 'Printer IP / host', 'printpilot' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $n ); ?>[ip]" value="<?php echo esc_attr( $p['ip'] ); ?>" class="regular-text" placeholder="192.168.1.50"></label>
				<label class="pp-field" data-show-for="network"><span><?php esc_html_e( 'Port', 'printpilot' ); ?></span>
					<input type="number" min="1" max="65535" name="<?php echo esc_attr( $n ); ?>[port]" value="<?php echo esc_attr( $p['port'] ); ?>" class="small-text"></label>
				<label class="pp-field" data-show-for="email"><span><?php esc_html_e( 'Send tickets to', 'printpilot' ); ?></span>
					<input type="email" name="<?php echo esc_attr( $n ); ?>[email]" value="<?php echo esc_attr( $p['email'] ); ?>" class="regular-text" placeholder="printer@example.com"></label>
				<label class="pp-field" data-show-for="network station_escpos station_html"><span><?php esc_html_e( 'Fallback email', 'printpilot' ); ?></span>
					<input type="email" name="<?php echo esc_attr( $n ); ?>[fallback_email]" value="<?php echo esc_attr( $p['fallback_email'] ); ?>" class="regular-text" placeholder="<?php esc_attr_e( 'Email the ticket if printing fails', 'printpilot' ); ?>"></label>
			</div>
			<?php if ( $saved ) : ?>
				<p class="pp-row-foot">
					<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=pp_test_print&printer=' . rawurlencode( $p['id'] ) ), 'pp_test_print' ) ); ?>"><?php esc_html_e( 'Test print', 'printpilot' ); ?></a>
					<code class="pp-id"><?php echo esc_html( $p['id'] ); ?></code>
				</p>
			<?php endif; ?>
		</fieldset>
		<?php
	}

	/**
	 * Printers tab.
	 *
	 * @return void
	 */
	protected static function tab_printers() {
		$printers = PrintPilot_Settings::printers();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="pp-form">
			<input type="hidden" name="action" value="pp_save_printers">
			<?php wp_nonce_field( 'pp_save_printers' ); ?>
			<p class="description"><?php esc_html_e( 'A printer is a destination for tickets. Choose how WordPress reaches it. Save before using the "Test print" button.', 'printpilot' ); ?></p>
			<div class="pp-rows" data-rows>
				<?php
				$i = 0;
				foreach ( $printers as $p ) {
					self::printer_row( (string) $i++, array_merge( PrintPilot_Settings::printer_defaults(), $p ), true );
				}
				?>
			</div>
			<template data-row-template>
				<?php self::printer_row( '__KEY__', array_merge( PrintPilot_Settings::printer_defaults(), array( 'id' => '' ) ), false ); ?>
			</template>
			<p class="pp-actions">
				<button type="button" class="button pp-add"><?php esc_html_e( 'Add printer', 'printpilot' ); ?></button>
				<button type="submit" class="button button-primary"><?php esc_html_e( 'Save printers', 'printpilot' ); ?></button>
			</p>
		</form>
		<?php
	}

	/* ------------------------------------------------------------------ *
	 * Tab: templates
	 * ------------------------------------------------------------------ */

	/**
	 * Output one template row.
	 *
	 * @param string $key Array key.
	 * @param array  $t   Template.
	 * @return void
	 */
	protected static function template_row( $key, $t ) {
		$n = 'templates[' . $key . ']';
		?>
		<fieldset class="pp-card pp-row pp-tpl" data-row>
			<input type="hidden" name="<?php echo esc_attr( $n ); ?>[id]" value="<?php echo esc_attr( $t['id'] ); ?>">
			<div class="pp-row-head">
				<label class="pp-grow"><span><?php esc_html_e( 'Template name', 'printpilot' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $n ); ?>[name]" value="<?php echo esc_attr( $t['name'] ); ?>" class="regular-text"></label>
				<label><span><?php esc_html_e( 'Type', 'printpilot' ); ?></span>
					<?php self::select( $n . '[type]', PrintPilot_Settings::template_types(), $t['type'] ); ?></label>
				<button type="button" class="button-link button-link-delete pp-remove"><?php esc_html_e( 'Remove', 'printpilot' ); ?></button>
			</div>
			<div class="pp-tpl-grid">
				<div>
					<label><span class="pp-label"><?php esc_html_e( 'Ticket layout', 'printpilot' ); ?></span>
						<textarea name="<?php echo esc_attr( $n ); ?>[body]" rows="16" class="large-text code pp-body" spellcheck="false"><?php echo esc_textarea( $t['body'] ); ?></textarea></label>
					<div class="pp-opts">
						<label class="pp-check"><input type="checkbox" class="pp-opt" name="<?php echo esc_attr( $n ); ?>[show_prices]" value="1" <?php checked( ! empty( $t['show_prices'] ) ); ?>> <?php esc_html_e( 'Show prices on items', 'printpilot' ); ?></label>
						<label class="pp-check"><input type="checkbox" class="pp-opt" name="<?php echo esc_attr( $n ); ?>[show_sku]" value="1" <?php checked( ! empty( $t['show_sku'] ) ); ?>> <?php esc_html_e( 'Show SKU', 'printpilot' ); ?></label>
						<label class="pp-check"><input type="checkbox" class="pp-opt" name="<?php echo esc_attr( $n ); ?>[show_meta]" value="1" <?php checked( ! empty( $t['show_meta'] ) ); ?>> <?php esc_html_e( 'Show options / variations', 'printpilot' ); ?></label>
						<label class="pp-check"><?php esc_html_e( 'Item text size', 'printpilot' ); ?>
							<?php self::select( $n . '[item_size]', array( '1' => __( 'Normal', 'printpilot' ), '2' => __( 'Tall', 'printpilot' ), '3' => __( 'Large (2x2)', 'printpilot' ) ), (string) $t['item_size'], 'pp-opt' ); ?></label>
					</div>
				</div>
				<div>
					<div class="pp-preview-head">
						<span class="pp-label"><?php esc_html_e( 'Live preview (sample order)', 'printpilot' ); ?></span>
						<select class="pp-paper" aria-label="<?php esc_attr_e( 'Preview paper width', 'printpilot' ); ?>"><option value="80">80 mm</option><option value="58">58 mm</option><option value="a4">A4</option></select>
					</div>
					<div class="pp-preview" aria-live="polite"></div>
				</div>
			</div>
		</fieldset>
		<?php
	}

	/**
	 * Templates tab.
	 *
	 * @return void
	 */
	protected static function tab_templates() {
		$templates = PrintPilot_Settings::templates();
		$presets   = PrintPilot_Install::default_templates();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="pp-form">
			<input type="hidden" name="action" value="pp_save_templates">
			<?php wp_nonce_field( 'pp_save_templates' ); ?>
			<div class="pp-help">
				<h3><?php esc_html_e( 'How templates work', 'printpilot' ); ?></h3>
				<p><?php esc_html_e( 'One line of text is one printed line. Start a line with tags to format it, then write your text and placeholders.', 'printpilot' ); ?></p>
				<ul class="pp-taglist">
					<li><code>[c]</code> <code>[l]</code> <code>[r]</code> <?php esc_html_e( 'align center / left / right', 'printpilot' ); ?></li>
					<li><code>[b]</code> <?php esc_html_e( 'bold', 'printpilot' ); ?> · <code>[u]</code> <?php esc_html_e( 'underline', 'printpilot' ); ?> · <code>[big]</code> <code>[wide]</code> <code>[tall]</code> <?php esc_html_e( 'text size', 'printpilot' ); ?></li>
					<li><code>[lr]Left text||Right text</code> <?php esc_html_e( 'text on both edges (prices)', 'printpilot' ); ?></li>
					<li><code>[hr]</code> <?php esc_html_e( 'horizontal rule', 'printpilot' ); ?> (<code>[hr==]</code> = <?php esc_html_e( 'double line', 'printpilot' ); ?>) · <code>[feed=2]</code> <?php esc_html_e( 'blank lines', 'printpilot' ); ?> · <code>[qr=5]{order_url}</code> <?php esc_html_e( 'QR code', 'printpilot' ); ?> · <code>[drawer]</code> · <code>[cut]</code></li>
					<li><code>[?notes]</code> <?php esc_html_e( 'print this line only when the placeholder has a value', 'printpilot' ); ?></li>
				</ul>
				<p class="pp-chips" aria-label="<?php esc_attr_e( 'Placeholders (click to insert)', 'printpilot' ); ?>">
					<?php foreach ( PrintPilot_Ticket::placeholders() as $k => $desc ) : ?>
						<button type="button" class="pp-chip" data-ph="{<?php echo esc_attr( $k ); ?>}" title="<?php echo esc_attr( $desc ); ?>">{<?php echo esc_html( $k ); ?>}</button>
					<?php endforeach; ?>
				</p>
			</div>
			<div class="pp-rows" data-rows data-presets="<?php echo esc_attr( wp_json_encode( array_values( $presets ) ) ); ?>">
				<?php
				$i = 0;
				foreach ( $templates as $t ) {
					self::template_row( (string) $i++, $t );
				}
				?>
			</div>
			<template data-row-template>
				<?php
				self::template_row(
					'__KEY__',
					array(
						'id'          => '',
						'name'        => '',
						'type'        => 'custom',
						'body'        => '',
						'show_prices' => 0,
						'show_sku'    => 0,
						'show_meta'   => 1,
						'item_size'   => 1,
					)
				);
				?>
			</template>
			<p class="pp-actions">
				<button type="button" class="button pp-add"><?php esc_html_e( 'Add blank template', 'printpilot' ); ?></button>
				<?php foreach ( $presets as $pr ) : ?>
					<button type="button" class="button pp-add-preset" data-preset="<?php echo esc_attr( $pr['id'] ); ?>"><?php /* translators: %s: preset name */ echo esc_html( sprintf( __( 'Add preset: %s', 'printpilot' ), $pr['name'] ) ); ?></button>
				<?php endforeach; ?>
				<button type="submit" class="button button-primary"><?php esc_html_e( 'Save templates', 'printpilot' ); ?></button>
			</p>
		</form>
		<?php
	}

	/* ------------------------------------------------------------------ *
	 * Tab: rules
	 * ------------------------------------------------------------------ */

	/**
	 * Output one rule row.
	 *
	 * @param string $key  Array key.
	 * @param array  $r    Rule.
	 * @param array  $cats Product categories id => name.
	 * @return void
	 */
	protected static function rule_row( $key, $r, $cats ) {
		$n = 'rules[' . $key . ']';
		?>
		<fieldset class="pp-card pp-row" data-row>
			<input type="hidden" name="<?php echo esc_attr( $n ); ?>[id]" value="<?php echo esc_attr( $r['id'] ); ?>">
			<div class="pp-row-head">
				<label class="pp-grow"><span><?php esc_html_e( 'Rule name', 'printpilot' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $n ); ?>[name]" value="<?php echo esc_attr( $r['name'] ); ?>" class="regular-text"></label>
				<label class="pp-check"><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[enabled]" value="1" <?php checked( ! empty( $r['enabled'] ) ); ?>> <?php esc_html_e( 'Enabled', 'printpilot' ); ?></label>
				<button type="button" class="button-link button-link-delete pp-remove"><?php esc_html_e( 'Remove', 'printpilot' ); ?></button>
			</div>
			<div class="pp-fields">
				<div class="pp-field pp-field-wide"><span><?php esc_html_e( 'When the order changes to…', 'printpilot' ); ?></span>
					<span class="pp-checks">
					<?php foreach ( self::statuses() as $slug => $label ) : ?>
						<label class="pp-check"><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[statuses][]" value="<?php echo esc_attr( $slug ); ?>" <?php checked( in_array( $slug, (array) $r['statuses'], true ) ); ?>> <?php echo esc_html( $label ); ?></label>
					<?php endforeach; ?>
					</span>
				</div>
				<label class="pp-field"><span><?php esc_html_e( 'Print on printer', 'printpilot' ); ?></span>
					<?php self::select( $n . '[printer]', self::printer_options( true ), $r['printer'] ); ?></label>
				<label class="pp-field"><span><?php esc_html_e( 'Using template', 'printpilot' ); ?></span>
					<?php self::select( $n . '[template]', self::template_options(), $r['template'] ); ?></label>
				<label class="pp-field"><span><?php esc_html_e( 'Copies', 'printpilot' ); ?></span>
					<input type="number" min="1" max="10" name="<?php echo esc_attr( $n ); ?>[copies]" value="<?php echo esc_attr( $r['copies'] ); ?>" class="small-text"></label>
				<label class="pp-field"><span><?php esc_html_e( 'Order type', 'printpilot' ); ?></span>
					<?php self::select( $n . '[order_type]', array( 'any' => __( 'Any', 'printpilot' ), 'pickup' => __( 'Pickup (local pickup shipping)', 'printpilot' ), 'delivery' => __( 'Delivery / shipped', 'printpilot' ), 'none' => __( 'No shipping (virtual / dine-in)', 'printpilot' ) ), $r['order_type'] ); ?></label>
				<label class="pp-field"><span><?php esc_html_e( 'Only if order contains these categories', 'printpilot' ); ?></span>
					<select name="<?php echo esc_attr( $n ); ?>[categories][]" multiple size="5">
						<?php foreach ( $cats as $cid => $cname ) : ?>
							<option value="<?php echo esc_attr( $cid ); ?>" <?php selected( in_array( (int) $cid, array_map( 'intval', (array) $r['categories'] ), true ) ); ?>><?php echo esc_html( $cname ); ?></option>
						<?php endforeach; ?>
					</select></label>
				<label class="pp-field"><span><?php esc_html_e( 'Shipping method IDs (comma separated)', 'printpilot' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $n ); ?>[shipping_methods]" value="<?php echo esc_attr( implode( ', ', (array) $r['shipping_methods'] ) ); ?>" class="regular-text" placeholder="local_pickup, flat_rate:3"></label>
				<label class="pp-field"><span><?php esc_html_e( 'Payment method IDs (comma separated)', 'printpilot' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $n ); ?>[payment_methods]" value="<?php echo esc_attr( implode( ', ', (array) $r['payment_methods'] ) ); ?>" class="regular-text" placeholder="cod, stripe"></label>
				<label class="pp-field"><span><?php esc_html_e( 'Order custom field (e.g. location)', 'printpilot' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $n ); ?>[meta_key]" value="<?php echo esc_attr( $r['meta_key'] ); ?>" class="regular-text" placeholder="_store_location"></label>
				<label class="pp-field"><span><?php esc_html_e( '…equals value (blank = any value)', 'printpilot' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $n ); ?>[meta_value]" value="<?php echo esc_attr( $r['meta_value'] ); ?>" class="regular-text"></label>
				<div class="pp-field pp-field-wide">
					<label class="pp-check"><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[split_items]" value="1" <?php checked( ! empty( $r['split_items'] ) ); ?>> <?php esc_html_e( 'Print only the items from the selected categories (split orders between bar / kitchen / warehouse)', 'printpilot' ); ?></label>
					<label class="pp-check"><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[stop]" value="1" <?php checked( ! empty( $r['stop'] ) ); ?>> <?php esc_html_e( 'Stop checking further rules after this one matches', 'printpilot' ); ?></label>
				</div>
			</div>
		</fieldset>
		<?php
	}

	/**
	 * Rules tab.
	 *
	 * @return void
	 */
	protected static function tab_rules() {
		$rules = PrintPilot_Settings::rules();
		$cats  = array();
		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
			)
		);
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$cats[ $term->term_id ] = $term->name;
			}
		}
		$methods = array();
		foreach ( WC()->shipping()->get_shipping_methods() as $m ) {
			$methods[] = $m->id;
		}
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="pp-form">
			<input type="hidden" name="action" value="pp_save_rules">
			<?php wp_nonce_field( 'pp_save_rules' ); ?>
			<p class="description"><?php esc_html_e( 'Rules are checked top to bottom when an order changes status. Every matching rule creates a print job, so one order can print a kitchen ticket, a receipt and a packing slip on different printers.', 'printpilot' ); ?>
				<?php if ( $methods ) : ?>
					<br><?php /* translators: %s: list of shipping method IDs */ echo esc_html( sprintf( __( 'Shipping method IDs on this store: %s', 'printpilot' ), implode( ', ', $methods ) ) ); ?>
				<?php endif; ?></p>
			<div class="pp-rows" data-rows>
				<?php
				$i = 0;
				foreach ( $rules as $r ) {
					self::rule_row( (string) $i++, array_merge( self::rule_defaults(), $r ), $cats );
				}
				?>
			</div>
			<template data-row-template>
				<?php self::rule_row( '__KEY__', self::rule_defaults(), $cats ); ?>
			</template>
			<p class="pp-actions">
				<button type="button" class="button pp-add"><?php esc_html_e( 'Add rule', 'printpilot' ); ?></button>
				<button type="submit" class="button button-primary"><?php esc_html_e( 'Save rules', 'printpilot' ); ?></button>
			</p>
		</form>
		<?php
	}

	/**
	 * Default rule.
	 *
	 * @return array
	 */
	protected static function rule_defaults() {
		return array(
			'id'               => '',
			'name'             => '',
			'enabled'          => 1,
			'statuses'         => array( 'processing' ),
			'categories'       => array(),
			'shipping_methods' => array(),
			'payment_methods'  => array(),
			'order_type'       => 'any',
			'meta_key'         => '',
			'meta_value'       => '',
			'printer'          => '',
			'template'         => PrintPilot_Settings::get_one( 'default_template' ),
			'copies'           => 1,
			'split_items'      => 0,
			'stop'             => 0,
		);
	}

	/* ------------------------------------------------------------------ *
	 * Tab: log
	 * ------------------------------------------------------------------ */

	/**
	 * Print log tab.
	 *
	 * @return void
	 */
	protected static function tab_log() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		$paged  = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		// phpcs:enable
		$per      = 25;
		$statuses = PrintPilot_Jobs::statuses();
		if ( $status && ! isset( $statuses[ $status ] ) ) {
			$status = '';
		}
		$total = PrintPilot_Jobs::count( $status );
		$jobs  = PrintPilot_Jobs::query(
			array(
				'status' => $status,
				'limit'  => $per,
				'offset' => ( $paged - 1 ) * $per,
			)
		);
		$base  = add_query_arg( array( 'page' => 'printpilot', 'tab' => 'log' ), admin_url( 'admin.php' ) );
		echo '<ul class="subsubsub"><li><a href="' . esc_url( $base ) . '"' . ( '' === $status ? ' class="current"' : '' ) . '>' . esc_html__( 'All', 'printpilot' ) . '</a> |</li>';
		$last = array_key_last( $statuses );
		foreach ( $statuses as $slug => $label ) {
			echo '<li><a href="' . esc_url( add_query_arg( 'status', $slug, $base ) ) . '"' . ( $slug === $status ? ' class="current"' : '' ) . '>' . esc_html( $label ) . ' <span class="count">(' . (int) PrintPilot_Jobs::count( $slug ) . ')</span></a>' . ( $slug !== $last ? ' |' : '' ) . '</li>';
		}
		echo '</ul><div class="clear"></div>';
		?>
		<table class="widefat striped pp-log">
			<thead><tr>
				<th><?php esc_html_e( 'ID', 'printpilot' ); ?></th>
				<th><?php esc_html_e( 'Created', 'printpilot' ); ?></th>
				<th><?php esc_html_e( 'Order', 'printpilot' ); ?></th>
				<th><?php esc_html_e( 'Printer', 'printpilot' ); ?></th>
				<th><?php esc_html_e( 'Template', 'printpilot' ); ?></th>
				<th><?php esc_html_e( 'Status', 'printpilot' ); ?></th>
				<th><?php esc_html_e( 'Tries', 'printpilot' ); ?></th>
				<th><?php esc_html_e( 'Source', 'printpilot' ); ?></th>
				<th><?php esc_html_e( 'Actions', 'printpilot' ); ?></th>
			</tr></thead>
			<tbody>
			<?php if ( ! $jobs ) : ?>
				<tr><td colspan="9"><?php esc_html_e( 'No print jobs yet.', 'printpilot' ); ?></td></tr>
			<?php endif; ?>
			<?php
			foreach ( $jobs as $j ) :
				$printer = PrintPilot_Settings::printer( $j->printer_id );
				$tpl     = PrintPilot_Settings::template( $j->template_id );
				$act     = function ( $do ) use ( $j ) {
					return wp_nonce_url( admin_url( 'admin-post.php?action=pp_job_action&do=' . $do . '&job=' . (int) $j->id ), 'pp_job_action' );
				};
				$order_cell = '—';
				if ( (int) $j->order_id > 0 ) {
					$order = wc_get_order( (int) $j->order_id );
					$order_cell = $order ? '<a href="' . esc_url( $order->get_edit_order_url() ) . '">#' . esc_html( $order->get_order_number() ) . '</a>' : '#' . (int) $j->order_id;
				} else {
					$order_cell = esc_html__( 'Test', 'printpilot' );
				}
				?>
				<tr>
					<td><?php echo (int) $j->id; ?></td>
					<td><?php echo esc_html( get_date_from_gmt( $j->created_gmt, 'Y-m-d H:i:s' ) ); ?></td>
					<td><?php echo wp_kses_post( $order_cell ); ?></td>
					<td><?php echo esc_html( $printer ? $printer['name'] : $j->printer_id ); ?></td>
					<td><?php echo esc_html( $tpl ? $tpl['name'] : $j->template_id ); ?></td>
					<td><span class="pp-pill pp-pill-<?php echo esc_attr( $j->status ); ?>"><?php echo esc_html( isset( $statuses[ $j->status ] ) ? $statuses[ $j->status ] : $j->status ); ?></span>
						<?php if ( $j->error ) : ?><br><small class="pp-err"><?php echo esc_html( $j->error ); ?></small><?php endif; ?></td>
					<td><?php echo (int) $j->attempts; ?></td>
					<td><small><?php echo esc_html( $j->source ); ?></small></td>
					<td class="pp-row-actions">
						<?php if ( in_array( $j->status, array( 'failed', 'cancelled', 'pending' ), true ) ) : ?>
							<a href="<?php echo esc_url( $act( 'retry' ) ); ?>"><?php esc_html_e( 'Retry', 'printpilot' ); ?></a> |
						<?php endif; ?>
						<a href="<?php echo esc_url( $act( 'reprint' ) ); ?>"><?php esc_html_e( 'Reprint', 'printpilot' ); ?></a> |
						<a target="_blank" rel="noopener" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=pp_view_ticket&job=' . (int) $j->id ), 'pp_view_ticket' ) ); ?>"><?php esc_html_e( 'View', 'printpilot' ); ?></a> |
						<?php if ( 'pending' === $j->status ) : ?>
							<a href="<?php echo esc_url( $act( 'cancel' ) ); ?>"><?php esc_html_e( 'Cancel', 'printpilot' ); ?></a> |
						<?php endif; ?>
						<a class="pp-del" href="<?php echo esc_url( $act( 'delete' ) ); ?>"><?php esc_html_e( 'Delete', 'printpilot' ); ?></a>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php
		$pages = (int) ceil( $total / $per );
		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">' . wp_kses_post(
				paginate_links(
					array(
						'base'    => add_query_arg( 'paged', '%#%', $status ? add_query_arg( 'status', $status, $base ) : $base ),
						'format'  => '',
						'current' => $paged,
						'total'   => $pages,
					)
				)
			) . '</div></div>';
		}
		?>
		<p><a class="button" data-confirm="1" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=pp_job_action&do=clear' ), 'pp_job_action' ) ); ?>"><?php esc_html_e( 'Clear entire log', 'printpilot' ); ?></a></p>
		<?php
	}

	/* ------------------------------------------------------------------ *
	 * Tab: settings
	 * ------------------------------------------------------------------ */

	/**
	 * Settings tab.
	 *
	 * @return void
	 */
	protected static function tab_settings() {
		$s = PrintPilot_Settings::get();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="pp-form">
			<input type="hidden" name="action" value="pp_save_settings">
			<?php wp_nonce_field( 'pp_save_settings' ); ?>
			<table class="form-table" role="presentation">
				<tr><th scope="row"><?php esc_html_e( 'Print Station refresh', 'printpilot' ); ?></th>
					<td><input type="number" min="3" max="30" name="pp[poll_interval]" value="<?php echo esc_attr( $s['poll_interval'] ); ?>" class="small-text"> <?php esc_html_e( 'seconds between checks for new jobs (5–10 recommended)', 'printpilot' ); ?></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Sound alert', 'printpilot' ); ?></th>
					<td><label><input type="checkbox" name="pp[sound]" value="1" <?php checked( $s['sound'] ); ?>> <?php esc_html_e( 'Play a beep when a new order or print job arrives', 'printpilot' ); ?></label><br>
					<label><input type="checkbox" name="pp[repeat_alarm]" value="1" <?php checked( $s['repeat_alarm'] ); ?>> <?php esc_html_e( 'Repeat the beep every 10 seconds while orders wait to be accepted', 'printpilot' ); ?></label></td></tr>
				<tr><th scope="row"><?php esc_html_e( '"Accept order" button', 'printpilot' ); ?></th>
					<td>
						<p><?php esc_html_e( 'Show orders with these statuses in the Print Station:', 'printpilot' ); ?></p>
						<?php foreach ( self::statuses() as $slug => $label ) : ?>
							<label class="pp-check"><input type="checkbox" name="pp[accept_statuses][]" value="<?php echo esc_attr( $slug ); ?>" <?php checked( in_array( $slug, (array) $s['accept_statuses'], true ) ); ?>> <?php echo esc_html( $label ); ?></label>
						<?php endforeach; ?>
						<p><?php esc_html_e( 'Accepting moves the order to:', 'printpilot' ); ?> <?php self::select( 'pp[accept_to]', self::statuses(), $s['accept_to'] ); ?></p>
					</td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Delivery / pickup time fields', 'printpilot' ); ?></th>
					<td><input type="text" name="pp[delivery_meta_keys]" value="<?php echo esc_attr( $s['delivery_meta_keys'] ); ?>" class="large-text code">
					<p class="description"><?php esc_html_e( 'Order custom-field keys checked (in order) to fill {delivery_time}. Add the key your delivery-date plugin uses.', 'printpilot' ); ?></p></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Default printer and template', 'printpilot' ); ?></th>
					<td><?php self::select( 'pp[default_printer]', self::printer_options( true ), $s['default_printer'] ); ?> <?php self::select( 'pp[default_template]', self::template_options(), $s['default_template'] ); ?>
					<p class="description"><?php esc_html_e( 'Used for manual prints when no routing rule matches.', 'printpilot' ); ?></p></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Automatic prints', 'printpilot' ); ?></th>
					<td><label><input type="checkbox" name="pp[dedupe]" value="1" <?php checked( $s['dedupe'] ); ?>> <?php esc_html_e( 'Print each order only once per rule and status (prevents duplicates if the status flips back and forth)', 'printpilot' ); ?></label></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Retries', 'printpilot' ); ?></th>
					<td><input type="number" min="1" max="10" name="pp[retry_max]" value="<?php echo esc_attr( $s['retry_max'] ); ?>" class="small-text"> <?php esc_html_e( 'attempts, waiting', 'printpilot' ); ?> <input type="number" min="10" max="3600" name="pp[retry_delay]" value="<?php echo esc_attr( $s['retry_delay'] ); ?>" class="small-text"> <?php esc_html_e( 'seconds between attempts', 'printpilot' ); ?></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Log retention', 'printpilot' ); ?></th>
					<td><input type="number" min="0" max="3650" name="pp[job_retention_days]" value="<?php echo esc_attr( $s['job_retention_days'] ); ?>" class="small-text"> <?php esc_html_e( 'days (0 = keep forever)', 'printpilot' ); ?></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Uninstall', 'printpilot' ); ?></th>
					<td><label><input type="checkbox" name="pp[remove_data]" value="1" <?php checked( $s['remove_data'] ); ?>> <?php esc_html_e( 'Delete all PrintPilot data (printers, templates, rules, print log) when the plugin is deleted', 'printpilot' ); ?></label></td></tr>
			</table>
			<?php submit_button( __( 'Save settings', 'printpilot' ) ); ?>
		</form>
		<?php
	}
}
