<?php
/**
 * REST API (namespace printpilot/v1).
 *
 * @package PrintPilot
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * REST endpoints used by the Print Station and the admin UI.
 */
class PrintPilot_REST {

	const NS = 'printpilot/v1';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	/**
	 * Register routes.
	 *
	 * @return void
	 */
	public static function routes() {
		$station = array( __CLASS__, 'station_permission' );
		$admin   = array( __CLASS__, 'admin_permission' );

		register_rest_route(
			self::NS,
			'/station/poll',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'poll' ),
				'permission_callback' => $station,
			)
		);
		register_rest_route(
			self::NS,
			'/station/jobs/(?P<id>\d+)/result',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'job_result' ),
				'permission_callback' => $station,
			)
		);
		register_rest_route(
			self::NS,
			'/station/jobs/(?P<id>\d+)/reprint',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'job_reprint' ),
				'permission_callback' => $station,
			)
		);
		register_rest_route(
			self::NS,
			'/station/orders/(?P<id>\d+)/accept',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'order_accept' ),
				'permission_callback' => $station,
			)
		);
		register_rest_route(
			self::NS,
			'/station/test',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'station_test' ),
				'permission_callback' => $station,
			)
		);
		register_rest_route(
			self::NS,
			'/orders/(?P<id>\d+)/print',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'order_print' ),
				'permission_callback' => $admin,
			)
		);
		register_rest_route(
			self::NS,
			'/orders/(?P<id>\d+)/jobs',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'order_jobs' ),
				'permission_callback' => $admin,
			)
		);
		register_rest_route(
			self::NS,
			'/templates/preview',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'template_preview' ),
				'permission_callback' => $admin,
			)
		);
	}

	/**
	 * Admin-only permission.
	 *
	 * @return bool
	 */
	public static function admin_permission() {
		return current_user_can( PrintPilot_Settings::capability() );
	}

	/**
	 * Station permission: shop manager session or station token.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool
	 */
	public static function station_permission( $request ) {
		if ( current_user_can( PrintPilot_Settings::capability() ) ) {
			return true;
		}
		$given = $request->get_header( 'X-PrintPilot-Token' );
		if ( ! $given ) {
			return false;
		}
		return hash_equals( PrintPilot_Settings::token(), (string) $given );
	}

	/**
	 * Job as shown in the station queue.
	 *
	 * @param object $job Job.
	 * @return array
	 */
	public static function job_summary( $job ) {
		$printer = PrintPilot_Settings::printer( $job->printer_id );
		$number  = '';
		if ( (int) $job->order_id > 0 ) {
			$order = wc_get_order( (int) $job->order_id );
			if ( $order ) {
				$number = $order->get_order_number();
			}
		}
		return array(
			'id'       => (int) $job->id,
			'order_id' => (int) $job->order_id,
			'number'   => $number,
			'printer'  => $printer ? $printer['name'] : $job->printer_id,
			'status'   => $job->status,
			'error'    => (string) $job->error,
			'source'   => $job->source,
			'copies'   => (int) $job->copies,
			'created'  => strtotime( $job->created_gmt . ' UTC' ),
			'updated'  => strtotime( $job->updated_gmt . ' UTC' ),
		);
	}

	/**
	 * Full payload so the station can print.
	 *
	 * @param object $job Claimed job.
	 * @return array|null
	 */
	protected static function job_payload( $job ) {
		$printer = PrintPilot_Settings::printer( $job->printer_id );
		$doc     = PrintPilot_Ticket::doc_for_job( $job );
		if ( is_wp_error( $doc ) || ! $printer ) {
			PrintPilot_Jobs::mark_failed( (int) $job->id, is_wp_error( $doc ) ? $doc->get_error_message() : __( 'Printer missing.', 'printpilot' ) );
			return null;
		}
		$p = self::job_summary( $job );
		$p['method']  = $job->method;
		$p['printer_id'] = $job->printer_id;
		$p['paper']   = $doc['paper'];
		$p['baud']    = (int) $printer['baud'];
		if ( 'station_escpos' === $job->method ) {
			$p['doc'] = $doc;
		} else {
			$p['html'] = PrintPilot_Ticket::html_document( $doc, 'PrintPilot #' . $job->id, false, false );
		}
		return $p;
	}

	/**
	 * Station poll + heartbeat.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function poll( $request ) {
		$body    = $request->get_json_params();
		$body    = is_array( $body ) ? $body : array();
		$station = isset( $body['station'] ) ? sanitize_text_field( $body['station'] ) : 'Station';
		$station = '' === $station ? 'Station' : substr( $station, 0, 60 );
		$ready   = isset( $body['ready'] ) && is_array( $body['ready'] ) ? array_map( 'sanitize_key', $body['ready'] ) : array();
		$only    = isset( $body['printers'] ) && is_array( $body['printers'] ) ? array_filter( array_map( 'sanitize_key', $body['printers'] ) ) : array();
		$accept  = ! empty( $body['claim'] );
		PrintPilot_Settings::touch_station(
			$station,
			array(
				'ready'    => $ready,
				'printers' => $only,
			)
		);

		$jobs = array();
		if ( $accept ) {
			foreach ( PrintPilot_Jobs::claim_for_station( $station, $ready, $only, 5 ) as $job ) {
				$payload = self::job_payload( $job );
				if ( $payload ) {
					$jobs[] = $payload;
				}
			}
		}

		$recent = array();
		foreach ( PrintPilot_Jobs::query( array( 'limit' => 25 ) ) as $j ) {
			if ( $only && ! in_array( $j->printer_id, $only, true ) ) {
				continue;
			}
			$recent[] = self::job_summary( $j );
		}

		$orders   = array();
		$statuses = (array) PrintPilot_Settings::get_one( 'accept_statuses', array() );
		if ( $statuses ) {
			$list = wc_get_orders(
				array(
					'status'  => $statuses,
					'limit'   => 15,
					'orderby' => 'date',
					'order'   => 'DESC',
				)
			);
			foreach ( $list as $o ) {
				$lines = array();
				foreach ( $o->get_items() as $it ) {
					$lines[] = (float) $it->get_quantity() . ' x ' . PrintPilot_Ticket::clean( $it->get_name() );
					if ( count( $lines ) >= 4 ) {
						break;
					}
				}
				$orders[] = array(
					'id'       => $o->get_id(),
					'number'   => $o->get_order_number(),
					'status'   => PrintPilot_Ticket::clean( wc_get_order_status_name( $o->get_status() ) ),
					'total'    => PrintPilot_Ticket::money( $o->get_total(), $o->get_currency() ),
					'customer' => PrintPilot_Ticket::clean( trim( $o->get_billing_first_name() . ' ' . $o->get_billing_last_name() ) ),
					'type'     => PrintPilot_Ticket::order_type_label( PrintPilot_Ticket::order_type( $o ) ),
					'lines'    => $lines,
					'created'  => $o->get_date_created() ? $o->get_date_created()->getTimestamp() : 0,
				);
			}
		}

		return rest_ensure_response(
			array(
				'ok'       => true,
				'now'      => time(),
				'interval' => (int) PrintPilot_Settings::get_one( 'poll_interval', 6 ),
				'jobs'     => $jobs,
				'recent'   => $recent,
				'orders'   => $orders,
				'stats'    => array(
					'pending' => PrintPilot_Jobs::count( 'pending' ),
					'failed'  => PrintPilot_Jobs::count( 'failed' ),
					'today'   => PrintPilot_Jobs::count_printed_since( strtotime( 'today midnight' ) ),
				),
			)
		);
	}

	/**
	 * Station reports a print result.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function job_result( $request ) {
		$job = PrintPilot_Jobs::get( (int) $request['id'] );
		if ( ! $job ) {
			return new WP_Error( 'pp_not_found', __( 'Job not found.', 'printpilot' ), array( 'status' => 404 ) );
		}
		$body = $request->get_json_params();
		$ok   = is_array( $body ) && ! empty( $body['ok'] );
		if ( 'printing' !== $job->status ) {
			return rest_ensure_response( array( 'ok' => false, 'status' => $job->status ) );
		}
		if ( $ok ) {
			PrintPilot_Jobs::mark_printed( (int) $job->id );
			return rest_ensure_response( array( 'ok' => true, 'status' => 'printed' ) );
		}
		$err = is_array( $body ) && isset( $body['error'] ) ? sanitize_text_field( $body['error'] ) : __( 'Unknown error', 'printpilot' );
		return rest_ensure_response( array( 'ok' => true, 'status' => PrintPilot_Jobs::mark_failed( (int) $job->id, $err ) ) );
	}

	/**
	 * Reprint from the station queue.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function job_reprint( $request ) {
		$id = PrintPilot_Jobs::reprint( (int) $request['id'], 'reprint:station' );
		if ( is_wp_error( $id ) ) {
			$id->add_data( array( 'status' => 400 ) );
			return $id;
		}
		return rest_ensure_response( array( 'ok' => true, 'job' => $id ) );
	}

	/**
	 * Accept an order from the station.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function order_accept( $request ) {
		$order = wc_get_order( (int) $request['id'] );
		if ( ! $order ) {
			return new WP_Error( 'pp_not_found', __( 'Order not found.', 'printpilot' ), array( 'status' => 404 ) );
		}
		$to = PrintPilot_Settings::get_one( 'accept_to', 'processing' );
		$order->update_status( $to, __( 'Order accepted in the PrintPilot Print Station.', 'printpilot' ) );
		return rest_ensure_response(
			array(
				'ok'     => true,
				'status' => $order->get_status(),
			)
		);
	}

	/**
	 * Test print from the station.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function station_test( $request ) {
		$body = $request->get_json_params();
		$pid  = is_array($body) && isset( $body['printer'] ) ? sanitize_key( $body['printer'] ) : '';
		$id   = PrintPilot_Router::test_print( $pid );
		if ( is_wp_error( $id ) ) {
			$id->add_data( array( 'status' => 400 ) );
			return $id;
		}
		return rest_ensure_response( array( 'ok' => true, 'job' => $id ) );
	}

	/**
	 * Print an order from the metabox.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function order_print( $request ) {
		$order = wc_get_order( (int) $request['id'] );
		if ( ! $order ) {
			return new WP_Error( 'pp_not_found', __( 'Order not found.', 'printpilot' ), array( 'status' => 404 ) );
		}
		$body    = $request->get_json_params();
		$body    = is_array( $body ) ? $body : array();
		$printer = isset( $body['printer'] ) ? sanitize_key( $body['printer'] ) : '';
		$tpl     = isset( $body['template'] ) ? sanitize_key( $body['template'] ) : '';
		$copies  = isset( $body['copies'] ) ? absint( $body['copies'] ) : 0;
		if ( '' === $printer ) {
			$ids = PrintPilot_Router::print_with_rules( $order, 'manual:' . get_current_user_id() );
		} else {
			$ids = PrintPilot_Router::print_manual( $order, $printer, $tpl, $copies, 'manual:' . get_current_user_id() );
			$ids = is_wp_error( $ids ) ? $ids : array( $ids );
		}
		if ( is_wp_error( $ids ) ) {
			$ids->add_data( array( 'status' => 400 ) );
			return $ids;
		}
		// Send server-side jobs now so the user sees the result immediately.
		foreach ( $ids as $jid ) {
			$job = PrintPilot_Jobs::get( $jid );
			if ( $job && in_array( $job->method, array( 'network', 'email' ), true ) ) {
				PrintPilot_Jobs::process_job( $jid );
			}
		}
		return rest_ensure_response(
			array(
				'ok'   => true,
				'jobs' => array_map( array( __CLASS__, 'job_row' ), $ids ),
			)
		);
	}

	/**
	 * Job row for the metabox history.
	 *
	 * @param int $id Job ID.
	 * @return array
	 */
	public static function job_row( $id ) {
		$job = PrintPilot_Jobs::get( (int) $id );
		return $job ? self::job_summary( $job ) : array();
	}

	/**
	 * Job history for an order.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function order_jobs( $request ) {
		$rows = array();
		foreach ( PrintPilot_Jobs::query( array( 'order_id' => (int) $request['id'], 'limit' => 30 ) ) as $j ) {
			$rows[] = self::job_summary( $j );
		}
		return rest_ensure_response( array( 'jobs' => $rows ) );
	}

	/**
	 * Live template preview with sample data.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function template_preview( $request ) {
		$body = $request->get_json_params();
		$body = is_array( $body ) ? $body : array();
		$tpls = PrintPilot_Settings::sanitize_templates(
			array(
				array(
					'name'        => 'preview',
					'type'        => isset( $body['type'] ) ? wp_slash( $body['type'] ) : 'custom',
					'body'        => isset( $body['body'] ) ? wp_slash( (string) $body['body'] ) : '',
					'show_prices' => ! empty( $body['show_prices'] ),
					'show_sku'    => ! empty( $body['show_sku'] ),
					'show_meta'   => ! empty( $body['show_meta'] ),
					'item_size'   => isset( $body['item_size'] ) ? (int) $body['item_size'] : 1,
				),
			)
		);
		$tpl     = reset( $tpls );
		$paper   = isset( $body['paper'] ) && in_array( (string) $body['paper'], array( '58', '80', 'a4' ), true ) ? (string) $body['paper'] : '80';
		$printer = array_merge( PrintPilot_Settings::printer_defaults(), array( 'paper' => $paper, 'drawer' => 0 ) );
		$ctx     = PrintPilot_Ticket::sample_context();
		$ctx['vars']['printer_name'] = 'Preview';
		$doc     = PrintPilot_Ticket::build_doc( $ctx, $tpl, $printer );
		return rest_ensure_response(
			array(
				'html' => PrintPilot_Ticket::render_html( $doc ),
				'css'  => PrintPilot_Ticket::css( $paper ),
			)
		);
	}
}
