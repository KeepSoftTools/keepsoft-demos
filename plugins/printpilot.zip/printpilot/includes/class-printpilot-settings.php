<?php
/**
 * Settings, printers, templates and rules storage.
 *
 * @package PrintPilot
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Option access and sanitisation.
 */
class PrintPilot_Settings {

	const OPT_SETTINGS  = 'pp_settings';
	const OPT_PRINTERS  = 'pp_printers';
	const OPT_TEMPLATES = 'pp_templates';
	const OPT_RULES     = 'pp_rules';
	const OPT_STATIONS  = 'pp_stations';

	/**
	 * Capability required to manage PrintPilot and use the station.
	 *
	 * @return string
	 */
	public static function capability() {
		return apply_filters( 'printpilot_capability', 'manage_woocommerce' );
	}

	/**
	 * Default general settings.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'station_token'        => '',
			'poll_interval'        => 6,
			'sound'                => 1,
			'repeat_alarm'         => 0,
			'auto_print'           => 1,
			'accept_statuses'      => array( 'on-hold', 'pending' ),
			'accept_to'            => 'processing',
			'delivery_meta_keys'   => '_delivery_time, delivery_time, _orddd_lite_timestamp, _orddd_timestamp, jckwds_time, _pickup_time, pickup_time',
			'retry_max'            => 3,
			'retry_delay'          => 60,
			'claim_timeout'        => 90,
			'dedupe'               => 1,
			'default_printer'      => '',
			'default_template'     => '',
			'job_retention_days'   => 30,
			'remove_data'          => 0,
			'station_name'         => '',
		);
	}

	/**
	 * Get all settings merged with defaults.
	 *
	 * @return array
	 */
	public static function get() {
		$saved = get_option( self::OPT_SETTINGS, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		return array_merge( self::defaults(), $saved );
	}

	/**
	 * Get one setting.
	 *
	 * @param string $key     Key.
	 * @param mixed  $default Default.
	 * @return mixed
	 */
	public static function get_one( $key, $default = null ) {
		$s = self::get();
		return isset( $s[ $key ] ) ? $s[ $key ] : $default;
	}

	/**
	 * Save settings (already sanitised).
	 *
	 * @param array $s Settings.
	 * @return void
	 */
	public static function save( $s ) {
		update_option( self::OPT_SETTINGS, array_merge( self::get(), $s ), false );
	}

	/**
	 * Sanitise submitted general settings.
	 *
	 * @param array $in Raw input.
	 * @return array
	 */
	public static function sanitize_settings( $in ) {
		$statuses = array_keys( wc_get_order_statuses() );
		$valid    = array();
		foreach ( $statuses as $st ) {
			$valid[] = self::strip_wc( $st );
		}
		$accept = array();
		if ( ! empty( $in['accept_statuses'] ) && is_array( $in['accept_statuses'] ) ) {
			foreach ( $in['accept_statuses'] as $st ) {
				$st = self::strip_wc( sanitize_key( $st ) );
				if ( in_array( $st, $valid, true ) ) {
					$accept[] = $st;
				}
			}
		}
		$accept_to = isset( $in['accept_to'] ) ? self::strip_wc( sanitize_key( $in['accept_to'] ) ) : 'processing';
		if ( ! in_array( $accept_to, $valid, true ) ) {
			$accept_to = 'processing';
		}
		$keys = array();
		if ( isset( $in['delivery_meta_keys'] ) ) {
			foreach ( explode( ',', sanitize_text_field( wp_unslash( $in['delivery_meta_keys'] ) ) ) as $k ) {
				$k = trim( $k );
				if ( '' !== $k && preg_match( '/^[A-Za-z0-9_\-\.]+$/', $k ) ) {
					$keys[] = $k;
				}
			}
		}
		return array(
			'poll_interval'      => min( 30, max( 3, (int) ( isset( $in['poll_interval'] ) ? $in['poll_interval'] : 6 ) ) ),
			'sound'              => empty( $in['sound'] ) ? 0 : 1,
			'repeat_alarm'       => empty( $in['repeat_alarm'] ) ? 0 : 1,
			'auto_print'         => empty( $in['auto_print'] ) ? 0 : 1,
			'accept_statuses'    => array_values( array_unique( $accept ) ),
			'accept_to'          => $accept_to,
			'delivery_meta_keys' => implode( ', ', $keys ),
			'retry_max'          => min( 10, max( 1, (int) ( isset( $in['retry_max'] ) ? $in['retry_max'] : 3 ) ) ),
			'retry_delay'        => min( 3600, max( 10, (int) ( isset( $in['retry_delay'] ) ? $in['retry_delay'] : 60 ) ) ),
			'dedupe'             => empty( $in['dedupe'] ) ? 0 : 1,
			'default_printer'    => isset( $in['default_printer'] ) ? sanitize_key( $in['default_printer'] ) : '',
			'default_template'   => isset( $in['default_template'] ) ? sanitize_key( $in['default_template'] ) : '',
			'job_retention_days' => min( 3650, max( 0, (int) ( isset( $in['job_retention_days'] ) ? $in['job_retention_days'] : 30 ) ) ),
			'remove_data'        => empty( $in['remove_data'] ) ? 0 : 1,
		);
	}

	/**
	 * Remove "wc-" prefix.
	 *
	 * @param string $status Status.
	 * @return string
	 */
	public static function strip_wc( $status ) {
		return 0 === strpos( $status, 'wc-' ) ? substr( $status, 3 ) : $status;
	}

	/**
	 * Station token (generated on demand).
	 *
	 * @return string
	 */
	public static function token() {
		$s = self::get();
		if ( empty( $s['station_token'] ) ) {
			self::regenerate_token();
			$s = self::get();
		}
		return $s['station_token'];
	}

	/**
	 * Create a new random station token.
	 *
	 * @return string
	 */
	public static function regenerate_token() {
		$token = wp_generate_password( 32, false, false );
		self::save( array( 'station_token' => $token ) );
		return $token;
	}

	/**
	 * Printer definitions keyed by ID.
	 *
	 * @return array
	 */
	public static function printers() {
		$p = get_option( self::OPT_PRINTERS, array() );
		return is_array( $p ) ? $p : array();
	}

	/**
	 * One printer.
	 *
	 * @param string $id ID.
	 * @return array|null
	 */
	public static function printer( $id ) {
		$all = self::printers();
		return isset( $all[ $id ] ) ? $all[ $id ] : null;
	}

	/**
	 * Printer connection methods.
	 *
	 * @return array<string,string>
	 */
	public static function methods() {
		return array(
			'station_html'   => __( 'Print Station – browser print (any printer, window.print)', 'printpilot' ),
			'station_escpos' => __( 'Print Station – direct ESC/POS (USB / Serial / Bluetooth)', 'printpilot' ),
			'network'        => __( 'Network ESC/POS (WordPress sends to printer IP:9100)', 'printpilot' ),
			'email'          => __( 'Email (print-to-email)', 'printpilot' ),
		);
	}

	/**
	 * Code pages offered in the UI.
	 *
	 * @return array<string,string>
	 */
	public static function codepages() {
		return array(
			'cp437'  => 'CP437 – USA / Standard Europe',
			'cp850'  => 'CP850 – Multilingual Latin 1',
			'cp858'  => 'CP858 – Latin 1 + Euro sign',
			'cp852'  => 'CP852 – Latin 2 (Central Europe)',
			'cp866'  => 'CP866 – Cyrillic',
			'cp1252' => 'WPC1252 – Windows Latin 1',
			'ascii'  => 'ASCII only (transliterate accents)',
		);
	}

	/**
	 * Default printer record.
	 *
	 * @return array
	 */
	public static function printer_defaults() {
		return array(
			'id'             => '',
			'name'           => '',
			'method'         => 'station_html',
			'enabled'        => 1,
			'paper'          => '80',
			'codepage'       => 'cp858',
			'cut'            => 'partial',
			'drawer'         => 0,
			'copies'         => 1,
			'ip'             => '',
			'port'           => 9100,
			'connection'     => 'serial',
			'baud'           => 9600,
			'email'          => '',
			'fallback_email' => '',
		);
	}

	/**
	 * Sanitise submitted printers.
	 *
	 * @param array $rows Raw rows.
	 * @return array
	 */
	public static function sanitize_printers( $rows ) {
		$out = array();
		if ( ! is_array( $rows ) ) {
			return $out;
		}
		$methods = self::methods();
		$cps     = self::codepages();
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$row  = wp_unslash( $row );
			$def  = self::printer_defaults();
			$id   = isset( $row['id'] ) ? sanitize_key( $row['id'] ) : '';
			$name = isset( $row['name'] ) ? sanitize_text_field( $row['name'] ) : '';
			if ( '' === $name ) {
				continue;
			}
			if ( '' === $id ) {
				$id = 'p' . strtolower( wp_generate_password( 6, false, false ) );
			}
			$method = isset( $row['method'] ) && isset( $methods[ $row['method'] ] ) ? $row['method'] : 'station_html';
			$paper  = isset( $row['paper'] ) && in_array( $row['paper'], array( '58', '80', 'a4' ), true ) ? $row['paper'] : '80';
			if ( 'a4' === $paper && in_array( $method, array( 'station_escpos', 'network' ), true ) ) {
				$paper = '80';
			}
			$ip = isset( $row['ip'] ) ? trim( sanitize_text_field( $row['ip'] ) ) : '';
			if ( '' !== $ip && ! preg_match( '/^[A-Za-z0-9\.\-\:\[\]]+$/', $ip ) ) {
				$ip = '';
			}
			$out[ $id ] = array(
				'id'             => $id,
				'name'           => $name,
				'method'         => $method,
				'enabled'        => empty( $row['enabled'] ) ? 0 : 1,
				'paper'          => $paper,
				'codepage'       => isset( $row['codepage'], $cps[ $row['codepage'] ] ) ? $row['codepage'] : $def['codepage'],
				'cut'            => isset( $row['cut'] ) && in_array( $row['cut'], array( 'none', 'partial', 'full' ), true ) ? $row['cut'] : 'partial',
				'drawer'         => empty( $row['drawer'] ) ? 0 : 1,
				'copies'         => min( 10, max( 1, (int) ( isset( $row['copies'] ) ? $row['copies'] : 1 ) ) ),
				'ip'             => $ip,
				'port'           => min( 65535, max( 1, (int) ( isset( $row['port'] ) ? $row['port'] : 9100 ) ) ),
				'connection'     => isset( $row['connection'] ) && in_array( $row['connection'], array( 'serial', 'usb', 'bluetooth' ), true ) ? $row['connection'] : 'serial',
				'baud'           => min( 921600, max( 1200, (int) ( isset( $row['baud'] ) ? $row['baud'] : 9600 ) ) ),
				'email'          => isset( $row['email'] ) ? sanitize_email( $row['email'] ) : '',
				'fallback_email' => isset( $row['fallback_email'] ) ? sanitize_email( $row['fallback_email'] ) : '',
			);
		}
		return $out;
	}

	/**
	 * Template definitions keyed by ID.
	 *
	 * @return array
	 */
	public static function templates() {
		$t = get_option( self::OPT_TEMPLATES, array() );
		return is_array( $t ) ? $t : array();
	}

	/**
	 * One template.
	 *
	 * @param string $id ID.
	 * @return array|null
	 */
	public static function template( $id ) {
		$all = self::templates();
		return isset( $all[ $id ] ) ? $all[ $id ] : null;
	}

	/**
	 * Template types.
	 *
	 * @return array<string,string>
	 */
	public static function template_types() {
		return array(
			'kitchen' => __( 'Kitchen ticket', 'printpilot' ),
			'receipt' => __( 'Receipt', 'printpilot' ),
			'packing' => __( 'Packing slip', 'printpilot' ),
			'custom'  => __( 'Custom', 'printpilot' ),
		);
	}

	/**
	 * Sanitise submitted templates.
	 *
	 * @param array $rows Raw rows.
	 * @return array
	 */
	public static function sanitize_templates( $rows ) {
		$out   = array();
		$types = self::template_types();
		if ( ! is_array( $rows ) ) {
			return $out;
		}
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$row  = wp_unslash( $row );
			$name = isset( $row['name'] ) ? sanitize_text_field( $row['name'] ) : '';
			if ( '' === $name ) {
				continue;
			}
			$id = isset( $row['id'] ) ? sanitize_key( $row['id'] ) : '';
			if ( '' === $id ) {
				$id = 't' . strtolower( wp_generate_password( 6, false, false ) );
			}
			$body = isset( $row['body'] ) ? str_replace( array( "\r\n", "\r" ), "\n", (string) $row['body'] ) : '';
			$body = wp_check_invalid_utf8( $body );
			$body = trim( preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $body ) );
			$out[ $id ] = array(
				'id'          => $id,
				'name'        => $name,
				'type'        => isset( $row['type'], $types[ $row['type'] ] ) ? $row['type'] : 'custom',
				'body'        => mb_substr( $body, 0, 6000 ),
				'show_prices' => empty( $row['show_prices'] ) ? 0 : 1,
				'show_sku'    => empty( $row['show_sku'] ) ? 0 : 1,
				'show_meta'   => empty( $row['show_meta'] ) ? 0 : 1,
				'item_size'   => isset( $row['item_size'] ) && in_array( (string) $row['item_size'], array( '1', '2', '3' ), true ) ? (int) $row['item_size'] : 1,
			);
		}
		return $out;
	}

	/**
	 * Routing rules (list).
	 *
	 * @return array
	 */
	public static function rules() {
		$r = get_option( self::OPT_RULES, array() );
		return is_array( $r ) ? array_values( $r ) : array();
	}

	/**
	 * Sanitise submitted rules.
	 *
	 * @param array $rows Raw rows.
	 * @return array
	 */
	public static function sanitize_rules( $rows ) {
		$out = array();
		if ( ! is_array( $rows ) ) {
			return $out;
		}
		$valid_status = array();
		foreach ( array_keys( wc_get_order_statuses() ) as $st ) {
			$valid_status[] = self::strip_wc( $st );
		}
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$row  = wp_unslash( $row );
			$name = isset( $row['name'] ) ? sanitize_text_field( $row['name'] ) : '';
			$pr   = isset( $row['printer'] ) ? sanitize_key( $row['printer'] ) : '';
			if ( '' === $pr ) {
				continue;
			}
			if ( '' === $name ) {
				$name = __( 'Rule', 'printpilot' );
			}
			$statuses = array();
			if ( ! empty( $row['statuses'] ) && is_array( $row['statuses'] ) ) {
				foreach ( $row['statuses'] as $st ) {
					$st = self::strip_wc( sanitize_key( $st ) );
					if ( in_array( $st, $valid_status, true ) ) {
						$statuses[] = $st;
					}
				}
			}
			$cats = array();
			if ( ! empty( $row['categories'] ) && is_array( $row['categories'] ) ) {
				$cats = array_values( array_filter( array_map( 'absint', $row['categories'] ) ) );
			}
			$id = isset( $row['id'] ) ? sanitize_key( $row['id'] ) : '';
			if ( '' === $id ) {
				$id = 'r' . strtolower( wp_generate_password( 6, false, false ) );
			}
			$out[] = array(
				'id'               => $id,
				'name'             => $name,
				'enabled'          => empty( $row['enabled'] ) ? 0 : 1,
				'statuses'         => array_values( array_unique( $statuses ) ),
				'categories'       => $cats,
				'shipping_methods' => self::clean_list( isset( $row['shipping_methods'] ) ? $row['shipping_methods'] : '' ),
				'payment_methods'  => self::clean_list( isset( $row['payment_methods'] ) ? $row['payment_methods'] : '' ),
				'order_type'       => isset( $row['order_type'] ) && in_array( $row['order_type'], array( 'any', 'pickup', 'delivery', 'none' ), true ) ? $row['order_type'] : 'any',
				'meta_key'         => isset( $row['meta_key'] ) ? preg_replace( '/[^A-Za-z0-9_\-\.]/', '', (string) $row['meta_key'] ) : '',
				'meta_value'       => isset( $row['meta_value'] ) ? sanitize_text_field( $row['meta_value'] ) : '',
				'printer'          => $pr,
				'template'         => isset( $row['template'] ) ? sanitize_key( $row['template'] ) : '',
				'copies'           => min( 10, max( 1, (int) ( isset( $row['copies'] ) ? $row['copies'] : 1 ) ) ),
				'split_items'      => empty( $row['split_items'] ) ? 0 : 1,
				'stop'             => empty( $row['stop'] ) ? 0 : 1,
			);
		}
		return $out;
	}

	/**
	 * Comma-separated list to clean array.
	 *
	 * @param string $s Input.
	 * @return string[]
	 */
	protected static function clean_list( $s ) {
		$out = array();
		foreach ( explode( ',', sanitize_text_field( (string) $s ) ) as $p ) {
			$p = trim( $p );
			if ( '' !== $p && preg_match( '/^[A-Za-z0-9_\-\.:]+$/', $p ) ) {
				$out[] = $p;
			}
		}
		return $out;
	}

	/**
	 * Heartbeat from a station.
	 *
	 * @param string $name Station name.
	 * @param array  $info Extra info.
	 * @return void
	 */
	public static function touch_station( $name, $info = array() ) {
		$all = get_option( self::OPT_STATIONS, array() );
		if ( ! is_array( $all ) ) {
			$all = array();
		}
		$key = md5( $name );
		foreach ( $all as $k => $v ) {
			if ( empty( $v['seen'] ) || $v['seen'] < time() - DAY_IN_SECONDS ) {
				unset( $all[ $k ] );
			}
		}
		$all[ $key ] = array(
			'name'    => $name,
			'seen'    => time(),
			'ready'   => isset( $info['ready'] ) ? array_map( 'sanitize_key', (array) $info['ready'] ) : array(),
			'printers' => isset( $info['printers'] ) ? array_map( 'sanitize_key', (array) $info['printers'] ) : array(),
		);
		update_option( self::OPT_STATIONS, $all, false );
	}

	/**
	 * Stations seen recently.
	 *
	 * @return array
	 */
	public static function stations() {
		$all = get_option( self::OPT_STATIONS, array() );
		return is_array( $all ) ? $all : array();
	}
}
