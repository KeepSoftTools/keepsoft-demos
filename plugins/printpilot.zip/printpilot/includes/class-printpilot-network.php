<?php
/**
 * Server-side transports: raw TCP (ESC/POS on port 9100) and email.
 *
 * @package PrintPilot
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Network and email delivery.
 */
class PrintPilot_Network {

	/**
	 * Send a job using its printer's server-side method.
	 *
	 * @param object $job Job row.
	 * @return true|WP_Error
	 */
	public static function dispatch( $job ) {
		$printer = PrintPilot_Settings::printer( $job->printer_id );
		if ( ! $printer ) {
			return new WP_Error( 'pp_no_printer', __( 'Printer no longer exists.', 'printpilot' ) );
		}
		if ( empty( $printer['enabled'] ) ) {
			return new WP_Error( 'pp_disabled', __( 'Printer is disabled.', 'printpilot' ) );
		}
		if ( 'email' === $printer['method'] ) {
			if ( empty( $printer['email'] ) ) {
				return new WP_Error( 'pp_no_email', __( 'No email address set for this printer.', 'printpilot' ) );
			}
			return self::email_job( $job, $printer['email'], false );
		}
		if ( 'network' !== $printer['method'] ) {
			return new WP_Error( 'pp_method', __( 'This printer is handled by the Print Station.', 'printpilot' ) );
		}
		$doc = PrintPilot_Ticket::doc_for_job( $job );
		if ( is_wp_error( $doc ) ) {
			return $doc;
		}
		$bytes = str_repeat( PrintPilot_ESCPOS::encode( $doc ), max( 1, (int) $job->copies ) );
		return self::send( $printer['ip'], (int) $printer['port'], $bytes );
	}

	/**
	 * Send raw bytes to host:port.
	 *
	 * @param string $host    IP or hostname.
	 * @param int    $port    TCP port.
	 * @param string $bytes   Data.
	 * @param int    $timeout Connect timeout in seconds.
	 * @return true|WP_Error
	 */
	public static function send( $host, $port, $bytes, $timeout = 4 ) {
		$host = trim( (string) $host );
		$port = (int) $port;
		if ( '' === $host || ! preg_match( '/^[A-Za-z0-9\.\-\:\[\]]+$/', $host ) ) {
			return new WP_Error( 'pp_host', __( 'Printer IP address / hostname is missing or invalid.', 'printpilot' ) );
		}
		if ( $port < 1 || $port > 65535 ) {
			return new WP_Error( 'pp_port', __( 'Invalid printer port.', 'printpilot' ) );
		}
		if ( ! function_exists( 'fsockopen' ) ) {
			return new WP_Error( 'pp_fsockopen', __( 'fsockopen() is disabled on this server. Use the Print Station instead.', 'printpilot' ) );
		}
		$errno = 0;
		$errstr = '';
		// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		$fp = @fsockopen( $host, $port, $errno, $errstr, $timeout );
		if ( ! $fp ) {
			/* translators: 1: host, 2: port, 3: error text */
			return new WP_Error( 'pp_connect', sprintf( __( 'Could not connect to %1$s:%2$d (%3$s).', 'printpilot' ), $host, $port, $errstr ? $errstr : 'error ' . $errno ) );
		}
		stream_set_timeout( $fp, 5 );
		$len     = strlen( $bytes );
		$written = 0;
		while ( $written < $len ) {
			// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			$n = @fwrite( $fp, substr( $bytes, $written, 4096 ) );
			if ( false === $n || 0 === $n ) {
				fclose( $fp ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
				return new WP_Error( 'pp_write', __( 'Connection to the printer was interrupted while sending.', 'printpilot' ) );
			}
			$written += $n;
		}
		fflush( $fp );
		usleep( 150000 );
		fclose( $fp ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		return true;
	}

	/**
	 * Email a ticket as HTML.
	 *
	 * @param object $job      Job.
	 * @param string $to       Recipient.
	 * @param bool   $fallback Whether this is a fallback for a failed printer.
	 * @return true|WP_Error
	 */
	public static function email_job( $job, $to, $fallback = false ) {
		if ( ! is_email( $to ) ) {
			return new WP_Error( 'pp_email', __( 'Invalid email address.', 'printpilot' ) );
		}
		$doc = PrintPilot_Ticket::doc_for_job( $job );
		if ( is_wp_error( $doc ) ) {
			return $doc;
		}
		$order_no = '';
		if ( (int) $job->order_id > 0 ) {
			$order = wc_get_order( (int) $job->order_id );
			if ( $order ) {
				$order_no = $order->get_order_number();
			}
		}
		/* translators: 1: site name, 2: order number */
		$subject = sprintf( __( '[%1$s] Print ticket – order #%2$s', 'printpilot' ), wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), $order_no ? $order_no : __( 'test', 'printpilot' ) );
		if ( $fallback ) {
			$subject = __( '[Printer offline] ', 'printpilot' ) . $subject;
		}
		$paper = isset( $doc['paper'] ) ? $doc['paper'] : '80';
		$html  = '<html><body style="margin:0;padding:12px;background:#f3f3f3"><style>' . PrintPilot_Ticket::css( $paper ) . '</style>' . PrintPilot_Ticket::render_html( $doc ) . '</body></html>';
		$ok    = wp_mail( $to, $subject, $html, array( 'Content-Type: text/html; charset=UTF-8' ) );
		return $ok ? true : new WP_Error( 'pp_mail', __( 'wp_mail() failed to send the ticket.', 'printpilot' ) );
	}
}
