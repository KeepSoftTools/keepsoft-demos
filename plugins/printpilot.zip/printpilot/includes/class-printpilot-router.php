<?php
/**
 * Order triggers and routing rules.
 *
 * @package PrintPilot
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Decides which printer and template an order goes to.
 */
class PrintPilot_Router {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'woocommerce_order_status_changed', array( __CLASS__, 'on_status_changed' ), 20, 4 );
	}

	/**
	 * Status change trigger.
	 *
	 * @param int           $order_id Order ID.
	 * @param string        $from     Old status.
	 * @param string        $to       New status.
	 * @param WC_Order|null $order    Order.
	 * @return void
	 */
	public static function on_status_changed( $order_id, $from, $to, $order = null ) {
		if ( ! $order instanceof WC_Order ) {
			$order = wc_get_order( $order_id );
		}
		if ( ! $order ) {
			return;
		}
		$to = PrintPilot_Settings::strip_wc( $to );
		self::run_auto( $order, $to );
	}

	/**
	 * Create jobs for rules triggered by a status.
	 *
	 * @param WC_Order $order  Order.
	 * @param string   $status Status slug without wc- prefix.
	 * @return int[] Job IDs.
	 */
	public static function run_auto( $order, $status ) {
		$ids    = array();
		$dedupe = (int) PrintPilot_Settings::get_one( 'dedupe', 1 );
		$done   = $order->get_meta( '_pp_auto', true );
		$done   = is_array( $done ) ? $done : array();
		$dirty  = false;
		foreach ( self::plan( $order, $status, true ) as $plan ) {
			$key = $status . '|' . $plan['rule'];
			if ( $dedupe && in_array( $key, $done, true ) ) {
				continue;
			}
			$id = PrintPilot_Jobs::create(
				array(
					'order_id'    => $order->get_id(),
					'printer_id'  => $plan['printer'],
					'template_id' => $plan['template'],
					'copies'      => $plan['copies'],
					'source'      => 'auto:' . $status,
					'meta'        => $plan['meta'],
				)
			);
			if ( ! is_wp_error( $id ) ) {
				$ids[]  = $id;
				$done[] = $key;
				$dirty  = true;
			}
		}
		if ( $dirty ) {
			$order->update_meta_data( '_pp_auto', $done );
			$order->save_meta_data();
		}
		return $ids;
	}

	/**
	 * Work out which rules apply.
	 *
	 * @param WC_Order    $order        Order.
	 * @param string|null $status       Status to match (when $check_status).
	 * @param bool        $check_status Whether to require the rule's status list to include $status.
	 * @return array[] Plans: rule, printer, template, copies, meta.
	 */
	public static function plan( $order, $status = null, $check_status = true ) {
		$printers = PrintPilot_Settings::printers();
		$plans    = array();
		foreach ( PrintPilot_Settings::rules() as $rule ) {
			if ( empty( $rule['enabled'] ) ) {
				continue;
			}
			if ( $check_status && ! in_array( $status, (array) $rule['statuses'], true ) ) {
				continue;
			}
			if ( empty( $printers[ $rule['printer'] ] ) || empty( $printers[ $rule['printer'] ]['enabled'] ) ) {
				continue;
			}
			if ( ! self::rule_matches( $rule, $order ) ) {
				continue;
			}
			$tpl = $rule['template'];
			if ( ! PrintPilot_Settings::template( $tpl ) ) {
				continue;
			}
			$meta = array( 'rule' => $rule['id'] );
			if ( ! empty( $rule['split_items'] ) && ! empty( $rule['categories'] ) ) {
				$meta['cats'] = array_map( 'intval', $rule['categories'] );
			}
			$plans[] = array(
				'rule'     => $rule['id'],
				'printer'  => $rule['printer'],
				'template' => $tpl,
				'copies'   => (int) $rule['copies'],
				'meta'     => $meta,
			);
			if ( ! empty( $rule['stop'] ) ) {
				break;
			}
		}
		return apply_filters( 'printpilot_plan', $plans, $order, $status );
	}

	/**
	 * Does a rule's condition set match an order?
	 *
	 * @param array    $rule  Rule.
	 * @param WC_Order $order Order.
	 * @return bool
	 */
	public static function rule_matches( $rule, $order ) {
		if ( ! empty( $rule['categories'] ) ) {
			$found = false;
			foreach ( $order->get_items() as $item ) {
				if ( $item instanceof WC_Order_Item_Product && array_intersect( array_map( 'intval', $rule['categories'] ), array_map( 'intval', wc_get_product_cat_ids( $item->get_product_id() ) ) ) ) {
					$found = true;
					break;
				}
			}
			if ( ! $found ) {
				return false;
			}
		}
		if ( ! empty( $rule['shipping_methods'] ) ) {
			$found = false;
			foreach ( $order->get_shipping_methods() as $sm ) {
				$mid = $sm->get_method_id();
				$ins = $mid . ':' . $sm->get_instance_id();
				if ( in_array( $mid, $rule['shipping_methods'], true ) || in_array( $ins, $rule['shipping_methods'], true ) ) {
					$found = true;
					break;
				}
			}
			if ( ! $found ) {
				return false;
			}
		}
		if ( ! empty( $rule['payment_methods'] ) && ! in_array( $order->get_payment_method(), $rule['payment_methods'], true ) ) {
			return false;
		}
		if ( ! empty( $rule['order_type'] ) && 'any' !== $rule['order_type'] && PrintPilot_Ticket::order_type( $order ) !== $rule['order_type'] ) {
			return false;
		}
		if ( ! empty( $rule['meta_key'] ) ) {
			$v = $order->get_meta( $rule['meta_key'], true );
			$v = is_scalar( $v ) ? (string) $v : '';
			if ( '' === (string) $rule['meta_value'] ) {
				if ( '' === $v ) {
					return false;
				}
			} elseif ( 0 !== strcasecmp( $v, (string) $rule['meta_value'] ) ) {
				return false;
			}
		}
		return (bool) apply_filters( 'printpilot_rule_matches', true, $rule, $order );
	}

	/**
	 * Print an order using routing rules (any status); falls back to the default printer/template.
	 *
	 * @param WC_Order $order  Order.
	 * @param string   $source Source label.
	 * @return int[]|WP_Error Job IDs.
	 */
	public static function print_with_rules( $order, $source = 'manual' ) {
		$plans = self::plan( $order, null, false );
		$ids   = array();
		if ( ! $plans ) {
			$pr = PrintPilot_Settings::get_one( 'default_printer' );
			$tp = PrintPilot_Settings::get_one( 'default_template' );
			$id = PrintPilot_Jobs::create(
				array(
					'order_id'    => $order->get_id(),
					'printer_id'  => $pr,
					'template_id' => $tp,
					'source'      => $source,
				)
			);
			return is_wp_error( $id ) ? $id : array( $id );
		}
		foreach ( $plans as $plan ) {
			$id = PrintPilot_Jobs::create(
				array(
					'order_id'    => $order->get_id(),
					'printer_id'  => $plan['printer'],
					'template_id' => $plan['template'],
					'copies'      => $plan['copies'],
					'source'      => $source,
					'meta'        => $plan['meta'],
				)
			);
			if ( ! is_wp_error( $id ) ) {
				$ids[] = $id;
			}
		}
		return $ids;
	}

	/**
	 * Print an order on a chosen printer with a chosen template.
	 *
	 * @param WC_Order $order    Order.
	 * @param string   $printer  Printer ID.
	 * @param string   $template Template ID.
	 * @param int      $copies   Copies (0 = printer default).
	 * @param string   $source   Source label.
	 * @return int|WP_Error
	 */
	public static function print_manual( $order, $printer, $template, $copies = 0, $source = 'manual' ) {
		return PrintPilot_Jobs::create(
			array(
				'order_id'    => $order->get_id(),
				'printer_id'  => $printer,
				'template_id' => $template,
				'copies'      => $copies,
				'source'      => $source,
			)
		);
	}

	/**
	 * Queue a test print.
	 *
	 * @param string $printer_id  Printer.
	 * @param string $template_id Template (optional).
	 * @return int|WP_Error
	 */
	public static function test_print( $printer_id, $template_id = '' ) {
		if ( '' === $template_id || ! PrintPilot_Settings::template( $template_id ) ) {
			$template_id = PrintPilot_Settings::get_one( 'default_template' );
			if ( ! PrintPilot_Settings::template( $template_id ) ) {
				$all         = array_keys( PrintPilot_Settings::templates() );
				$template_id = $all ? $all[0] : '';
			}
		}
		return PrintPilot_Jobs::create(
			array(
				'order_id'    => 0,
				'printer_id'  => $printer_id,
				'template_id' => $template_id,
				'copies'      => 1,
				'source'      => 'test',
				'meta'        => array( 'test' => 1 ),
			)
		);
	}
}
