<?php
/**
 * ESC/POS encoder (PHP). Mirrors assets/js/pp-escpos.js byte for byte.
 *
 * @package PrintPilot
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Converts a ticket document into ESC/POS bytes.
 */
class PrintPilot_ESCPOS {

	/**
	 * Upper half (0x80-0xFF) of supported code pages. U+FFFD marks undefined positions.
	 *
	 * @return array<string,string>
	 */
	public static function tables() {
		static $t = null;
		if ( null === $t ) {
			$t = array(
				'cp437' => "\u{C7}\u{FC}\u{E9}\u{E2}\u{E4}\u{E0}\u{E5}\u{E7}\u{EA}\u{EB}\u{E8}\u{EF}\u{EE}\u{EC}\u{C4}\u{C5}\u{C9}\u{E6}\u{C6}\u{F4}\u{F6}\u{F2}\u{FB}\u{F9}\u{FF}\u{D6}\u{DC}\u{A2}\u{A3}\u{A5}\u{20A7}\u{192}\u{E1}\u{ED}\u{F3}\u{FA}\u{F1}\u{D1}\u{AA}\u{BA}\u{BF}\u{2310}\u{AC}\u{BD}\u{BC}\u{A1}\u{AB}\u{BB}\u{2591}\u{2592}\u{2593}\u{2502}\u{2524}\u{2561}\u{2562}\u{2556}\u{2555}\u{2563}\u{2551}\u{2557}\u{255D}\u{255C}\u{255B}\u{2510}\u{2514}\u{2534}\u{252C}\u{251C}\u{2500}\u{253C}\u{255E}\u{255F}\u{255A}\u{2554}\u{2569}\u{2566}\u{2560}\u{2550}\u{256C}\u{2567}\u{2568}\u{2564}\u{2565}\u{2559}\u{2558}\u{2552}\u{2553}\u{256B}\u{256A}\u{2518}\u{250C}\u{2588}\u{2584}\u{258C}\u{2590}\u{2580}\u{3B1}\u{DF}\u{393}\u{3C0}\u{3A3}\u{3C3}\u{B5}\u{3C4}\u{3A6}\u{398}\u{3A9}\u{3B4}\u{221E}\u{3C6}\u{3B5}\u{2229}\u{2261}\u{B1}\u{2265}\u{2264}\u{2320}\u{2321}\u{F7}\u{2248}\u{B0}\u{2219}\u{B7}\u{221A}\u{207F}\u{B2}\u{25A0}\u{A0}",
				'cp850' => "\u{C7}\u{FC}\u{E9}\u{E2}\u{E4}\u{E0}\u{E5}\u{E7}\u{EA}\u{EB}\u{E8}\u{EF}\u{EE}\u{EC}\u{C4}\u{C5}\u{C9}\u{E6}\u{C6}\u{F4}\u{F6}\u{F2}\u{FB}\u{F9}\u{FF}\u{D6}\u{DC}\u{F8}\u{A3}\u{D8}\u{D7}\u{192}\u{E1}\u{ED}\u{F3}\u{FA}\u{F1}\u{D1}\u{AA}\u{BA}\u{BF}\u{AE}\u{AC}\u{BD}\u{BC}\u{A1}\u{AB}\u{BB}\u{2591}\u{2592}\u{2593}\u{2502}\u{2524}\u{C1}\u{C2}\u{C0}\u{A9}\u{2563}\u{2551}\u{2557}\u{255D}\u{A2}\u{A5}\u{2510}\u{2514}\u{2534}\u{252C}\u{251C}\u{2500}\u{253C}\u{E3}\u{C3}\u{255A}\u{2554}\u{2569}\u{2566}\u{2560}\u{2550}\u{256C}\u{A4}\u{F0}\u{D0}\u{CA}\u{CB}\u{C8}\u{131}\u{CD}\u{CE}\u{CF}\u{2518}\u{250C}\u{2588}\u{2584}\u{A6}\u{CC}\u{2580}\u{D3}\u{DF}\u{D4}\u{D2}\u{F5}\u{D5}\u{B5}\u{FE}\u{DE}\u{DA}\u{DB}\u{D9}\u{FD}\u{DD}\u{AF}\u{B4}\u{AD}\u{B1}\u{2017}\u{BE}\u{B6}\u{A7}\u{F7}\u{B8}\u{B0}\u{A8}\u{B7}\u{B9}\u{B3}\u{B2}\u{25A0}\u{A0}",
				'cp858' => "\u{C7}\u{FC}\u{E9}\u{E2}\u{E4}\u{E0}\u{E5}\u{E7}\u{EA}\u{EB}\u{E8}\u{EF}\u{EE}\u{EC}\u{C4}\u{C5}\u{C9}\u{E6}\u{C6}\u{F4}\u{F6}\u{F2}\u{FB}\u{F9}\u{FF}\u{D6}\u{DC}\u{F8}\u{A3}\u{D8}\u{D7}\u{192}\u{E1}\u{ED}\u{F3}\u{FA}\u{F1}\u{D1}\u{AA}\u{BA}\u{BF}\u{AE}\u{AC}\u{BD}\u{BC}\u{A1}\u{AB}\u{BB}\u{2591}\u{2592}\u{2593}\u{2502}\u{2524}\u{C1}\u{C2}\u{C0}\u{A9}\u{2563}\u{2551}\u{2557}\u{255D}\u{A2}\u{A5}\u{2510}\u{2514}\u{2534}\u{252C}\u{251C}\u{2500}\u{253C}\u{E3}\u{C3}\u{255A}\u{2554}\u{2569}\u{2566}\u{2560}\u{2550}\u{256C}\u{A4}\u{F0}\u{D0}\u{CA}\u{CB}\u{C8}\u{20AC}\u{CD}\u{CE}\u{CF}\u{2518}\u{250C}\u{2588}\u{2584}\u{A6}\u{CC}\u{2580}\u{D3}\u{DF}\u{D4}\u{D2}\u{F5}\u{D5}\u{B5}\u{FE}\u{DE}\u{DA}\u{DB}\u{D9}\u{FD}\u{DD}\u{AF}\u{B4}\u{AD}\u{B1}\u{2017}\u{BE}\u{B6}\u{A7}\u{F7}\u{B8}\u{B0}\u{A8}\u{B7}\u{B9}\u{B3}\u{B2}\u{25A0}\u{A0}",
				'cp852' => "\u{C7}\u{FC}\u{E9}\u{E2}\u{E4}\u{16F}\u{107}\u{E7}\u{142}\u{EB}\u{150}\u{151}\u{EE}\u{179}\u{C4}\u{106}\u{C9}\u{139}\u{13A}\u{F4}\u{F6}\u{13D}\u{13E}\u{15A}\u{15B}\u{D6}\u{DC}\u{164}\u{165}\u{141}\u{D7}\u{10D}\u{E1}\u{ED}\u{F3}\u{FA}\u{104}\u{105}\u{17D}\u{17E}\u{118}\u{119}\u{AC}\u{17A}\u{10C}\u{15F}\u{AB}\u{BB}\u{2591}\u{2592}\u{2593}\u{2502}\u{2524}\u{C1}\u{C2}\u{11A}\u{15E}\u{2563}\u{2551}\u{2557}\u{255D}\u{17B}\u{17C}\u{2510}\u{2514}\u{2534}\u{252C}\u{251C}\u{2500}\u{253C}\u{102}\u{103}\u{255A}\u{2554}\u{2569}\u{2566}\u{2560}\u{2550}\u{256C}\u{A4}\u{111}\u{110}\u{10E}\u{CB}\u{10F}\u{147}\u{CD}\u{CE}\u{11B}\u{2518}\u{250C}\u{2588}\u{2584}\u{162}\u{16E}\u{2580}\u{D3}\u{DF}\u{D4}\u{143}\u{144}\u{148}\u{160}\u{161}\u{154}\u{DA}\u{155}\u{170}\u{FD}\u{DD}\u{163}\u{B4}\u{AD}\u{2DD}\u{2DB}\u{2C7}\u{2D8}\u{A7}\u{F7}\u{B8}\u{B0}\u{A8}\u{2D9}\u{171}\u{158}\u{159}\u{25A0}\u{A0}",
				'cp866' => "\u{410}\u{411}\u{412}\u{413}\u{414}\u{415}\u{416}\u{417}\u{418}\u{419}\u{41A}\u{41B}\u{41C}\u{41D}\u{41E}\u{41F}\u{420}\u{421}\u{422}\u{423}\u{424}\u{425}\u{426}\u{427}\u{428}\u{429}\u{42A}\u{42B}\u{42C}\u{42D}\u{42E}\u{42F}\u{430}\u{431}\u{432}\u{433}\u{434}\u{435}\u{436}\u{437}\u{438}\u{439}\u{43A}\u{43B}\u{43C}\u{43D}\u{43E}\u{43F}\u{2591}\u{2592}\u{2593}\u{2502}\u{2524}\u{2561}\u{2562}\u{2556}\u{2555}\u{2563}\u{2551}\u{2557}\u{255D}\u{255C}\u{255B}\u{2510}\u{2514}\u{2534}\u{252C}\u{251C}\u{2500}\u{253C}\u{255E}\u{255F}\u{255A}\u{2554}\u{2569}\u{2566}\u{2560}\u{2550}\u{256C}\u{2567}\u{2568}\u{2564}\u{2565}\u{2559}\u{2558}\u{2552}\u{2553}\u{256B}\u{256A}\u{2518}\u{250C}\u{2588}\u{2584}\u{258C}\u{2590}\u{2580}\u{440}\u{441}\u{442}\u{443}\u{444}\u{445}\u{446}\u{447}\u{448}\u{449}\u{44A}\u{44B}\u{44C}\u{44D}\u{44E}\u{44F}\u{401}\u{451}\u{404}\u{454}\u{407}\u{457}\u{40E}\u{45E}\u{B0}\u{2219}\u{B7}\u{221A}\u{2116}\u{A4}\u{25A0}\u{A0}",
				'cp1252' => "\u{20AC}\u{FFFD}\u{201A}\u{192}\u{201E}\u{2026}\u{2020}\u{2021}\u{2C6}\u{2030}\u{160}\u{2039}\u{152}\u{FFFD}\u{17D}\u{FFFD}\u{FFFD}\u{2018}\u{2019}\u{201C}\u{201D}\u{2022}\u{2013}\u{2014}\u{2DC}\u{2122}\u{161}\u{203A}\u{153}\u{FFFD}\u{17E}\u{178}\u{A0}\u{A1}\u{A2}\u{A3}\u{A4}\u{A5}\u{A6}\u{A7}\u{A8}\u{A9}\u{AA}\u{AB}\u{AC}\u{AD}\u{AE}\u{AF}\u{B0}\u{B1}\u{B2}\u{B3}\u{B4}\u{B5}\u{B6}\u{B7}\u{B8}\u{B9}\u{BA}\u{BB}\u{BC}\u{BD}\u{BE}\u{BF}\u{C0}\u{C1}\u{C2}\u{C3}\u{C4}\u{C5}\u{C6}\u{C7}\u{C8}\u{C9}\u{CA}\u{CB}\u{CC}\u{CD}\u{CE}\u{CF}\u{D0}\u{D1}\u{D2}\u{D3}\u{D4}\u{D5}\u{D6}\u{D7}\u{D8}\u{D9}\u{DA}\u{DB}\u{DC}\u{DD}\u{DE}\u{DF}\u{E0}\u{E1}\u{E2}\u{E3}\u{E4}\u{E5}\u{E6}\u{E7}\u{E8}\u{E9}\u{EA}\u{EB}\u{EC}\u{ED}\u{EE}\u{EF}\u{F0}\u{F1}\u{F2}\u{F3}\u{F4}\u{F5}\u{F6}\u{F7}\u{F8}\u{F9}\u{FA}\u{FB}\u{FC}\u{FD}\u{FE}\u{FF}",
			);
		}
		return $t;
	}

	/**
	 * ESC t selector per code page.
	 *
	 * @return array<string,int>
	 */
	public static function codepages() {
		return array(
			'cp437'  => 0,
			'cp850'  => 2,
			'cp852'  => 18,
			'cp858'  => 19,
			'cp866'  => 17,
			'cp1252' => 16,
			'ascii'  => 0,
		);
	}

	/**
	 * Best-effort replacements for characters missing from a code page.
	 *
	 * @return array<string,string>
	 */
	protected static function fallback() {
		return array(
			"\u{2018}" => "'",
			"\u{2019}" => "'",
			"\u{201A}" => ',',
			"\u{201C}" => '"',
			"\u{201D}" => '"',
			"\u{201E}" => '"',
			"\u{2013}" => '-',
			"\u{2014}" => '-',
			"\u{2026}" => '...',
			"\u{2022}" => '*',
			"\u{2122}" => '(TM)',
			"\u{20AC}" => 'EUR',
			"\u{00A0}" => ' ',
			"\u{00D7}" => 'x',
			"\u{2212}" => '-',
			"\u{00B7}" => '.',
		);
	}

	/**
	 * Reverse lookup (char => byte) for a code page.
	 *
	 * @param string $cp Code page key.
	 * @return array<string,int>
	 */
	protected static function char_map( $cp ) {
		static $cache = array();
		if ( isset( $cache[ $cp ] ) ) {
			return $cache[ $cp ];
		}
		$map    = array();
		$tables = self::tables();
		if ( isset( $tables[ $cp ] ) ) {
			$chars = preg_split( '//u', $tables[ $cp ], -1, PREG_SPLIT_NO_EMPTY );
			foreach ( $chars as $i => $ch ) {
				if ( "\u{FFFD}" !== $ch ) {
					$map[ $ch ] = 128 + $i;
				}
			}
		}
		$cache[ $cp ] = $map;
		return $map;
	}

	/**
	 * Strip diacritics from one character when possible.
	 *
	 * @param string $ch Character.
	 * @return string|null
	 */
	protected static function strip_accent( $ch ) {
		if ( class_exists( 'Normalizer' ) ) {
			$d = Normalizer::normalize( $ch, Normalizer::FORM_D );
			if ( is_string( $d ) ) {
				$d = preg_replace( '/[\x{0300}-\x{036f}]/u', '', $d );
				if ( '' !== $d && ord( $d[0] ) < 128 ) {
					return $d;
				}
			}
		}
		return null;
	}

	/**
	 * Encode a UTF-8 string to an array of byte values for the given code page.
	 *
	 * @param string $str UTF-8 text.
	 * @param string $cp  Code page key.
	 * @return int[]
	 */
	public static function encode_text( $str, $cp ) {
		$out   = array();
		$map   = 'ascii' === $cp ? array() : self::char_map( $cp );
		$fb    = self::fallback();
		$chars = preg_split( '//u', (string) $str, -1, PREG_SPLIT_NO_EMPTY );
		if ( false === $chars ) {
			$chars = str_split( preg_replace( '/[^\x20-\x7e]/', '?', (string) $str ) );
		}
		foreach ( $chars as $ch ) {
			$code = self::ord_utf8( $ch );
			if ( 10 === $code || 13 === $code ) {
				continue;
			}
			if ( $code >= 32 && $code < 127 ) {
				$out[] = $code;
				continue;
			}
			if ( isset( $map[ $ch ] ) ) {
				$out[] = $map[ $ch ];
				continue;
			}
			$f = isset( $fb[ $ch ] ) ? $fb[ $ch ] : self::strip_accent( $ch );
			if ( null === $f ) {
				$f = '?';
			}
			$n = strlen( $f );
			for ( $j = 0; $j < $n; $j++ ) {
				$a     = ord( $f[ $j ] );
				$out[] = ( $a < 127 && $a >= 32 ) ? $a : 63;
			}
		}
		return $out;
	}

	/**
	 * Code point of a single UTF-8 character.
	 *
	 * @param string $ch Character.
	 * @return int
	 */
	protected static function ord_utf8( $ch ) {
		$l = strlen( $ch );
		if ( 1 === $l ) {
			return ord( $ch );
		}
		$o = ord( $ch[0] );
		if ( 2 === $l ) {
			return ( ( $o & 0x1F ) << 6 ) | ( ord( $ch[1] ) & 0x3F );
		}
		if ( 3 === $l ) {
			return ( ( $o & 0x0F ) << 12 ) | ( ( ord( $ch[1] ) & 0x3F ) << 6 ) | ( ord( $ch[2] ) & 0x3F );
		}
		return ( ( $o & 0x07 ) << 18 ) | ( ( ord( $ch[1] ) & 0x3F ) << 12 ) | ( ( ord( $ch[2] ) & 0x3F ) << 6 ) | ( ord( $ch[3] ) & 0x3F );
	}

	/**
	 * Printed length of a string.
	 *
	 * @param string $str Text.
	 * @param string $cp  Code page.
	 * @return int
	 */
	protected static function text_len( $str, $cp ) {
		return count( self::encode_text( $str, $cp ) );
	}

	/**
	 * Word wrap. Leading spaces are kept as an indent.
	 *
	 * @param string $text  Text.
	 * @param int    $width Width in characters.
	 * @param string $cp    Code page.
	 * @return string[]
	 */
	public static function wrap( $text, $width, $cp ) {
		$text   = (string) $text;
		$width  = max( 1, (int) $width );
		$indent = 0;
		if ( preg_match( '/^ +/', $text, $m ) && strlen( $m[0] ) < $width - 1 ) {
			$indent = strlen( $m[0] );
			$text   = substr( $text, $indent );
		}
		$lines = self::wrap_core( $text, $width - $indent, $cp );
		if ( $indent ) {
			$pre   = str_repeat( ' ', $indent );
			$lines = array_map(
				function ( $l ) use ( $pre ) {
					return $pre . $l;
				},
				$lines
			);
		}
		return $lines;
	}

	/**
	 * Word wrap without indent handling.
	 *
	 * @param string $text  Text.
	 * @param int    $width Width.
	 * @param string $cp    Code page.
	 * @return string[]
	 */
	protected static function wrap_core( $text, $width, $cp ) {
		$lines = array();
		$line  = '';
		foreach ( explode( ' ', $text ) as $w ) {
			while ( self::text_len( $w, $cp ) > $width ) {
				if ( '' !== $line ) {
					$lines[] = $line;
					$line    = '';
				}
				$chars   = preg_split( '//u', $w, -1, PREG_SPLIT_NO_EMPTY );
				$lines[] = implode( '', array_slice( $chars, 0, $width ) );
				$w       = implode( '', array_slice( $chars, $width ) );
			}
			if ( '' === $line ) {
				$line = $w;
			} elseif ( self::text_len( $line, $cp ) + 1 + self::text_len( $w, $cp ) <= $width ) {
				$line .= ' ' . $w;
			} else {
				$lines[] = $line;
				$line    = $w;
			}
		}
		$lines[] = $line;
		return $lines;
	}

	/**
	 * Clamp an integer.
	 *
	 * @param mixed $n  Value.
	 * @param int   $lo Min.
	 * @param int   $hi Max.
	 * @param int   $d  Default.
	 * @return int
	 */
	protected static function clamp( $n, $lo, $hi, $d ) {
		$n = is_numeric( $n ) ? (int) $n : $d;
		return min( $hi, max( $lo, $n ) );
	}

	/**
	 * Encode a document.
	 *
	 * @param array $doc Ticket document: cols, cp, cut, ops.
	 * @return string Binary string.
	 */
	public static function encode( $doc ) {
		$cols = self::clamp( isset( $doc['cols'] ) ? $doc['cols'] : 48, 16, 80, 48 );
		$cp   = isset( $doc['cp'] ) ? $doc['cp'] : 'cp437';
		if ( 'ascii' !== $cp && ! isset( self::tables()[ $cp ] ) ) {
			$cp = 'cp437';
		}
		$cut = isset( $doc['cut'] ) ? $doc['cut'] : 'partial';
		$ops = isset( $doc['ops'] ) && is_array( $doc['ops'] ) ? $doc['ops'] : array();
		$cps = self::codepages();

		$b  = array( 0x1B, 0x40, 0x1B, 0x74, isset( $cps[ $cp ] ) ? $cps[ $cp ] : 0 );
		$st = array(
			'a' => 0,
			'b' => 0,
			'u' => 0,
			'w' => 1,
			'h' => 1,
		);

		$set_state = function ( $a, $bold, $under, $w, $h ) use ( &$b, &$st ) {
			if ( $a !== $st['a'] ) {
				$st['a'] = $a;
				array_push( $b, 0x1B, 0x61, $a );
			}
			$bold = $bold ? 1 : 0;
			if ( $bold !== $st['b'] ) {
				$st['b'] = $bold;
				array_push( $b, 0x1B, 0x45, $bold );
			}
			$under = $under ? 1 : 0;
			if ( $under !== $st['u'] ) {
				$st['u'] = $under;
				array_push( $b, 0x1B, 0x2D, $under );
			}
			if ( $w !== $st['w'] || $h !== $st['h'] ) {
				$st['w'] = $w;
				$st['h'] = $h;
				array_push( $b, 0x1D, 0x21, ( ( $w - 1 ) << 4 ) | ( $h - 1 ) );
			}
		};
		$line      = function ( $s ) use ( &$b, $cp ) {
			foreach ( self::encode_text( $s, $cp ) as $x ) {
				$b[] = $x;
			}
			$b[] = 0x0A;
		};
		$align_map = array(
			'l' => 0,
			'c' => 1,
			'r' => 2,
		);

		foreach ( $ops as $op ) {
			$kind = isset( $op['op'] ) ? $op['op'] : '';
			switch ( $kind ) {
				case 'text':
					$w     = self::clamp( isset( $op['w'] ) ? $op['w'] : 1, 1, 8, 1 );
					$h     = self::clamp( isset( $op['h'] ) ? $op['h'] : 1, 1, 8, 1 );
					$width = max( 1, (int) floor( $cols / $w ) );
					$al    = isset( $op['a'], $align_map[ $op['a'] ] ) ? $align_map[ $op['a'] ] : 0;
					$set_state( $al, ! empty( $op['b'] ), ! empty( $op['u'] ), $w, $h );
					foreach ( self::wrap( isset( $op['s'] ) ? $op['s'] : '', $width, $cp ) as $l ) {
						$line( $l );
					}
					break;
				case 'lr':
					$w     = self::clamp( isset( $op['w'] ) ? $op['w'] : 1, 1, 8, 1 );
					$h     = self::clamp( isset( $op['h'] ) ? $op['h'] : 1, 1, 8, 1 );
					$width = max( 1, (int) floor( $cols / $w ) );
					$set_state( 0, ! empty( $op['b'] ), ! empty( $op['u'] ), $w, $h );
					$left  = isset( $op['l'] ) ? (string) $op['l'] : '';
					$right = isset( $op['r'] ) ? (string) $op['r'] : '';
					$rl    = self::text_len( $right, $cp );
					if ( $rl >= $width - 2 ) {
						$rl    = 0;
						$left  = $left . ' ' . $right;
						$right = '';
					}
					$lines = self::wrap( $left, $rl ? $width - $rl - 1 : $width, $cp );
					foreach ( $lines as $k => $l ) {
						if ( 0 === $k && $rl ) {
							$line( $l . str_repeat( ' ', max( 0, $width - self::text_len( $l, $cp ) - $rl ) ) . $right );
						} else {
							$line( $l );
						}
					}
					break;
				case 'hr':
					$set_state( 0, 0, 0, 1, 1 );
					$ch = ( isset( $op['ch'] ) && '' !== $op['ch'] ) ? substr( (string) $op['ch'], 0, 1 ) : '-';
					$line( str_repeat( $ch, $cols ) );
					break;
				case 'feed':
					$n = self::clamp( isset( $op['n'] ) ? $op['n'] : 1, 0, 20, 1 );
					if ( $n ) {
						array_push( $b, 0x1B, 0x64, $n );
					}
					break;
				case 'qr':
					$al = isset( $op['a'], $align_map[ $op['a'] ] ) ? $align_map[ $op['a'] ] : 1;
					$set_state( $al, 0, $st['u'], 1, 1 );
					$txt = self::encode_text( isset( $op['s'] ) ? $op['s'] : '', 'ascii' );
					if ( ! $txt ) {
						break;
					}
					$txt = array_slice( $txt, 0, 400 );
					$n   = self::clamp( isset( $op['size'] ) ? $op['size'] : 6, 1, 16, 6 );
					array_push( $b, 0x1D, 0x28, 0x6B, 0x04, 0x00, 0x31, 0x41, 0x32, 0x00 );
					array_push( $b, 0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x43, $n );
					array_push( $b, 0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x45, 0x31 );
					$len = count( $txt ) + 3;
					array_push( $b, 0x1D, 0x28, 0x6B, $len & 255, ( $len >> 8 ) & 255, 0x31, 0x50, 0x30 );
					foreach ( $txt as $x ) {
						$b[] = $x;
					}
					array_push( $b, 0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x51, 0x30 );
					$b[] = 0x0A;
					break;
				case 'drawer':
					array_push( $b, 0x1B, 0x70, 0x00, 0x19, 0xFA );
					break;
				case 'cut':
					$set_state( 0, 0, 0, 1, 1 );
					if ( 'none' === $cut ) {
						array_push( $b, 0x1B, 0x64, 0x03 );
					} else {
						array_push( $b, 0x1B, 0x64, 0x04, 0x1D, 0x56, 'full' === $cut ? 0x00 : 0x01 );
					}
					break;
				default:
					break;
			}
		}
		$set_state( 0, 0, 0, 1, 1 );
		return implode( '', array_map( 'chr', $b ) );
	}
}
