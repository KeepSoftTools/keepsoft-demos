<?php
/**
 * Print job queue and log.
 *
 * @package PrintPilot
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Jobs.
 */
class PrintPilot_Jobs {

	/**
	 * Whether the shutdown processor has been hooked.
	 *
	 * @var bool
	 */
	protected static $shutdown_hooked = false;

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'pp_process_queue', array( __CLASS__, 'process_due' ) );
		add_action( 'pp_daily_cleanup', array( __CLASS__, 'cleanup' ) );
	}

	/**
	 * One-minute cron interval.
	 *
	 * @param array $s Schedules.
	 * @return array
	 */
	public static function cron_schedules( $s ) {
		$s['pp_minute'] = array(
			'interval' => 60,
			'display'  => __( 'Every minute (PrintPilot)', 'printpilot' ),
		);
		return $s;
	}

	/**
	 * Statuses with labels.
	 *
	 * @return array<string,string>
	 */
	public static function statuses() {
		return array(
			'pending'   => __( 'Pending', 'printpilot' ),
			'printing'  => __( 'Printing', 'printpilot' ),
			'printed'   => __( 'Printed', 'printpilot' ),
			'failed'    => __( 'Failed', 'printpilot' ),
			'cancelled' => __( 'Cancelled', 'printpilot' ),
		);
	}

	/**
	 * Current GMT time in MySQL format.
	 *
	 * @return string
	 */
	protected static function now() {
		return gmdate( 'Y-m-d H:i:s' );
	}

	/**
	 * Create a job.
	 *
	 * @param array $args order_id, printer_id, template_id, copies, source, meta.
	 * @return int|WP_Error Job ID.
	 */
	public static function create( $args ) {
		global $wpdb;
		$args    = wp_parse_args(
			$args,
			array(
				'order_id'    => 0,
				'printer_id'  => '',
				'template_id' => '',
				'copies'      => 0,
				'source'      => 'manual',
				'meta'        => array(),
			)
		);
		$printer = PrintPilot_Settings::printer( $args['printer_id'] );
		if ( ! $printer ) {
			return new WP_Error( 'pp_no_printer', __( 'Unknown printer.', 'printpilot' ) );
		}
		if ( ! PrintPilot_Settings::template( $args['template_id'] ) ) {
			return new WP_Error( 'pp_no_template', __( 'Unknown template.', 'printpilot' ) );
		}
		$copies = (int) $args['copies'];
		if ( $copies < 1 ) {
			$copies = max( 1, (int) $printer['copies'] );
		}
		$now = self::now();
		$ok  = $wpdb->insert(
			PrintPilot_Install::table(),
			array(
				'order_id'    => absint( $args['order_id'] ),
				'printer_id'  => $printer['id'],
				'template_id' => $args['template_id'],
				'method'      => $printer['method'],
				'status'      => 'pending',
				'copies'      => min( 10, $copies ),
				'attempts'    => 0,
				'source'      => substr( sanitize_text_field( $args['source'] ), 0, 60 ),
				'meta'        => wp_json_encode( $args['meta'] ),
				'created_gmt' => $now,
				'updated_gmt' => $now,
			)
		);
		if ( ! $ok ) {
			return new WP_Error( 'pp_db', __( 'Could not save the print job.', 'printpilot' ) );
		}
		$id = (int) $wpdb->insert_id;
		if ( in_array( $printer['method'], array( 'network', 'email' ), true ) ) {
			self::hook_shutdown();
		}
		do_action( 'printpilot_job_created', $id, $args );
		return $id;
	}

	/**
	 * Process server-side jobs after the response is sent.
	 *
	 * @return void
	 */
	protected static function hook_shutdown() {
		if ( self::$shutdown_hooked ) {
			return;
		}
		self::$shutdown_hooked = true;
		add_action(
			'shutdown',
			function () {
				if ( function_exists( 'fastcgi_finish_request' ) ) {
					fastcgi_finish_request();
				}
				ignore_user_abort( true );
				self::process_due();
			},
			99
		);
	}

	/**
	 * Fetch a job.
	 *
	 * @param int $id Job ID.
	 * @return object|null
	 */
	public static function get( $id ) {
		global $wpdb;
		$t = PrintPilot_Install::table();
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Decode job meta.
	 *
	 * @param object $job Job.
	 * @return array
	 */
	public static function meta( $job ) {
		$m = ! empty( $job->meta ) ? json_decode( $job->meta, true ) : array();
		return is_array( $m ) ? $m : array();
	}

	/**
	 * Update columns.
	 *
	 * @param int   $id   Job ID.
	 * @param array $data Columns.
	 * @return void
	 */
	public static function update( $id, $data ) {
		global $wpdb;
		$data['updated_gmt'] = self::now();
		$wpdb->update( PrintPilot_Install::table(), $data, array( 'id' => (int) $id ) );
	}

	/**
	 * Query jobs.
	 *
	 * @param array $a status, order_id, printer_id, limit, offset, search.
	 * @return object[]
	 */
	public static function query( $a = array() ) {
		global $wpdb;
		$t     = PrintPilot_Install::table();
		$where = array( '1=1' );
		$vals  = array();
		if ( ! empty( $a['status'] ) ) {
			$where[] = 'status = %s';
			$vals[]  = $a['status'];
		}
		if ( ! empty( $a['order_id'] ) ) {
			$where[] = 'order_id = %d';
			$vals[]  = (int) $a['order_id'];
		}
		if ( ! empty( $a['printer_id'] ) ) {
			$where[] = 'printer_id = %s';
			$vals[]  = $a['printer_id'];
		}
		$limit  = isset( $a['limit'] ) ? max( 1, min( 500, (int) $a['limit'] ) ) : 50;
		$offset = isset( $a['offset'] ) ? max( 0, (int) $a['offset'] ) : 0;
		$sql    = "SELECT * FROM {$t} WHERE " . implode( ' AND ', $where ) . ' ORDER BY id DESC LIMIT %d OFFSET %d'; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$vals[] = $limit;
		$vals[] = $offset;
		return $wpdb->get_results( $wpdb->prepare( $sql, $vals ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	}

	/**
	 * Count jobs with optional status.
	 *
	 * @param string $status Status or empty.
	 * @return int
	 */
	public static function count( $status = '' ) {
		global $wpdb;
		$t = PrintPilot_Install::table();
		if ( $status ) {
			return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE status = %s", $status ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Count jobs printed since a time.
	 *
	 * @param int $since Unix time.
	 * @return int
	 */
	public static function count_printed_since( $since ) {
		global $wpdb;
		$t = PrintPilot_Install::table();
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE status = 'printed' AND printed_gmt >= %s", gmdate( 'Y-m-d H:i:s', $since ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Atomically claim a pending job for a worker.
	 *
	 * @param int    $id      Job ID.
	 * @param string $station Station name (optional).
	 * @return bool
	 */
	public static function claim( $id, $station = '' ) {
		global $wpdb;
		$t    = PrintPilot_Install::table();
		$rows = $wpdb->query( $wpdb->prepare( "UPDATE {$t} SET status = 'printing', attempts = attempts + 1, station = %s, updated_gmt = %s WHERE id = %d AND status = 'pending'", substr( $station, 0, 80 ), self::now(), $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return 1 === (int) $rows;
	}

	/**
	 * Jobs for the Print Station to pick up.
	 *
	 * @param string   $station Station name.
	 * @param string[] $ready   Printers (ESC/POS) that are connected in the browser.
	 * @param string[] $only    Optional printer ID filter for this station.
	 * @param int      $limit   Max jobs.
	 * @return object[] Claimed jobs.
	 */
	public static function claim_for_station( $station, $ready, $only = array(), $limit = 5 ) {
		global $wpdb;
		$t = PrintPilot_Install::table();
		// Release jobs claimed by a station that vanished.
		$timeout = max( 20, (int) PrintPilot_Settings::get_one( 'claim_timeout', 90 ) );
		$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET status = 'pending' WHERE status = 'printing' AND method IN ('station_html','station_escpos') AND updated_gmt < %s", gmdate( 'Y-m-d H:i:s', time() - $timeout ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE status = 'pending' AND method IN ('station_html','station_escpos') AND (retry_gmt IS NULL OR retry_gmt <= %s) ORDER BY id ASC LIMIT 40", self::now() ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$out  = array();
		foreach ( $rows as $job ) {
			if ( count( $out ) >= $limit ) {
				break;
			}
			if ( $only && ! in_array( $job->printer_id, $only, true ) ) {
				continue;
			}
			if ( 'station_escpos' === $job->method && ! in_array( $job->printer_id, $ready, true ) ) {
				continue;
			}
			if ( self::claim( (int) $job->id, $station ) ) {
				$out[] = self::get( (int) $job->id );
			}
		}
		return $out;
	}

	/**
	 * Record a successful print.
	 *
	 * @param int $id Job ID.
	 * @return void
	 */
	public static function mark_printed( $id ) {
		self::update(
			$id,
			array(
				'status'      => 'printed',
				'error'       => null,
				'retry_gmt'   => null,
				'printed_gmt' => self::now(),
			)
		);
		do_action( 'printpilot_job_printed', $id );
	}

	/**
	 * Record a failure; schedules a retry or marks failed.
	 *
	 * @param int    $id    Job ID.
	 * @param string $error Message.
	 * @return string New status.
	 */
	public static function mark_failed( $id, $error ) {
		$job = self::get( $id );
		if ( ! $job ) {
			return 'failed';
		}
		$max   = max( 1, (int) PrintPilot_Settings::get_one( 'retry_max', 3 ) );
		$delay = max( 10, (int) PrintPilot_Settings::get_one( 'retry_delay', 60 ) );
		$error = substr( sanitize_text_field( $error ), 0, 500 );
		if ( (int) $job->attempts < $max ) {
			self::update(
				$id,
				array(
					'status'    => 'pending',
					'error'     => $error,
					'retry_gmt' => gmdate( 'Y-m-d H:i:s', time() + $delay ),
				)
			);
			return 'pending';
		}
		self::update(
			$id,
			array(
				'status'    => 'failed',
				'error'     => $error,
				'retry_gmt' => null,
			)
		);
		do_action( 'printpilot_job_failed', $id, $error );
		self::maybe_fallback_email( self::get( $id ) );
		return 'failed';
	}

	/**
	 * Email the ticket if a printer has a fallback address.
	 *
	 * @param object $job Job.
	 * @return void
	 */
	protected static function maybe_fallback_email( $job ) {
		$printer = PrintPilot_Settings::printer( $job->printer_id );
		if ( ! $printer || empty( $printer['fallback_email'] ) || 'email' === $printer['method'] ) {
			return;
		}
		$meta = self::meta( $job );
		if ( ! empty( $meta['fallback_sent'] ) ) {
			return;
		}
		$res = PrintPilot_Network::email_job( $job, $printer['fallback_email'], true );
		if ( ! is_wp_error( $res ) ) {
			$meta['fallback_sent'] = 1;
			self::update( (int) $job->id, array( 'meta' => wp_json_encode( $meta ) ) );
		}
	}

	/**
	 * Manually retry a failed/cancelled job.
	 *
	 * @param int $id Job ID.
	 * @return bool
	 */
	public static function retry( $id ) {
		$job = self::get( $id );
		if ( ! $job ) {
			return false;
		}
		self::update(
			$id,
			array(
				'status'    => 'pending',
				'attempts'  => 0,
				'error'     => null,
				'retry_gmt' => null,
			)
		);
		if ( in_array( $job->method, array( 'network', 'email' ), true ) ) {
			self::hook_shutdown();
		}
		return true;
	}

	/**
	 * Clone a job so it prints again.
	 *
	 * @param int    $id     Job ID.
	 * @param string $source Source label.
	 * @return int|WP_Error
	 */
	public static function reprint( $id, $source = 'reprint' ) {
		$job = self::get( $id );
		if ( ! $job ) {
			return new WP_Error( 'pp_no_job', __( 'Job not found.', 'printpilot' ) );
		}
		$meta = self::meta( $job );
		unset( $meta['fallback_sent'] );
		return self::create(
			array(
				'order_id'    => (int) $job->order_id,
				'printer_id'  => $job->printer_id,
				'template_id' => $job->template_id,
				'copies'      => (int) $job->copies,
				'source'      => $source,
				'meta'        => $meta,
			)
		);
	}

	/**
	 * Delete a job row.
	 *
	 * @param int $id Job ID.
	 * @return void
	 */
	public static function delete( $id ) {
		global $wpdb;
		$wpdb->delete( PrintPilot_Install::table(), array( 'id' => (int) $id ) );
	}

	/**
	 * Delete all jobs, optionally filtered by status.
	 *
	 * @param string $status Status or empty for all.
	 * @return void
	 */
	public static function clear( $status = '' ) {
		global $wpdb;
		$t = PrintPilot_Install::table();
		if ( $status ) {
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$t} WHERE status = %s", $status ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		} else {
			$wpdb->query( "DELETE FROM {$t}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}
	}

	/**
	 * Remove old finished jobs.
	 *
	 * @return void
	 */
	public static function cleanup() {
		global $wpdb;
		$days = (int) PrintPilot_Settings::get_one( 'job_retention_days', 30 );
		if ( $days < 1 ) {
			return;
		}
		$t = PrintPilot_Install::table();
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$t} WHERE status IN ('printed','failed','cancelled') AND updated_gmt < %s", gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Send due server-side jobs (network and email).
	 *
	 * @return int Number processed.
	 */
	public static function process_due() {
		global $wpdb;
		$t = PrintPilot_Install::table();
		// Recover jobs stuck mid-print (PHP crash).
		$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET status = 'pending' WHERE status = 'printing' AND method IN ('network','email') AND updated_gmt < %s", gmdate( 'Y-m-d H:i:s', time() - 120 ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id FROM {$t} WHERE status = 'pending' AND method IN ('network','email') AND (retry_gmt IS NULL OR retry_gmt <= %s) ORDER BY id ASC LIMIT 20", self::now() ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$n    = 0;
		foreach ( $rows as $r ) {
			if ( self::process_job( (int) $r->id ) ) {
				$n++;
			}
		}
		return $n;
	}

	/**
	 * Send one network/email job now.
	 *
	 * @param int $id Job ID.
	 * @return bool True if this call handled the job (even if it failed).
	 */
	public static function process_job( $id ) {
		if ( ! self::claim( $id, 'server' ) ) {
			return false;
		}
		$job = self::get( $id );
		if ( ! $job ) {
			return false;
		}
		$res = PrintPilot_Network::dispatch( $job );
		if ( is_wp_error( $res ) ) {
			self::mark_failed( $id, $res->get_error_message() );
		} else {
			self::mark_printed( $id );
		}
		return true;
	}
}
