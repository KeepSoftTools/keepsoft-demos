/**
 * PrintPilot QR code generator (byte mode, error correction M, versions 1-15). Vanilla JS.
 * Used to draw QR codes on HTML tickets. Algorithm follows ISO/IEC 18004.
 */
(function (root, factory) {
	'use strict';
	if (typeof module === 'object' && module.exports) {
		module.exports = factory();
	} else {
		root.PPQR = factory();
	}
}(typeof self !== 'undefined' ? self : this, function () {
	'use strict';

	var ECC_PER_BLOCK = [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24];
	var NUM_BLOCKS = [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10];
	var MAX_VER = 15;

	function rawModules(ver) {
		var r = (16 * ver + 128) * ver + 64, na;
		if (ver >= 2) {
			na = Math.floor(ver / 7) + 2;
			r -= (25 * na - 10) * na - 55;
			if (ver >= 7) { r -= 36; }
		}
		return r;
	}
	function dataCodewords(ver) {
		return Math.floor(rawModules(ver) / 8) - ECC_PER_BLOCK[ver] * NUM_BLOCKS[ver];
	}
	function bit(x, i) { return ((x >>> i) & 1) !== 0; }

	function gfMul(x, y) {
		var z = 0, i;
		for (i = 7; i >= 0; i--) { z = (z << 1) ^ ((z >>> 7) * 0x11D); z ^= ((y >>> i) & 1) * x; }
		return z;
	}
	function rsDivisor(degree) {
		var res = [], i, j, rt = 1;
		for (i = 0; i < degree - 1; i++) { res.push(0); }
		res.push(1);
		for (i = 0; i < degree; i++) {
			for (j = 0; j < res.length; j++) {
				res[j] = gfMul(res[j], rt);
				if (j + 1 < res.length) { res[j] ^= res[j + 1]; }
			}
			rt = gfMul(rt, 2);
		}
		return res;
	}
	function rsRemainder(data, div) {
		var res = div.map(function () { return 0; });
		data.forEach(function (b) {
			var f = b ^ res.shift();
			res.push(0);
			div.forEach(function (c, i) { res[i] ^= gfMul(c, f); });
		});
		return res;
	}

	function utf8Bytes(str) {
		var out = [], i, c, enc;
		if (typeof TextEncoder !== 'undefined') { return Array.prototype.slice.call(new TextEncoder().encode(str)); }
		enc = unescape(encodeURIComponent(str));
		for (i = 0; i < enc.length; i++) { c = enc.charCodeAt(i); out.push(c); }
		return out;
	}

	function alignPositions(ver) {
		var na, step, res, pos;
		if (ver === 1) { return []; }
		na = Math.floor(ver / 7) + 2;
		step = ver === 32 ? 26 : Math.ceil((ver * 4 + 4) / (na * 2 - 2)) * 2;
		res = [6];
		for (pos = ver * 4 + 17 - 7; res.length < na; pos -= step) { res.splice(1, 0, pos); }
		return res;
	}

	function build(text, minVer) {
		var bytes = utf8Bytes(String(text)), ver, bits, cap, i, size, mods, isFn, y, x;
		for (ver = minVer || 1; ver <= MAX_VER; ver++) {
			cap = dataCodewords(ver) * 8;
			if (4 + (ver < 10 ? 8 : 16) + bytes.length * 8 <= cap) { break; }
		}
		if (ver > MAX_VER) { return null; }

		bits = [];
		function put(val, len) { for (var k = len - 1; k >= 0; k--) { bits.push((val >>> k) & 1); } }
		put(4, 4);
		put(bytes.length, ver < 10 ? 8 : 16);
		bytes.forEach(function (b) { put(b, 8); });
		cap = dataCodewords(ver) * 8;
		put(0, Math.min(4, cap - bits.length));
		while (bits.length % 8) { bits.push(0); }
		for (i = 0xEC; bits.length < cap; i ^= 0xEC ^ 0x11) { put(i, 8); }
		var data = [];
		for (i = 0; i < bits.length; i += 8) {
			data.push(parseInt(bits.slice(i, i + 8).join(''), 2));
		}

		/* split into blocks + error correction, interleave */
		var nb = NUM_BLOCKS[ver], be = ECC_PER_BLOCK[ver], raw = Math.floor(rawModules(ver) / 8);
		var nShort = nb - raw % nb, shortLen = Math.floor(raw / nb), blocks = [], div = rsDivisor(be), k = 0, dat, ecc;
		for (i = 0; i < nb; i++) {
			dat = data.slice(k, k + shortLen - be + (i < nShort ? 0 : 1));
			k += dat.length;
			ecc = rsRemainder(dat, div);
			if (i < nShort) { dat.push(0); }
			blocks.push(dat.concat(ecc));
		}
		var all = [], j;
		for (i = 0; i < blocks[0].length; i++) {
			for (j = 0; j < blocks.length; j++) {
				if (i !== shortLen - be || j >= nShort) { all.push(blocks[j][i]); }
			}
		}

		size = ver * 4 + 17;
		mods = []; isFn = [];
		for (y = 0; y < size; y++) { mods.push(new Array(size).fill(false)); isFn.push(new Array(size).fill(false)); }
		function setFn(xx, yy, v) { mods[yy][xx] = v; isFn[yy][xx] = true; }

		for (i = 0; i < size; i++) { setFn(6, i, i % 2 === 0); setFn(i, 6, i % 2 === 0); }
		function finder(cx, cy) {
			var dx, dy, d, xx, yy;
			for (dy = -4; dy <= 4; dy++) {
				for (dx = -4; dx <= 4; dx++) {
					d = Math.max(Math.abs(dx), Math.abs(dy)); xx = cx + dx; yy = cy + dy;
					if (xx >= 0 && xx < size && yy >= 0 && yy < size) { setFn(xx, yy, d !== 2 && d !== 4); }
				}
			}
		}
		finder(3, 3); finder(size - 4, 3); finder(3, size - 4);
		var ap = alignPositions(ver), na = ap.length, a, b, dx, dy;
		for (a = 0; a < na; a++) {
			for (b = 0; b < na; b++) {
				if ((a === 0 && b === 0) || (a === 0 && b === na - 1) || (a === na - 1 && b === 0)) { continue; }
				for (dy = -2; dy <= 2; dy++) {
					for (dx = -2; dx <= 2; dx++) { setFn(ap[a] + dx, ap[b] + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1); }
				}
			}
		}
		function formatBits(mask) {
			var d = (0 << 3) | mask, r = d, q, fb;
			for (q = 0; q < 10; q++) { r = (r << 1) ^ ((r >>> 9) * 0x537); }
			fb = ((d << 10) | r) ^ 0x5412;
			for (q = 0; q <= 5; q++) { setFn(8, q, bit(fb, q)); }
			setFn(8, 7, bit(fb, 6)); setFn(8, 8, bit(fb, 7)); setFn(7, 8, bit(fb, 8));
			for (q = 9; q < 15; q++) { setFn(14 - q, 8, bit(fb, q)); }
			for (q = 0; q < 8; q++) { setFn(size - 1 - q, 8, bit(fb, q)); }
			for (q = 8; q < 15; q++) { setFn(8, size - 15 + q, bit(fb, q)); }
			setFn(8, size - 8, true);
		}
		formatBits(0);
		if (ver >= 7) {
			var vr = ver, vb, c1;
			for (i = 0; i < 12; i++) { vr = (vr << 1) ^ ((vr >>> 11) * 0x1F25); }
			vb = (ver << 12) | vr;
			for (i = 0; i < 18; i++) {
				c1 = bit(vb, i); a = size - 11 + i % 3; b = Math.floor(i / 3);
				setFn(a, b, c1); setFn(b, a, c1);
			}
		}

		/* place data */
		var idx = 0, right, vert, upward;
		for (right = size - 1; right >= 1; right -= 2) {
			if (right === 6) { right = 5; }
			for (vert = 0; vert < size; vert++) {
				for (j = 0; j < 2; j++) {
					x = right - j; upward = ((right + 1) & 2) === 0; y = upward ? size - 1 - vert : vert;
					if (!isFn[y][x] && idx < all.length * 8) { mods[y][x] = bit(all[idx >>> 3], 7 - (idx & 7)); idx++; }
				}
			}
		}

		function applyMask(m) {
			var yy, xx, inv;
			for (yy = 0; yy < size; yy++) {
				for (xx = 0; xx < size; xx++) {
					switch (m) {
						case 0: inv = (xx + yy) % 2 === 0; break;
						case 1: inv = yy % 2 === 0; break;
						case 2: inv = xx % 3 === 0; break;
						case 3: inv = (xx + yy) % 3 === 0; break;
						case 4: inv = (Math.floor(xx / 3) + Math.floor(yy / 2)) % 2 === 0; break;
						case 5: inv = xx * yy % 2 + xx * yy % 3 === 0; break;
						case 6: inv = (xx * yy % 2 + xx * yy % 3) % 2 === 0; break;
						default: inv = ((xx + yy) % 2 + xx * yy % 3) % 2 === 0; break;
					}
					if (!isFn[yy][xx] && inv) { mods[yy][xx] = !mods[yy][xx]; }
				}
			}
		}
		function penalty() {
			var p = 0, yy, xx, run, dark = 0, c;
			for (yy = 0; yy < size; yy++) {
				run = 1;
				for (xx = 1; xx < size; xx++) {
					if (mods[yy][xx] === mods[yy][xx - 1]) { run++; if (run === 5) { p += 3; } else if (run > 5) { p++; } } else { run = 1; }
				}
			}
			for (xx = 0; xx < size; xx++) {
				run = 1;
				for (yy = 1; yy < size; yy++) {
					if (mods[yy][xx] === mods[yy - 1][xx]) { run++; if (run === 5) { p += 3; } else if (run > 5) { p++; } } else { run = 1; }
				}
			}
			for (yy = 0; yy < size - 1; yy++) {
				for (xx = 0; xx < size - 1; xx++) {
					c = mods[yy][xx];
					if (c === mods[yy][xx + 1] && c === mods[yy + 1][xx] && c === mods[yy + 1][xx + 1]) { p += 3; }
				}
			}
			for (yy = 0; yy < size; yy++) { for (xx = 0; xx < size; xx++) { if (mods[yy][xx]) { dark++; } } }
			p += Math.floor(Math.abs(dark * 20 - size * size * 10) / (size * size)) * 10;
			return p;
		}
		var best = 0, bestP = Infinity, m, pn;
		for (m = 0; m < 8; m++) {
			applyMask(m); formatBits(m);
			pn = penalty();
			if (pn < bestP) { bestP = pn; best = m; }
			applyMask(m);
		}
		applyMask(best); formatBits(best);
		return mods;
	}

	/** @return {boolean[][]|null} module matrix, true = dark */
	function matrix(text) { return build(text, 1); }

	/** Inline SVG string for the text; empty string if it does not fit. */
	function svg(text, opt) {
		opt = opt || {};
		var m = matrix(text), q = opt.margin === undefined ? 2 : opt.margin, n, x, y, d = '', px = opt.size || 0;
		if (!m) { return ''; }
		n = m.length;
		for (y = 0; y < n; y++) {
			for (x = 0; x < n; x++) { if (m[y][x]) { d += 'M' + (x + q) + ',' + (y + q) + 'h1v1h-1z'; } }
		}
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + (n + q * 2) + ' ' + (n + q * 2) + '"' +
			(px ? ' width="' + px + '" height="' + px + '"' : '') + ' shape-rendering="crispEdges" role="img" aria-label="QR code">' +
			'<rect width="100%" height="100%" fill="#fff"/><path d="' + d + '" fill="#000"/></svg>';
	}

	/** Replace every .pp-qr[data-qr] inside root with an SVG. */
	function hydrate(rootEl) {
		var nodes = (rootEl || document).querySelectorAll('.pp-qr[data-qr]'), i, s;
		for (i = 0; i < nodes.length; i++) {
			s = svg(nodes[i].getAttribute('data-qr'), { size: parseInt(nodes[i].getAttribute('data-size'), 10) || 120 });
			if (s) { nodes[i].innerHTML = s; }
		}
	}

	return { matrix: matrix, svg: svg, hydrate: hydrate };
}));
