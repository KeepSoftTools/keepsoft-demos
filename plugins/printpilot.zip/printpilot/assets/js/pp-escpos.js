/**
 * PrintPilot ESC/POS encoder (vanilla JS, no dependencies).
 *
 * Turns a PrintPilot ticket document (see PrintPilot_Ticket::build_doc) into the raw byte
 * stream understood by ESC/POS thermal printers. The PHP class PrintPilot_ESCPOS implements the
 * same byte layout so browser and server printing give the same result.
 *
 * Usable in the browser (window.PPEscPos) and in Node (module.exports) for unit tests.
 */
(function (root, factory) {
	'use strict';
	if (typeof module === 'object' && module.exports) {
		module.exports = factory();
	} else {
		root.PPEscPos = factory();
	}
}(typeof self !== 'undefined' ? self : this, function () {
	'use strict';

	/* High half (0x80-0xFF) of the supported single-byte code pages. U+FFFD = undefined. */
	var CP_TABLES = {"cp437": "\u00c7\u00fc\u00e9\u00e2\u00e4\u00e0\u00e5\u00e7\u00ea\u00eb\u00e8\u00ef\u00ee\u00ec\u00c4\u00c5\u00c9\u00e6\u00c6\u00f4\u00f6\u00f2\u00fb\u00f9\u00ff\u00d6\u00dc\u00a2\u00a3\u00a5\u20a7\u0192\u00e1\u00ed\u00f3\u00fa\u00f1\u00d1\u00aa\u00ba\u00bf\u2310\u00ac\u00bd\u00bc\u00a1\u00ab\u00bb\u2591\u2592\u2593\u2502\u2524\u2561\u2562\u2556\u2555\u2563\u2551\u2557\u255d\u255c\u255b\u2510\u2514\u2534\u252c\u251c\u2500\u253c\u255e\u255f\u255a\u2554\u2569\u2566\u2560\u2550\u256c\u2567\u2568\u2564\u2565\u2559\u2558\u2552\u2553\u256b\u256a\u2518\u250c\u2588\u2584\u258c\u2590\u2580\u03b1\u00df\u0393\u03c0\u03a3\u03c3\u00b5\u03c4\u03a6\u0398\u03a9\u03b4\u221e\u03c6\u03b5\u2229\u2261\u00b1\u2265\u2264\u2320\u2321\u00f7\u2248\u00b0\u2219\u00b7\u221a\u207f\u00b2\u25a0\u00a0", "cp850": "\u00c7\u00fc\u00e9\u00e2\u00e4\u00e0\u00e5\u00e7\u00ea\u00eb\u00e8\u00ef\u00ee\u00ec\u00c4\u00c5\u00c9\u00e6\u00c6\u00f4\u00f6\u00f2\u00fb\u00f9\u00ff\u00d6\u00dc\u00f8\u00a3\u00d8\u00d7\u0192\u00e1\u00ed\u00f3\u00fa\u00f1\u00d1\u00aa\u00ba\u00bf\u00ae\u00ac\u00bd\u00bc\u00a1\u00ab\u00bb\u2591\u2592\u2593\u2502\u2524\u00c1\u00c2\u00c0\u00a9\u2563\u2551\u2557\u255d\u00a2\u00a5\u2510\u2514\u2534\u252c\u251c\u2500\u253c\u00e3\u00c3\u255a\u2554\u2569\u2566\u2560\u2550\u256c\u00a4\u00f0\u00d0\u00ca\u00cb\u00c8\u0131\u00cd\u00ce\u00cf\u2518\u250c\u2588\u2584\u00a6\u00cc\u2580\u00d3\u00df\u00d4\u00d2\u00f5\u00d5\u00b5\u00fe\u00de\u00da\u00db\u00d9\u00fd\u00dd\u00af\u00b4\u00ad\u00b1\u2017\u00be\u00b6\u00a7\u00f7\u00b8\u00b0\u00a8\u00b7\u00b9\u00b3\u00b2\u25a0\u00a0", "cp858": "\u00c7\u00fc\u00e9\u00e2\u00e4\u00e0\u00e5\u00e7\u00ea\u00eb\u00e8\u00ef\u00ee\u00ec\u00c4\u00c5\u00c9\u00e6\u00c6\u00f4\u00f6\u00f2\u00fb\u00f9\u00ff\u00d6\u00dc\u00f8\u00a3\u00d8\u00d7\u0192\u00e1\u00ed\u00f3\u00fa\u00f1\u00d1\u00aa\u00ba\u00bf\u00ae\u00ac\u00bd\u00bc\u00a1\u00ab\u00bb\u2591\u2592\u2593\u2502\u2524\u00c1\u00c2\u00c0\u00a9\u2563\u2551\u2557\u255d\u00a2\u00a5\u2510\u2514\u2534\u252c\u251c\u2500\u253c\u00e3\u00c3\u255a\u2554\u2569\u2566\u2560\u2550\u256c\u00a4\u00f0\u00d0\u00ca\u00cb\u00c8\u20ac\u00cd\u00ce\u00cf\u2518\u250c\u2588\u2584\u00a6\u00cc\u2580\u00d3\u00df\u00d4\u00d2\u00f5\u00d5\u00b5\u00fe\u00de\u00da\u00db\u00d9\u00fd\u00dd\u00af\u00b4\u00ad\u00b1\u2017\u00be\u00b6\u00a7\u00f7\u00b8\u00b0\u00a8\u00b7\u00b9\u00b3\u00b2\u25a0\u00a0", "cp852": "\u00c7\u00fc\u00e9\u00e2\u00e4\u016f\u0107\u00e7\u0142\u00eb\u0150\u0151\u00ee\u0179\u00c4\u0106\u00c9\u0139\u013a\u00f4\u00f6\u013d\u013e\u015a\u015b\u00d6\u00dc\u0164\u0165\u0141\u00d7\u010d\u00e1\u00ed\u00f3\u00fa\u0104\u0105\u017d\u017e\u0118\u0119\u00ac\u017a\u010c\u015f\u00ab\u00bb\u2591\u2592\u2593\u2502\u2524\u00c1\u00c2\u011a\u015e\u2563\u2551\u2557\u255d\u017b\u017c\u2510\u2514\u2534\u252c\u251c\u2500\u253c\u0102\u0103\u255a\u2554\u2569\u2566\u2560\u2550\u256c\u00a4\u0111\u0110\u010e\u00cb\u010f\u0147\u00cd\u00ce\u011b\u2518\u250c\u2588\u2584\u0162\u016e\u2580\u00d3\u00df\u00d4\u0143\u0144\u0148\u0160\u0161\u0154\u00da\u0155\u0170\u00fd\u00dd\u0163\u00b4\u00ad\u02dd\u02db\u02c7\u02d8\u00a7\u00f7\u00b8\u00b0\u00a8\u02d9\u0171\u0158\u0159\u25a0\u00a0", "cp866": "\u0410\u0411\u0412\u0413\u0414\u0415\u0416\u0417\u0418\u0419\u041a\u041b\u041c\u041d\u041e\u041f\u0420\u0421\u0422\u0423\u0424\u0425\u0426\u0427\u0428\u0429\u042a\u042b\u042c\u042d\u042e\u042f\u0430\u0431\u0432\u0433\u0434\u0435\u0436\u0437\u0438\u0439\u043a\u043b\u043c\u043d\u043e\u043f\u2591\u2592\u2593\u2502\u2524\u2561\u2562\u2556\u2555\u2563\u2551\u2557\u255d\u255c\u255b\u2510\u2514\u2534\u252c\u251c\u2500\u253c\u255e\u255f\u255a\u2554\u2569\u2566\u2560\u2550\u256c\u2567\u2568\u2564\u2565\u2559\u2558\u2552\u2553\u256b\u256a\u2518\u250c\u2588\u2584\u258c\u2590\u2580\u0440\u0441\u0442\u0443\u0444\u0445\u0446\u0447\u0448\u0449\u044a\u044b\u044c\u044d\u044e\u044f\u0401\u0451\u0404\u0454\u0407\u0457\u040e\u045e\u00b0\u2219\u00b7\u221a\u2116\u00a4\u25a0\u00a0", "cp1252": "\u20ac\ufffd\u201a\u0192\u201e\u2026\u2020\u2021\u02c6\u2030\u0160\u2039\u0152\ufffd\u017d\ufffd\ufffd\u2018\u2019\u201c\u201d\u2022\u2013\u2014\u02dc\u2122\u0161\u203a\u0153\ufffd\u017e\u0178\u00a0\u00a1\u00a2\u00a3\u00a4\u00a5\u00a6\u00a7\u00a8\u00a9\u00aa\u00ab\u00ac\u00ad\u00ae\u00af\u00b0\u00b1\u00b2\u00b3\u00b4\u00b5\u00b6\u00b7\u00b8\u00b9\u00ba\u00bb\u00bc\u00bd\u00be\u00bf\u00c0\u00c1\u00c2\u00c3\u00c4\u00c5\u00c6\u00c7\u00c8\u00c9\u00ca\u00cb\u00cc\u00cd\u00ce\u00cf\u00d0\u00d1\u00d2\u00d3\u00d4\u00d5\u00d6\u00d7\u00d8\u00d9\u00da\u00db\u00dc\u00dd\u00de\u00df\u00e0\u00e1\u00e2\u00e3\u00e4\u00e5\u00e6\u00e7\u00e8\u00e9\u00ea\u00eb\u00ec\u00ed\u00ee\u00ef\u00f0\u00f1\u00f2\u00f3\u00f4\u00f5\u00f6\u00f7\u00f8\u00f9\u00fa\u00fb\u00fc\u00fd\u00fe\u00ff"};

	/* ESC t n selector for each code page (Epson numbering, used by most clones). */
	var CP_NUM = { cp437: 0, cp850: 2, cp852: 18, cp858: 19, cp866: 17, cp1252: 16, ascii: 0 };

	var FALLBACK = {
		'‘': "'", '’': "'", '‚': ',', '“': '"', '”': '"', '„': '"',
		'–': '-', '—': '-', '…': '...', '•': '*', '™': '(TM)',
		'€': 'EUR', ' ': ' ', '×': 'x', '−': '-', '·': '.'
	};

	var mapCache = {};

	function charMap(cp) {
		if (mapCache[cp]) { return mapCache[cp]; }
		var m = {}, t = CP_TABLES[cp] || '', i;
		for (i = 0; i < t.length; i++) {
			if (t.charAt(i) !== '�') { m[t.charAt(i)] = 128 + i; }
		}
		mapCache[cp] = m;
		return m;
	}

	function stripAccent(ch) {
		if (typeof ch.normalize === 'function') {
			var d = ch.normalize('NFD').replace(/[̀-ͯ]/g, '');
			if (d && d.charCodeAt(0) < 128) { return d; }
		}
		return null;
	}

	/** Encode a JS string for the given code page. Unknown characters become best-effort ASCII or "?". */
	function encodeText(str, cp) {
		var out = [], map = cp === 'ascii' ? {} : charMap(cp), i, ch, code, f, a, j, chars;
		chars = Array.from(String(str));
		for (i = 0; i < chars.length; i++) {
			ch = chars[i];
			code = ch.codePointAt(0);
			if (code === 10 || code === 13) { continue; }
			if (code >= 32 && code < 127) { out.push(code); continue; }
			if (Object.prototype.hasOwnProperty.call(map, ch)) { out.push(map[ch]); continue; }
			f = Object.prototype.hasOwnProperty.call(FALLBACK, ch) ? FALLBACK[ch] : stripAccent(ch);
			if (f === null || f === undefined) { f = '?'; }
			for (j = 0; j < f.length; j++) { a = f.charCodeAt(j); out.push(a < 127 && a >= 32 ? a : 63); }
		}
		return out;
	}

	/** Number of characters in the string as the printer will count them. */
	function textLen(str, cp) { return encodeText(str, cp).length; }

	/** Word-wrap to width characters (counted after encoding). Leading spaces are kept as indent. Returns array of lines. */
	function wrap(text, width, cp) {
		var m, indent = 0, lines, pre = '', k;
		text = String(text);
		if (width < 1) { width = 1; }
		m = text.match(/^ +/);
		if (m && m[0].length < width - 1) { indent = m[0].length; text = text.slice(indent); }
		lines = wrapCore(text, width - indent, cp);
		if (indent) {
			for (k = 0; k < indent; k++) { pre += ' '; }
			lines = lines.map(function (l) { return pre + l; });
		}
		return lines;
	}

	function wrapCore(text, width, cp) {
		var lines = [], words, line = '', w, k;
		words = text.split(' ');
		for (k = 0; k < words.length; k++) {
			w = words[k];
			while (textLen(w, cp) > width) {
				if (line !== '') { lines.push(line); line = ''; }
				lines.push(Array.from(w).slice(0, width).join(''));
				w = Array.from(w).slice(width).join('');
			}
			if (line === '') { line = w; }
			else if (textLen(line, cp) + 1 + textLen(w, cp) <= width) { line += ' ' + w; }
			else { lines.push(line); line = w; }
		}
		lines.push(line);
		return lines;
	}

	function pad(n, ch) { var s = ''; while (n-- > 0) { s += ch; } return s; }

	function Encoder() {
		this.b = [];
		this.align = 0;
		this.bold = 0;
		this.under = 0;
		this.sw = 1;
		this.sh = 1;
	}
	Encoder.prototype.raw = function (arr) { for (var i = 0; i < arr.length; i++) { this.b.push(arr[i] & 255); } return this; };
	Encoder.prototype.setAlign = function (a) { if (a !== this.align) { this.align = a; this.raw([0x1B, 0x61, a]); } };
	Encoder.prototype.setBold = function (v) { v = v ? 1 : 0; if (v !== this.bold) { this.bold = v; this.raw([0x1B, 0x45, v]); } };
	Encoder.prototype.setUnder = function (v) { v = v ? 1 : 0; if (v !== this.under) { this.under = v; this.raw([0x1B, 0x2D, v]); } };
	Encoder.prototype.setSize = function (w, h) {
		if (w !== this.sw || h !== this.sh) { this.sw = w; this.sh = h; this.raw([0x1D, 0x21, ((w - 1) << 4) | (h - 1)]); }
	};
	Encoder.prototype.reset = function () {
		this.setAlign(0); this.setBold(0); this.setUnder(0); this.setSize(1, 1);
	};

	var ALIGN = { l: 0, c: 1, r: 2 };

	function clamp(n, lo, hi, d) { n = parseInt(n, 10); if (isNaN(n)) { n = d; } return Math.min(hi, Math.max(lo, n)); }

	/**
	 * Encode a ticket document into bytes.
	 * @param {Object} doc  {cols, cp, cut, ops:[...]}
	 * @param {Object} [opt] optional overrides {cols, cp, cut}
	 * @return {Uint8Array}
	 */
	function encode(doc, opt) {
		opt = opt || {};
		var cols = clamp(opt.cols || doc.cols, 16, 80, 48);
		var cp = opt.cp || doc.cp || 'cp437';
		if (cp !== 'ascii' && !CP_TABLES[cp]) { cp = 'cp437'; }
		var cut = opt.cut || doc.cut || 'partial';
		var e = new Encoder(), ops = doc.ops || [], i, op, k, lines, w, h, width, txt, n, left, right, rl;

		function emitLine(s) { e.raw(encodeText(s, cp)); e.raw([0x0A]); }

		e.raw([0x1B, 0x40]);
		e.raw([0x1B, 0x74, CP_NUM[cp] || 0]);

		for (i = 0; i < ops.length; i++) {
			op = ops[i];
			switch (op.op) {
				case 'text':
					w = clamp(op.w, 1, 8, 1); h = clamp(op.h, 1, 8, 1);
					width = Math.max(1, Math.floor(cols / w));
					e.setAlign(ALIGN[op.a] || 0); e.setBold(op.b); e.setUnder(op.u); e.setSize(w, h);
					lines = wrap(op.s, width, cp);
					for (k = 0; k < lines.length; k++) { emitLine(lines[k]); }
					break;
				case 'lr':
					w = clamp(op.w, 1, 8, 1); h = clamp(op.h, 1, 8, 1);
					width = Math.max(1, Math.floor(cols / w));
					e.setAlign(0); e.setBold(op.b); e.setUnder(op.u); e.setSize(w, h);
					left = String(op.l); right = String(op.r);
					rl = textLen(right, cp);
					if (rl >= width - 2) { rl = 0; left = left + ' ' + right; right = ''; }
					lines = wrap(left, rl ? width - rl - 1 : width, cp);
					for (k = 0; k < lines.length; k++) {
						if (k === 0 && rl) {
							emitLine(lines[0] + pad(width - textLen(lines[0], cp) - rl, ' ') + right);
						} else {
							emitLine(lines[k]);
						}
					}
					break;
				case 'hr':
					e.setAlign(0); e.setBold(0); e.setUnder(0); e.setSize(1, 1);
					txt = (op.ch && String(op.ch).charAt(0)) || '-';
					emitLine(pad(cols, txt));
					break;
				case 'feed':
					n = clamp(op.n, 0, 20, 1);
					if (n) { e.raw([0x1B, 0x64, n]); }
					break;
				case 'qr':
					e.setAlign(ALIGN[op.a] !== undefined ? ALIGN[op.a] : 1); e.setBold(0); e.setSize(1, 1);
					txt = encodeText(op.s, 'ascii');
					if (!txt.length) { break; }
					if (txt.length > 400) { txt = txt.slice(0, 400); }
					n = clamp(op.size, 1, 16, 6);
					e.raw([0x1D, 0x28, 0x6B, 0x04, 0x00, 0x31, 0x41, 0x32, 0x00]);
					e.raw([0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x43, n]);
					e.raw([0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x45, 0x31]);
					e.raw([0x1D, 0x28, 0x6B, (txt.length + 3) & 255, ((txt.length + 3) >> 8) & 255, 0x31, 0x50, 0x30]);
					e.raw(txt);
					e.raw([0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x51, 0x30]);
					e.raw([0x0A]);
					break;
				case 'drawer':
					e.raw([0x1B, 0x70, 0x00, 0x19, 0xFA]);
					break;
				case 'cut':
					e.reset();
					if (cut === 'none') { e.raw([0x1B, 0x64, 0x03]); }
					else { e.raw([0x1B, 0x64, 0x04]); e.raw([0x1D, 0x56, cut === 'full' ? 0x00 : 0x01]); }
					break;
				default:
					break;
			}
		}
		e.reset();
		return new Uint8Array(e.b);
	}

	function toHex(bytes) {
		var s = [], i;
		for (i = 0; i < bytes.length; i++) { s.push((bytes[i] < 16 ? '0' : '') + bytes[i].toString(16)); }
		return s.join(' ');
	}

	return { encode: encode, encodeText: encodeText, wrap: wrap, toHex: toHex, CP_NUM: CP_NUM };
}));
