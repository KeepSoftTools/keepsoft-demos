/**
 * PrintPilot Print Station. Vanilla JS, no dependencies.
 * Polls the REST API for print jobs, prints HTML tickets with window.print(), and sends
 * ESC/POS bytes straight to USB / Serial / Bluetooth thermal printers.
 */
(function () {
	'use strict';

	var cfgEl = document.getElementById('pp-config');
	if (!cfgEl) { return; }
	var cfg = JSON.parse(cfgEl.textContent);
	var T = cfg.i18n || {};

	/* ---------- helpers ---------- */
	function $(id) { return document.getElementById(id); }

	var store = {
		get: function (k) { try { return window.localStorage.getItem('pp_' + k); } catch (e) { return null; } },
		set: function (k, v) { try { window.localStorage.setItem('pp_' + k, v); } catch (e) { /* storage blocked */ } },
		del: function (k) { try { window.localStorage.removeItem('pp_' + k); } catch (e) { /* storage blocked */ } },
		json: function (k) { try { return JSON.parse(window.localStorage.getItem('pp_' + k)); } catch (e) { return null; } }
	};

	function h(tag, attrs, kids) {
		var el = document.createElement(tag), k, i;
		if (attrs) {
			for (k in attrs) {
				if (!Object.prototype.hasOwnProperty.call(attrs, k)) { continue; }
				if (k === 'class') { el.className = attrs[k]; }
				else if (k === 'text') { el.textContent = attrs[k]; }
				else if (k.indexOf('on') === 0) { el.addEventListener(k.slice(2), attrs[k]); }
				else { el.setAttribute(k, attrs[k]); }
			}
		}
		if (kids) {
			for (i = 0; i < kids.length; i++) {
				if (kids[i]) { el.appendChild(typeof kids[i] === 'string' ? document.createTextNode(kids[i]) : kids[i]); }
			}
		}
		return el;
	}

	function delay(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

	var state = {
		online: false,
		lastOk: 0,
		fails: 0,
		skew: 0,
		paused: store.get('paused') === '1',
		sound: cfg.sound && store.get('sound') !== '0',
		orders: [],
		recent: [],
		knownOrders: null,
		pollTimer: null,
		alarmTimer: null,
		audio: null,
		wake: null,
		accepting: {}
	};

	/* ---------- API ---------- */
	function headers() {
		var hd = { 'Content-Type': 'application/json' };
		if (cfg.auth === 'nonce') { hd['X-WP-Nonce'] = cfg.nonce; }
		else { hd['X-PrintPilot-Token'] = cfg.token; }
		return hd;
	}

	function api(path, body) {
		return fetch(cfg.rest + path, {
			method: 'POST',
			headers: headers(),
			body: JSON.stringify(body || {}),
			credentials: cfg.auth === 'nonce' ? 'same-origin' : 'omit',
			cache: 'no-store'
		}).then(function (r) {
			return r.json().catch(function () { return {}; }).then(function (j) {
				if (!r.ok) { var e = new Error(j && j.message ? j.message : 'HTTP ' + r.status); e.status = r.status; throw e; }
				return j;
			});
		});
	}

	/* ---------- sound ---------- */
	function initAudio() {
		var AC = window.AudioContext || window.webkitAudioContext;
		if (!AC || state.audio) { return; }
		try { state.audio = new AC(); } catch (e) { state.audio = null; }
	}

	function beep(kind) {
		var ctx = state.audio, t, seq, i, o, g;
		if (!state.sound || !ctx) { return; }
		if (ctx.state === 'suspended') { ctx.resume(); }
		seq = kind === 'error' ? [[330, 0.25], [247, 0.35]] : [[880, 0.12], [1175, 0.12], [1320, 0.2]];
		t = ctx.currentTime + 0.02;
		for (i = 0; i < seq.length; i++) {
			o = ctx.createOscillator(); g = ctx.createGain();
			o.type = 'sine'; o.frequency.value = seq[i][0];
			g.gain.setValueAtTime(0.0001, t);
			g.gain.exponentialRampToValueAtTime(0.35, t + 0.02);
			g.gain.exponentialRampToValueAtTime(0.0001, t + seq[i][1]);
			o.connect(g); g.connect(ctx.destination);
			o.start(t); o.stop(t + seq[i][1] + 0.02);
			t += seq[i][1] + 0.04;
		}
	}

	function updateAlarm() {
		if (cfg.repeatAlarm && state.sound && state.orders.length) {
			if (!state.alarmTimer) { state.alarmTimer = setInterval(function () { beep('new'); }, 10000); }
		} else if (state.alarmTimer) {
			clearInterval(state.alarmTimer); state.alarmTimer = null;
		}
	}

	/* ---------- toast ---------- */
	var toastTimer = null;
	function toast(msg, bad) {
		var el = $('ps-toast');
		el.textContent = msg;
		el.className = 'ps-toast is-on' + (bad ? ' is-bad' : '');
		clearTimeout(toastTimer);
		toastTimer = setTimeout(function () { el.className = 'ps-toast'; }, 5000);
	}

	/* ---------- printer connections ---------- */
	var BT_SERVICES = [
		'000018f0-0000-1000-8000-00805f9b34fb',
		'e7810a71-73ae-499d-8c15-faa9aef0c3f2',
		'49535343-fe7d-4ae5-8fa9-9fafd205e455',
		'0000ff00-0000-1000-8000-00805f9b34fb',
		'0000ffe0-0000-1000-8000-00805f9b34fb'
	];

	function Conn(p) {
		this.p = p;
		this.ready = false;
		this.handle = null;
		this.err = '';
	}

	Conn.prototype.supported = function () {
		if (this.p.connection === 'usb') { return !!navigator.usb; }
		if (this.p.connection === 'bluetooth') { return !!navigator.bluetooth; }
		return !!navigator.serial;
	};

	Conn.prototype.key = function () { return 'dev_' + this.p.id; };

	/** Connect. request=true shows the browser device chooser (needs a user gesture). */
	Conn.prototype.connect = function (request) {
		var self = this;
		if (!this.supported()) { return Promise.reject(new Error(T.unsupported)); }
		var job;
		if (this.p.connection === 'usb') { job = this.connectUsb(request); }
		else if (this.p.connection === 'bluetooth') { job = this.connectBt(request); }
		else { job = this.connectSerial(request); }
		return job.then(function () { self.ready = true; self.err = ''; renderPrinters(); }, function (e) {
			self.ready = false; self.err = e && e.message ? e.message : String(e); renderPrinters(); throw e;
		});
	};

	/* Web Serial */
	Conn.prototype.connectSerial = function (request) {
		var self = this, saved = store.json(this.key());
		return Promise.resolve().then(function () {
			if (request) { return navigator.serial.requestPort(); }
			return navigator.serial.getPorts().then(function (ports) {
				var i, info;
				for (i = 0; i < ports.length; i++) {
					info = ports[i].getInfo ? ports[i].getInfo() : {};
					if (saved && info.usbVendorId === saved.v && info.usbProductId === saved.p) { return ports[i]; }
				}
				if (saved && ports.length === 1 && saved.v === undefined) { return ports[0]; }
				throw new Error(T.noDevice);
			});
		}).then(function (port) {
			var info = port.getInfo ? port.getInfo() : {};
			if (self.handle && self.handle !== port) { try { self.handle.close(); } catch (e) { /* closed */ } }
			var open = port.readable || port.writable ? Promise.resolve() : port.open({ baudRate: self.p.baud || 9600 });
			return open.then(function () {
				self.handle = port;
				store.set(self.key(), JSON.stringify({ v: info.usbVendorId, p: info.usbProductId }));
			});
		});
	};

	/* WebUSB */
	Conn.prototype.connectUsb = function (request) {
		var self = this, saved = store.json(this.key());
		return Promise.resolve().then(function () {
			if (request) { return navigator.usb.requestDevice({ filters: [] }); }
			return navigator.usb.getDevices().then(function (list) {
				var i;
				for (i = 0; i < list.length; i++) {
					if (saved && list[i].vendorId === saved.v && list[i].productId === saved.p && (!saved.s || list[i].serialNumber === saved.s)) { return list[i]; }
				}
				throw new Error(T.noDevice);
			});
		}).then(function (dev) {
			var open = dev.opened ? Promise.resolve() : dev.open();
			return open.then(function () {
				return dev.configuration === null ? dev.selectConfiguration(1) : null;
			}).then(function () {
				var best = null, i, j, k, ifc, alt, ep;
				for (i = 0; i < dev.configuration.interfaces.length; i++) {
					ifc = dev.configuration.interfaces[i];
					for (j = 0; j < ifc.alternates.length; j++) {
						alt = ifc.alternates[j];
						for (k = 0; k < alt.endpoints.length; k++) {
							ep = alt.endpoints[k];
							if (ep.direction === 'out' && ep.type === 'bulk') {
								if (!best || (alt.interfaceClass === 7 && best.cls !== 7)) {
									best = { n: ifc.interfaceNumber, alt: alt.alternateSetting, ep: ep.endpointNumber, cls: alt.interfaceClass, claimed: ifc.claimed };
								}
							}
						}
					}
				}
				if (!best) { throw new Error('No bulk OUT endpoint found'); }
				return (best.claimed ? Promise.resolve() : dev.claimInterface(best.n)).then(function () {
					self.handle = { dev: dev, ep: best.ep };
					store.set(self.key(), JSON.stringify({ v: dev.vendorId, p: dev.productId, s: dev.serialNumber || '' }));
				});
			});
		});
	};

	/* Web Bluetooth */
	Conn.prototype.connectBt = function (request) {
		var self = this, saved = store.json(this.key());
		return Promise.resolve().then(function () {
			if (!request && saved && navigator.bluetooth.getDevices) {
				return navigator.bluetooth.getDevices().then(function (list) {
					var i;
					for (i = 0; i < list.length; i++) { if (list[i].id === saved.id) { return list[i]; } }
					throw new Error(T.noDevice);
				});
			}
			if (!request) { throw new Error(T.noDevice); }
			return navigator.bluetooth.requestDevice({ acceptAllDevices: true, optionalServices: BT_SERVICES });
		}).then(function (dev) {
			return dev.gatt.connect().then(function (server) {
				return server.getPrimaryServices().then(function (services) {
					var chain = Promise.resolve(null), found = null;
					services.forEach(function (svc) {
						chain = chain.then(function () {
							if (found) { return null; }
							return svc.getCharacteristics().then(function (chars) {
								var i;
								for (i = 0; i < chars.length; i++) {
									if (chars[i].properties.write || chars[i].properties.writeWithoutResponse) { found = chars[i]; break; }
								}
							}).catch(function () { return null; });
						});
					});
					return chain.then(function () {
						if (!found) { throw new Error('No writable Bluetooth characteristic found'); }
						self.handle = { dev: dev, ch: found };
						store.set(self.key(), JSON.stringify({ id: dev.id }));
						dev.addEventListener('gattserverdisconnected', function () { self.ready = false; renderPrinters(); });
					});
				});
			});
		});
	};

	Conn.prototype.forget = function () {
		store.del(this.key());
		this.ready = false;
		try {
			if (this.p.connection === 'serial' && this.handle && this.handle.close) { this.handle.close(); }
			if (this.p.connection === 'usb' && this.handle) { this.handle.dev.close(); }
			if (this.p.connection === 'bluetooth' && this.handle && this.handle.dev.gatt.connected) { this.handle.dev.gatt.disconnect(); }
		} catch (e) { /* ignore */ }
		this.handle = null;
		renderPrinters();
	};

	Conn.prototype.write = function (bytes) {
		var self = this;
		if (!this.ready || !this.handle) { return Promise.reject(new Error(T.notConnected)); }
		return this.rawWrite(bytes).catch(function (e) {
			/* One automatic reconnect attempt with the remembered device, then retry. */
			self.ready = false;
			return self.connect(false).then(function () { return self.rawWrite(bytes); }).catch(function () { throw e; });
		});
	};

	Conn.prototype.rawWrite = function (bytes) {
		var hd = this.handle, i, chain, size;
		if (this.p.connection === 'serial') {
			var w = hd.writable.getWriter();
			return w.write(bytes).then(function () { w.releaseLock(); }, function (e) { try { w.releaseLock(); } catch (x) { /* ignore */ } throw e; });
		}
		if (this.p.connection === 'usb') {
			chain = Promise.resolve(); size = 4096;
			for (i = 0; i < bytes.length; i += size) {
				(function (part) { chain = chain.then(function () { return hd.dev.transferOut(hd.ep, part); }); }(bytes.slice(i, i + size)));
			}
			return chain;
		}
		chain = Promise.resolve(); size = 100;
		for (i = 0; i < bytes.length; i += size) {
			(function (part) {
				chain = chain.then(function () {
					return (hd.ch.writeValueWithoutResponse ? hd.ch.writeValueWithoutResponse(part) : hd.ch.writeValue(part)).then(function () { return delay(25); });
				});
			}(bytes.slice(i, i + size)));
		}
		return chain;
	};

	var conns = {};
	cfg.printers.forEach(function (p) {
		if (p.method === 'station_escpos') { conns[p.id] = new Conn(p); }
	});

	function readyIds() {
		var out = [], k;
		for (k in conns) { if (conns[k].ready) { out.push(k); } }
		return out;
	}

	/* Re-open previously authorised devices without any prompt. */
	function autoReconnect() {
		var k;
		for (k in conns) {
			if (store.get('dev_' + k) && conns[k].supported()) { conns[k].connect(false).catch(function () { /* user can press Connect */ }); }
		}
	}

	if (navigator.serial && navigator.serial.addEventListener) {
		navigator.serial.addEventListener('disconnect', function (e) {
			var k;
			for (k in conns) { if (conns[k].handle === e.target) { conns[k].ready = false; conns[k].handle = null; } }
			renderPrinters();
		});
	}
	if (navigator.usb && navigator.usb.addEventListener) {
		navigator.usb.addEventListener('disconnect', function (e) {
			var k;
			for (k in conns) { if (conns[k].handle && conns[k].handle.dev === e.device) { conns[k].ready = false; conns[k].handle = null; } }
			renderPrinters();
		});
	}

	/* ---------- printing ---------- */
	var frame = null;
	function getFrame() {
		if (!frame) {
			frame = document.createElement('iframe');
			frame.setAttribute('aria-hidden', 'true');
			frame.setAttribute('tabindex', '-1');
			frame.className = 'ps-frame';
			document.body.appendChild(frame);
		}
		return frame;
	}

	function printHtml(job) {
		return new Promise(function (resolve, reject) {
			var f = getFrame(), done = false;
			f.onload = function () {
				if (done) { return; }
				done = true;
				var win = f.contentWindow, doc = f.contentDocument, n = Math.max(1, job.copies | 0), chain = Promise.resolve(), i;
				try { if (window.PPQR) { window.PPQR.hydrate(doc); } } catch (e) { /* QR is optional */ }
				if (typeof window.__ppOnPrint === 'function') { try { window.__ppOnPrint(job, doc.documentElement.outerHTML); } catch (e2) { /* test hook */ } }
				function once() {
					return new Promise(function (res) {
						var finished = false;
						function fin() { if (!finished) { finished = true; res(); } }
						win.onafterprint = fin;
						try { win.focus(); win.print(); } catch (e3) { fin(); }
						setTimeout(fin, 2500);
					}).then(function () { return delay(400); });
				}
				for (i = 0; i < n; i++) { chain = chain.then(once); }
				chain.then(resolve, reject);
			};
			f.srcdoc = job.html;
			setTimeout(function () { if (!done) { done = true; reject(new Error('Ticket did not load')); } }, 10000);
		});
	}

	function printEscpos(job) {
		var conn = conns[job.printer_id], bytes, n, chain = Promise.resolve(), i;
		if (!conn || !conn.ready) { return Promise.reject(new Error(T.notConnected)); }
		bytes = window.PPEscPos.encode(job.doc);
		n = Math.max(1, job.copies | 0);
		function one() { return conn.write(bytes).then(function () { return delay(250); }); }
		for (i = 0; i < n; i++) { chain = chain.then(one); }
		return chain;
	}

	var printChain = Promise.resolve();
	function enqueue(job) {
		printChain = printChain.then(function () {
			var run = job.method === 'station_escpos' ? printEscpos(job) : printHtml(job);
			return run.then(function () {
				return api('station/jobs/' + job.id + '/result', { ok: true });
			}, function (e) {
				beep('error');
				toast((T.printError || 'Print error') + ': ' + (e && e.message ? e.message : e), true);
				return api('station/jobs/' + job.id + '/result', { ok: false, error: e && e.message ? e.message : String(e) });
			}).catch(function () { /* result report failed; server will release the claim */ }).then(function () { schedule(300); });
		});
	}

	/* ---------- rendering ---------- */
	function ago(ts) {
		var s = Math.max(0, Math.round(Date.now() / 1000 + state.skew - ts));
		if (s < 10) { return T.now; }
		if (s < 90) { return s + T.secsAgo; }
		if (s < 5400) { return Math.round(s / 60) + T.minsAgo; }
		return Math.round(s / 3600) + T.hrsAgo;
	}

	function renderQueue() {
		var box = $('ps-queue'), items = state.recent;
		box.textContent = '';
		if (!items.length) { box.appendChild(h('p', { class: 'ps-empty', text: T.noJobs })); return; }
		items.forEach(function (j) {
			var label = j.order_id ? (T.order + ' #' + j.number) : T.test;
			var card = h('div', { class: 'ps-card ps-job is-' + j.status, 'data-job': String(j.id) }, [
				h('div', { class: 'ps-card-main' }, [
					h('div', { class: 'ps-card-title' }, [h('strong', { text: label }), h('span', { class: 'ps-pill ps-pill-' + j.status, text: T[j.status] || j.status })]),
					h('div', { class: 'ps-card-sub', text: j.printer + ' · ' + ago(j.created) + (j.copies > 1 ? ' · x' + j.copies : '') }),
					j.error ? h('div', { class: 'ps-card-err', text: j.error }) : null
				]),
				h('button', { type: 'button', class: 'ps-btn ps-btn-sm', text: T.reprint, onclick: function (e) { reprint(j, e.currentTarget); } })
			]);
			box.appendChild(card);
		});
	}

	function renderOrders() {
		var box = $('ps-orders');
		box.textContent = '';
		$('ps-orders-count').textContent = String(state.orders.length);
		if (!state.orders.length) { box.appendChild(h('p', { class: 'ps-empty', text: T.noOrders })); return; }
		state.orders.forEach(function (o) {
			var lines = h('ul', { class: 'ps-lines' }, o.lines.map(function (l) { return h('li', { text: l }); }));
			box.appendChild(h('div', { class: 'ps-card ps-order', 'data-order': String(o.id) }, [
				h('div', { class: 'ps-card-main' }, [
					h('div', { class: 'ps-card-title' }, [h('strong', { text: T.order + ' #' + o.number }), o.type ? h('span', { class: 'ps-pill ps-pill-type', text: o.type }) : null]),
					h('div', { class: 'ps-card-sub', text: (o.customer || '') + ' · ' + o.total + ' · ' + ago(o.created) }),
					lines
				]),
				h('button', { type: 'button', class: 'ps-btn ps-btn-primary', 'data-accept': String(o.id), text: state.accepting[o.id] ? '…' : T.accept, onclick: function (e) { accept(o, e.currentTarget); } })
			]));
		});
	}

	function renderPrinters() {
		var box = $('ps-printers'), shown = 0;
		box.textContent = '';
		cfg.printers.forEach(function (p) {
			if (cfg.only.length && cfg.only.indexOf(p.id) < 0) { return; }
			shown++;
			var conn = conns[p.id], kids = [], status, sub;
			if (conn) {
				status = h('span', { class: 'ps-pill ' + (conn.ready ? 'ps-pill-printed' : 'ps-pill-failed'), text: conn.ready ? T.printerReady : T.printerNot });
				sub = T[p.connection] + ' · ' + p.paper + 'mm';
				kids.push(h('button', { type: 'button', class: 'ps-btn ps-btn-sm ps-btn-primary', 'data-connect': p.id, text: conn.ready ? T.reconnect : T.connect, onclick: function (e) { connectPrinter(conn, e.currentTarget); } }));
				if (store.get('dev_' + p.id)) { kids.push(h('button', { type: 'button', class: 'ps-btn ps-btn-sm', text: T.forget, onclick: function () { conn.forget(); } })); }
				if (!conn.supported()) { kids.push(h('div', { class: 'ps-card-err', text: T.unsupported })); }
			} else {
				status = h('span', { class: 'ps-pill ps-pill-printed', text: T.printerReady });
				sub = T.browserPrint + (p.paper === 'a4' ? ' · A4' : ' · ' + p.paper + 'mm');
			}
			kids.push(h('button', { type: 'button', class: 'ps-btn ps-btn-sm', 'data-test': p.id, text: T.testPrint, onclick: function () { testPrint(p); } }));
			box.appendChild(h('div', { class: 'ps-card ps-printer', 'data-printer': p.id }, [
				h('div', { class: 'ps-card-main' }, [
					h('div', { class: 'ps-card-title' }, [h('strong', { text: p.name }), status]),
					h('div', { class: 'ps-card-sub', text: sub }),
					conn && conn.err ? h('div', { class: 'ps-card-err', text: conn.err }) : null
				]),
				h('div', { class: 'ps-card-actions' }, kids)
			]));
		});
		if (!shown) { box.appendChild(h('p', { class: 'ps-empty', text: T.noPrinters })); }
		$('ps-hint').textContent = cfg.printers.some(function (p) { return p.method === 'station_html'; }) ? T.hintSilent : '';
	}

	function renderHeader() {
		var dot = $('ps-dot');
		dot.className = 'ps-dot ' + (state.online ? 'is-on' : 'is-off');
		$('ps-conn').textContent = state.online ? T.connected : (state.fails > 0 ? T.offline : T.connecting);
		var last = $('ps-last');
		if (state.lastOk) {
			var d = new Date(state.lastOk);
			last.textContent = T.lastSeen + ' ' + ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2) + ':' + ('0' + d.getSeconds()).slice(-2);
		}
		$('ps-btn-sound').textContent = state.sound ? T.soundOn : T.soundOff;
		$('ps-btn-sound').className = 'ps-btn' + (state.sound ? ' is-active' : '');
		$('ps-btn-auto').textContent = state.paused ? T.paused : T.autoOn;
		$('ps-btn-auto').className = 'ps-btn' + (state.paused ? ' is-warn' : ' is-active');
		document.body.classList.toggle('is-offline', !state.online && state.fails > 1);
	}

	/* ---------- actions ---------- */
	function accept(o, btn) {
		if (state.accepting[o.id]) { return; }
		state.accepting[o.id] = true;
		btn.disabled = true;
		api('station/orders/' + o.id + '/accept', {}).then(function () {
			state.orders = state.orders.filter(function (x) { return x.id !== o.id; });
			delete state.accepting[o.id];
			renderOrders(); updateAlarm(); toast(T.accepted + ' #' + o.number);
			schedule(200);
		}).catch(function (e) {
			delete state.accepting[o.id];
			btn.disabled = false; toast(e.message, true);
		});
	}

	function reprint(j, btn) {
		btn.disabled = true;
		api('station/jobs/' + j.id + '/reprint', {}).then(function () { schedule(100); }).catch(function (e) { toast(e.message, true); }).then(function () { btn.disabled = false; });
	}

	function testPrint(p) {
		api('station/test', { printer: p.id }).then(function () { toast(T.queuedTest); schedule(100); }).catch(function (e) { toast(e.message, true); });
	}

	function connectPrinter(conn, btn) {
		btn.disabled = true;
		conn.connect(true).then(function () { toast(T.connectedTo + ': ' + conn.p.name); schedule(100); }, function (e) {
			if (e && e.name !== 'NotFoundError' && e.name !== 'AbortError') { toast(e.message, true); }
		}).then(function () { btn.disabled = false; });
	}

	/* ---------- polling ---------- */
	function schedule(ms) {
		clearTimeout(state.pollTimer);
		var base = Math.max(3, cfg.interval) * 1000;
		var wait = typeof ms === 'number' ? ms : (state.fails ? Math.min(30000, base * (1 + state.fails)) : base);
		state.pollTimer = setTimeout(poll, wait);
	}

	function handle(res) {
		var firstOrders = state.knownOrders === null, newOrder = false, newJob = false;
		state.online = true; state.fails = 0; state.lastOk = Date.now();
		if (res.now) { state.skew = res.now - Date.now() / 1000; }
		if (res.interval) { cfg.interval = res.interval; }
		$('ps-pend').textContent = String(res.stats.pending);
		$('ps-today').textContent = String(res.stats.today);
		$('ps-failed').textContent = String(res.stats.failed);
		state.recent = res.recent || [];
		state.orders = res.orders || [];
		if (firstOrders) { state.knownOrders = {}; }
		state.orders.forEach(function (o) {
			if (!state.knownOrders[o.id]) { state.knownOrders[o.id] = true; if (!firstOrders) { newOrder = true; } }
		});
		(res.jobs || []).forEach(function (j) { newJob = true; enqueue(j); });
		if (newOrder || newJob) { beep('new'); }
		renderQueue(); renderOrders(); renderHeader(); updateAlarm();
	}

	function poll() {
		api('station/poll', { station: cfg.station, ready: readyIds(), printers: cfg.only, claim: !state.paused }).then(handle).catch(function (e) {
			state.online = false; state.fails++;
			if (e.status === 401 || e.status === 403) {
				$('ps-conn').textContent = T.expired;
				if (cfg.auth === 'nonce') {
					var last = parseInt(store.get('reload') || '0', 10);
					if (Date.now() - last > 300000) { store.set('reload', String(Date.now())); window.location.reload(); return; }
				}
			}
			renderHeader();
		}).then(function () { schedule(); });
	}

	/* ---------- boot ---------- */
	function wakeLock() {
		if (!navigator.wakeLock || document.visibilityState !== 'visible') { return; }
		navigator.wakeLock.request('screen').then(function (l) { state.wake = l; }).catch(function () { /* not allowed */ });
	}

	function boot() {
		$('ps-name').textContent = cfg.station;
		$('ps-btn-sound').addEventListener('click', function () {
			state.sound = !state.sound; store.set('sound', state.sound ? '1' : '0');
			initAudio(); if (state.sound) { beep('new'); }
			renderHeader(); updateAlarm();
		});
		$('ps-btn-auto').addEventListener('click', function () {
			state.paused = !state.paused; store.set('paused', state.paused ? '1' : '0'); renderHeader();
			if (!state.paused) { schedule(100); }
		});
		$('ps-btn-full').addEventListener('click', function () {
			var el = document.documentElement;
			if (document.fullscreenElement) { document.exitFullscreen(); }
			else if (el.requestFullscreen) { el.requestFullscreen().catch(function () { /* denied */ }); }
		});
		$('ps-start-btn').addEventListener('click', function () {
			initAudio(); wakeLock();
			$('ps-start').className = 'ps-start is-hidden';
			if (state.sound) { beep('new'); }
		});
		document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible') { wakeLock(); schedule(200); } });
		window.addEventListener('online', function () { schedule(100); });
		renderHeader(); renderPrinters(); renderQueue(); renderOrders();
		autoReconnect();
		poll();
		setInterval(function () { renderHeader(); }, 5000);
	}

	boot();
	window.PPStation = { state: state, conns: conns, poll: poll };
}());
