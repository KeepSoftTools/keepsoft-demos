/**
 * PrintPilot admin scripts (vanilla JS).
 */
(function () {
	'use strict';

	var A = window.PPAdmin || { rest: '', nonce: '', i18n: {} };
	var T = A.i18n || {};
	var counter = 0;

	function qs(sel, ctx) { return (ctx || document).querySelector(sel); }
	function qsa(sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }

	function api(method, path, body) {
		var opt = { method: method, headers: { 'X-WP-Nonce': A.nonce, 'Content-Type': 'application/json' }, credentials: 'same-origin' };
		if (body) { opt.body = JSON.stringify(body); }
		return fetch(A.rest + path, opt).then(function (r) {
			return r.json().catch(function () { return {}; }).then(function (j) {
				if (!r.ok) { throw new Error(j && j.message ? j.message : 'HTTP ' + r.status); }
				return j;
			});
		});
	}

	/* ---------- repeater rows ---------- */
	function newKey() { counter++; return 'n' + Date.now().toString(36) + counter; }

	function addRow(form) {
		var tpl = qs('template[data-row-template]', form), rows = qs('[data-rows]', form), frag, key = newKey(), row;
		if (!tpl || !rows) { return null; }
		frag = tpl.content.cloneNode(true);
		qsa('[name]', frag).forEach(function (el) { el.setAttribute('name', el.getAttribute('name').replace('__KEY__', key)); });
		row = frag.querySelector('[data-row]');
		rows.appendChild(frag);
		initRow(row);
		return row;
	}

	function initRow(row) {
		if (!row) { return; }
		var sw = qs('[data-method-switch]', row), sel = qs('.pp-method', row);
		if (sw && sel) {
			sel.addEventListener('change', function () { switchMethod(sw, sel.value); });
			switchMethod(sw, sel.value);
		}
		if (row.classList.contains('pp-tpl')) { initPreview(row); }
	}

	function switchMethod(box, method) {
		qsa('[data-show-for]', box).forEach(function (el) {
			var list = el.getAttribute('data-show-for').split(' ');
			el.hidden = list.indexOf(method) < 0;
		});
	}

	/* ---------- template preview ---------- */
	var styleEl = null;
	function initPreview(row) {
		var body = qs('.pp-body', row), box = qs('.pp-preview', row), paper = qs('.pp-paper', row), timer = null;
		if (!body || !box) { return; }
		function run() {
			var typeSel = qs('select[name$="[type]"]', row);
			api('POST', 'templates/preview', {
				body: body.value,
				type: typeSel ? typeSel.value : 'custom',
				paper: paper ? paper.value : '80',
				show_prices: !!qs('input[name$="[show_prices]"]', row).checked,
				show_sku: !!qs('input[name$="[show_sku]"]', row).checked,
				show_meta: !!qs('input[name$="[show_meta]"]', row).checked,
				item_size: parseInt(qs('select[name$="[item_size]"]', row).value, 10) || 1
			}).then(function (res) {
				if (!styleEl) {
					styleEl = document.createElement('style');
					styleEl.textContent = res.css.replace(/@page\{[^}]*\}/, '') + '.pp-preview .pp-ticket{box-shadow:0 1px 6px rgba(0,0,0,.25)}';
					document.head.appendChild(styleEl);
				}
				box.innerHTML = res.html;
				if (window.PPQR) { window.PPQR.hydrate(box); }
			}).catch(function (e) { box.textContent = e.message; });
		}
		function later() { clearTimeout(timer); timer = setTimeout(run, 350); }
		body.addEventListener('input', later);
		qsa('.pp-opt', row).forEach(function (el) { el.addEventListener('change', later); });
		if (paper) { paper.addEventListener('change', run); }
		var ts = qs('select[name$="[type]"]', row);
		if (ts) { ts.addEventListener('change', later); }
		row.__ppPreview = run;
		run();
	}

	/* ---------- generic click handling ---------- */
	var lastTextarea = null;
	document.addEventListener('focusin', function (e) {
		if (e.target && e.target.classList && e.target.classList.contains('pp-body')) { lastTextarea = e.target; }
	});

	document.addEventListener('click', function (e) {
		var t = e.target, form, row, copyFrom;
		if (!t || !t.closest) { return; }

		if (t.closest('.pp-add')) {
			form = t.closest('form'); addRow(form); return;
		}
		var preset = t.closest('.pp-add-preset');
		if (preset) {
			form = preset.closest('form');
			var rowsBox = qs('[data-rows]', form), list = [];
			try { list = JSON.parse(rowsBox.getAttribute('data-presets')); } catch (err) { list = []; }
			var found = list.filter(function (p) { return p.id === preset.getAttribute('data-preset'); })[0];
			row = addRow(form);
			if (row && found) {
				qs('input[name$="[name]"]', row).value = found.name;
				qs('select[name$="[type]"]', row).value = found.type;
				qs('.pp-body', row).value = found.body;
				qs('input[name$="[show_prices]"]', row).checked = !!parseInt(found.show_prices, 10);
				qs('input[name$="[show_sku]"]', row).checked = !!parseInt(found.show_sku, 10);
				qs('input[name$="[show_meta]"]', row).checked = !!parseInt(found.show_meta, 10);
				qs('select[name$="[item_size]"]', row).value = String(found.item_size);
				if (row.__ppPreview) { row.__ppPreview(); }
			}
			return;
		}
		if (t.closest('.pp-remove')) {
			row = t.closest('[data-row]');
			if (row && window.confirm(T.confirm || 'Are you sure?')) { row.parentNode.removeChild(row); }
			return;
		}
		var chip = t.closest('.pp-chip');
		if (chip) {
			var ta = lastTextarea || qs('.pp-body');
			if (ta) {
				var s = ta.selectionStart || 0, en = ta.selectionEnd || 0, ph = chip.getAttribute('data-ph');
				ta.value = ta.value.slice(0, s) + ph + ta.value.slice(en);
				ta.focus(); ta.selectionStart = ta.selectionEnd = s + ph.length;
				ta.dispatchEvent(new Event('input', { bubbles: true }));
			}
			return;
		}
		var cp = t.closest('.pp-copy');
		if (cp) {
			copyFrom = document.getElementById(cp.getAttribute('data-target'));
			if (copyFrom) {
				copyFrom.select();
				var done = function () { var old = cp.textContent; cp.textContent = T.copied || 'Copied'; setTimeout(function () { cp.textContent = old; }, 1500); };
				if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(copyFrom.value).then(done, function () { document.execCommand('copy'); done(); }); }
				else { document.execCommand('copy'); done(); }
			}
			return;
		}
		var conf = t.closest('[data-confirm], .pp-del');
		if (conf && !window.confirm(T.confirm || 'Are you sure?')) { e.preventDefault(); }
	});

	qsa('[data-row]').forEach(initRow);

	/* ---------- order metabox ---------- */
	function statusLabel(s) { return s === 'printing' ? (T.printing_s || s) : (T[s] || s); }

	function renderHistory(box, jobs) {
		var ul = qs('.pp-mb-history', box);
		ul.textContent = '';
		if (!jobs.length) { var li0 = document.createElement('li'); li0.textContent = T.noJobs || ''; ul.appendChild(li0); return; }
		jobs.forEach(function (j) {
			var li = document.createElement('li'), pill = document.createElement('span'), txt = document.createElement('span'), d = new Date(j.created * 1000);
			pill.className = 'pp-pill pp-pill-' + j.status; pill.textContent = statusLabel(j.status);
			txt.textContent = ' #' + j.id + ' · ' + j.printer + ' · ' + d.toLocaleString() + (j.error ? ' · ' + j.error : '');
			li.appendChild(pill); li.appendChild(txt); ul.appendChild(li);
		});
	}

	qsa('.pp-metabox').forEach(function (box) {
		var id = box.getAttribute('data-order'), msg = qs('.pp-mb-msg', box), btn = qs('.pp-mb-print', box);
		var pSel = qs('.pp-mb-printer', box), tSel = qs('.pp-mb-template', box), cIn = qs('.pp-mb-copies', box), link = qs('.pp-mb-browser', box);

		function load() { api('GET', 'orders/' + id + '/jobs').then(function (r) { renderHistory(box, r.jobs || []); }).catch(function (e) { msg.textContent = e.message; }); }
		function syncLink() {
			var base = link.getAttribute('data-base');
			link.href = base + '&printer=' + encodeURIComponent(pSel.value) + '&template=' + encodeURIComponent(tSel.value);
		}
		pSel.addEventListener('change', syncLink); tSel.addEventListener('change', syncLink); syncLink();

		btn.addEventListener('click', function () {
			btn.disabled = true; msg.textContent = T.printing || '…';
			api('POST', 'orders/' + id + '/print', { printer: pSel.value, template: tSel.value, copies: parseInt(cIn.value, 10) || 1 }).then(function (r) {
				var bad = (r.jobs || []).filter(function (j) { return j.status === 'failed' || j.status === 'pending' && j.error; });
				msg.textContent = bad.length ? (T.error || 'Error') + ': ' + bad[0].error : (T.queued || 'Queued');
				load();
			}).catch(function (e) { msg.textContent = (T.error || 'Error') + ': ' + e.message; }).then(function () { btn.disabled = false; });
		});
		load();
	});
}());
