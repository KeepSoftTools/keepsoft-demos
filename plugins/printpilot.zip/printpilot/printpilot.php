<?php
/**
 * Plugin Name:       PrintPilot – Automatic Order Printing for WooCommerce (No Subscription)
 * Plugin URI:        https://codecanyon.net/user/keepsoft
 * Description:       Automatically print WooCommerce kitchen tickets, receipts and packing slips. Print Station kiosk, direct USB / Serial / Bluetooth ESC/POS printing from the browser, network (LAN) printers and email fallback. No PrintNode, no cloud subscription.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Keepsoft
 * Author URI:        https://codecanyon.net/user/keepsoft
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       printpilot
 * Domain Path:       /languages
 * WC requires at least: 6.0
 * WC tested up to:   9.4
 *
 * @package PrintPilot
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'PP_VERSION', '1.0.0' );
define( 'PP_FILE', __FILE__ );
define( 'PP_PATH', plugin_dir_path( __FILE__ ) );
define( 'PP_URL', plugin_dir_url( __FILE__ ) );
define( 'PP_DB_VERSION', '1.0' );

// Declare compatibility with High-Performance Order Storage (custom order tables).
add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', PP_FILE, true );
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', PP_FILE, true );
		}
	}
);

require_once PP_PATH . 'includes/class-printpilot-settings.php';
require_once PP_PATH . 'includes/class-printpilot-install.php';
require_once PP_PATH . 'includes/class-printpilot-escpos.php';
require_once PP_PATH . 'includes/class-printpilot-ticket.php';
require_once PP_PATH . 'includes/class-printpilot-jobs.php';
require_once PP_PATH . 'includes/class-printpilot-network.php';
require_once PP_PATH . 'includes/class-printpilot-router.php';
require_once PP_PATH . 'includes/class-printpilot-rest.php';
require_once PP_PATH . 'includes/class-printpilot-station.php';
require_once PP_PATH . 'includes/class-printpilot-admin.php';

// The one-minute cron interval must exist before activation schedules the queue worker.
add_filter( 'cron_schedules', array( 'PrintPilot_Jobs', 'cron_schedules' ) );

register_activation_hook( __FILE__, array( 'PrintPilot_Install', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'PrintPilot_Install', 'deactivate' ) );

/**
 * Boot the plugin once WooCommerce is available.
 *
 * @return void
 */
function pp_init() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', 'pp_missing_woo_notice' );
		return;
	}

	PrintPilot_Install::maybe_upgrade();
	PrintPilot_Jobs::init();
	PrintPilot_Router::init();
	PrintPilot_REST::init();
	PrintPilot_Station::init();
	PrintPilot_Admin::init();
}
add_action( 'plugins_loaded', 'pp_init', 20 );

/**
 * Load translations.
 *
 * @return void
 */
function pp_load_textdomain() {
	load_plugin_textdomain( 'printpilot', false, dirname( plugin_basename( PP_FILE ) ) . '/languages' );
}
add_action( 'init', 'pp_load_textdomain' );

/**
 * Admin notice when WooCommerce is missing.
 *
 * @return void
 */
function pp_missing_woo_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	echo '<div class="notice notice-error"><p>' . esc_html__( 'PrintPilot requires WooCommerce to be installed and active.', 'printpilot' ) . '</p></div>';
}

/**
 * Add a Settings link on the plugins screen.
 *
 * @param array $links Existing links.
 * @return array
 */
function pp_action_links( $links ) {
	array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=printpilot' ) ) . '">' . esc_html__( 'Settings', 'printpilot' ) . '</a>' );
	return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'pp_action_links' );
